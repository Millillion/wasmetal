#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__16(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__16\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___026143_;
    wasmetal_core__DOT___026143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026239_;
    wasmetal_core__DOT___026239_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027654_;
    wasmetal_core__DOT___027654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027719_;
    wasmetal_core__DOT___027719_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027880_;
    wasmetal_core__DOT___027880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___028009_;
    wasmetal_core__DOT___028009_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029199_;
    wasmetal_core__DOT___029199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029300_;
    wasmetal_core__DOT___029300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029360_;
    wasmetal_core__DOT___029360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029662_;
    wasmetal_core__DOT___029662_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029722_;
    wasmetal_core__DOT___029722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029831_;
    wasmetal_core__DOT___029831_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029891_;
    wasmetal_core__DOT___029891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030000_;
    wasmetal_core__DOT___030000_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030362_;
    wasmetal_core__DOT___030362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030574_;
    wasmetal_core__DOT___030574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030725_;
    wasmetal_core__DOT___030725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031108_;
    wasmetal_core__DOT___031108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031112_;
    wasmetal_core__DOT___031112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031396_;
    wasmetal_core__DOT___031396_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031400_;
    wasmetal_core__DOT___031400_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031601_;
    wasmetal_core__DOT___031601_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031683_;
    wasmetal_core__DOT___031683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031883_;
    wasmetal_core__DOT___031883_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032082_;
    wasmetal_core__DOT___032082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032172_;
    wasmetal_core__DOT___032172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032419_;
    wasmetal_core__DOT___032419_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032423_;
    wasmetal_core__DOT___032423_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032619_;
    wasmetal_core__DOT___032619_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032776_;
    wasmetal_core__DOT___032776_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032809_;
    wasmetal_core__DOT___032809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032810_;
    wasmetal_core__DOT___032810_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032811_;
    wasmetal_core__DOT___032811_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032812_;
    wasmetal_core__DOT___032812_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032940_;
    wasmetal_core__DOT___032940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032973_;
    wasmetal_core__DOT___032973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032978_;
    wasmetal_core__DOT___032978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033112_;
    wasmetal_core__DOT___033112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033206_;
    wasmetal_core__DOT___033206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033918_;
    wasmetal_core__DOT___033918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033978_;
    wasmetal_core__DOT___033978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034706_;
    wasmetal_core__DOT___034706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034902_;
    wasmetal_core__DOT___034902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035030_;
    wasmetal_core__DOT___035030_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063146_;
    wasmetal_core__DOT___063146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063152_;
    wasmetal_core__DOT___063152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063158_;
    wasmetal_core__DOT___063158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063164_;
    wasmetal_core__DOT___063164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063170_;
    wasmetal_core__DOT___063170_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063176_;
    wasmetal_core__DOT___063176_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063182_;
    wasmetal_core__DOT___063182_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063188_;
    wasmetal_core__DOT___063188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063194_;
    wasmetal_core__DOT___063194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063200_;
    wasmetal_core__DOT___063200_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063206_;
    wasmetal_core__DOT___063206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063212_;
    wasmetal_core__DOT___063212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064107_;
    wasmetal_core__DOT___064107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064263_;
    wasmetal_core__DOT___064263_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064364_;
    wasmetal_core__DOT___064364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064365_;
    wasmetal_core__DOT___064365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064369_;
    wasmetal_core__DOT___064369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064410_;
    wasmetal_core__DOT___064410_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064414_;
    wasmetal_core__DOT___064414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064415_;
    wasmetal_core__DOT___064415_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064420_;
    wasmetal_core__DOT___064420_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064421_;
    wasmetal_core__DOT___064421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064424_;
    wasmetal_core__DOT___064424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064425_;
    wasmetal_core__DOT___064425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065223_;
    wasmetal_core__DOT___065223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065380_;
    wasmetal_core__DOT___065380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065485_;
    wasmetal_core__DOT___065485_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065509_;
    wasmetal_core__DOT___065509_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065649_;
    wasmetal_core__DOT___065649_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065761_;
    wasmetal_core__DOT___065761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065844_;
    wasmetal_core__DOT___065844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065956_;
    wasmetal_core__DOT___065956_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066027_;
    wasmetal_core__DOT___066027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066180_;
    wasmetal_core__DOT___066180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066225_;
    wasmetal_core__DOT___066225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066336_;
    wasmetal_core__DOT___066336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066434_;
    wasmetal_core__DOT___066434_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066500_;
    wasmetal_core__DOT___066500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066581_;
    wasmetal_core__DOT___066581_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128199___O;
    wasmetal_core__DOT____Vcellout___128199___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128200___O;
    wasmetal_core__DOT____Vcellout___128200___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128201___O;
    wasmetal_core__DOT____Vcellout___128201___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128362___O;
    wasmetal_core__DOT____Vcellout___128362___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128363___O;
    wasmetal_core__DOT____Vcellout___128363___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128430___O;
    wasmetal_core__DOT____Vcellout___128430___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128450___O;
    wasmetal_core__DOT____Vcellout___128450___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128451___O;
    wasmetal_core__DOT____Vcellout___128451___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128519___S;
    wasmetal_core__DOT____Vcellinp___128519___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128520___S;
    wasmetal_core__DOT____Vcellinp___128520___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128538___O;
    wasmetal_core__DOT____Vcellout___128538___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128539___O;
    wasmetal_core__DOT____Vcellout___128539___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128582___O;
    wasmetal_core__DOT____Vcellout___128582___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128714___O;
    wasmetal_core__DOT____Vcellout___128714___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128715___O;
    wasmetal_core__DOT____Vcellout___128715___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0;
    wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h325e7d4e__0;
    __VdfgTmp_h325e7d4e__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf4b373dc__0;
    __VdfgTmp_hf4b373dc__0 = 0;
    CData/*2:0*/ __VdfgTmp_h98c6c754__0;
    __VdfgTmp_h98c6c754__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___029295_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128159___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029229_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d));
    wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026173_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128580___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b16__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128580___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034639_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034702_));
    wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035092_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127998___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027645_)))));
    vlSelf->wasmetal_core__DOT___027649_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127998___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030849_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030784_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128338___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031167_)))));
    wasmetal_core__DOT___031108_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128338___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128362___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031455_)))));
    wasmetal_core__DOT___031396_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128362___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128450___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032483_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032482_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032544_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032543_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032478_)))));
    wasmetal_core__DOT___032419_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032483_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___128450___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032483_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031807_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031742_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034898_));
    vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029922_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d));
    wasmetal_core__DOT____Vcellout___128199___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029751_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029750_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029749_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029748_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029714_)))));
    vlSelf->wasmetal_core__DOT___029718_ = ((IData)(vlSelf->wasmetal_core__DOT___029751_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128199___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d));
    wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026265_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128485___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032872_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032871_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032870_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032869_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032836_)))));
    vlSelf->wasmetal_core__DOT___032840_ = ((IData)(vlSelf->wasmetal_core__DOT___032872_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032680_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032644_)))));
    vlSelf->wasmetal_core__DOT___032648_ = ((IData)(vlSelf->wasmetal_core__DOT___032680_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__ = 0U;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b18__05d) {
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b19__05d) {
        wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        wasmetal_core__DOT___031883_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        wasmetal_core__DOT___033918_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        wasmetal_core__DOT___032940_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
    } else {
        wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___031883_ = vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___033918_ = vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___032940_ = vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128518___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033133_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___033108_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033202_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033974_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033108_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128518___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033202_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033974_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128526___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128526___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033227_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128603___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128518___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128603___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033999_)))));
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027808_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027775_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d));
    vlSelf->__VdfgTmp_hd4f12848__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)))))))));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026331_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d));
    wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045540_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___045552_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128428___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032201_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032168_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032806_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029657_));
    vlSelf->wasmetal_core__DOT___039847_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039846_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039845_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039844_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128278___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d)))))));
    wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030569_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b20__05d) {
        wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027714_;
        wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b20__05d;
    } else {
        wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__ = 0U;
        wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032077_;
    }
    wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031596_));
    wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029995_));
    wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029391_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d));
    wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029826_));
    wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029295_));
    wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029230_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d));
    wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026174_)
            ? (IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128589___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b17__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128589___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
           & (IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034640_) 
           & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035093_)
            ? (IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027649_));
    wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030850_)
            ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)
            : (IData)(wasmetal_core__DOT___031108_));
    wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)
            : (IData)(wasmetal_core__DOT___031396_));
    wasmetal_core__DOT___063146_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063152_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128450___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063158_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063164_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128450___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032484_)
                  ? (IData)(wasmetal_core__DOT___032419_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032484_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031808_)
            ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)) 
           & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029923_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d));
    vlSelf->wasmetal_core__DOT___063169_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063175_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128199___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063181_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128199___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029718_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d));
    wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026266_)
            ? (IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032873_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032840_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___070643_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O))))));
    vlSelf->wasmetal_core__DOT___070646_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032681_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032648_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b20__05d) {
        wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___032619_ = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b20__05d;
    } else {
        wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___032619_ = vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___031883_;
        wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___033918_;
        wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032940_;
    }
    wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
           & (IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033108_));
        vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033202_));
        vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033974_));
    }
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027809_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026365_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128038___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128038___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028000_)))));
    vlSelf->wasmetal_core__DOT___028004_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128038___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032202_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d));
    wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032807_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128502___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032969_)))));
    wasmetal_core__DOT___032973_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128502___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)
            : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b21__05d) {
        wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b21__05d;
    } else {
        wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__ = 0U;
        wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)
            : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128167___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029392_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029391_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029390_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029389_)))) 
           ^ (((IData)(wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128167___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029356_)))));
    wasmetal_core__DOT___029360_ = ((IData)(vlSelf->wasmetal_core__DOT___029392_)
                                     ? (IData)(wasmetal_core__DOT___128167___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d));
    wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128151___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029231_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029230_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029229_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029228_)))) 
           ^ (((IData)(wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128151___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029195_)))));
    wasmetal_core__DOT___029199_ = ((IData)(vlSelf->wasmetal_core__DOT___029231_)
                                     ? (IData)(wasmetal_core__DOT___128151___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127830___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026175_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026174_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026173_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026172_)))) 
           ^ (((IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127830___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026139_)))));
    wasmetal_core__DOT___026143_ = ((IData)(vlSelf->wasmetal_core__DOT___026175_)
                                     ? (IData)(wasmetal_core__DOT___127830___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d));
    wasmetal_core__DOT____Vcellout___128538___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b18__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128538___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
           & (IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034641_) 
           & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128714___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035094_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035093_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035092_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035091_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128714___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035026_)))));
    wasmetal_core__DOT___035030_ = ((IData)(vlSelf->wasmetal_core__DOT___035094_)
                                     ? (IData)(wasmetal_core__DOT___128714___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
           & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030788_)
            ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)
            : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)
            : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063148_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063146_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063145_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063154_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063152_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063151_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063160_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063157_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128362___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063166_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063164_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063163_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128215___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128362___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032485_)
                  ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032485_))));
    wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031746_)
            ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d));
    wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)) 
           & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128217___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029924_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029923_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029922_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029921_)))) 
           ^ (((IData)(wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128217___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029887_)))));
    wasmetal_core__DOT___029891_ = ((IData)(vlSelf->wasmetal_core__DOT___029924_)
                                     ? (IData)(wasmetal_core__DOT___128217___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d));
    vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127837___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026267_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026266_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026265_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026264_)))) 
           ^ (((IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127837___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026231_)))));
    vlSelf->wasmetal_core__DOT___026235_ = ((IData)(vlSelf->wasmetal_core__DOT___026267_)
                                             ? (IData)(wasmetal_core__DOT___127837___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032682_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128259___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128259___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128259___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030353_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b21__05d) {
        vlSelf->wasmetal_core__DOT___030357_ = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030357_ = wasmetal_core__DOT___128259___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032619_;
        wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128022___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128022___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027871_)))));
    vlSelf->wasmetal_core__DOT___027875_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128022___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128398___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128398___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031879_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128462___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128462___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032615_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128597___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128597___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033914_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))) {
        wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
        wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
        wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                     >> 3U));
    } else {
        wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128494___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128494___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032936_)))));
    wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027810_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d));
    wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026366_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d));
    wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028004_));
    wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032203_)
            ? (IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128477___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032808_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032807_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032806_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032805_)))) 
           ^ (((IData)(wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128477___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032772_)))));
    wasmetal_core__DOT___032776_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032808_)
                                           ? (IData)(wasmetal_core__DOT___128477___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                              >> 3U)));
    wasmetal_core__DOT___032812_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___032811_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___032810_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___032809_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)))));
    wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)
            : (IData)(wasmetal_core__DOT___032973_));
    wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)
            : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b22__05d) {
        wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b22__05d;
    } else {
        wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)
            : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029394_)
            ? (IData)(wasmetal_core__DOT___029360_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d));
    wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___044576_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029233_)
            ? (IData)(wasmetal_core__DOT___029199_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d));
    vlSelf->wasmetal_core__DOT___044596_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026177_)
            ? (IData)(wasmetal_core__DOT___026143_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128572___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128572___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128681___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034642_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034639_)))) 
           ^ (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034702_)))));
    wasmetal_core__DOT___034706_ = ((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                    & (IData)(wasmetal_core__DOT___128681___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034646_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___034645_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___034644_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128714___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___034643_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128714___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d)))));
    wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035096_)
            ? (IData)(wasmetal_core__DOT___035030_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d));
    wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
           & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128306___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030789_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030788_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030850_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030849_)))) 
           ^ (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030784_)))));
    wasmetal_core__DOT___030725_ = ((IData)(vlSelf->wasmetal_core__DOT___030789_)
                                     ? (IData)(wasmetal_core__DOT___128306___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d));
    wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)
            : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)
            : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032486_)
                  ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032486_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128386___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031747_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031746_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031807_)))) 
           ^ (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031742_)))));
    wasmetal_core__DOT___031683_ = ((IData)(vlSelf->wasmetal_core__DOT___031747_)
                                     ? (IData)(wasmetal_core__DOT___128386___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128698___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034898_)))));
    wasmetal_core__DOT___034902_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)) 
                                    & (IData)(wasmetal_core__DOT___128698___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029926_)
            ? (IData)(wasmetal_core__DOT___029891_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d));
    wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d));
    vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026268_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026235_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d));
    wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032875_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032683_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b22__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030357_;
        wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027875_));
    wasmetal_core__DOT____Vcellinp___128519___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
        wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
        wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O));
    } else {
        wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128014___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027811_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027808_)))) 
           ^ (((IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027775_)))));
    vlSelf->wasmetal_core__DOT___027779_ = ((IData)(vlSelf->wasmetal_core__DOT___027811_)
                                             ? (IData)(wasmetal_core__DOT___128014___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026367_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026366_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026365_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026364_)))) 
           ^ (((IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026331_)))));
    vlSelf->wasmetal_core__DOT___026335_ = ((IData)(vlSelf->wasmetal_core__DOT___026367_)
                                             ? (IData)(wasmetal_core__DOT___127846___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d));
    wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128430___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032204_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032203_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032202_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032201_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128430___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032168_)))));
    wasmetal_core__DOT___032172_ = ((IData)(vlSelf->wasmetal_core__DOT___032204_)
                                     ? (IData)(wasmetal_core__DOT___128430___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032809_)
                  ? (IData)(wasmetal_core__DOT___032776_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)));
    wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)
            : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128193___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029657_)))));
    wasmetal_core__DOT___029662_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128193___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128279___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030569_)))));
    wasmetal_core__DOT___030574_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128279___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128007___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI) 
           ^ (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027714_)))));
    wasmetal_core__DOT___027719_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128007___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128423___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032077_)))));
    wasmetal_core__DOT___032082_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128423___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128375___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031596_)))));
    wasmetal_core__DOT___031601_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128375___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128227___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029995_)))));
    wasmetal_core__DOT___030000_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128227___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029395_)
            ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128210___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029826_)))));
    wasmetal_core__DOT___029831_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128210___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128160___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029295_)))));
    wasmetal_core__DOT___029300_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128160___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029234_)
            ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d));
    wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026178_)
            ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128581___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128581___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
           & (IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034643_) 
           & (IData)(wasmetal_core__DOT___034706_));
    wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035097_)
            ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127999___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027649_)))));
    wasmetal_core__DOT___027654_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
                                    & (IData)(wasmetal_core__DOT___127999___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030790_)
            ? (IData)(wasmetal_core__DOT___030725_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128339___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031108_)))));
    wasmetal_core__DOT___031112_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128339___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128363___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___031396_)))));
    wasmetal_core__DOT___031400_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)
                                     : (IData)(wasmetal_core__DOT___128363___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128451___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032487_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032486_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032485_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032484_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032419_)))));
    wasmetal_core__DOT___032423_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032487_)
                                           ? (IData)(wasmetal_core__DOT___128451___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032487_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031748_)
            ? (IData)(wasmetal_core__DOT___031683_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)) 
           & (IData)(wasmetal_core__DOT___034902_));
    wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029927_)
            ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d));
    wasmetal_core__DOT____Vcellout___128200___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029755_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029754_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029753_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029752_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128200___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029718_)))));
    wasmetal_core__DOT___029722_ = ((IData)(vlSelf->wasmetal_core__DOT___029755_)
                                     ? (IData)(wasmetal_core__DOT___128200___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d));
    wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026269_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128486___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032876_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032875_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032874_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032873_)))) 
           ^ (((IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032840_)))));
    vlSelf->wasmetal_core__DOT___032844_ = ((IData)(vlSelf->wasmetal_core__DOT___032876_)
                                             ? (IData)(wasmetal_core__DOT___128486___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032684_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032683_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032681_)))) 
           ^ (((IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032648_)))));
    vlSelf->wasmetal_core__DOT___032652_ = ((IData)(vlSelf->wasmetal_core__DOT___032684_)
                                             ? (IData)(wasmetal_core__DOT___128470___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b23__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___031888_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___033923_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___032945_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031888_ = wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033923_ = wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032945_ = wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
           & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128519___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128519___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033108_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___033112_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
        wasmetal_core__DOT___033206_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
        wasmetal_core__DOT___033978_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                              >> 1U));
    } else {
        wasmetal_core__DOT___033112_ = (1U & (IData)(wasmetal_core__DOT___128519___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___033206_ = (1U & (IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___033978_ = (1U & (IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128527___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128527___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128527___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033202_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128604___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128519___S) 
           ^ (((IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128604___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128604___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033974_)))));
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027813_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027779_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d));
    vlSelf->wasmetal_core__DOT___044380_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026335_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d));
    wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045542_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045541_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(wasmetal_core__DOT____Vcellout___128430___O))))))))));
    vlSelf->wasmetal_core__DOT___045554_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128430___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128430___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045553_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128429___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(wasmetal_core__DOT____Vcellout___128430___O))))))))));
    wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032206_)
            ? (IData)(wasmetal_core__DOT___032172_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032810_)
                  ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                     >> 1U)));
    wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)
            : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029662_));
    vlSelf->wasmetal_core__DOT___039829_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039838_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039824_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x14U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039842_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128279___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d)))))));
    wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)
            : (IData)(wasmetal_core__DOT___030574_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b24__05d) {
        wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___027719_;
        wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b24__05d;
    } else {
        wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__ = 0U;
        wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___032082_;
    }
    wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)
            : (IData)(wasmetal_core__DOT___031601_));
    wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d) 
           & (IData)(wasmetal_core__DOT___030000_));
    wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029396_)
            ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d));
    wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029831_));
    wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d) 
           & (IData)(wasmetal_core__DOT___029300_));
    wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029235_)
            ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d));
    wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026179_)
            ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128590___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b21__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128590___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034644_) 
           & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035098_)
            ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q) 
           & (IData)(wasmetal_core__DOT___027654_));
    wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030791_)
            ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)
            : (IData)(wasmetal_core__DOT___031112_));
    wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)
            : (IData)(wasmetal_core__DOT___031400_));
    wasmetal_core__DOT___063170_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063176_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128451___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063182_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063188_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128451___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032488_)
                  ? (IData)(wasmetal_core__DOT___032423_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032488_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031749_)
            ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)) 
           & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029928_)
            ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d));
    vlSelf->wasmetal_core__DOT___063193_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063199_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128200___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063205_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063211_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128200___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029757_)
            ? (IData)(wasmetal_core__DOT___029722_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d));
    wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026270_)
            ? (IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b48__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___019808_) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b53__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054563_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128644___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034331_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b52__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b51__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054562_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128644___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034330_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b51__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b50__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054561_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128643___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034329_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b50__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b49__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128643___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034328_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b49__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b48__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054559_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128643___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034326_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b48__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b47__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054558_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128643___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034325_)))))))))));
    }
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032878_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032844_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___070649_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032686_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032652_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b24__05d) {
        wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___032624_ = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
    } else {
        wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032624_ = wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031888_;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033923_;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032945_;
    }
    wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
        wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
        wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 2U));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033112_));
        wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033206_));
        wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___033978_));
    }
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027814_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026370_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128039___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI) 
           ^ (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028004_)))));
    wasmetal_core__DOT___028009_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128039___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032207_)
            ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d));
    wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___032811_)
                  ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128503___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032973_)))));
    wasmetal_core__DOT___032978_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128503___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)
            : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b25__05d) {
        wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b25__05d;
    } else {
        wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__ = 0U;
        wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)
            : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128168___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029397_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029396_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029395_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029394_)))) 
           ^ (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029360_)))));
    vlSelf->wasmetal_core__DOT___029365_ = ((IData)(vlSelf->wasmetal_core__DOT___029397_)
                                             ? (IData)(wasmetal_core__DOT___128168___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d));
    wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128152___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029236_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029235_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029234_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029233_)))) 
           ^ (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029199_)))));
    vlSelf->wasmetal_core__DOT___029204_ = ((IData)(vlSelf->wasmetal_core__DOT___029236_)
                                             ? (IData)(wasmetal_core__DOT___128152___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127831___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026180_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026179_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026178_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026177_)))) 
           ^ (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026143_)))));
    vlSelf->wasmetal_core__DOT___026148_ = ((IData)(vlSelf->wasmetal_core__DOT___026180_)
                                             ? (IData)(wasmetal_core__DOT___127831___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d));
    wasmetal_core__DOT____Vcellout___128539___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b22__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___128539___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034645_) 
           & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128715___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035099_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035098_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035097_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035030_)))));
    vlSelf->wasmetal_core__DOT___035035_ = ((IData)(vlSelf->wasmetal_core__DOT___035099_)
                                             ? (IData)(wasmetal_core__DOT___128715___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
           & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030792_)
            ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)
            : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)
            : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063172_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063169_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063178_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063176_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063175_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063184_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063181_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128363___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063190_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063188_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063187_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128216___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128363___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032489_)
                  ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032489_))));
    wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031750_)
            ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d));
    wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128218___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029929_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029928_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029927_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029926_)))) 
           ^ (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029891_)))));
    vlSelf->wasmetal_core__DOT___029896_ = ((IData)(vlSelf->wasmetal_core__DOT___029929_)
                                             ? (IData)(wasmetal_core__DOT___128218___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d));
    wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029758_)
            ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127838___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026271_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026270_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026269_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026268_)))) 
           ^ (((IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127838___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026235_)))));
    wasmetal_core__DOT___026239_ = ((IData)(vlSelf->wasmetal_core__DOT___026271_)
                                     ? (IData)(wasmetal_core__DOT___127838___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d));
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032879_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032687_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128260___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128260___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030357_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b25__05d) {
        wasmetal_core__DOT___030362_ = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
    } else {
        wasmetal_core__DOT___030362_ = wasmetal_core__DOT___128260___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032624_;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128023___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI) 
           ^ (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027875_)))));
    wasmetal_core__DOT___027880_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___128023___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128399___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128399___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031883_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128463___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128463___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032619_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128598___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128598___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033918_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
        wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
        wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                     >> 3U));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128495___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128495___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032940_)))));
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027815_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d));
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d));
    wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d) 
           & (IData)(wasmetal_core__DOT___028009_));
    wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032208_)
            ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128478___O 
        = ((((IData)(wasmetal_core__DOT___032812_) 
             << 3U) | (((IData)(wasmetal_core__DOT___032811_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___032810_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___032809_)))) 
           ^ (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032776_)))));
    vlSelf->wasmetal_core__DOT___032780_ = (1U & ((IData)(wasmetal_core__DOT___032812_)
                                                   ? (IData)(wasmetal_core__DOT___128478___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032817_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032816_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032815_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032814_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)))));
    wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)
            : (IData)(wasmetal_core__DOT___032978_));
    wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b26__05d) {
        wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b26__05d;
    } else {
        wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__ = 0U;
        wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029398_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029365_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d));
    wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029237_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029204_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026181_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026148_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    __VdfgTmp_h98c6c754__0 = ((4U & (IData)(wasmetal_core__DOT____Vcellout___128538___O)) 
                              | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(wasmetal_core__DOT____Vcellout___128539___O))));
    wasmetal_core__DOT___064263_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(wasmetal_core__DOT____Vcellout___128538___O)) 
                                                               | (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128573___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b23__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(wasmetal_core__DOT___128573___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128682___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034646_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034643_)))) 
           ^ (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034706_)))));
    vlSelf->wasmetal_core__DOT___034710_ = ((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                            & (IData)(wasmetal_core__DOT___128682___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034651_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d)))));
    vlSelf->wasmetal_core__DOT___034650_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___034649_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128715___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___034648_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128715___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035100_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035035_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d));
    wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
           & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128307___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030793_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030792_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030791_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030790_)))) 
           ^ (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030725_)))));
    vlSelf->wasmetal_core__DOT___030729_ = ((IData)(vlSelf->wasmetal_core__DOT___030793_)
                                             ? (IData)(wasmetal_core__DOT___128307___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d));
    wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)
            : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)
            : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032490_)
                  ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032490_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128387___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031751_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031750_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031749_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031748_)))) 
           ^ (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031683_)))));
    vlSelf->wasmetal_core__DOT___031687_ = ((IData)(vlSelf->wasmetal_core__DOT___031751_)
                                             ? (IData)(wasmetal_core__DOT___128387___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128699___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034902_)))));
    vlSelf->wasmetal_core__DOT___034907_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)) 
                                            & (IData)(wasmetal_core__DOT___128699___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029930_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029896_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d));
    wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029759_)
            ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d));
    wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026273_)
            ? (IData)(wasmetal_core__DOT___026239_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d));
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032880_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032688_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b26__05d) {
        wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
    } else {
        wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___030362_;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
           & (IData)(wasmetal_core__DOT___027880_));
    wasmetal_core__DOT____Vcellinp___128520___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 2U))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
        wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
        wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O));
    } else {
        wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128015___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027816_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027815_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027814_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027813_)))) 
           ^ (((IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027779_)))));
    vlSelf->wasmetal_core__DOT___027784_ = ((IData)(vlSelf->wasmetal_core__DOT___027816_)
                                             ? (IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127847___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026372_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026371_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026370_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026369_)))) 
           ^ (((IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026335_)))));
    vlSelf->wasmetal_core__DOT___026340_ = ((IData)(vlSelf->wasmetal_core__DOT___026372_)
                                             ? (IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d));
    wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128431___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032209_) 
             << 3U) | (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0)) 
           ^ (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032172_)))));
    vlSelf->wasmetal_core__DOT___032177_ = ((IData)(vlSelf->wasmetal_core__DOT___032209_)
                                             ? (IData)(wasmetal_core__DOT___128431___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032814_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032780_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)));
    wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)
            : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128194___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029662_)))));
    vlSelf->wasmetal_core__DOT___029666_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128194___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128280___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030574_)))));
    vlSelf->wasmetal_core__DOT___030578_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128280___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128008___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha5b552f8__0))) 
           ^ (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027719_)))));
    vlSelf->wasmetal_core__DOT___027723_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128008___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128424___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032082_)))));
    vlSelf->wasmetal_core__DOT___032086_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128424___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128376___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031601_)))));
    vlSelf->wasmetal_core__DOT___031605_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128376___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128228___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030000_)))));
    vlSelf->wasmetal_core__DOT___030004_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128228___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029399_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128211___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029831_)))));
    vlSelf->wasmetal_core__DOT___029835_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128211___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128161___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he45fe6bb__0))) 
           ^ (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___029300_)))));
    vlSelf->wasmetal_core__DOT___029304_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128161___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029238_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d));
    vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026182_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d));
    vlSelf->wasmetal_core__DOT___064267_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(wasmetal_core__DOT___064263_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O)) 
                                                                                | (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128538___O) 
                                                                                >> 1U)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128537___O) 
                                                                                >> 3U)))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x38U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128539___O) 
                                                                        << 2U)) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((1U 
                                                                               >> (IData)(__VdfgTmp_h98c6c754__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0x80U 
                                                                                >> (IData)(__VdfgTmp_h98c6c754__0)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                         << 2U)) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                               << 2U)) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128536___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h015c016b__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h261f62de__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128535___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h015c016b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h261f62de__0)))))))))))))))))))))));
    __VdfgTmp_hf4b373dc__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O))));
    wasmetal_core__DOT___064107_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__)))))))))));
    wasmetal_core__DOT____Vcellout___128582___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034648_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034710_));
    vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035101_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128000___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q)))) 
           ^ (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027654_)))));
    vlSelf->wasmetal_core__DOT___027658_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
                                            & (IData)(wasmetal_core__DOT___128000___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030794_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030729_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128340___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031112_)))));
    vlSelf->wasmetal_core__DOT___031116_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128340___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128364___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031400_)))));
    vlSelf->wasmetal_core__DOT___031404_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128364___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128452___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032488_)))) 
           ^ (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032423_)))));
    vlSelf->wasmetal_core__DOT___032427_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032491_)
                                                   ? (IData)(wasmetal_core__DOT___128452___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032491_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031687_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034907_));
    vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029931_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d));
    wasmetal_core__DOT____Vcellout___128201___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029760_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029759_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029758_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029757_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___029722_)))));
    vlSelf->wasmetal_core__DOT___029727_ = ((IData)(vlSelf->wasmetal_core__DOT___029760_)
                                             ? (IData)(wasmetal_core__DOT___128201___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d));
    wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026274_)
            ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128487___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032881_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032880_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032879_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032878_)))) 
           ^ (((IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032844_)))));
    vlSelf->wasmetal_core__DOT___032849_ = ((IData)(vlSelf->wasmetal_core__DOT___032881_)
                                             ? (IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128471___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032689_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032687_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032686_)))) 
           ^ (((IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032652_)))));
    vlSelf->wasmetal_core__DOT___032657_ = ((IData)(vlSelf->wasmetal_core__DOT___032689_)
                                             ? (IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b27__05d) {
        wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___031892_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___033927_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___032949_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
    } else {
        wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031892_ = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033927_ = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032949_ = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
           & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128520___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033112_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___033116_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033210_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033982_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033116_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128520___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033210_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033982_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128528___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128528___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033206_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128605___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128520___S) 
           ^ (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128605___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033978_)))));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027817_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027784_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026373_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026340_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d));
    wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045543_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___045555_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032210_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032177_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032815_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                     >> 1U)));
    wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)
            : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029666_));
    vlSelf->wasmetal_core__DOT___039841_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039840_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x17U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039839_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x18U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039848_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x19U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)))))));
    wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030578_));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b28__05d) {
        wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___027723_;
        wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b28__05d;
    } else {
        wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__ = 0U;
        wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032086_;
    }
    wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031605_));
    wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030004_));
    wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029400_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d));
    wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029835_));
    wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029304_));
    wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029239_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d));
    wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026183_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d));
    vlSelf->wasmetal_core__DOT___064440_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___064690_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___065143_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___065026_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___064437_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064433_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064432_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064423_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064367_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064373_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064377_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064384_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064388_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064337_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064268_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064438_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064336_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064319_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064282_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064294_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064318_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064290_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064295_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064291_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064315_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064301_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064314_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064304_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064111_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(wasmetal_core__DOT___064107_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                              << 1U)) 
                                                                          | ((2U 
                                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                                >> 2U)))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O) 
                                                                        << 4U)) 
                                                                    | ((0x18U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O) 
                                                                           << 1U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(__VdfgTmp_hf4b373dc__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(__VdfgTmp_hf4b373dc__0))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                         << 4U)) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                            << 2U)) 
                                                                        | ((8U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                               << 1U)) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                >> 1U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a9a4b36__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3321aa0d__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a9a4b36__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3321aa0d__0)))))))))))))))))))))));
    __VdfgTmp_h325e7d4e__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(wasmetal_core__DOT____Vcellout___128582___O))));
    vlSelf->wasmetal_core__DOT___064031_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)))))))))))));
    vlSelf->wasmetal_core__DOT___033860_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b28__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128591___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b28__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034649_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035102_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d));
    vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128964___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027658_));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030795_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d));
    vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031116_));
    vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031404_));
    wasmetal_core__DOT___063194_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063200_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063206_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063212_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032493_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032427_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032493_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029932_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d));
    vlSelf->wasmetal_core__DOT___063217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063223_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128201___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063229_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063235_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128201___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029727_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d));
    wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026275_)
            ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032882_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032849_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___070652_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032690_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032657_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b28__05d) {
        wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        vlSelf->wasmetal_core__DOT___032628_ = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
    } else {
        wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___032628_ = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
           & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033116_));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033210_));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033982_));
    }
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027818_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026374_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128040___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h17166267__0))) 
           ^ (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___028009_)))));
    vlSelf->wasmetal_core__DOT___028013_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128040___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032211_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032816_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___032982_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128504___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128504___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032978_)))));
    wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)
            : (IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) {
        wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__call_depth__05b29__05d;
    } else {
        wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__ = 0U;
        wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)
            : (IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128169___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029401_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029400_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029399_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029398_)))) 
           ^ (((IData)(wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029365_)))));
    vlSelf->wasmetal_core__DOT___029369_ = ((IData)(vlSelf->wasmetal_core__DOT___029401_)
                                             ? (IData)(wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d));
    wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128153___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029240_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029239_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029238_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029237_)))) 
           ^ (((IData)(wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029204_)))));
    vlSelf->wasmetal_core__DOT___029208_ = ((IData)(vlSelf->wasmetal_core__DOT___029240_)
                                             ? (IData)(wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127832___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026184_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026183_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026182_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026181_)))) 
           ^ (((IData)(wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026148_)))));
    vlSelf->wasmetal_core__DOT___026152_ = ((IData)(vlSelf->wasmetal_core__DOT___026184_)
                                             ? (IData)(wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d));
    vlSelf->wasmetal_core__DOT___065144_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___064835_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064437_))));
    wasmetal_core__DOT___065223_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064431_))));
    vlSelf->wasmetal_core__DOT___064435_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064431_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064430_)))));
    wasmetal_core__DOT___065380_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064430_))));
    vlSelf->wasmetal_core__DOT___064689_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064430_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064433_)))));
    wasmetal_core__DOT___065485_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064433_))));
    vlSelf->wasmetal_core__DOT___064434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064433_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065509_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064432_))));
    vlSelf->wasmetal_core__DOT___064688_ = (1U & (0xf3f5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065649_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064408_))));
    wasmetal_core__DOT___064410_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064409_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065761_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064409_))));
    wasmetal_core__DOT___064414_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064413_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065956_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064413_))));
    wasmetal_core__DOT___064415_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064412_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065844_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064412_))));
    wasmetal_core__DOT___064421_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064418_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066027_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064418_))));
    wasmetal_core__DOT___064420_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064419_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066180_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064419_))));
    wasmetal_core__DOT___064425_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064422_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066225_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064422_))));
    wasmetal_core__DOT___064424_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064423_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066336_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064423_))));
    wasmetal_core__DOT___064365_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064362_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066434_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064362_))));
    wasmetal_core__DOT___064364_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064363_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066500_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064363_))));
    vlSelf->wasmetal_core__DOT___069265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064351_))));
    vlSelf->wasmetal_core__DOT___064352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064351_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___064369_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064366_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066581_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064366_))));
    vlSelf->wasmetal_core__DOT___064368_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064367_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066695_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064367_))));
    vlSelf->wasmetal_core__DOT___064375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064372_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066748_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064372_))));
    vlSelf->wasmetal_core__DOT___064374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066830_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064373_))));
    vlSelf->wasmetal_core__DOT___064379_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064376_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066914_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064376_))));
    vlSelf->wasmetal_core__DOT___064378_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064377_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066998_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064377_))));
    vlSelf->wasmetal_core__DOT___064387_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064384_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064384_))));
    vlSelf->wasmetal_core__DOT___069216_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064350_))));
    vlSelf->wasmetal_core__DOT___064353_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064350_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064386_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064385_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067128_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064385_))));
    vlSelf->wasmetal_core__DOT___064391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064388_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067239_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064388_))));
    vlSelf->wasmetal_core__DOT___069184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064347_))));
    vlSelf->wasmetal_core__DOT___064348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064390_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064389_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064389_))));
    vlSelf->wasmetal_core__DOT___064397_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067383_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064394_))));
    vlSelf->wasmetal_core__DOT___069117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064346_))));
    vlSelf->wasmetal_core__DOT___064349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064346_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064396_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064395_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064395_))));
    vlSelf->wasmetal_core__DOT___064401_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064398_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067527_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064398_))));
    vlSelf->wasmetal_core__DOT___069069_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064341_))));
    vlSelf->wasmetal_core__DOT___064342_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064341_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___069022_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064340_))));
    vlSelf->wasmetal_core__DOT___064343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064340_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068991_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064337_))));
    vlSelf->wasmetal_core__DOT___064338_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064337_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064400_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067575_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064399_))));
    vlSelf->wasmetal_core__DOT___064271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064268_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067641_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064268_))));
    vlSelf->wasmetal_core__DOT___065654_ = (1U & (0x30aU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064438_))));
    vlSelf->wasmetal_core__DOT___065492_ = (1U & (0x35U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064438_))));
    vlSelf->wasmetal_core__DOT___065033_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___068924_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064336_))));
    vlSelf->wasmetal_core__DOT___064339_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064336_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064270_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064269_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064269_))));
    vlSelf->wasmetal_core__DOT___064275_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064272_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067788_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064272_))));
    vlSelf->wasmetal_core__DOT___068875_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064329_))));
    vlSelf->wasmetal_core__DOT___064330_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064329_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068828_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064328_))));
    vlSelf->wasmetal_core__DOT___064331_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064328_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064273_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067837_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064273_))));
    vlSelf->wasmetal_core__DOT___068681_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064319_))));
    vlSelf->wasmetal_core__DOT___064320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064319_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068778_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064325_))));
    vlSelf->wasmetal_core__DOT___064326_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064325_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068728_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064324_))));
    vlSelf->wasmetal_core__DOT___064327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064324_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064278_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067880_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064278_))));
    vlSelf->wasmetal_core__DOT___064280_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067940_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064279_))));
    vlSelf->wasmetal_core__DOT___064285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064282_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068003_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064282_))));
    vlSelf->wasmetal_core__DOT___064284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064283_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068056_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064283_))));
    vlSelf->wasmetal_core__DOT___064297_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064294_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064294_))));
    vlSelf->wasmetal_core__DOT___068631_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064318_))));
    vlSelf->wasmetal_core__DOT___064321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064290_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068131_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064290_))));
    vlSelf->wasmetal_core__DOT___064296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064295_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064295_))));
    vlSelf->wasmetal_core__DOT___064292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064291_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064291_))));
    vlSelf->wasmetal_core__DOT___064303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064300_))));
    vlSelf->wasmetal_core__DOT___068581_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064315_))));
    vlSelf->wasmetal_core__DOT___064316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064315_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068379_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064301_))));
    vlSelf->wasmetal_core__DOT___064317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064314_))));
    vlSelf->wasmetal_core__DOT___064307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064304_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068454_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064304_))));
    vlSelf->wasmetal_core__DOT___064306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064305_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064305_))));
    vlSelf->wasmetal_core__DOT___064199_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064111_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___064616_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064127_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064189_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064190_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064179_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064123_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064122_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064113_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064157_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064161_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064158_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064162_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064149_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064167_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064171_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064134_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064135_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064588_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064032_ = (1U & (IData)(
                                                         (0x5ffffffffffffff3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128582___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128582___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128582___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(__VdfgTmp_h325e7d4e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80U 
                                                                             >> (IData)(__VdfgTmp_h325e7d4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___064215_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O)) 
                                                                       | (1U 
                                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT___033860_)))))))))));
    vlSelf->__VdfgTmp_hb90eb6ff__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128591___O) 
                                             >> 1U)) 
                                      | (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128591___O)));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034650_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128716___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035103_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035102_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035101_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035035_)))));
    vlSelf->wasmetal_core__DOT___035039_ = ((IData)(vlSelf->wasmetal_core__DOT___035103_)
                                             ? (IData)(wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d));
    vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128965___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030796_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d));
    vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063196_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063202_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063200_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063199_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063208_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063205_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063214_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063212_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063211_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032494_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032494_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128219___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029933_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029932_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029931_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029930_)))) 
           ^ (((IData)(wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029896_)))));
    vlSelf->wasmetal_core__DOT___029900_ = ((IData)(vlSelf->wasmetal_core__DOT___029933_)
                                             ? (IData)(wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d));
    vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127839___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026276_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026275_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026274_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026273_)))) 
           ^ (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026239_)))));
    vlSelf->wasmetal_core__DOT___026244_ = ((IData)(vlSelf->wasmetal_core__DOT___026276_)
                                             ? (IData)(wasmetal_core__DOT___127839___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032883_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032691_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128261___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030362_)))));
    vlSelf->wasmetal_core__DOT___030366_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
                                             : (IData)(wasmetal_core__DOT___128261___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128024___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd225b533__0))) 
           ^ (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027880_)))));
    vlSelf->wasmetal_core__DOT___027884_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128024___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128400___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031888_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128464___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032624_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128599___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033923_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128496___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032945_)))));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027819_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d));
    vlSelf->wasmetal_core__DOT___128041___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028013_));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032212_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128479___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032817_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032816_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032815_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032814_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032780_)))));
    vlSelf->wasmetal_core__DOT___032785_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032817_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___128505___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032982_));
    vlSelf->wasmetal_core__DOT___032821_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032820_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032819_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032818_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128195___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029666_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128281___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030578_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128009___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027723_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128425___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032086_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128377___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031605_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128229___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030004_)))));
    vlSelf->wasmetal_core__DOT___128170___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029402_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029369_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128212___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029835_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128162___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029304_)))));
    vlSelf->wasmetal_core__DOT___044577_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___128154___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029241_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029208_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d));
    vlSelf->wasmetal_core__DOT___044597_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___127833___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026185_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026152_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d));
    vlSelf->wasmetal_core__DOT___065027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065026_))));
    vlSelf->wasmetal_core__DOT___065224_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___065381_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065380_))));
    vlSelf->wasmetal_core__DOT___065486_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065380_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065485_))));
    vlSelf->wasmetal_core__DOT___064436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064435_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064434_))));
    vlSelf->wasmetal_core__DOT___065510_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065485_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065509_))));
    vlSelf->wasmetal_core__DOT___064693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064688_))));
    vlSelf->wasmetal_core__DOT___065650_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065509_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065649_))));
    vlSelf->wasmetal_core__DOT___064417_ = (1U & (0x53U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064410_))));
    vlSelf->wasmetal_core__DOT___065762_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065649_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065761_))));
    vlSelf->wasmetal_core__DOT___064683_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064410_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064415_))));
    vlSelf->wasmetal_core__DOT___064416_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064415_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064414_))));
    vlSelf->wasmetal_core__DOT___065845_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065761_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065844_))));
    vlSelf->wasmetal_core__DOT___065957_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065844_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065956_))));
    vlSelf->wasmetal_core__DOT___064682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064414_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064421_))));
    vlSelf->wasmetal_core__DOT___066028_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065956_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066027_))));
    vlSelf->wasmetal_core__DOT___064427_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064421_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064420_))));
    vlSelf->wasmetal_core__DOT___066181_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066027_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066180_))));
    vlSelf->wasmetal_core__DOT___064685_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064420_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064425_))));
    vlSelf->wasmetal_core__DOT___066226_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066180_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066225_))));
    vlSelf->wasmetal_core__DOT___064426_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064425_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066225_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066336_))));
    vlSelf->wasmetal_core__DOT___064684_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066435_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066336_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066434_))));
    vlSelf->wasmetal_core__DOT___064371_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064364_))));
    vlSelf->wasmetal_core__DOT___066501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066434_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066500_))));
    vlSelf->wasmetal_core__DOT___064669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064364_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064369_))));
    vlSelf->wasmetal_core__DOT___066582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066500_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066581_))));
    vlSelf->wasmetal_core__DOT___064370_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064368_))));
    vlSelf->wasmetal_core__DOT___066696_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066695_))));
}
