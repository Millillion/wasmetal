#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__31(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__31\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013207_;
    wasmetal_core__DOT___013207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013208_;
    wasmetal_core__DOT___013208_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013506_;
    wasmetal_core__DOT___013506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014355_;
    wasmetal_core__DOT___014355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014375_;
    wasmetal_core__DOT___014375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014381_;
    wasmetal_core__DOT___014381_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014382_;
    wasmetal_core__DOT___014382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014383_;
    wasmetal_core__DOT___014383_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014440_;
    wasmetal_core__DOT___014440_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014447_;
    wasmetal_core__DOT___014447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014454_;
    wasmetal_core__DOT___014454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016432_;
    wasmetal_core__DOT___016432_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016459_;
    wasmetal_core__DOT___016459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019677_;
    wasmetal_core__DOT___019677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019684_;
    wasmetal_core__DOT___019684_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019760_;
    wasmetal_core__DOT___019760_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042791_;
    wasmetal_core__DOT___042791_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042795_;
    wasmetal_core__DOT___042795_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048954_;
    wasmetal_core__DOT___048954_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051265_;
    wasmetal_core__DOT___051265_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057713_;
    wasmetal_core__DOT___057713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057915_;
    wasmetal_core__DOT___057915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057936_;
    wasmetal_core__DOT___057936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057950_;
    wasmetal_core__DOT___057950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057970_;
    wasmetal_core__DOT___057970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057977_;
    wasmetal_core__DOT___057977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057979_;
    wasmetal_core__DOT___057979_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058023_;
    wasmetal_core__DOT___058023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058027_;
    wasmetal_core__DOT___058027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058032_;
    wasmetal_core__DOT___058032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058042_;
    wasmetal_core__DOT___058042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058054_;
    wasmetal_core__DOT___058054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058055_;
    wasmetal_core__DOT___058055_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058056_;
    wasmetal_core__DOT___058056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058981_;
    wasmetal_core__DOT___058981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071733_;
    wasmetal_core__DOT___071733_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127528___O;
    wasmetal_core__DOT____Vcellout___127528___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h9dc510af__0;
    __VdfgTmp_h9dc510af__0 = 0;
    CData/*1:0*/ __VdfgTmp_hba696de2__0;
    __VdfgTmp_hba696de2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8453cf34__0;
    __VdfgTmp_h8453cf34__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbb8e97f6__0;
    __VdfgTmp_hbb8e97f6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3fbd9b9f__0;
    __VdfgTmp_h3fbd9b9f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h98614ec5__0;
    __VdfgTmp_h98614ec5__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6ff3b264__0;
    __VdfgTmp_h6ff3b264__0 = 0;
    CData/*3:0*/ __VdfgTmp_h63472758__0;
    __VdfgTmp_h63472758__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c9bc85d__0;
    __VdfgTmp_h0c9bc85d__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf656a041__0;
    __VdfgTmp_hf656a041__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a1a10ae__0;
    __VdfgTmp_h7a1a10ae__0 = 0;
    CData/*4:0*/ __VdfgTmp_hb2511b98__0;
    __VdfgTmp_hb2511b98__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf3511969__0;
    __VdfgTmp_hf3511969__0 = 0;
    CData/*1:0*/ __VdfgTmp_h78b7c78d__0;
    __VdfgTmp_h78b7c78d__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf87abe5d__0;
    __VdfgTmp_hf87abe5d__0 = 0;
    CData/*3:0*/ __VdfgTmp_h32a58059__0;
    __VdfgTmp_h32a58059__0 = 0;
    CData/*4:0*/ __VdfgTmp_h836204cc__0;
    __VdfgTmp_h836204cc__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___060075_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060146_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060645_ = (1U & (IData)(
                                                         (0x77ff7777030f0303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018272_)))))))));
    vlSelf->wasmetal_core__DOT___060483_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060500_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060514_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060542_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060556_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060528_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060618_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060258_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060629_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019197_)))));
    vlSelf->__VdfgTmp_h74741c3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058358_))));
    vlSelf->__VdfgTmp_hdd49dc43__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058309_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058308_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015597_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0))));
    vlSelf->__VdfgTmp_ha1b196f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058249_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0)));
    vlSelf->__VdfgTmp_had1ad578__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___058338_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058337_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_heb95d931__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058343_))));
    vlSelf->__VdfgTmp_h8f31d0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058234_));
    vlSelf->wasmetal_core__DOT___016443_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058312_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x1000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))))));
    vlSelf->__VdfgTmp_ha253f9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016452_));
    vlSelf->__VdfgTmp_he2e2fa14__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058332_));
    vlSelf->wasmetal_core__DOT___058345_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))));
    vlSelf->wasmetal_core__DOT___058266_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058264_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))))));
    vlSelf->wasmetal_core__DOT___016458_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058361_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058359_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058359_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058344_))));
    vlSelf->wasmetal_core__DOT___058256_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058254_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc888fbf4__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058350_))));
    vlSelf->__VdfgTmp_hff2cd213__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016449_));
    vlSelf->wasmetal_core__DOT___058524_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (0xffe0001fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058306_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058305_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h787befb5__0))));
    vlSelf->wasmetal_core__DOT___017182_ = (1U & (0x40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058689_))))));
    vlSelf->wasmetal_core__DOT___060587_ = (1U & (IData)(
                                                         (0xfcffffff00540055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___013523_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013205_))))));
    vlSelf->__VdfgTmp_h60102cdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                       << 1U) | (1U 
                                                 & (0xefU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d 
        = (1U & (0x8fU >> (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                            << 2U) | ((2U & ((1U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 1U))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057692_)))));
    vlSelf->wasmetal_core__DOT___057725_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017782_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017794_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017756_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057694_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057701_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057698_))));
    vlSelf->wasmetal_core__DOT___057699_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057698_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128792___O 
        = ((3U & (- (IData)((1U & (1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))) 
           ^ (((((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                 & (IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035864_)));
    vlSelf->wasmetal_core__DOT___042756_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___035721_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048951_))));
    vlSelf->wasmetal_core__DOT___042760_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048951_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))))));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127528___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023185_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023184_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023183_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023246_)))));
    vlSelf->wasmetal_core__DOT___023250_ = ((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053600_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035962_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035905_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d));
    vlSelf->wasmetal_core__DOT___017952_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059318_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059312_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018102_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059381_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059375_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018194_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059424_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059418_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018556_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059679_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059673_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018586_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059700_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059694_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018664_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059746_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018777_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059857_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059851_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018848_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059974_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059973_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059967_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002473_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002473_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018868_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060001_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060000_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059994_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005868_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002636_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002636_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018879_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002629_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002629_)))))))))))))));
    vlSelf->wasmetal_core__DOT___059648_ = (1U & (IData)(
                                                         (0xeefe00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0b0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006015_))))))))))));
    vlSelf->wasmetal_core__DOT___060588_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he45ddc74__0))));
    vlSelf->wasmetal_core__DOT___060302_ = (1U & (IData)(
                                                         (0xcaf0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))));
    vlSelf->wasmetal_core__DOT___060336_ = (1U & (IData)(
                                                         (0xcaf0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060334_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))));
    vlSelf->wasmetal_core__DOT___060241_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                               ? 
                                                              (1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019032_))
                                                               : (IData)(
                                                                         (0xf0305000f030f03ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019033_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019032_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___019043_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                               ? 
                                                              (1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019046_))
                                                               : (IData)(
                                                                         (0xf0305000f030f03ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019047_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019046_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005889_))))));
    vlSelf->wasmetal_core__DOT___019085_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060283_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019092_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019093_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019092_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005802_)))))))));
    vlSelf->wasmetal_core__DOT___019099_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060291_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019106_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019107_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019106_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005882_)))))))));
    vlSelf->wasmetal_core__DOT___060318_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060317_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019116_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019117_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019116_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005948_)))))))));
    vlSelf->wasmetal_core__DOT___019131_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060323_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019138_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019139_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019138_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006051_)))))))));
    vlSelf->wasmetal_core__DOT___019150_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060328_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019157_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019158_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019157_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006029_)))))))));
    vlSelf->wasmetal_core__DOT___019001_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060210_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))
                                                                             ? (IData)(
                                                                                (0x3310303033333030ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019005_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019004_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_))))))))
                                                                             : 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019004_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005711_)))))))));
    vlSelf->wasmetal_core__DOT___060276_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060272_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013795_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005955_)))))));
    vlSelf->wasmetal_core__DOT___060378_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060374_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013738_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006151_)))))));
    vlSelf->wasmetal_core__DOT___060395_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060389_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013918_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006226_)))))));
    vlSelf->wasmetal_core__DOT___019180_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060404_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006274_)))))));
    vlSelf->wasmetal_core__DOT___060419_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060412_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013780_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005823_)))))));
    vlSelf->wasmetal_core__DOT___019188_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060428_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013778_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005903_)))))));
    vlSelf->wasmetal_core__DOT___060446_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060442_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___014245_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005816_)))))));
    vlSelf->wasmetal_core__DOT___018830_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059942_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002472_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018898_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060057_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060056_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060050_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002630_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018914_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060082_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060081_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060075_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002633_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018947_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060128_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060122_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002631_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060163_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060153_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060146_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002632_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060648_ = (1U & (0x440f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xeee0fff0fff0ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060646_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060645_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))));
    vlSelf->wasmetal_core__DOT___019163_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060349_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013737_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006058_)))))));
    vlSelf->wasmetal_core__DOT___019060_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060258_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013798_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005788_)))))));
    vlSelf->__VdfgTmp_h3835a6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h74741c3a__0));
    wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_had1ad578__0))) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0))));
    vlSelf->__VdfgTmp_h10d9a2f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016443_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b38__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058345_))));
    vlSelf->__VdfgTmp_h14d2ff5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058266_));
    wasmetal_core__DOT___016432_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___058266_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058256_))));
    vlSelf->__VdfgTmp_hed92d4b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058256_));
    wasmetal_core__DOT___016459_ = (1U & (IData)((0x1fff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058524_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058356_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbec899f6__0))))));
    vlSelf->wasmetal_core__DOT___016502_ = (1U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfcfaf0f000000000ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O)))))))))))) 
                                                  & (IData)(
                                                            (0xffeefff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017175_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017174_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xff3333f0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                                ? 
                                                                               (0xbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017183_)))
                                                                                : 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___017185_)
                                                                                 ? (IData)(
                                                                                (0xb0000000b000bULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017183_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017182_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013672_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))))))
                                                                                 : 
                                                                                (0x45U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017183_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017182_)))))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___017171_))))))))));
    vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0))) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0))));
    vlSelf->wasmetal_core__DOT___057732_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d)))));
    vlSelf->__VdfgTmp_hd5a7b943__0 = (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_));
    vlSelf->__VdfgTmp_h310e5162__0 = (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_));
    vlSelf->__VdfgTmp_h513c757b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_));
    vlSelf->__VdfgTmp_hafd7ea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015657_));
    vlSelf->wasmetal_core__DOT___057711_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017756_))));
    vlSelf->wasmetal_core__DOT___017599_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013621_))));
    vlSelf->wasmetal_core__DOT___017600_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057725_))));
    vlSelf->__VdfgTmp_h4e8a0148__0 = (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051535_));
    vlSelf->wasmetal_core__DOT___057710_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057701_))));
    wasmetal_core__DOT___013506_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___057695_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057699_))));
    vlSelf->wasmetal_core__DOT___017716_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017640_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___017652_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017623_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017610_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017701_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057699_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___017691_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057699_))));
    wasmetal_core__DOT___042795_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O)) 
                                                      | ((6U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128792___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O))))))));
    wasmetal_core__DOT___042791_ = (1U & (IData)((0xffff8000ULL 
                                                  >> 
                                                  ((0x30U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128792___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                          << 3U)) 
                                                      | (7U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                            >> 1U)))))));
    wasmetal_core__DOT___048954_ = (1U & (0x44f0U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___042760_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(
                                                             (0x8000000000000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                                   << 2U)) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                      << 4U)) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                         << 2U)) 
                                                                     | ((6U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                                            >> 1U)) 
                                                                        | (1U 
                                                                           & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               ((0x30U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                                    << 4U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O))))))))));
    vlSelf->wasmetal_core__DOT___006117_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___042760_)) 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))));
    vlSelf->wasmetal_core__DOT___042754_ = ((IData)(vlSelf->wasmetal_core__DOT___042760_) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___042756_));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005916_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xff03fe02ff03aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd9cc8b65__0))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd9cc8b65__0))))));
    vlSelf->wasmetal_core__DOT___005850_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h18c745e6__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h18c745e6__0)))))));
    vlSelf->wasmetal_core__DOT___005780_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2c009b21__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7136f53f__0)))));
    vlSelf->wasmetal_core__DOT___005781_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127528___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he5d5d55b__0)))
                                                        : 
                                                       (0x302U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8057b5__0)))));
    vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023187_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023250_));
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035963_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d));
    wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
           & (IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018503_ = (1U & ((
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058295_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058297_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058296_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058294_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))) 
                                                   & (IData)(
                                                             (0x8000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016452_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016451_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016450_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016449_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016448_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___016447_))))))))) 
                                                  & ((0x80U 
                                                      >> 
                                                      ((4U 
                                                        & ((0xf00088U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058249_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058241_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058248_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___058242_)))))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058234_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058225_)))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016433_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___016432_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016431_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___058332_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058328_))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016429_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(
                                                                                (0x10ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058309_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058308_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5238d18__0))))))) 
                                                                                & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016444_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016443_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016442_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016441_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heb95d931__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036315_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6a49916d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h513c757b__0));
    vlSelf->wasmetal_core__DOT___057696_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e8a0148__0))));
    vlSelf->wasmetal_core__DOT___017601_ = ((IData)(wasmetal_core__DOT___013506_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013508_));
    vlSelf->wasmetal_core__DOT___017728_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___013506_))));
    vlSelf->__VdfgTmp_haf20b36b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015666_));
    vlSelf->__VdfgTmp_h77210e87__0 = (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->wasmetal_core__DOT___057726_ = (1U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017640_))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                      ? 
                                                     (0x55330f00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he88fe03e__0))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___006178_)))));
    vlSelf->__VdfgTmp_hf223abb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015668_));
    vlSelf->__VdfgTmp_h2f0f6f72__0 = (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_));
    vlSelf->wasmetal_core__DOT___057719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017623_))));
    vlSelf->__VdfgTmp_h692ab415__0 = (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015673_));
    vlSelf->wasmetal_core__DOT___013611_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015671_))))));
    vlSelf->__VdfgTmp_h219534f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015672_));
    vlSelf->__VdfgTmp_hb3fd333a__0 = (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT___017676_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057710_))));
    vlSelf->wasmetal_core__DOT___017576_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___013519_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017589_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017561_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017548_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017531_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057701_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___042788_ = ((IData)(wasmetal_core__DOT___042795_) 
                                            | (IData)(wasmetal_core__DOT___042791_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc322cfc1__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))));
    vlSelf->__VdfgTmp_hce64fd81__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d)));
    vlSelf->__VdfgTmp_hf76f8bb1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d)));
    vlSelf->__VdfgTmp_h90b8d623__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)));
    vlSelf->__VdfgTmp_h3f89240a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)));
    vlSelf->__VdfgTmp_h65d009ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)));
    vlSelf->__VdfgTmp_h7dbcfedb__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006117_));
    vlSelf->__VdfgTmp_h95d04b06__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006117_));
    vlSelf->__VdfgTmp_h04542857__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcc37b29f__0));
    vlSelf->__VdfgTmp_h9195d647__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d)));
    vlSelf->__VdfgTmp_h70d6e582__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)));
    vlSelf->__VdfgTmp_hf5a62b29__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)));
    vlSelf->__VdfgTmp_h84f7054c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)));
    vlSelf->__VdfgTmp_hdf4ff5ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d)));
    vlSelf->__VdfgTmp_h767f4755__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)));
    vlSelf->__VdfgTmp_h93626d60__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d)));
    vlSelf->__VdfgTmp_hc5b0708b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d)));
    vlSelf->__VdfgTmp_hff1a4828__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)));
    vlSelf->__VdfgTmp_h105c18f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)));
    vlSelf->__VdfgTmp_h3dc01c55__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)));
    vlSelf->__VdfgTmp_h2bde81d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d)));
    vlSelf->__VdfgTmp_h7297059c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d)));
    vlSelf->__VdfgTmp_h1b003ae2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)));
    vlSelf->__VdfgTmp_h89d2961b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d)));
    vlSelf->__VdfgTmp_hf97b813d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)));
    vlSelf->__VdfgTmp_h15d2d521__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)));
    vlSelf->__VdfgTmp_hf30cf57d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d)));
    vlSelf->__VdfgTmp_h9cb72e5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d)));
    vlSelf->__VdfgTmp_h5721c23b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)));
    vlSelf->__VdfgTmp_h7d7923ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)));
    vlSelf->__VdfgTmp_h7f56c529__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)));
    vlSelf->__VdfgTmp_h16c6eb53__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d)));
    vlSelf->__VdfgTmp_he5f506d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)));
    vlSelf->__VdfgTmp_h885d0717__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)));
    vlSelf->__VdfgTmp_h1caccec5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)));
    vlSelf->__VdfgTmp_h4b8dd412__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)));
    vlSelf->__VdfgTmp_h6a2ef1d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)));
    vlSelf->__VdfgTmp_h030e49d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d)));
    vlSelf->__VdfgTmp_h77324dc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d)));
    vlSelf->__VdfgTmp_hfd12f0c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)));
    vlSelf->__VdfgTmp_heb875033__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he488fa83__0));
    vlSelf->__VdfgTmp_h04659776__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)));
    vlSelf->__VdfgTmp_hc17e62e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)));
    vlSelf->wasmetal_core__DOT___048955_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128780___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048957_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128780___O))))));
    vlSelf->wasmetal_core__DOT___048958_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048956_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___014455_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048954_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O)))))));
    vlSelf->wasmetal_core__DOT___014456_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048954_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128779___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___035398_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  | ((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                     | (IData)(
                                                               (0x80000000ffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006116_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006115_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006113_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006112_)))))))))));
    vlSelf->wasmetal_core__DOT___057899_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d))));
    vlSelf->wasmetal_core__DOT___057918_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d))));
    vlSelf->wasmetal_core__DOT___057938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d))));
    vlSelf->wasmetal_core__DOT___058018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d))));
    vlSelf->wasmetal_core__DOT___058000_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d))));
    vlSelf->wasmetal_core__DOT___057955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d))));
    vlSelf->wasmetal_core__DOT___057954_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d))));
    vlSelf->wasmetal_core__DOT___057965_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d))));
    vlSelf->wasmetal_core__DOT___057968_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d))));
    vlSelf->wasmetal_core__DOT___057959_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d))));
    vlSelf->wasmetal_core__DOT___057961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d 
        = (1U & (IData)((0xfcccfaaaf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d 
        = (1U & (IData)((0xfaaafcccf000f000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbb788d21__0))))))));
    vlSelf->__VdfgTmp_h1cbe113f__0 = (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128884___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036490_)))));
    vlSelf->wasmetal_core__DOT___036494_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006194_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf9e966c8__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006232_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006038_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005783_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005782_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005780_)))))))))));
    vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023188_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035964_)
            ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127495___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h8f31d0f1__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_had1ad578__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023013_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d) 
                                            & (IData)(wasmetal_core__DOT___127495___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017938_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018505_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018507_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018503_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))));
    vlSelf->wasmetal_core__DOT___017937_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058532_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058531_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018503_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (((1U 
                                                                    & (0xe000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))
                                                                    ? 
                                                                   (1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                                    : (IData)(
                                                                              (0xffffff8fffffffULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015954_))))))))) 
                                                                  & (IData)(
                                                                            (0x8000000000000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016460_) 
                                                                               << 5U) 
                                                                              | (((IData)(wasmetal_core__DOT___016459_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016458_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbec899f6__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058341_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1ff00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058248_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc888fbf4__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058346_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058345_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058338_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058350_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058349_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058348_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058347_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___013612_ = (1U & (0xeU 
                                                  >> 
                                                  ((((~ (IData)(vlSelf->wasmetal_core__DOT___013621_)) 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___013508_)) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017728_)))));
    vlSelf->__VdfgTmp_h25476d0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017728_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_));
    vlSelf->wasmetal_core__DOT___013381_ = (1U & (IData)(
                                                         (0xefefef00efefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017701_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015671_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017728_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf20b36b__0))))))));
    vlSelf->wasmetal_core__DOT___013379_ = (1U & (IData)(
                                                         (0xefefef00efefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h692ab415__0))))))));
    vlSelf->wasmetal_core__DOT___058982_ = (1U & (0xeeeef0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017623_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h219534f4__0))))));
    vlSelf->__VdfgTmp_h7594c868__0 = (((IData)(vlSelf->wasmetal_core__DOT___017676_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015674_));
    vlSelf->wasmetal_core__DOT___013613_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015656_))))));
    vlSelf->__VdfgTmp_h46466860__0 = (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013520_));
    vlSelf->__VdfgTmp_h8c0ae79e__0 = (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_));
    vlSelf->wasmetal_core__DOT___057712_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017599_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017576_)))))));
    vlSelf->wasmetal_core__DOT___057722_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017676_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013519_))));
    vlSelf->__VdfgTmp_h9ce496ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015678_));
    vlSelf->wasmetal_core__DOT___013524_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015676_))))));
    vlSelf->__VdfgTmp_h3d32f603__0 = (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT___013380_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017600_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017561_)))))));
    vlSelf->wasmetal_core__DOT___013522_ = (1U & (0xe0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xefU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017548_))))));
    vlSelf->__VdfgTmp_h9110e1f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___017548_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_));
    vlSelf->wasmetal_core__DOT___017598_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017548_))));
    vlSelf->__VdfgTmp_h0bc68a5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017531_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_));
    vlSelf->wasmetal_core__DOT___057703_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017531_))));
    vlSelf->wasmetal_core__DOT___057707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017548_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017531_))));
    vlSelf->__VdfgTmp_h56cb633a__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0))));
    vlSelf->__VdfgTmp_ha3ec838c__0 = ((4U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                << 1U)) 
                                         | (1U & (0x53U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)))));
    vlSelf->__VdfgTmp_hed9f0c33__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0))));
    vlSelf->wasmetal_core__DOT___058043_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h93626d60__0))))))));
    vlSelf->wasmetal_core__DOT___058044_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0))))));
    vlSelf->__VdfgTmp_hff1952b3__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0))));
    vlSelf->__VdfgTmp_he122bc0f__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0))));
    vlSelf->__VdfgTmp_hdb52a936__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))));
    vlSelf->wasmetal_core__DOT___057787_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0))))));
    vlSelf->__VdfgTmp_h91cdf6cd__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))));
    vlSelf->wasmetal_core__DOT___013631_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048955_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048957_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048958_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___014357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048956_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048954_))));
    vlSelf->wasmetal_core__DOT___057957_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))));
    vlSelf->wasmetal_core__DOT___057934_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)))))));
    vlSelf->wasmetal_core__DOT___014453_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)))))));
    vlSelf->wasmetal_core__DOT___057935_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc322cfc1__0))))));
    vlSelf->wasmetal_core__DOT___014460_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcc37b29f__0))))));
    vlSelf->wasmetal_core__DOT___057914_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)))))));
    vlSelf->wasmetal_core__DOT___057913_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)))))));
    vlSelf->wasmetal_core__DOT___057929_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)))))));
    vlSelf->wasmetal_core__DOT___057911_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))))));
    vlSelf->wasmetal_core__DOT___057912_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0)))));
    vlSelf->wasmetal_core__DOT___057909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04659776__0))))));
    vlSelf->wasmetal_core__DOT___057910_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0))))));
    vlSelf->wasmetal_core__DOT___057928_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_heb875033__0))))));
    vlSelf->wasmetal_core__DOT___057930_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)))))));
    vlSelf->wasmetal_core__DOT___057931_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)))))));
    vlSelf->wasmetal_core__DOT___057933_ = (1U & (0x5533f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h04659776__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))))));
    vlSelf->wasmetal_core__DOT___057932_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_heb875033__0)))))));
    vlSelf->wasmetal_core__DOT___057976_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))))))));
    vlSelf->wasmetal_core__DOT___058057_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)))))))))));
    vlSelf->wasmetal_core__DOT___058029_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)))))))))));
    vlSelf->wasmetal_core__DOT___058034_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)))))))))));
    vlSelf->wasmetal_core__DOT___058025_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)))))))))));
    vlSelf->wasmetal_core__DOT___014446_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)))))))))));
    vlSelf->wasmetal_core__DOT___014354_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))))))));
    vlSelf->wasmetal_core__DOT___014353_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)))))))))));
    vlSelf->wasmetal_core__DOT___014959_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048958_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048957_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048956_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048955_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014456_)))))));
    vlSelf->wasmetal_core__DOT___057908_ = (1U & (IData)(
                                                         (0xb00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x53U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))))));
    vlSelf->wasmetal_core__DOT___057916_ = (1U & (0xf0f000bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95d04b06__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057899_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___057926_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___057939_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT___058019_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058018_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___058010_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058000_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___058031_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006117_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___058046_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))));
    vlSelf->wasmetal_core__DOT___057978_ = (1U & (IData)(
                                                         (0x5555333300ff000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))))));
    vlSelf->wasmetal_core__DOT___057956_ = (1U & (IData)(
                                                         (0xf0f030300ff0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057955_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he29625ac__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d 
        = (1U & (0xfcfaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057954_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___057969_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057965_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->__VdfgTmp_ha1cc8027__0 = (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___057963_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___057962_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006117_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d 
        = (1U & (0xfafcf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___042754_) 
                                  << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128775___O) 
                                                   << 3U)) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___057961_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___035659_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___035636_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d))));
    vlSelf->wasmetal_core__DOT___035630_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d))));
    vlSelf->wasmetal_core__DOT___035629_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d))));
    vlSelf->wasmetal_core__DOT___035628_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d))));
    vlSelf->wasmetal_core__DOT___035627_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d))));
    vlSelf->wasmetal_core__DOT___035626_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d))));
    vlSelf->wasmetal_core__DOT___035625_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d))));
    vlSelf->wasmetal_core__DOT___035624_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d))));
    vlSelf->wasmetal_core__DOT___035623_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d))));
    vlSelf->wasmetal_core__DOT___035673_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d))));
    vlSelf->wasmetal_core__DOT___035672_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d))));
    vlSelf->wasmetal_core__DOT___035653_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035642_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035631_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d 
        = (1U & (8U >> ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d 
        = (1U & (0xf888U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057918_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d 
        = (1U & (0xfffff888U >> (((IData)(vlSelf->wasmetal_core__DOT___057938_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                             << 3U) 
                                            | ((4U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                   << 2U)) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d 
        = (1U & (IData)((0xfffff888f888f888ULL >> (
                                                   (0x20U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d 
        = (1U & (0xf888U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1cbe113f__0))))))));
    vlSelf->wasmetal_core__DOT___060270_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058496_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036494_));
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023189_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128803___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035965_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035964_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035963_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035962_)))) 
           ^ (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035905_)))));
    vlSelf->wasmetal_core__DOT___035909_ = ((IData)(vlSelf->wasmetal_core__DOT___035965_)
                                             ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d));
    vlSelf->__VdfgTmp_he6069ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h69683dae__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h42022071__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__ 
        = ((0xf10eU >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023013_));
    vlSelf->wasmetal_core__DOT___059445_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00aaaafc0cfc0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058241_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058242_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127495___O) 
                                                                                >> 3U))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9aa3e645__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e80d283__0)))))))))));
    vlSelf->wasmetal_core__DOT___017482_ = (1U & ((0xeee0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017623_))))) 
                                                  & ((0xeee0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017676_))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013613_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013612_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013611_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xeee0U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015665_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017716_))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017652_))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xeee0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015658_))))))))))))))));
    vlSelf->wasmetal_core__DOT___058980_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015677_)))))))));
    vlSelf->wasmetal_core__DOT___013378_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057722_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))));
    wasmetal_core__DOT___058981_ = (1U & (0xeeeef0ffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))));
    vlSelf->wasmetal_core__DOT___017483_ = (1U & ((
                                                   (0xf70000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013319_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___013549_)))))) 
                                                   & (IData)(
                                                             (0x4000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___013540_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013539_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013538_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((IData)(vlSelf->wasmetal_core__DOT___013549_)
                                                                              ? (IData)(
                                                                                (0xeee0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013546_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013545_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b65f112__0)))))))
                                                                              : 
                                                                             (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___013547_)))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x8fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013335_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013503_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf3f5f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017531_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he3b69f57__0))))))))))))) 
                                                  & ((0x8000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017385_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017427_))))) 
                                                     & (IData)(
                                                               (0xe000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013524_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013523_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013522_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057732_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013519_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128848___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036315_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036342_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___013208_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057703_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    wasmetal_core__DOT___013207_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057707_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___057950_ = (1U & (IData)((0xff00aaaaccccf0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    __VdfgTmp_h7a1a10ae__0 = ((4U & ((0x53U >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0));
    wasmetal_core__DOT___058056_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    wasmetal_core__DOT___058042_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014360_))));
    vlSelf->__VdfgTmp_hb0772ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013631_));
    vlSelf->wasmetal_core__DOT___058037_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014357_))));
    vlSelf->__VdfgTmp_hd09be45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014358_));
    vlSelf->wasmetal_core__DOT___014372_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))));
    __VdfgTmp_hb2511b98__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___014453_) 
                                           << 2U) | 
                                          ((2U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                  << 1U)) 
                                           | (1U & 
                                              (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))));
    vlSelf->wasmetal_core__DOT___014371_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057935_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    vlSelf->wasmetal_core__DOT___014461_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057935_)))));
    vlSelf->wasmetal_core__DOT___014374_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___014383_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    wasmetal_core__DOT___014447_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)))))))));
    __VdfgTmp_hba696de2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057913_));
    wasmetal_core__DOT___014382_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057929_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___019684_ = (1U & (0xf011U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057913_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057911_))))));
    wasmetal_core__DOT___057915_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057911_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057910_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___057909_)))))));
    vlSelf->wasmetal_core__DOT___019683_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057928_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057909_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057910_))))));
    __VdfgTmp_h9dc510af__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057928_));
    vlSelf->wasmetal_core__DOT___014373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057929_)))));
    vlSelf->wasmetal_core__DOT___019676_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057931_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h98614ec5__0 = (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057931_));
    wasmetal_core__DOT___057936_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h8453cf34__0 = (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057932_));
    wasmetal_core__DOT___014381_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057932_))));
    vlSelf->wasmetal_core__DOT___071749_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014446_))));
    vlSelf->__VdfgTmp_h51e83899__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___005668_ = (1U & (IData)(
                                                         (0xdf2f20d00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))));
    wasmetal_core__DOT___014454_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)))))))));
    vlSelf->wasmetal_core__DOT___019668_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014453_)))));
    vlSelf->wasmetal_core__DOT___035645_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d))));
    vlSelf->wasmetal_core__DOT___057927_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))))));
    wasmetal_core__DOT___058054_ = (1U & (IData)((0xaaaaccccff00f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)))))))))));
    wasmetal_core__DOT___058027_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)))))))))));
    wasmetal_core__DOT___058032_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)))))))))));
    vlSelf->wasmetal_core__DOT___057940_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057939_)))))))));
    wasmetal_core__DOT___058023_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058019_)))))))));
    vlSelf->wasmetal_core__DOT___035634_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058041_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7297059c__0))))))));
    wasmetal_core__DOT___058055_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058010_)))))))));
    vlSelf->wasmetal_core__DOT___058028_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)))))))))));
    vlSelf->wasmetal_core__DOT___058033_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___058024_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___035633_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d))));
    vlSelf->wasmetal_core__DOT___035622_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d))));
    vlSelf->wasmetal_core__DOT___058059_ = (1U & (0xf0f000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057978_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014455_)))))));
    vlSelf->wasmetal_core__DOT___057971_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057957_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057956_)))));
    vlSelf->wasmetal_core__DOT___058026_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0))))));
    vlSelf->wasmetal_core__DOT___035621_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d))));
    wasmetal_core__DOT___057979_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057969_)))));
    vlSelf->wasmetal_core__DOT___035671_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d))));
    __VdfgTmp_h63472758__0 = (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0));
    vlSelf->wasmetal_core__DOT___035670_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d))));
    wasmetal_core__DOT___057977_ = (1U & (0xf0f000bbU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0))))));
    vlSelf->wasmetal_core__DOT___035669_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))));
    wasmetal_core__DOT___014440_ = (1U & (0x8000U >> 
                                          ((8U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057962_))))));
    vlSelf->wasmetal_core__DOT___058061_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    wasmetal_core__DOT___057970_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057962_)))));
    vlSelf->wasmetal_core__DOT___035664_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d))));
    vlSelf->wasmetal_core__DOT___035667_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d))));
    vlSelf->wasmetal_core__DOT___035666_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d))));
    vlSelf->wasmetal_core__DOT___035665_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d))));
    vlSelf->wasmetal_core__DOT___035663_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035662_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035661_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d))));
    vlSelf->wasmetal_core__DOT___035660_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___035658_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___035657_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___035656_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___035655_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035654_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035652_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d))));
    vlSelf->wasmetal_core__DOT___035651_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d))));
    vlSelf->wasmetal_core__DOT___035650_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035649_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035648_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d))));
    vlSelf->wasmetal_core__DOT___035647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d))));
    vlSelf->wasmetal_core__DOT___035646_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d))));
    vlSelf->wasmetal_core__DOT___035644_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d))));
    vlSelf->wasmetal_core__DOT___035643_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d))));
    vlSelf->wasmetal_core__DOT___035641_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d))));
    vlSelf->wasmetal_core__DOT___035640_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d))));
    vlSelf->wasmetal_core__DOT___035639_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d))));
    vlSelf->wasmetal_core__DOT___035638_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d))));
    vlSelf->wasmetal_core__DOT___035637_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d))));
    vlSelf->wasmetal_core__DOT___035635_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d))));
    vlSelf->wasmetal_core__DOT___035632_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d))));
    vlSelf->wasmetal_core__DOT___035620_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127529___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023187_)))) 
           ^ (((IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023250_)))));
    vlSelf->wasmetal_core__DOT___023254_ = ((IData)(vlSelf->wasmetal_core__DOT___023190_) 
                                            & (IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053611_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053598_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035966_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035909_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d));
    vlSelf->wasmetal_core__DOT___059355_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0)))))))))));
    vlSelf->wasmetal_core__DOT___059254_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                   ? 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))
                                                                   : 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))))))))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017485_ = ((1U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017601_))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefef00efU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h219534f4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xefef00efU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h310e5162__0)))))))))))));
    vlSelf->wasmetal_core__DOT___017591_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058982_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058981_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058980_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___017601_)) 
                                                                         & (IData)(
                                                                                (0xb0bbb0bb0000b0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017600_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015681_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057711_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xefefef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d32f603__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9110e1f3__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036342_));
    wasmetal_core__DOT___057713_ = (1U & ((IData)((0xef0000ffffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___057697_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057696_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))))))) 
                                          & (IData)(
                                                    (0xcc000000f5ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                       << 5U) 
                                                      | (((IData)(wasmetal_core__DOT___013208_) 
                                                          << 4U) 
                                                         | (((IData)(wasmetal_core__DOT___013207_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013205_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___013204_))))))))));
    vlSelf->wasmetal_core__DOT___057985_ = (1U & (0xfefeff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___057950_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))))))));
    vlSelf->wasmetal_core__DOT___058030_ = (1U & (IData)(
                                                         (0xccccaaaaf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->wasmetal_core__DOT___058035_ = (1U & (IData)(
                                                         (0xff00ccaaaaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->__VdfgTmp_ha0dc9087__0 = (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058056_));
    vlSelf->wasmetal_core__DOT___058045_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014358_))));
    vlSelf->wasmetal_core__DOT___058040_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccc0c0f000aa00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058068_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56cb633a__0))))))));
    vlSelf->wasmetal_core__DOT___057906_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0))))));
    vlSelf->wasmetal_core__DOT___057907_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xa0c0f0f0f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057787_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xe000000000000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((0x53U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb875033__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h04659776__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014358_)))))))))))));
    vlSelf->wasmetal_core__DOT___019685_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hb2511b98__0)))));
    vlSelf->__VdfgTmp_h5970a25a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    vlSelf->__VdfgTmp_he15aac2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    if (vlSelf->wasmetal_core__DOT___014357_) {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014461_)));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___014454_)));
    } else {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (IData)(wasmetal_core__DOT___014383_));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> (IData)(__VdfgTmp_hb2511b98__0)));
    }
    vlSelf->wasmetal_core__DOT___019669_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hba696de2__0))));
    vlSelf->__VdfgTmp_hd4b4ff41__0 = (((IData)(wasmetal_core__DOT___014383_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014382_));
    __VdfgTmp_h32a58059__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___019684_))));
    vlSelf->wasmetal_core__DOT___019688_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___014447_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019684_)))));
    vlSelf->wasmetal_core__DOT___014356_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057915_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hba696de2__0))))));
    __VdfgTmp_h836204cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019683_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___014447_)))));
    vlSelf->wasmetal_core__DOT___071762_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019683_))))));
    vlSelf->wasmetal_core__DOT___071742_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014447_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___019684_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014446_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019683_)))))))));
    vlSelf->__VdfgTmp_h06185798__0 = (((IData)(wasmetal_core__DOT___019684_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019683_));
    vlSelf->wasmetal_core__DOT___019670_ = (1U & (0xf077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___057915_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9dc510af__0)))));
    wasmetal_core__DOT___014355_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h9dc510af__0))));
    __VdfgTmp_hbb8e97f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014373_));
    __VdfgTmp_hf87abe5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019676_));
    vlSelf->wasmetal_core__DOT___019696_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014382_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    vlSelf->wasmetal_core__DOT___014384_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057936_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    wasmetal_core__DOT___019677_ = (1U & (0x3500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h8453cf34__0)))));
    wasmetal_core__DOT___014375_ = (1U & (0xf0f0ccaaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019676_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h8453cf34__0))))));
    vlSelf->wasmetal_core__DOT___019758_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___014381_))))));
    __VdfgTmp_h3fbd9b9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    __VdfgTmp_h78b7c78d__0 = (((IData)(wasmetal_core__DOT___057936_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    wasmetal_core__DOT___051265_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005668_))));
    vlSelf->__VdfgTmp_h51855551__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019668_));
    vlSelf->wasmetal_core__DOT___014359_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057927_))))));
    vlSelf->wasmetal_core__DOT___071751_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___014454_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058054_))))));
    vlSelf->wasmetal_core__DOT___019710_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058027_))))));
    vlSelf->wasmetal_core__DOT___019706_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058032_))))));
    vlSelf->wasmetal_core__DOT___014385_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014461_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057940_))))));
    vlSelf->wasmetal_core__DOT___019698_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058023_))))));
    vlSelf->wasmetal_core__DOT___058050_ = (1U & (0xfafcffffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058041_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058043_)))))));
    __VdfgTmp_hf3511969__0 = (((IData)(wasmetal_core__DOT___058055_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058054_));
    vlSelf->__VdfgTmp_h17641de8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058028_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058027_));
    vlSelf->__VdfgTmp_hb21fd03f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058033_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058032_));
    vlSelf->__VdfgTmp_h3ea29050__0 = (((IData)(vlSelf->wasmetal_core__DOT___058024_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058023_));
    vlSelf->wasmetal_core__DOT___071750_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058056_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___058055_)))))))));
    vlSelf->wasmetal_core__DOT___057980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057978_)))));
    vlSelf->wasmetal_core__DOT___057972_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h63472758__0))))));
    vlSelf->__VdfgTmp_hfa4aa235__0 = ((2U & ((IData)(
                                                     (0xf4f400ff00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                           << 4U) 
                                                          | (IData)(__VdfgTmp_h63472758__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___057957_)))));
    vlSelf->wasmetal_core__DOT___058060_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057977_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057979_)))));
    vlSelf->wasmetal_core__DOT___057981_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)))))))));
    vlSelf->wasmetal_core__DOT___058051_ = (1U & ((1U 
                                                   & (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))
                                                   ? (IData)(
                                                             (0xfeccaa00c0c00000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                      << 4U)) 
                                                                  | (((IData)(wasmetal_core__DOT___014440_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xb00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0))))))))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   ((4U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd09be45d__0)))));
    vlSelf->__VdfgTmp_h625062d0__0 = (((IData)(wasmetal_core__DOT___057970_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014456_));
    vlSelf->wasmetal_core__DOT___057975_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057970_))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035620_) 
           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d));
    wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006166_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hde955cd8__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hde955cd8__0)))))));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023192_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023254_));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035967_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h3d32f603__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017590_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xefefef00efefefefULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057713_)))));
    vlSelf->wasmetal_core__DOT___017484_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057713_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057712_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057711_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015657_)))))))));
    vlSelf->wasmetal_core__DOT___071723_ = (1U & (0xccaafff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057950_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057971_)))))));
    vlSelf->wasmetal_core__DOT___019690_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014446_)))));
    vlSelf->__VdfgTmp_h2a7b33bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___019669_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___035375_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((1U 
                                                          & (0xdf2f20dU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0x50003000U 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0x4000U 
                                                           >> (IData)(__VdfgTmp_h32a58059__0)))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0xafffcfffU 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0xbfffU 
                                                           >> (IData)(__VdfgTmp_h32a58059__0))))))));
    vlSelf->wasmetal_core__DOT___035384_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04659776__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071762_))))));
    vlSelf->__VdfgTmp_h74456d25__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071742_)));
    vlSelf->wasmetal_core__DOT___035379_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x3500000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h06185798__0))))))))))));
    vlSelf->wasmetal_core__DOT___071753_ = (1U & (0xf0aaccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014447_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06185798__0))))));
    vlSelf->wasmetal_core__DOT___071758_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019670_))));
    vlSelf->wasmetal_core__DOT___071763_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    if (vlSelf->wasmetal_core__DOT___014358_) {
        vlSelf->wasmetal_core__DOT___071735_ = (1U 
                                                & (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014355_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))));
        vlSelf->wasmetal_core__DOT___071728_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___019690_)
                                                    : 
                                                   (0xbU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___019683_)))));
    } else {
        vlSelf->wasmetal_core__DOT___071735_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014356_))));
        vlSelf->wasmetal_core__DOT___071728_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014360_)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019688_)));
    }
    vlSelf->wasmetal_core__DOT___014363_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014356_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    vlSelf->__VdfgTmp_h42589940__0 = (((IData)(vlSelf->wasmetal_core__DOT___019697_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019696_));
    vlSelf->__VdfgTmp_h09be8eb6__0 = (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                     ? 
                                                    (0xf0cc55ffU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___014383_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___014382_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___014381_))))))
                                                     : 
                                                    (0xbU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014384_))))));
    vlSelf->wasmetal_core__DOT___071760_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019677_)))));
    if (vlSelf->wasmetal_core__DOT___014360_) {
        if (vlSelf->wasmetal_core__DOT___014358_) {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he15aac2f__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5970a25a__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014385_)));
            vlSelf->wasmetal_core__DOT___071721_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h51855551__0))));
        } else {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hf87abe5d__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hbb8e97f6__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014385_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))));
            vlSelf->wasmetal_core__DOT___071721_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h2a7b33bb__0))));
        }
        vlSelf->wasmetal_core__DOT___013627_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014359_)) 
                                                   & (0xffcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___071725_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (1U 
                                                      >> (IData)(wasmetal_core__DOT___019677_))));
        vlSelf->wasmetal_core__DOT___013628_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (2U 
                                                      >> (IData)(wasmetal_core__DOT___014375_))));
        vlSelf->wasmetal_core__DOT___013629_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___014384_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(__VdfgTmp_h3fbd9b9f__0))));
        vlSelf->wasmetal_core__DOT___071721_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019670_))));
        vlSelf->wasmetal_core__DOT___013627_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014363_));
    }
    vlSelf->__VdfgTmp_hd8777223__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___019677_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf87abe5d__0)));
    vlSelf->wasmetal_core__DOT___019724_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___014375_))));
    vlSelf->__VdfgTmp_h929e6874__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___014375_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbb8e97f6__0))));
    vlSelf->wasmetal_core__DOT___035385_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019758_))))));
    vlSelf->wasmetal_core__DOT___019713_ = (1U & (0xf880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014384_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3fbd9b9f__0))))));
    vlSelf->wasmetal_core__DOT___035372_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f33aa00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019696_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h78b7c78d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___019695_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h78b7c78d__0))));
    vlSelf->wasmetal_core__DOT___035703_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___035702_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___035712_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___035711_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    vlSelf->wasmetal_core__DOT___035710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___035709_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT___035683_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___035682_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___035681_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d)))));
    vlSelf->wasmetal_core__DOT___035680_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___035679_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___035676_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)))));
    vlSelf->__VdfgTmp_h4eafc8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014448_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___014447_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014446_)));
    vlSelf->wasmetal_core__DOT___019751_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014454_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058056_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hf3511969__0))))))));
    vlSelf->wasmetal_core__DOT___058058_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf3511969__0))));
    vlSelf->wasmetal_core__DOT___071737_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014371_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17641de8__0))))))));
    __VdfgTmp_hf656a041__0 = (((IData)(vlSelf->wasmetal_core__DOT___058029_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h17641de8__0));
    wasmetal_core__DOT___071733_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb21fd03f__0))))))));
    __VdfgTmp_h6ff3b264__0 = (((IData)(vlSelf->wasmetal_core__DOT___058034_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb21fd03f__0));
    wasmetal_core__DOT___019760_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014461_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h3ea29050__0))))))));
    __VdfgTmp_h0c9bc85d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058025_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h3ea29050__0));
    vlSelf->wasmetal_core__DOT___071720_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057980_))))));
    vlSelf->wasmetal_core__DOT___058067_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa4aa235__0)))));
    vlSelf->wasmetal_core__DOT___058064_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058059_)))));
    vlSelf->wasmetal_core__DOT___071719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057981_))));
    vlSelf->wasmetal_core__DOT___057984_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057980_)))));
    vlSelf->wasmetal_core__DOT___057982_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057972_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057971_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h625062d0__0))))));
    vlSelf->wasmetal_core__DOT___057983_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057976_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057975_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfa4aa235__0))))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035631_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128885___O 
        = (((8U & ((0x4bU >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036494_)))));
    vlSelf->wasmetal_core__DOT___036498_ = ((0x4bU 
                                             >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                                            & (IData)(wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023193_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127496___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0xf10eU 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023013_)))));
    vlSelf->wasmetal_core__DOT___023017_ = ((6U >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9ce496ce__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017532_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017485_))))));
    vlSelf->wasmetal_core__DOT___017533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017484_))));
    vlSelf->__VdfgTmp_hf1e8a9a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019670_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2a7b33bb__0))));
    vlSelf->wasmetal_core__DOT___035371_ = (1U & (0x40bfbf40U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74456d25__0)))));
    vlSelf->wasmetal_core__DOT___035358_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0fe0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___071751_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019685_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___071749_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071753_)))))))));
    vlSelf->wasmetal_core__DOT___035342_ = (1U & (IData)(
                                                         (0x5530aacfaacf5530ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071753_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff00ff000000f1f1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071751_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071750_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071749_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019685_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___035382_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071758_)))))));
    vlSelf->wasmetal_core__DOT___035386_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_heb875033__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071763_))))));
    vlSelf->wasmetal_core__DOT___035368_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071735_))))));
    vlSelf->wasmetal_core__DOT___035377_ = (1U & (0x40bfbf40U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014363_)))))));
    vlSelf->wasmetal_core__DOT___058071_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42589940__0))));
    vlSelf->wasmetal_core__DOT___035367_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09be8eb6__0)))));
    vlSelf->wasmetal_core__DOT___035383_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071760_))))));
    vlSelf->wasmetal_core__DOT___035365_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071725_))))));
    vlSelf->wasmetal_core__DOT___035357_ = (1U & (0xe01f1fe0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x33550000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd8777223__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f5f0f300000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019710_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he15aac2f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___071748_ = (1U & (IData)(
                                                         (0x3355f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd8777223__0))))));
    vlSelf->wasmetal_core__DOT___035378_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019724_)))))));
    vlSelf->wasmetal_core__DOT___035361_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013628_))))));
    vlSelf->wasmetal_core__DOT___071739_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h929e6874__0)))));
    vlSelf->wasmetal_core__DOT___035376_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019713_))))));
    vlSelf->__VdfgTmp_hf6f65f53__0 = (((IData)(vlSelf->wasmetal_core__DOT___019696_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019695_));
    vlSelf->wasmetal_core__DOT___019734_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019695_))));
    vlSelf->wasmetal_core__DOT___035701_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035676_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005668_)))));
    vlSelf->wasmetal_core__DOT___058065_ = (1U & ((~ 
                                                   (0x3050000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h06185798__0)))))) 
                                                  & (IData)(
                                                            (0xf0fff0ffaaffccffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4eafc8bd__0))))))));
    vlSelf->wasmetal_core__DOT___035359_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013629_))))));
    vlSelf->wasmetal_core__DOT___035350_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071762_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019751_))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___019690_)
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___019688_))))))))));
    vlSelf->__VdfgTmp_hc1e5da71__0 = (((IData)(vlSelf->wasmetal_core__DOT___014448_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058058_));
    vlSelf->wasmetal_core__DOT___019728_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058058_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha0dc9087__0))))));
    vlSelf->wasmetal_core__DOT___035353_ = (1U & (IData)(
                                                         (0x3050cfafcfaf3050ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071737_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xccaaf0f0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h929e6874__0)))))))))));
    vlSelf->wasmetal_core__DOT___019744_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf656a041__0)))))));
    vlSelf->wasmetal_core__DOT___019725_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf656a041__0)))))));
    vlSelf->wasmetal_core__DOT___035352_ = (1U & (IData)(
                                                         (0x3fcfc03aa5555aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xdf2f20dU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0xcaU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___071733_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014356_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071763_)))))))));
    vlSelf->wasmetal_core__DOT___019737_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6ff3b264__0)))))));
    vlSelf->wasmetal_core__DOT___019720_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6ff3b264__0)))))));
    vlSelf->wasmetal_core__DOT___035351_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                   ? 
                                                  (0x35caca35U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 4U)) 
                                                    | ((8U 
                                                        & ((0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___019760_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xccaaf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014384_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))))))))))
                                                   : 
                                                  (0x96U 
                                                   >> 
                                                   ((4U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019758_))))));
    vlSelf->wasmetal_core__DOT___019733_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h0c9bc85d__0)))))));
    vlSelf->wasmetal_core__DOT___019715_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h0c9bc85d__0)))))));
    vlSelf->wasmetal_core__DOT___035389_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057984_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058034_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(wasmetal_core__DOT___071733_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071735_)))))));
    vlSelf->wasmetal_core__DOT___035388_ = (1U & (0xf10e0ef1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x3500U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057983_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058025_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(wasmetal_core__DOT___019760_))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h09be8eb6__0))))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035642_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d));
    vlSelf->wasmetal_core__DOT___060286_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058497_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O))))))));
    vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036498_));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023194_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128804___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035969_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035968_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035967_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035966_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035909_)))));
    vlSelf->wasmetal_core__DOT___035913_ = ((IData)(vlSelf->wasmetal_core__DOT___035969_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d));
    vlSelf->__VdfgTmp_h3d6ee6a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
}
