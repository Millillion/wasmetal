#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__14(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__14\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___030769_;
    wasmetal_core__DOT___030769_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030777_;
    wasmetal_core__DOT___030777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031160_;
    wasmetal_core__DOT___031160_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031448_;
    wasmetal_core__DOT___031448_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031727_;
    wasmetal_core__DOT___031727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031731_;
    wasmetal_core__DOT___031731_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031735_;
    wasmetal_core__DOT___031735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032471_;
    wasmetal_core__DOT___032471_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034946_;
    wasmetal_core__DOT___034946_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128710___O;
    wasmetal_core__DOT____Vcellout___128710___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__ = 0;
    // Body
    wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035140_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035074_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128693___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034942_)))));
    wasmetal_core__DOT___034946_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128301___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030833_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030832_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030830_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030829_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030764_)))));
    wasmetal_core__DOT___030769_ = ((IData)(vlSelf->wasmetal_core__DOT___030833_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d));
    wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032530_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032530_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128381___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031791_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031790_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031788_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031787_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031722_)))));
    wasmetal_core__DOT___031727_ = ((IData)(vlSelf->wasmetal_core__DOT___031791_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d));
    wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034687_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034750_));
    wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035141_)
            ? (IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d));
    wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)) 
           & (IData)(wasmetal_core__DOT___034946_));
    wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030834_)
            ? (IData)(wasmetal_core__DOT___030769_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128334___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031152_)))));
    vlSelf->wasmetal_core__DOT___031156_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)
                                             : (IData)(wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128358___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031440_)))));
    vlSelf->wasmetal_core__DOT___031444_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)
                                             : (IData)(wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128446___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032531_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032530_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032529_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032528_)))) 
           ^ (((IData)(wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032463_)))));
    vlSelf->wasmetal_core__DOT___032467_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032531_)
                                                   ? (IData)(wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032531_))));
    wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031792_)
            ? (IData)(wasmetal_core__DOT___031727_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d));
    wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034688_) 
           & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128710___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035143_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035142_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035141_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035140_)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___035142_)
                                                       ? (IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035074_)))));
    wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)) 
           & (IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030835_)
            ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031156_));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031444_));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032532_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032467_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032532_))));
    wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031793_)
            ? (IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d));
    wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034689_) 
           & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___034695_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___034694_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___034693_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128710___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d)))));
    vlSelf->wasmetal_core__DOT___034692_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128694___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)) 
                & (IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034946_)))));
    wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030836_)
            ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032533_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032533_))));
    vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031794_)
            ? (IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128677___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034690_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034687_)))) 
           ^ (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034750_)))));
    vlSelf->wasmetal_core__DOT___034754_ = ((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                            & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128302___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030837_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030836_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030835_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030834_)))) 
           ^ (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030769_)))));
    vlSelf->wasmetal_core__DOT___030773_ = ((IData)(vlSelf->wasmetal_core__DOT___030837_)
                                             ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032534_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032534_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128382___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031794_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031793_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031792_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031727_)))));
    wasmetal_core__DOT___031731_ = ((IData)(vlSelf->wasmetal_core__DOT___031795_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d));
    wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034754_));
    wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030838_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030773_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128335___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031156_)))));
    wasmetal_core__DOT___031160_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128359___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031444_)))));
    wasmetal_core__DOT___031448_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128447___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032535_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032534_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032533_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032532_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032467_)))));
    wasmetal_core__DOT___032471_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032535_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032535_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031796_)
            ? (IData)(wasmetal_core__DOT___031731_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d));
    wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034693_) 
           & (IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030839_)
            ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d));
    wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)
            : (IData)(wasmetal_core__DOT___031160_));
    wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)
            : (IData)(wasmetal_core__DOT___031448_));
    wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032537_)
                  ? (IData)(wasmetal_core__DOT___032471_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032537_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031797_)
            ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128678___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034695_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034692_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                & (IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034754_)))));
    wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030840_)
            ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d));
    wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)
            : (IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)
            : (IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032538_)
                  ? (IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032538_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031798_)
            ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128303___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030841_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030840_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030839_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030838_)))) 
           ^ (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030773_)))));
    wasmetal_core__DOT___030777_ = ((IData)(vlSelf->wasmetal_core__DOT___030841_)
                                     ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128336___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)
                 : (IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031160_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128360___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)
                 : (IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031448_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128448___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032540_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032539_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032538_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032537_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___032539_)
                       ? (IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___032539_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___032471_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128383___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031799_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031798_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031796_)))) 
           ^ (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031731_)))));
    wasmetal_core__DOT___031735_ = ((IData)(vlSelf->wasmetal_core__DOT___031799_)
                                     ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d));
    wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030843_)
            ? (IData)(wasmetal_core__DOT___030777_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d));
    wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031801_)
            ? (IData)(wasmetal_core__DOT___031735_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d));
    wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030844_)
            ? (IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d));
    wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031802_)
            ? (IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128304___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030846_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030845_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030844_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030843_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030845_)
                 ? (IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030777_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128384___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031804_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031803_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031802_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031801_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031803_)
                 ? (IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031735_)))));
}

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__18(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__18\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___066316_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066896_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066893_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066855_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x15U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066772_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066769_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066650_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x13U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067197_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067078_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066973_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066970_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067456_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067344_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067342_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067314_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067312_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) {
        vlSelf->wasmetal_core__DOT___001164_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h81e66010__0))));
        vlSelf->wasmetal_core__DOT___001142_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0))));
        vlSelf->wasmetal_core__DOT___001120_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0))));
        vlSelf->wasmetal_core__DOT___001098_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0))));
        vlSelf->wasmetal_core__DOT___001076_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb19b1393__0))));
        vlSelf->wasmetal_core__DOT___001054_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7def20ec__0))));
        vlSelf->wasmetal_core__DOT___001032_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0))));
        vlSelf->wasmetal_core__DOT___001010_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h80bc039f__0))));
        vlSelf->wasmetal_core__DOT___000988_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h85029f86__0))));
        vlSelf->wasmetal_core__DOT___000976_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0))));
        vlSelf->wasmetal_core__DOT___001323_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0))));
        vlSelf->wasmetal_core__DOT___000653_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h95441b9a__0))));
        vlSelf->wasmetal_core__DOT___000631_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0))));
        vlSelf->wasmetal_core__DOT___000609_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0))));
        vlSelf->wasmetal_core__DOT___000587_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0))));
        vlSelf->wasmetal_core__DOT___000560_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0))));
        vlSelf->wasmetal_core__DOT___000494_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha29002c9__0))));
        vlSelf->wasmetal_core__DOT___000472_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5b213075__0))));
        vlSelf->wasmetal_core__DOT___000412_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he64a7376__0))));
        vlSelf->wasmetal_core__DOT___000538_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0))));
        vlSelf->wasmetal_core__DOT___000516_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8a521099__0))));
        vlSelf->wasmetal_core__DOT___000460_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12d7401d__0))));
        vlSelf->wasmetal_core__DOT___000428_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4f514d50__0))));
        vlSelf->wasmetal_core__DOT___001642_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0))));
        vlSelf->wasmetal_core__DOT___001576_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he721caff__0))));
        vlSelf->wasmetal_core__DOT___001564_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0))));
        vlSelf->wasmetal_core__DOT___001532_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63a71256__0))));
        vlSelf->wasmetal_core__DOT___001520_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h17123258__0))));
        vlSelf->wasmetal_core__DOT___001421_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h42734187__0))));
        vlSelf->wasmetal_core__DOT___001409_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0))));
        vlSelf->wasmetal_core__DOT___001377_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0))));
        vlSelf->wasmetal_core__DOT___001620_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0))));
        vlSelf->wasmetal_core__DOT___001608_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he176d11c__0))));
        vlSelf->wasmetal_core__DOT___001365_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he0f0059b__0))));
        vlSelf->wasmetal_core__DOT___001483_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fd66007__0))));
        vlSelf->wasmetal_core__DOT___001471_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hefb6870d__0))));
        vlSelf->wasmetal_core__DOT___001439_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0))));
        vlSelf->wasmetal_core__DOT___001433_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0))));
        vlSelf->wasmetal_core__DOT___001882_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0))));
        vlSelf->wasmetal_core__DOT___001870_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0))));
    } else {
        vlSelf->wasmetal_core__DOT___001164_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hac8a82be__0))));
        vlSelf->wasmetal_core__DOT___001142_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h87463cf8__0))));
        vlSelf->wasmetal_core__DOT___001120_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7685727c__0))));
        vlSelf->wasmetal_core__DOT___001098_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hca84dae7__0))));
        vlSelf->wasmetal_core__DOT___001076_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0b41010__0))));
        vlSelf->wasmetal_core__DOT___001054_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1871ad84__0))));
        vlSelf->wasmetal_core__DOT___001032_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0))));
        vlSelf->wasmetal_core__DOT___001010_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0))));
        vlSelf->wasmetal_core__DOT___000988_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0))));
        vlSelf->wasmetal_core__DOT___000976_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h23462764__0))));
        vlSelf->wasmetal_core__DOT___001323_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0))));
        vlSelf->wasmetal_core__DOT___000653_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h981495cf__0))));
        vlSelf->wasmetal_core__DOT___000631_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h346dffe3__0))));
        vlSelf->wasmetal_core__DOT___000609_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4641aed4__0))));
        vlSelf->wasmetal_core__DOT___000587_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb9d73245__0))));
        vlSelf->wasmetal_core__DOT___000560_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0))));
        vlSelf->wasmetal_core__DOT___000494_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h0990f42c__0))));
        vlSelf->wasmetal_core__DOT___000472_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5680e757__0))));
        vlSelf->wasmetal_core__DOT___000412_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4633c50c__0))));
        vlSelf->wasmetal_core__DOT___000538_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0))));
        vlSelf->wasmetal_core__DOT___000516_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h64f45cce__0))));
        vlSelf->wasmetal_core__DOT___000460_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc8339843__0))));
        vlSelf->wasmetal_core__DOT___000428_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fec380d__0))));
        vlSelf->wasmetal_core__DOT___001642_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h42c0d879__0))));
        vlSelf->wasmetal_core__DOT___001576_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h348ae581__0))));
        vlSelf->wasmetal_core__DOT___001564_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h32a20063__0))));
        vlSelf->wasmetal_core__DOT___001532_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h92680a0a__0))));
        vlSelf->wasmetal_core__DOT___001520_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0))));
        vlSelf->wasmetal_core__DOT___001421_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0))));
        vlSelf->wasmetal_core__DOT___001409_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0))));
        vlSelf->wasmetal_core__DOT___001377_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0))));
        vlSelf->wasmetal_core__DOT___001620_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h464afc51__0))));
        vlSelf->wasmetal_core__DOT___001608_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0))));
        vlSelf->wasmetal_core__DOT___001365_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0))));
        vlSelf->wasmetal_core__DOT___001483_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_haec160c4__0))));
        vlSelf->wasmetal_core__DOT___001471_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc089566f__0))));
        vlSelf->wasmetal_core__DOT___001439_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5875da01__0))));
        vlSelf->wasmetal_core__DOT___001433_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h283b87b9__0))));
        vlSelf->wasmetal_core__DOT___001882_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h86168fd0__0))));
        vlSelf->wasmetal_core__DOT___001870_ = (1U 
                                                & (0xe2U 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1495cfda__0))));
    }
    vlSelf->wasmetal_core__DOT___052175_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2ee186c3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052159_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h81e66010__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b62__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052159_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h81e66010__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2ee186c3__0))))))));
    vlSelf->wasmetal_core__DOT___005244_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001158_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81e66010__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hac8a82be__0)))))))));
    vlSelf->wasmetal_core__DOT___001169_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81e66010__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hac8a82be__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001158_)))))));
    vlSelf->wasmetal_core__DOT___001165_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001159_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001158_)));
    vlSelf->wasmetal_core__DOT___052189_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5085d456__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052146_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b61__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052146_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5085d456__0))))))));
    vlSelf->wasmetal_core__DOT___005312_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001136_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h87463cf8__0)))))))));
    vlSelf->wasmetal_core__DOT___001147_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h87463cf8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001136_)))))));
    vlSelf->wasmetal_core__DOT___001143_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001137_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001136_)));
    vlSelf->wasmetal_core__DOT___052188_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5ef7d401__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052186_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b60__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052186_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ef7d401__0))))))));
    vlSelf->wasmetal_core__DOT___004904_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001114_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7685727c__0)))))))));
    vlSelf->wasmetal_core__DOT___001125_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7685727c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001114_)))))));
    vlSelf->wasmetal_core__DOT___001121_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001115_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001114_)));
    vlSelf->wasmetal_core__DOT___052504_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hdf96a80c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052481_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b59__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052481_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdf96a80c__0))))))));
    vlSelf->wasmetal_core__DOT___005040_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001092_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hca84dae7__0)))))))));
    vlSelf->wasmetal_core__DOT___001103_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hca84dae7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001092_)))))));
    vlSelf->wasmetal_core__DOT___001099_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001093_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001092_)));
    vlSelf->wasmetal_core__DOT___052503_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h26403b1c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052486_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b58__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052486_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb19b1393__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h26403b1c__0))))))));
    vlSelf->wasmetal_core__DOT___004972_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001070_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb0b41010__0)))))))));
    vlSelf->wasmetal_core__DOT___001081_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb19b1393__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb0b41010__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001070_)))))));
    vlSelf->wasmetal_core__DOT___001077_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001071_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001070_)));
    vlSelf->wasmetal_core__DOT___052178_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hfbb7166b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052173_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b57__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052173_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7def20ec__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbb7166b__0))))))));
    vlSelf->wasmetal_core__DOT___005380_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001048_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1871ad84__0)))))))));
    vlSelf->wasmetal_core__DOT___001059_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7def20ec__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1871ad84__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001048_)))))));
    vlSelf->wasmetal_core__DOT___001055_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001049_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001048_)));
    vlSelf->wasmetal_core__DOT___052177_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hec62ba82__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052164_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b56__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052164_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hec62ba82__0))))))));
    vlSelf->wasmetal_core__DOT___005108_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001026_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0)))))))));
    vlSelf->wasmetal_core__DOT___001037_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hccb9e3d4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001026_)))))));
    vlSelf->wasmetal_core__DOT___001033_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001027_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001026_)));
    vlSelf->wasmetal_core__DOT___052449_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc6c0965f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052427_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b55__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052427_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h80bc039f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc6c0965f__0))))))));
    vlSelf->wasmetal_core__DOT___005176_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001004_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0)))))))));
    vlSelf->wasmetal_core__DOT___001015_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h80bc039f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd6ccf561__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001004_)))))));
    vlSelf->wasmetal_core__DOT___001011_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001005_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001004_)));
    vlSelf->wasmetal_core__DOT___052448_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2e9416a5__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052422_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h85029f86__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b54__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h85029f86__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2e9416a5__0))))))));
    vlSelf->wasmetal_core__DOT___003360_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000960_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h85029f86__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0)))))))));
    vlSelf->wasmetal_core__DOT___000993_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h85029f86__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha8f762bd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000960_)))))));
    vlSelf->wasmetal_core__DOT___000989_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000961_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000960_)));
    vlSelf->wasmetal_core__DOT___052140_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc0a5660d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052123_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b53__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052123_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc0a5660d__0))))))));
    vlSelf->wasmetal_core__DOT___003428_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000970_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h23462764__0)))))))));
    vlSelf->wasmetal_core__DOT___000981_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h23462764__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000970_)))))));
    vlSelf->wasmetal_core__DOT___000977_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000971_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000970_)));
    vlSelf->wasmetal_core__DOT___052139_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h651ffab0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052118_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b52__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052118_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651ffab0__0))))))));
    vlSelf->wasmetal_core__DOT___003948_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000948_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0)))))))));
    vlSelf->wasmetal_core__DOT___000926_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9d577f3c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000948_)))))));
    vlSelf->wasmetal_core__DOT___001324_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000949_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000948_)));
    vlSelf->__VdfgTmp_hf33ae1e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003883_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h55f26059__0))));
    vlSelf->wasmetal_core__DOT___003885_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h55f26059__0))));
    vlSelf->wasmetal_core__DOT___003876_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000939_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000938_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6366d506__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0908881__0)))))))));
    vlSelf->wasmetal_core__DOT___000927_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6366d506__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc0908881__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000939_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000938_)))))));
    vlSelf->__VdfgTmp_hccc0d080__0 = (((IData)(vlSelf->wasmetal_core__DOT___004099_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4b0186c1__0))));
    vlSelf->wasmetal_core__DOT___004101_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4b0186c1__0))));
    vlSelf->wasmetal_core__DOT___004092_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000909_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000908_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he74cbbd8__0)))))))));
    vlSelf->wasmetal_core__DOT___000897_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he74cbbd8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000909_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000908_)))))));
    vlSelf->__VdfgTmp_h39926e96__0 = (((IData)(vlSelf->wasmetal_core__DOT___004321_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5a6445ef__0))));
    vlSelf->wasmetal_core__DOT___004323_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a6445ef__0))));
    vlSelf->wasmetal_core__DOT___004314_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000919_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000918_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h650b1858__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3a817888__0)))))))));
    vlSelf->wasmetal_core__DOT___000896_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h650b1858__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3a817888__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000919_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000918_)))))));
    vlSelf->__VdfgTmp_h58c7b8aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___004025_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hcba3b702__0))));
    vlSelf->wasmetal_core__DOT___004027_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcba3b702__0))));
    vlSelf->wasmetal_core__DOT___004018_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000885_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000884_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hebb33e32__0)))))))));
    vlSelf->wasmetal_core__DOT___000873_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hebb33e32__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000885_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000884_)))))));
    vlSelf->__VdfgTmp_h9b219d07__0 = (((IData)(vlSelf->wasmetal_core__DOT___003727_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5e9c07be__0))));
    vlSelf->wasmetal_core__DOT___003729_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e9c07be__0))));
    vlSelf->wasmetal_core__DOT___003720_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000895_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000894_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hffc6befa__0)))))))));
    vlSelf->wasmetal_core__DOT___000872_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hffc6befa__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000895_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000894_)))))));
    vlSelf->__VdfgTmp_h21caabb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004691_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h60070975__0))));
    vlSelf->wasmetal_core__DOT___004693_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60070975__0))));
    vlSelf->wasmetal_core__DOT___004684_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000861_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000860_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70e821ff__0)))))))));
    vlSelf->wasmetal_core__DOT___000849_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70e821ff__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000861_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000860_)))))));
    vlSelf->__VdfgTmp_hd35a9dc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004247_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h74f399ec__0))));
    vlSelf->wasmetal_core__DOT___004249_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h74f399ec__0))));
    vlSelf->wasmetal_core__DOT___004240_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000871_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000870_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb87fbc4d__0)))))))));
    vlSelf->wasmetal_core__DOT___000848_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb87fbc4d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000871_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000870_)))))));
    vlSelf->__VdfgTmp_h31a231e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004173_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9cca9eb0__0))));
    vlSelf->wasmetal_core__DOT___004175_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9cca9eb0__0))));
    vlSelf->wasmetal_core__DOT___004166_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000847_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000846_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdfd359a7__0)))))))));
    vlSelf->wasmetal_core__DOT___000824_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdfd359a7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000847_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000846_)))))));
    vlSelf->__VdfgTmp_hc1c0d33f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003579_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h67445948__0))));
    vlSelf->wasmetal_core__DOT___003581_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67445948__0))));
    vlSelf->wasmetal_core__DOT___003572_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000837_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000836_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h456da093__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h49f908f3__0)))))))));
    vlSelf->wasmetal_core__DOT___000825_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h456da093__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h49f908f3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000837_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000836_)))))));
    vlSelf->__VdfgTmp_h01d0ee79__0 = (((IData)(vlSelf->wasmetal_core__DOT___003505_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h252badb1__0))));
    vlSelf->wasmetal_core__DOT___003507_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h252badb1__0))));
    vlSelf->wasmetal_core__DOT___003498_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000808_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000807_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfd0db41d__0)))))))));
    vlSelf->wasmetal_core__DOT___000796_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfd0db41d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000808_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000807_)))))));
    vlSelf->__VdfgTmp_he23a6b26__0 = (((IData)(vlSelf->wasmetal_core__DOT___003653_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h34a57f42__0))));
    vlSelf->wasmetal_core__DOT___003655_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h34a57f42__0))));
    vlSelf->wasmetal_core__DOT___003646_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000818_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000817_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h90eba162__0)))))))));
    vlSelf->wasmetal_core__DOT___000795_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h90eba162__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000818_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000817_)))))));
    vlSelf->__VdfgTmp_h07a3b670__0 = (((IData)(vlSelf->wasmetal_core__DOT___003801_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4e280dfe__0))));
    vlSelf->wasmetal_core__DOT___003803_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e280dfe__0))));
    vlSelf->wasmetal_core__DOT___003794_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000784_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000783_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb4397905__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h636dab99__0)))))))));
    vlSelf->wasmetal_core__DOT___000772_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb4397905__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h636dab99__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000784_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000783_)))))));
    vlSelf->__VdfgTmp_he0dafd81__0 = (((IData)(vlSelf->wasmetal_core__DOT___004617_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h054c8d5f__0))));
    vlSelf->wasmetal_core__DOT___004619_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h054c8d5f__0))));
    vlSelf->wasmetal_core__DOT___004610_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000794_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000793_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ff40a3b__0)))))))));
    vlSelf->wasmetal_core__DOT___000771_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ff40a3b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000794_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000793_)))))));
    vlSelf->__VdfgTmp_h2b977022__0 = (((IData)(vlSelf->wasmetal_core__DOT___004469_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc00537e7__0))));
    vlSelf->wasmetal_core__DOT___004471_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc00537e7__0))));
    vlSelf->wasmetal_core__DOT___004462_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000770_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000769_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea8a286f__0)))))))));
    vlSelf->wasmetal_core__DOT___000747_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea8a286f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000770_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000769_)))))));
    vlSelf->__VdfgTmp_hd438e6c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___004395_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4f517b43__0))));
    vlSelf->wasmetal_core__DOT___004397_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4f517b43__0))));
    vlSelf->wasmetal_core__DOT___004388_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000760_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000759_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfcc5cb61__0)))))))));
    vlSelf->wasmetal_core__DOT___000748_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfcc5cb61__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000760_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000759_)))))));
    vlSelf->__VdfgTmp_h50f5670e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004543_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_haf89032c__0))));
    vlSelf->wasmetal_core__DOT___004545_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf89032c__0))));
    vlSelf->wasmetal_core__DOT___004536_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000746_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000745_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3d4b630e__0)))))))));
    vlSelf->wasmetal_core__DOT___000723_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3d4b630e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000746_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000745_)))))));
    vlSelf->__VdfgTmp_he2ad86dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004765_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5500fae9__0))));
    vlSelf->wasmetal_core__DOT___004767_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5500fae9__0))));
    vlSelf->wasmetal_core__DOT___004758_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000736_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000735_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc72a6a37__0)))))))));
    vlSelf->wasmetal_core__DOT___000724_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc72a6a37__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000736_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000735_)))))));
    vlSelf->__VdfgTmp_h4cb51258__0 = (((IData)(vlSelf->wasmetal_core__DOT___004839_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3c930b99__0))));
    vlSelf->wasmetal_core__DOT___004841_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c930b99__0))));
    vlSelf->wasmetal_core__DOT___004832_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000716_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000715_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_heda84e5a__0)))))))));
    vlSelf->wasmetal_core__DOT___000694_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_heda84e5a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000716_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000715_)))))));
    vlSelf->__VdfgTmp_h319b52f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003295_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h95280768__0))));
    vlSelf->wasmetal_core__DOT___003297_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95280768__0))));
    vlSelf->wasmetal_core__DOT___003288_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000706_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000705_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h550ff904__0)))))))));
    vlSelf->wasmetal_core__DOT___000693_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h550ff904__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000706_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000705_)))))));
    vlSelf->__VdfgTmp_h0683198f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003215_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf410ea07__0))));
    vlSelf->wasmetal_core__DOT___003217_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf410ea07__0))));
    vlSelf->wasmetal_core__DOT___003208_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000682_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000681_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h339ccfdb__0)))))))));
    vlSelf->wasmetal_core__DOT___000665_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h339ccfdb__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000682_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000681_)))))));
    vlSelf->__VdfgTmp_h7752095d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005625_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2a120d0d__0))));
    vlSelf->wasmetal_core__DOT___005627_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a120d0d__0))));
    vlSelf->wasmetal_core__DOT___005618_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000692_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000691_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h149fa621__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfafc2bd6__0)))))))));
    vlSelf->wasmetal_core__DOT___005617_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h149fa621__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfafc2bd6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000692_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000691_)))))));
    vlSelf->wasmetal_core__DOT___052234_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h38fef573__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052220_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b30__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052220_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h95441b9a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h38fef573__0))))))));
    vlSelf->wasmetal_core__DOT___005232_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000647_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h981495cf__0)))))))));
    vlSelf->wasmetal_core__DOT___000658_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h95441b9a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h981495cf__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000647_)))))));
    vlSelf->wasmetal_core__DOT___000654_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000648_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000647_)));
    vlSelf->wasmetal_core__DOT___052233_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hf146791e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052215_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b29__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf146791e__0))))))));
    vlSelf->wasmetal_core__DOT___005300_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000625_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h346dffe3__0)))))))));
    vlSelf->wasmetal_core__DOT___000636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h346dffe3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000625_)))))));
    vlSelf->wasmetal_core__DOT___000632_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000626_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000625_)));
    vlSelf->wasmetal_core__DOT___052232_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd0875e26__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052210_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b28__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052210_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd0875e26__0))))))));
    vlSelf->wasmetal_core__DOT___004892_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000603_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4641aed4__0)))))))));
    vlSelf->wasmetal_core__DOT___000614_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4641aed4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000603_)))))));
    vlSelf->wasmetal_core__DOT___000610_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000604_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000603_)));
    vlSelf->wasmetal_core__DOT___052567_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1a1b2f4c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052564_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b27__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052564_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1a1b2f4c__0))))))));
    vlSelf->wasmetal_core__DOT___005028_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000581_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb9d73245__0)))))))));
    vlSelf->wasmetal_core__DOT___000592_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb9d73245__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000581_)))))));
    vlSelf->wasmetal_core__DOT___000588_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000582_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000581_)));
    vlSelf->wasmetal_core__DOT___052566_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbb570836__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052512_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b26__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052512_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hbb570836__0))))))));
    vlSelf->wasmetal_core__DOT___004960_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000554_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0)))))))));
    vlSelf->wasmetal_core__DOT___000565_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd4b6f7f5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000554_)))))));
    vlSelf->wasmetal_core__DOT___000561_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000555_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000554_)));
    vlSelf->wasmetal_core__DOT___052236_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1ddac1d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc070dcf__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b25__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb1ddac1d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hdc070dcf__0))))));
    vlSelf->wasmetal_core__DOT___005368_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000532_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0)))))))));
    vlSelf->wasmetal_core__DOT___000543_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf6a1a834__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6f0fb759__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000532_)))))));
    vlSelf->wasmetal_core__DOT___000539_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000533_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000532_)));
    vlSelf->wasmetal_core__DOT___052237_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27610e5d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h329ed040__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b24__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h27610e5d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h329ed040__0))))));
    vlSelf->wasmetal_core__DOT___005096_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000510_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8a521099__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h64f45cce__0)))))))));
    vlSelf->wasmetal_core__DOT___000521_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8a521099__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h64f45cce__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000510_)))))));
    vlSelf->wasmetal_core__DOT___000517_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000511_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000510_)));
    vlSelf->wasmetal_core__DOT___052527_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d3f3876__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052517_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b23__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052517_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha29002c9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d3f3876__0))))))));
    vlSelf->wasmetal_core__DOT___005164_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000488_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0990f42c__0)))))))));
    vlSelf->wasmetal_core__DOT___000499_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha29002c9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0990f42c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000488_)))))));
    vlSelf->wasmetal_core__DOT___000495_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000489_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000488_)));
    vlSelf->wasmetal_core__DOT___052528_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3c70beb3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052522_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5b213075__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b22__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052522_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5b213075__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3c70beb3__0))))))));
    vlSelf->wasmetal_core__DOT___003348_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000444_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5b213075__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5680e757__0)))))))));
    vlSelf->wasmetal_core__DOT___000477_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5b213075__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5680e757__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000444_)))))));
    vlSelf->wasmetal_core__DOT___000473_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000445_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000444_)));
    vlSelf->wasmetal_core__DOT___052403_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hda033d4f__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6effbe38__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b21__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hda033d4f__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h6effbe38__0))))));
    vlSelf->wasmetal_core__DOT___003416_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000454_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h12d7401d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc8339843__0)))))))));
    vlSelf->wasmetal_core__DOT___000465_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h12d7401d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc8339843__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000454_)))))));
    vlSelf->wasmetal_core__DOT___000461_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000455_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000454_)));
    vlSelf->wasmetal_core__DOT___052402_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbabec73__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1dec8a5e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b20__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbabec73__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h1dec8a5e__0))))));
    vlSelf->wasmetal_core__DOT___003936_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000406_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f514d50__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6fec380d__0)))))))));
    vlSelf->wasmetal_core__DOT___000433_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4f514d50__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6fec380d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000406_)))))));
    vlSelf->wasmetal_core__DOT___000429_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000407_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000406_)));
    vlSelf->wasmetal_core__DOT___052555_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d5da343__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052550_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he64a7376__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b19__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052550_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he64a7376__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d5da343__0))))))));
    vlSelf->wasmetal_core__DOT___003862_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000396_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he64a7376__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4633c50c__0)))))))));
    vlSelf->wasmetal_core__DOT___000420_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he64a7376__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4633c50c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000396_)))))));
    vlSelf->wasmetal_core__DOT___000413_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000397_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000396_)));
    vlSelf->wasmetal_core__DOT___052560_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9975f0a8__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4c7ff695__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b18__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9975f0a8__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h4c7ff695__0))))));
    vlSelf->wasmetal_core__DOT___004078_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001636_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42c0d879__0)))))))));
    vlSelf->wasmetal_core__DOT___001647_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h252dd1a8__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42c0d879__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001636_)))))));
    vlSelf->wasmetal_core__DOT___001643_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001637_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001636_)));
    vlSelf->wasmetal_core__DOT___052559_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40e72268__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h152b96e8__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b17__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h40e72268__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h152b96e8__0))))));
    vlSelf->wasmetal_core__DOT___004300_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001602_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h464afc51__0)))))))));
    vlSelf->wasmetal_core__DOT___001625_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h2dcfbe3b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h464afc51__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001602_)))))));
    vlSelf->wasmetal_core__DOT___001621_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001603_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001602_)));
    vlSelf->wasmetal_core__DOT___052529_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7409986d__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd259e3cd__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b16__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7409986d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hd259e3cd__0))))));
    vlSelf->wasmetal_core__DOT___004004_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001592_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he176d11c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0)))))))));
    vlSelf->wasmetal_core__DOT___001613_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he176d11c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0e64e6bd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001592_)))))));
    vlSelf->wasmetal_core__DOT___001609_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001593_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001592_)));
    vlSelf->wasmetal_core__DOT___052400_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h121dc976__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052385_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he721caff__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b15__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052385_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he721caff__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h121dc976__0))))))));
    vlSelf->wasmetal_core__DOT___003706_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001558_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he721caff__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h348ae581__0)))))))));
    vlSelf->wasmetal_core__DOT___001581_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he721caff__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h348ae581__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001558_)))))));
    vlSelf->wasmetal_core__DOT___001577_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001559_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001558_)));
    vlSelf->wasmetal_core__DOT___052401_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hcb57359d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052393_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b14__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052393_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcb57359d__0))))))));
    vlSelf->wasmetal_core__DOT___004670_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001548_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h32a20063__0)))))))));
    vlSelf->wasmetal_core__DOT___001569_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h32a20063__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001548_)))))));
    vlSelf->wasmetal_core__DOT___001565_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001549_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001548_)));
    vlSelf->wasmetal_core__DOT___052257_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_habe5487e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052251_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h63a71256__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b13__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052251_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h63a71256__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_habe5487e__0))))))));
    vlSelf->wasmetal_core__DOT___004226_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001514_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63a71256__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h92680a0a__0)))))))));
    vlSelf->wasmetal_core__DOT___001537_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63a71256__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h92680a0a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001514_)))))));
    vlSelf->wasmetal_core__DOT___001533_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001515_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001514_)));
    vlSelf->wasmetal_core__DOT___052255_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h56e67fc1__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052201_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h17123258__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b12__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052201_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h17123258__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h56e67fc1__0))))))));
    vlSelf->wasmetal_core__DOT___004152_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001504_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h17123258__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0)))))))));
    vlSelf->wasmetal_core__DOT___001525_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h17123258__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc6a0da7a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001504_)))))));
    vlSelf->wasmetal_core__DOT___001521_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001505_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001504_)));
    vlSelf->wasmetal_core__DOT___052477_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd416e14c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052472_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h42734187__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b11__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052472_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h42734187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd416e14c__0))))))));
    vlSelf->wasmetal_core__DOT___003558_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001403_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42734187__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0)))))))));
    vlSelf->wasmetal_core__DOT___001426_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42734187__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h77c9da1a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001403_)))))));
    vlSelf->wasmetal_core__DOT___001422_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001404_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001403_)));
    vlSelf->wasmetal_core__DOT___052476_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h382fd4d9__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052467_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b10__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052467_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h382fd4d9__0))))))));
    vlSelf->wasmetal_core__DOT___003484_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001393_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0)))))))));
    vlSelf->wasmetal_core__DOT___001414_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63e2f59d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001393_)))))));
    vlSelf->wasmetal_core__DOT___001410_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001394_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001393_)));
    vlSelf->wasmetal_core__DOT___052398_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h63bcab38__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052375_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b9__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052375_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h63bcab38__0))))))));
    vlSelf->wasmetal_core__DOT___003632_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001349_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0)))))))));
    vlSelf->wasmetal_core__DOT___001382_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7b4dcb8a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001349_)))))));
    vlSelf->wasmetal_core__DOT___001378_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001350_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001349_)));
    vlSelf->wasmetal_core__DOT___052399_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3b706e40__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052380_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b8__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052380_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he0f0059b__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3b706e40__0))))))));
    vlSelf->wasmetal_core__DOT___003780_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001359_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0)))))))));
    vlSelf->wasmetal_core__DOT___001370_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he0f0059b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbc2ed277__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001359_)))))));
    vlSelf->wasmetal_core__DOT___001366_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001360_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001359_)));
    vlSelf->wasmetal_core__DOT___052557_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h86663798__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052545_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b7__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052545_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6fd66007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h86663798__0))))))));
    vlSelf->wasmetal_core__DOT___004596_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001465_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_haec160c4__0)))))))));
    vlSelf->wasmetal_core__DOT___001488_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6fd66007__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_haec160c4__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001465_)))))));
    vlSelf->wasmetal_core__DOT___001484_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001466_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001465_)));
    vlSelf->wasmetal_core__DOT___052556_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc4ffb8dc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052533_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b6__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052533_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hefb6870d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4ffb8dc__0))))))));
    vlSelf->wasmetal_core__DOT___004448_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001455_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc089566f__0)))))))));
    vlSelf->wasmetal_core__DOT___001476_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hefb6870d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc089566f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001455_)))))));
    vlSelf->wasmetal_core__DOT___001472_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001456_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001455_)));
    vlSelf->wasmetal_core__DOT___052474_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc8d1ef5e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052457_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b5__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052457_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc8d1ef5e__0))))))));
    vlSelf->wasmetal_core__DOT___004374_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001190_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5875da01__0)))))))));
    vlSelf->wasmetal_core__DOT___001444_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5875da01__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001190_)))))));
    vlSelf->wasmetal_core__DOT___001440_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001191_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001190_)));
    vlSelf->wasmetal_core__DOT___052475_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h55f072d8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052462_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b4__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052462_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h55f072d8__0))))))));
    vlSelf->wasmetal_core__DOT___004522_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001200_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h283b87b9__0)))))))));
    vlSelf->wasmetal_core__DOT___001438_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h283b87b9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001200_)))))));
    vlSelf->wasmetal_core__DOT___001434_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___001201_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001200_)));
    vlSelf->wasmetal_core__DOT___052253_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h60503c86__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052241_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b3__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052241_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h60503c86__0))))))));
    vlSelf->wasmetal_core__DOT___004744_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000192_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h86168fd0__0)))))))));
    vlSelf->wasmetal_core__DOT___001887_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h86168fd0__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000192_)))))));
    vlSelf->wasmetal_core__DOT___001883_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000193_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000192_)));
    vlSelf->wasmetal_core__DOT___052254_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc4c8e202__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052246_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b2__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052246_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4c8e202__0))))))));
    vlSelf->wasmetal_core__DOT___004818_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___000386_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1495cfda__0)))))))));
    vlSelf->wasmetal_core__DOT___001875_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1495cfda__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___000386_)))))));
    vlSelf->wasmetal_core__DOT___001871_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))
                                                ? (IData)(vlSelf->wasmetal_core__DOT___000387_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000386_)));
    vlSelf->wasmetal_core__DOT___003270_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001869_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001868_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf7db9798__0)))))))));
    vlSelf->wasmetal_core__DOT___003269_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf7db9798__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001869_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001868_)))))));
    vlSelf->__VdfgTmp_he7820a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___003277_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc744024d__0))));
    vlSelf->wasmetal_core__DOT___003279_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc744024d__0))));
    vlSelf->wasmetal_core__DOT___003190_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001845_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001844_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h173fc958__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea8c2790__0)))))))));
    vlSelf->wasmetal_core__DOT___003189_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h173fc958__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea8c2790__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001845_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001844_)))))));
    vlSelf->__VdfgTmp_he9245313__0 = (((IData)(vlSelf->wasmetal_core__DOT___003197_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h856b720a__0))));
    vlSelf->wasmetal_core__DOT___003199_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h856b720a__0))));
    vlSelf->wasmetal_core__DOT___135425___DOT____VdfgTmp_ha5045b21__0 
        = (0x1fffU & ((0xffeU & ((IData)(vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz) 
                                 << 1U)) + (0xfffU 
                                            & (IData)(vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed))));
    vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053286_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053280_))));
    vlSelf->wasmetal_core__DOT___053426_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053280_))));
    vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031064_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___004802_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001991_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001990_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h978f5c03__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfd858dc9__0)))))))));
    vlSelf->wasmetal_core__DOT___004801_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h978f5c03__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfd858dc9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001991_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001990_)))))));
    vlSelf->wasmetal_core__DOT___004944_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002829_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002828_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h567f5b99__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h346b1359__0)))))))));
    vlSelf->wasmetal_core__DOT___004943_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h567f5b99__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h346b1359__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002829_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002828_)))))));
    vlSelf->wasmetal_core__DOT___004876_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002747_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002746_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ab68aeb__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefb6db46__0)))))))));
    vlSelf->wasmetal_core__DOT___004875_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6ab68aeb__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hefb6db46__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002747_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002746_)))))));
    vlSelf->wasmetal_core__DOT___005284_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002787_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002786_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ecae377__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hba4202f8__0)))))))));
    vlSelf->wasmetal_core__DOT___005283_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ecae377__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hba4202f8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002787_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002786_)))))));
    vlSelf->wasmetal_core__DOT___005216_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002911_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002910_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc521e256__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9c9a7e74__0)))))))));
    vlSelf->wasmetal_core__DOT___005215_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc521e256__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9c9a7e74__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002911_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002910_)))))));
    vlSelf->wasmetal_core__DOT___003252_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001926_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001925_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hed1e62e4__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha418026d__0)))))))));
    vlSelf->wasmetal_core__DOT___003095_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hed1e62e4__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha418026d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001926_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001925_)))))));
    vlSelf->wasmetal_core__DOT___003172_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001835_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001834_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h76024217__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h10a0c0f5__0)))))))));
    vlSelf->wasmetal_core__DOT___003091_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h76024217__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h10a0c0f5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001835_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001834_)))))));
    vlSelf->wasmetal_core__DOT___005600_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___003090_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___003089_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0def293__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h87f6cbda__0)))))))));
    vlSelf->wasmetal_core__DOT___005599_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc0def293__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h87f6cbda__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___003090_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___003089_)))))));
    vlSelf->wasmetal_core__DOT___052312_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h563719e8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b98__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053153_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hacde19aa__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h563719e8__0))))))));
    vlSelf->__VdfgTmp_hdf4f28bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___004811_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbc270d96__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004809_))));
    vlSelf->__VdfgTmp_h45f8df98__0 = (((IData)(vlSelf->wasmetal_core__DOT___004953_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hacecf0f9__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004951_))));
    vlSelf->wasmetal_core__DOT___069887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d))));
    vlSelf->wasmetal_core__DOT___062397_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b90__05d)))))));
    vlSelf->__VdfgTmp_hfaaa855f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005021_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b91__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002863_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002862_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005019_))));
    vlSelf->wasmetal_core__DOT___069909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))));
    vlSelf->wasmetal_core__DOT___062399_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___048259_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005012_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005011_)));
    vlSelf->__VdfgTmp_h5f30aa50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005012_));
    vlSelf->__VdfgTmp_h331e01c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___004885_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2876322d__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004883_))));
    vlSelf->wasmetal_core__DOT___069928_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d))));
    vlSelf->wasmetal_core__DOT___062402_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b92__05d)))))));
    vlSelf->__VdfgTmp_h62281c26__0 = (((IData)(vlSelf->wasmetal_core__DOT___005293_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h27483593__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005291_))));
    vlSelf->wasmetal_core__DOT___069949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d))));
    vlSelf->wasmetal_core__DOT___062405_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b93__05d)))))));
    vlSelf->__VdfgTmp_h22e3dba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___005225_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc644e6af__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005223_))));
    vlSelf->wasmetal_core__DOT___062407_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___069968_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069964_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069963_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b94__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069967_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1bU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT__value_aux__05b97__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053151_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha36d230f__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha0b12c43__0))))))));
    vlSelf->__VdfgTmp_h0a17a2b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003261_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc39d0419__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003259_))));
    vlSelf->__VdfgTmp_ha1faee4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003181_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hcd3797e9__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003179_))));
    vlSelf->wasmetal_core__DOT___070005_ = (1U & (IData)(
                                                         (0x45cf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___062414_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b96__05d)))))));
    vlSelf->__VdfgTmp_hf772eecc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005609_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7de933ba__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005607_))));
}
