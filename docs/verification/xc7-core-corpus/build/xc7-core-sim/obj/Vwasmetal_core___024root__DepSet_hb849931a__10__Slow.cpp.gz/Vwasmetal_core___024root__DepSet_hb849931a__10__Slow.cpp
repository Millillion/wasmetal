#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__9(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__9\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___063194_;
    wasmetal_core__DOT___063194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063200_;
    wasmetal_core__DOT___063200_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063206_;
    wasmetal_core__DOT___063206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063212_;
    wasmetal_core__DOT___063212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063522_;
    wasmetal_core__DOT___063522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063530_;
    wasmetal_core__DOT___063530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063538_;
    wasmetal_core__DOT___063538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063546_;
    wasmetal_core__DOT___063546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064107_;
    wasmetal_core__DOT___064107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064364_;
    wasmetal_core__DOT___064364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064365_;
    wasmetal_core__DOT___064365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064369_;
    wasmetal_core__DOT___064369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064410_;
    wasmetal_core__DOT___064410_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064414_;
    wasmetal_core__DOT___064414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064415_;
    wasmetal_core__DOT___064415_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064420_;
    wasmetal_core__DOT___064420_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064421_;
    wasmetal_core__DOT___064421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064424_;
    wasmetal_core__DOT___064424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064425_;
    wasmetal_core__DOT___064425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065223_;
    wasmetal_core__DOT___065223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065380_;
    wasmetal_core__DOT___065380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065485_;
    wasmetal_core__DOT___065485_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065509_;
    wasmetal_core__DOT___065509_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065649_;
    wasmetal_core__DOT___065649_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065761_;
    wasmetal_core__DOT___065761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065844_;
    wasmetal_core__DOT___065844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065956_;
    wasmetal_core__DOT___065956_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066027_;
    wasmetal_core__DOT___066027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066180_;
    wasmetal_core__DOT___066180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066225_;
    wasmetal_core__DOT___066225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066336_;
    wasmetal_core__DOT___066336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066434_;
    wasmetal_core__DOT___066434_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066500_;
    wasmetal_core__DOT___066500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066581_;
    wasmetal_core__DOT___066581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068784_;
    wasmetal_core__DOT___068784_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069560_;
    wasmetal_core__DOT___069560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069793_;
    wasmetal_core__DOT___069793_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128202___O;
    wasmetal_core__DOT____Vcellout___128202___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128412___O;
    wasmetal_core__DOT____Vcellout___128412___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellinp___128521___S;
    wasmetal_core__DOT____Vcellinp___128521___S = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128582___O;
    wasmetal_core__DOT____Vcellout___128582___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128025___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128025___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128025___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128025___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128041___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128041___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128202___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128202___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128505___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128505___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h325e7d4e__0;
    __VdfgTmp_h325e7d4e__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf4b373dc__0;
    __VdfgTmp_hf4b373dc__0 = 0;
    CData/*1:0*/ __VdfgTmp_h183f3794__0;
    __VdfgTmp_h183f3794__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6f16836b__0;
    __VdfgTmp_h6f16836b__0 = 0;
    CData/*2:0*/ __VdfgTmp_he0dd3f12__0;
    __VdfgTmp_he0dd3f12__0 = 0;
    CData/*2:0*/ __VdfgTmp_h82a2f635__0;
    __VdfgTmp_h82a2f635__0 = 0;
    CData/*1:0*/ __VdfgTmp_hff1aabe2__0;
    __VdfgTmp_hff1aabe2__0 = 0;
    // Body
    __VdfgTmp_hf4b373dc__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O))));
    wasmetal_core__DOT___064107_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__)))))))))));
    wasmetal_core__DOT____Vcellout___128582___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b24__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___128582___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128400___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031888_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b27__05d) {
        vlSelf->wasmetal_core__DOT___031892_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___033927_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        vlSelf->wasmetal_core__DOT___032949_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___031892_ = vlSelf->wasmetal_core__DOT___128400___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033927_ = vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032949_ = vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031941_));
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128464___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032624_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b28__05d) {
        vlSelf->wasmetal_core__DOT___032628_ = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___032628_ = vlSelf->wasmetal_core__DOT___128464___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031892_;
        vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033927_;
        vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032949_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128183___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029585_)))));
    vlSelf->wasmetal_core__DOT___029589_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128286___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030660_)))));
    wasmetal_core__DOT____Vcellout___128412___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032030_)))));
    vlSelf->wasmetal_core__DOT___032003_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036770_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128350___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031338_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031337_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031304_)))));
    vlSelf->wasmetal_core__DOT___031308_ = ((IData)(vlSelf->wasmetal_core__DOT___031340_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128599___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128599___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033923_)))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))) {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128496___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128496___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032945_)))));
    wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x1cU) & (IData)(vlSelf->wasmetal_core__DOT___027948_));
    wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1cU)
                  : (IData)(vlSelf->wasmetal_core__DOT___030483_)));
    wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027723_));
    vlSelf->wasmetal_core__DOT___128041___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028013_));
    wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029304_));
    wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029666_));
    wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029835_));
    wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031605_));
    wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032086_));
    vlSelf->wasmetal_core__DOT___039841_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039840_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x17U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039839_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x18U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039848_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128280___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 0x19U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d)))))));
    wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030578_));
    vlSelf->wasmetal_core__DOT___039814_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039815_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039821_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039818_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d)))))))));
    wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030004_));
    wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029932_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d));
    wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032884_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128964___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027658_));
    wasmetal_core__DOT___128202___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d));
    wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029400_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027819_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d));
    vlSelf->wasmetal_core__DOT___062893_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062904_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062926_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x1cU) & (IData)(vlSelf->wasmetal_core__DOT___028174_));
    wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029239_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d));
    wasmetal_core__DOT___128025___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027884_));
    vlSelf->wasmetal_core__DOT___044766_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                        << 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x18U)))))))));
    vlSelf->wasmetal_core__DOT___044778_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x15U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x17U))))))))));
    wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x1cU)) & (IData)(vlSelf->wasmetal_core__DOT___030965_));
    vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032212_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___044811_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___044799_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070652_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O))))))))));
    wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032692_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037202_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h4679be83__0))));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034649_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035102_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026279_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d));
    wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026183_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128479___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032817_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032816_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032815_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032814_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032780_)))));
    vlSelf->wasmetal_core__DOT___032785_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032817_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128479___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___128505___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032982_));
    vlSelf->wasmetal_core__DOT___032821_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032820_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032819_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032818_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O)))));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030795_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d));
    vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031116_));
    vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031404_));
    wasmetal_core__DOT___063194_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063200_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063206_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063212_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128452___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032493_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032427_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032493_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d));
    vlSelf->wasmetal_core__DOT___067582_ = (1U & (IData)(
                                                         (0x50f0f030f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___064440_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___064690_ = (1U & (0xf5f3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___065143_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___065026_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064267_)))));
    vlSelf->wasmetal_core__DOT___064437_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064433_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064432_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064423_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064367_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064373_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064377_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064384_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064388_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064337_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064268_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064438_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064336_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064319_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064282_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064294_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064318_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064290_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064295_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064291_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064315_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064301_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064314_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064304_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___019408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___064111_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(wasmetal_core__DOT___064107_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                              << 1U)) 
                                                                          | ((2U 
                                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128572___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128571___O) 
                                                                                >> 2U)))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O) 
                                                                        << 4U)) 
                                                                    | ((0x18U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128573___O) 
                                                                           << 1U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(__VdfgTmp_hf4b373dc__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(__VdfgTmp_hf4b373dc__0))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                         << 4U)) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                            << 2U)) 
                                                                        | ((8U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                               << 1U)) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                >> 1U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a9a4b36__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3321aa0d__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128570___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128569___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a9a4b36__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3321aa0d__0)))))))))))))))))))))));
    __VdfgTmp_h325e7d4e__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O) 
                                        >> 2U)) | (1U 
                                                   & (IData)(wasmetal_core__DOT____Vcellout___128582___O))));
    vlSelf->wasmetal_core__DOT___064031_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128580___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128581___O)))))))))))));
    vlSelf->wasmetal_core__DOT___033860_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b28__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128591___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b28__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b27__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b26__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b25__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128583___DOT__CO__BRA__0__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128574___DOT__CO__BRA__0__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128540___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128591___DOT____VdfgTmp_h9d2c3928__0)))));
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b19__05d) {
        vlSelf->wasmetal_core__DOT___030664_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
        vlSelf->wasmetal_core__DOT___030699_ = vlSelf->wasmetal_core__DOT__sp__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030664_ = vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030699_ = wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032628_));
    if (vlSelf->wasmetal_core__DOT__sp__05b30__05d) {
        wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b30__05d;
        vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b30__05d;
    } else {
        wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030366_;
        vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128465___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b29__05d) {
        vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128401___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128600___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128497___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___063588_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___063596_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___063604_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___063612_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029589_));
    vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030664_));
    wasmetal_core__DOT___063522_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063530_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128412___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063538_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063546_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032003_));
    vlSelf->wasmetal_core__DOT___036739_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036771_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031342_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031308_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    wasmetal_core__DOT____Vcellinp___128521___S = (
                                                   (8U 
                                                    & ((~ 
                                                        ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                         >> 1U)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((~ 
                                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                               >> 3U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 2U))))));
    vlSelf->wasmetal_core__DOT___062872_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))))));
    vlSelf->wasmetal_core__DOT___062883_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062894_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062905_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 3U))))))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))) {
        wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O));
        wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O));
        wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O));
    } else {
        wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__));
    }
    wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x1dU) & (IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1dU)
                  : (IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128041___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128041___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)
            : (IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d)
            : (IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)
            : (IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128219___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029933_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029932_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029931_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029930_)))) 
           ^ (((IData)(wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128219___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029896_)))));
    vlSelf->wasmetal_core__DOT___029900_ = ((IData)(vlSelf->wasmetal_core__DOT___029933_)
                                             ? (IData)(wasmetal_core__DOT___128219___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128488___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032885_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032884_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032883_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032882_)))) 
           ^ (((IData)(wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032849_)))));
    vlSelf->wasmetal_core__DOT___032853_ = ((IData)(vlSelf->wasmetal_core__DOT___032885_)
                                             ? (IData)(wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128965___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128202___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029764_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029763_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029762_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029761_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128202___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128202___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029727_)))));
    vlSelf->wasmetal_core__DOT___029731_ = ((IData)(vlSelf->wasmetal_core__DOT___029764_)
                                             ? (IData)(wasmetal_core__DOT___128202___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128169___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029401_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029400_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029399_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029398_)))) 
           ^ (((IData)(wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128169___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029365_)))));
    vlSelf->wasmetal_core__DOT___029369_ = ((IData)(vlSelf->wasmetal_core__DOT___029401_)
                                             ? (IData)(wasmetal_core__DOT___128169___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128016___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027820_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027819_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027818_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027817_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027784_)))));
    vlSelf->wasmetal_core__DOT___027788_ = ((IData)(vlSelf->wasmetal_core__DOT___027820_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128262___O 
        = (((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)) 
                   << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)))) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)
                  ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)
                  : (IData)(wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(wasmetal_core__DOT___128262___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___030366_)));
    wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x1dU) & (IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128153___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029240_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029239_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029238_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029237_)))) 
           ^ (((IData)(wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128153___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029204_)))));
    vlSelf->wasmetal_core__DOT___029208_ = ((IData)(vlSelf->wasmetal_core__DOT___029240_)
                                             ? (IData)(wasmetal_core__DOT___128153___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d));
    wasmetal_core__DOT___128025___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
           & (IData)(wasmetal_core__DOT___128025___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x1dU)) & (IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128432___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032213_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032212_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032211_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032210_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032177_)))));
    vlSelf->wasmetal_core__DOT___032181_ = ((IData)(vlSelf->wasmetal_core__DOT___032213_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128432___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128472___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032693_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h42a8fe82__0))) 
           ^ (((IData)(wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032657_)))));
    vlSelf->wasmetal_core__DOT___032661_ = ((IData)(vlSelf->wasmetal_core__DOT___032693_)
                                             ? (IData)(wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134214___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037203_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037202_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037201_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037200_)))) 
           ^ (((IData)(wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037168_)))));
    vlSelf->wasmetal_core__DOT___037172_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037203_)
                                                   ? (IData)(wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4312483e__0))));
    vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034650_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128716___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035103_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035102_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035101_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128716___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035035_)))));
    vlSelf->wasmetal_core__DOT___035039_ = ((IData)(vlSelf->wasmetal_core__DOT___035103_)
                                             ? (IData)(wasmetal_core__DOT___128716___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d));
    vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127840___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026280_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026279_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026278_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026277_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026244_)))));
    vlSelf->wasmetal_core__DOT___026248_ = ((IData)(vlSelf->wasmetal_core__DOT___026280_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127832___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026184_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026183_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026182_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026181_)))) 
           ^ (((IData)(wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127832___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026148_)))));
    vlSelf->wasmetal_core__DOT___026152_ = ((IData)(vlSelf->wasmetal_core__DOT___026184_)
                                             ? (IData)(wasmetal_core__DOT___127832___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127848___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026376_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026375_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026374_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026373_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026340_)))));
    vlSelf->wasmetal_core__DOT___026344_ = ((IData)(vlSelf->wasmetal_core__DOT___026376_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d));
    wasmetal_core__DOT___128505___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128505___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032818_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032785_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O)));
    vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030796_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d));
    vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063196_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063202_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063200_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063199_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063208_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063205_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063214_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063212_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063211_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128217___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128364___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032494_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032494_))));
    vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d));
    vlSelf->wasmetal_core__DOT___065144_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___064835_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064437_))));
    wasmetal_core__DOT___065223_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064431_))));
    vlSelf->wasmetal_core__DOT___064435_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064431_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064430_)))));
    wasmetal_core__DOT___065380_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064430_))));
    vlSelf->wasmetal_core__DOT___064689_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064430_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064433_)))));
    wasmetal_core__DOT___065485_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064433_))));
    vlSelf->wasmetal_core__DOT___064434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064433_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065509_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064432_))));
    vlSelf->wasmetal_core__DOT___064688_ = (1U & (0xf3f5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065649_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064408_))));
    wasmetal_core__DOT___064410_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064409_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065761_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064409_))));
    wasmetal_core__DOT___064414_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064413_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065956_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064413_))));
    wasmetal_core__DOT___064415_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064412_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065844_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064412_))));
    wasmetal_core__DOT___064421_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064418_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066027_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064418_))));
    wasmetal_core__DOT___064420_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064419_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066180_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064419_))));
    wasmetal_core__DOT___064425_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064422_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066225_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064422_))));
    wasmetal_core__DOT___064424_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064423_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066336_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064423_))));
    wasmetal_core__DOT___064365_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064362_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066434_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064362_))));
    wasmetal_core__DOT___064364_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064363_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066500_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064363_))));
    vlSelf->wasmetal_core__DOT___069265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064351_))));
    vlSelf->wasmetal_core__DOT___064352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064351_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___064369_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064366_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066581_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064366_))));
    vlSelf->wasmetal_core__DOT___064368_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064367_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066695_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064367_))));
    vlSelf->wasmetal_core__DOT___064375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064372_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066748_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064372_))));
    vlSelf->wasmetal_core__DOT___064374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066830_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064373_))));
    vlSelf->wasmetal_core__DOT___064379_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064376_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066914_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064376_))));
    vlSelf->wasmetal_core__DOT___064378_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064377_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066998_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064377_))));
    vlSelf->wasmetal_core__DOT___064387_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064384_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064384_))));
    vlSelf->wasmetal_core__DOT___069216_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064350_))));
    vlSelf->wasmetal_core__DOT___064353_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064350_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064386_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064385_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067128_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064385_))));
    vlSelf->wasmetal_core__DOT___064391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064388_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067239_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064388_))));
    vlSelf->wasmetal_core__DOT___069184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064347_))));
    vlSelf->wasmetal_core__DOT___064348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064390_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064389_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064389_))));
    vlSelf->wasmetal_core__DOT___064397_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067383_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064394_))));
    vlSelf->wasmetal_core__DOT___069117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064346_))));
    vlSelf->wasmetal_core__DOT___064349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064346_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064396_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064395_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064395_))));
    vlSelf->wasmetal_core__DOT___064401_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064398_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067527_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064398_))));
    vlSelf->wasmetal_core__DOT___069069_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064341_))));
    vlSelf->wasmetal_core__DOT___064342_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064341_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___069022_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064340_))));
    vlSelf->wasmetal_core__DOT___064343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064340_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068991_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064337_))));
    vlSelf->wasmetal_core__DOT___064338_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064337_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064400_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067575_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064399_))));
    vlSelf->wasmetal_core__DOT___064271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064268_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067641_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064268_))));
    vlSelf->wasmetal_core__DOT___066701_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))))))));
    vlSelf->wasmetal_core__DOT___067287_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x44f00000U 
                                                         >> 
                                                         ((0x10U 
                                                           & ((1U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 2U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                              << 1U)) 
                                                                            << 1U))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))))))))));
    vlSelf->wasmetal_core__DOT___065230_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (1U 
                                                             & (1U 
                                                                >> 
                                                                (3U 
                                                                 & (- (IData)(
                                                                              (1U 
                                                                               & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))))))));
    vlSelf->wasmetal_core__DOT___066746_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (1U 
                                                            & (1U 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->wasmetal_core__DOT___064709_ = (1U & (0x8000bfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                               << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___067134_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___066236_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U))) 
                                                                      << 1U))))))))));
    vlSelf->wasmetal_core__DOT___065772_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___066507_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                              << 1U))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066038_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (1U 
                                                                        & (1U 
                                                                           >> 
                                                                           (3U 
                                                                            & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                                      << 1U))))))))));
    vlSelf->wasmetal_core__DOT___066440_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                               << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___065654_ = (1U & (0x30aU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064438_))));
    vlSelf->wasmetal_core__DOT___065492_ = (1U & (0x35U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064438_))));
    vlSelf->wasmetal_core__DOT___065033_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064868_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064710_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___068924_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064336_))));
    vlSelf->wasmetal_core__DOT___064339_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064336_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064270_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064269_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064269_))));
    vlSelf->wasmetal_core__DOT___064275_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064272_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067788_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064272_))));
    vlSelf->wasmetal_core__DOT___068875_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064329_))));
    vlSelf->wasmetal_core__DOT___064330_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064329_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068828_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064328_))));
    vlSelf->wasmetal_core__DOT___064331_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064328_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064273_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067837_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064273_))));
    vlSelf->wasmetal_core__DOT___068681_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064319_))));
    vlSelf->wasmetal_core__DOT___064320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064319_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068778_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064325_))));
    vlSelf->wasmetal_core__DOT___064326_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064325_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068728_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064324_))));
    vlSelf->wasmetal_core__DOT___064327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064324_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064278_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067880_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064278_))));
    vlSelf->wasmetal_core__DOT___064280_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067940_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064279_))));
    vlSelf->wasmetal_core__DOT___064285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064282_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068003_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064282_))));
    vlSelf->wasmetal_core__DOT___064284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064283_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068056_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064283_))));
    vlSelf->wasmetal_core__DOT___064297_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064294_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064294_))));
    vlSelf->wasmetal_core__DOT___068631_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064318_))));
    vlSelf->wasmetal_core__DOT___064321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064290_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068131_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064290_))));
    vlSelf->wasmetal_core__DOT___064296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064295_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064295_))));
    vlSelf->wasmetal_core__DOT___064292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064291_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064291_))));
    vlSelf->wasmetal_core__DOT___064303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064300_))));
    vlSelf->wasmetal_core__DOT___068581_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064315_))));
    vlSelf->wasmetal_core__DOT___064316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064315_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068379_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064301_))));
    vlSelf->wasmetal_core__DOT___064317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064314_))));
    vlSelf->wasmetal_core__DOT___064307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064304_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068454_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064304_))));
    vlSelf->wasmetal_core__DOT___064306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064305_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064305_))));
    vlSelf->wasmetal_core__DOT___067285_ = (1U & (0xfe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))));
    vlSelf->wasmetal_core__DOT___069639_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     (2U 
                                                                      & ((4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U)) 
                                                                         << 1U))) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->__VdfgTmp_hc11d54c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 2U)) 
                                                 | ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                        << 3U)) 
                                                    | (4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___069837_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1fe0000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                   << 5U) 
                                                                  | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U))))))));
    vlSelf->wasmetal_core__DOT___070253_ = (1U & (IData)(
                                                         (0xa802aaaaaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 1U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d))))))));
    vlSelf->wasmetal_core__DOT___069683_ = (1U & (0xcf00aaU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                              << 1U))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___069815_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                      << 1U)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069939_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069980_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->__VdfgTmp_h9ae21ada__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | (0x1cU 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                    << 2U)));
    vlSelf->wasmetal_core__DOT___067845_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> 
                                                                  (1U 
                                                                   & (8U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069454_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    wasmetal_core__DOT___069793_ = (1U & (1U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xbU 
                                                       >> 
                                                       ((4U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 2U)) 
                                                        | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                           << 1U)))))));
    vlSelf->__VdfgTmp_h5851eae3__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 2U)) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8d2606de__0)));
    vlSelf->wasmetal_core__DOT___069190_ = (1U & (IData)(
                                                         (0x1ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 4U)) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 1U)))))));
    vlSelf->wasmetal_core__DOT___069075_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8d2606de__0))))));
    vlSelf->wasmetal_core__DOT___066185_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                               << 4U) 
                                                              | (8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    << 2U)))))));
    vlSelf->wasmetal_core__DOT___069521_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (1U 
                                                            & (1U 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069874_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                               << 1U))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___067438_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | (0x18U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 3U))))));
    wasmetal_core__DOT___068784_ = (1U & (IData)((0xff00ff00ff1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                         << 3U))))));
    vlSelf->wasmetal_core__DOT___065388_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                      << 2U))));
    vlSelf->wasmetal_core__DOT___066838_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (4U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    << 2U)))))));
    wasmetal_core__DOT___069560_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                             << 1U)) 
                                                           << 1U)))))));
    vlSelf->__VdfgTmp_heceac102__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O), 3U)));
    __VdfgTmp_hff1aabe2__0 = ((2U & ((1U >> (3U & (- (IData)(
                                                             (1U 
                                                              & (4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                  << 1U))))))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 1U))));
    vlSelf->wasmetal_core__DOT___064707_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> 
                                                         (1U 
                                                          & (0x80U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))))));
    vlSelf->wasmetal_core__DOT___066586_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0000000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___064875_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___065036_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0000000U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                          << 2U))))));
    vlSelf->wasmetal_core__DOT___069455_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___065516_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___066441_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___065962_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))));
    __VdfgTmp_h82a2f635__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                               << 2U) | ((2U & ((8U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                                << 1U)) 
                                         | (1U & (0x80U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->__VdfgTmp_hfe76cb01__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                         << 4U));
    vlSelf->__VdfgTmp_h62686ece__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                         << 3U));
    vlSelf->__VdfgTmp_h9d53ab65__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                    << 4U)));
    __VdfgTmp_h6f16836b__0 = ((4U & ((0x80U >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                     << 2U)) | ((2U 
                                                 & ((8U 
                                                     >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)));
    vlSelf->wasmetal_core__DOT___066341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    __VdfgTmp_he0dd3f12__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                               << 2U) | (1U & (0x80U 
                                               >> (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    __VdfgTmp_h183f3794__0 = ((2U & ((0x80U >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___067647_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___064698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___064199_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064111_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___064616_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064127_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064189_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064190_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064179_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064123_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064122_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064113_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064157_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064161_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064158_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064162_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064149_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064167_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064171_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064134_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064135_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064588_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064111_))));
    vlSelf->wasmetal_core__DOT___064032_ = (1U & (IData)(
                                                         (0x5ffffffffffffff3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128582___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128582___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128582___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(__VdfgTmp_h325e7d4e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80U 
                                                                             >> (IData)(__VdfgTmp_h325e7d4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___064215_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128589___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128590___O)) 
                                                                       | (1U 
                                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT___033860_)))))))))));
    vlSelf->__VdfgTmp_hb90eb6ff__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128591___O) 
                                             >> 1U)) 
                                      | (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128591___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128174___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           ^ (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029479_)))));
    vlSelf->wasmetal_core__DOT___029483_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128294___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030695_)))));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063523_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063522_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063521_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063531_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063529_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063539_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063538_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063537_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063547_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063546_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063545_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036772_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036739_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031343_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___062873_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062872_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062871_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062884_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062895_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062894_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062906_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062904_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128521___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128521___S) 
           ^ (((IData)(wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128521___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033116_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))) {
        vlSelf->wasmetal_core__DOT___033121_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033215_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033987_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033121_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128521___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033215_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033987_ = (1U 
                                                & (IData)(wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128529___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128521___S) 
           ^ (((IData)(wasmetal_core__DOT___128529___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128529___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033210_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128606___O 
        = ((IData)(wasmetal_core__DOT____Vcellinp___128521___S) 
           ^ (((IData)(wasmetal_core__DOT___128606___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128606___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033982_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128033___O 
        = (0xfU & ((vlSelf->insn_z >> 0x1cU) ^ ((0x18U 
                                                 & ((vlSelf->insn_z 
                                                     >> 0x1bU) 
                                                    & ((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__) 
                                                       << 3U))) 
                                                | (((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027948_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128273___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x1fU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x1eU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x1dU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)))))) 
           ^ ((8U & (((0x40000000U & vlSelf->mem_rdata[0U])
                       ? (vlSelf->mem_rdata[0U] >> 0x1eU)
                       : (IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___030483_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128009___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128009___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027723_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128041___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128041___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128041___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128041___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028013_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128162___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128162___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029304_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128195___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128195___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029666_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128212___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128212___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029835_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128377___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128377___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031605_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128425___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128425___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032086_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128281___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128281___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030578_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128229___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128229___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030004_)))));
    vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029934_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029900_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d));
    vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032886_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032853_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128001___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128967___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128966___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128965___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128964___Q)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128966___Q) 
                & (IData)(vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128001___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027658_)))));
    vlSelf->wasmetal_core__DOT___063241_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128202___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063247_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128202___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063253_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128202___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063259_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128202___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029765_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029731_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d));
    vlSelf->wasmetal_core__DOT___128170___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029402_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029369_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d));
    vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027821_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027788_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d));
    vlSelf->wasmetal_core__DOT___062937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062948_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128057___O 
        = (0xfU & ((vlSelf->insn_x >> 0x1cU) ^ ((0x18U 
                                                 & ((vlSelf->insn_x 
                                                     >> 0x1bU) 
                                                    & ((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__) 
                                                       << 3U))) 
                                                | (((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028174_))))));
    vlSelf->wasmetal_core__DOT___044577_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___128154___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029241_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029208_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128025___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                & (IData)(wasmetal_core__DOT___128025___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128025___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128025___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027884_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128321___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x1fU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x1eU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x1dU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x1cU)))))) 
           ^ ((((~ (vlSelf->function_params >> 0x1eU)) 
                & (IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030965_)))));
    vlSelf->wasmetal_core__DOT___045544_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___045556_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128431___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032214_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032181_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___070655_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O))))));
    vlSelf->wasmetal_core__DOT___070658_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032694_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032661_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037204_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037172_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbc309d1b__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128683___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034651_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034650_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034649_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034648_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034710_)))));
    vlSelf->wasmetal_core__DOT___034715_ = ((IData)(vlSelf->wasmetal_core__DOT___034651_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128683___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034655_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128716___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___034654_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128716___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d)))));
    vlSelf->wasmetal_core__DOT___034653_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128716___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___034652_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128716___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))));
    vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035104_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035039_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128700___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034907_)))));
    vlSelf->wasmetal_core__DOT___034911_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128700___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026281_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026248_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d));
    vlSelf->wasmetal_core__DOT___044597_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___127833___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026185_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026152_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d));
    vlSelf->wasmetal_core__DOT___054525_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054527_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054529_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054531_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063647_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063655_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063671_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___044381_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                     << 2U)) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                          >> 2U)))))))));
    vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026377_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026344_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128505___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128505___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128505___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128505___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032982_)))));
    vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032819_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128308___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030797_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030796_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030795_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030794_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030729_)))));
    vlSelf->wasmetal_core__DOT___030733_ = ((IData)(vlSelf->wasmetal_core__DOT___030797_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128308___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d));
    vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128341___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128365___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032495_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128453___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032495_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128388___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031755_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031754_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031753_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031752_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031687_)))));
    vlSelf->wasmetal_core__DOT___031691_ = ((IData)(vlSelf->wasmetal_core__DOT___031755_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128388___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d));
    vlSelf->wasmetal_core__DOT___065027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065026_))));
    vlSelf->wasmetal_core__DOT___065224_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___065381_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065380_))));
    vlSelf->wasmetal_core__DOT___065486_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065380_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065485_))));
    vlSelf->wasmetal_core__DOT___064436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064435_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064434_))));
    vlSelf->wasmetal_core__DOT___065510_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065485_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065509_))));
    vlSelf->wasmetal_core__DOT___064693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064688_))));
    vlSelf->wasmetal_core__DOT___065650_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065509_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065649_))));
    vlSelf->wasmetal_core__DOT___064417_ = (1U & (0x53U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064410_))));
    vlSelf->wasmetal_core__DOT___065762_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065649_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065761_))));
    vlSelf->wasmetal_core__DOT___064683_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064410_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064415_))));
    vlSelf->wasmetal_core__DOT___064416_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064415_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064414_))));
    vlSelf->wasmetal_core__DOT___065845_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065761_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065844_))));
    vlSelf->wasmetal_core__DOT___065957_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065844_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065956_))));
    vlSelf->wasmetal_core__DOT___064682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064414_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064421_))));
    vlSelf->wasmetal_core__DOT___066028_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065956_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066027_))));
    vlSelf->wasmetal_core__DOT___064427_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064421_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064420_))));
    vlSelf->wasmetal_core__DOT___066181_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066027_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066180_))));
    vlSelf->wasmetal_core__DOT___064685_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064420_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064425_))));
    vlSelf->wasmetal_core__DOT___066226_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066180_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066225_))));
    vlSelf->wasmetal_core__DOT___064426_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064425_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066225_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066336_))));
    vlSelf->wasmetal_core__DOT___064684_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066435_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066336_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066434_))));
    vlSelf->wasmetal_core__DOT___064371_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064364_))));
    vlSelf->wasmetal_core__DOT___066501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066434_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066500_))));
    vlSelf->wasmetal_core__DOT___069979_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064364_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064369_))));
    vlSelf->wasmetal_core__DOT___066582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066500_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066581_))));
    vlSelf->wasmetal_core__DOT___064370_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064368_))));
    vlSelf->wasmetal_core__DOT___066696_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066695_))));
    vlSelf->wasmetal_core__DOT___064668_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064375_))));
    vlSelf->wasmetal_core__DOT___066749_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066748_))));
    vlSelf->__VdfgTmp_hdbf4091d__0 = (((IData)(vlSelf->wasmetal_core__DOT___064375_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___064374_));
    vlSelf->wasmetal_core__DOT___066831_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066748_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066830_))));
    vlSelf->wasmetal_core__DOT___064671_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064379_))));
    vlSelf->wasmetal_core__DOT___066915_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066914_))));
    vlSelf->wasmetal_core__DOT___064380_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064379_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064378_))));
    vlSelf->wasmetal_core__DOT___066999_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066998_))));
    vlSelf->wasmetal_core__DOT___064670_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064378_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064387_))));
    vlSelf->wasmetal_core__DOT___067044_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067043_))));
    vlSelf->wasmetal_core__DOT___069266_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069216_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069265_))));
    vlSelf->wasmetal_core__DOT___064354_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064353_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064352_))));
    vlSelf->wasmetal_core__DOT___064393_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064387_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064386_))));
    vlSelf->wasmetal_core__DOT___067129_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067043_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067128_))));
    vlSelf->wasmetal_core__DOT___064675_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064391_))));
    vlSelf->wasmetal_core__DOT___067240_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067128_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067239_))));
    vlSelf->wasmetal_core__DOT___069217_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069216_))));
    vlSelf->wasmetal_core__DOT___064661_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064353_))));
    vlSelf->wasmetal_core__DOT___064392_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064391_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064390_))));
    vlSelf->wasmetal_core__DOT___067279_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067239_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067278_))));
    vlSelf->wasmetal_core__DOT___064674_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064390_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064397_))));
    vlSelf->wasmetal_core__DOT___067384_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067383_))));
    vlSelf->wasmetal_core__DOT___069185_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069184_))));
    vlSelf->wasmetal_core__DOT___064355_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064348_))));
    vlSelf->wasmetal_core__DOT___064403_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064396_))));
    vlSelf->wasmetal_core__DOT___067431_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067430_))));
    vlSelf->wasmetal_core__DOT___064677_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064401_))));
    vlSelf->wasmetal_core__DOT___067528_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067527_))));
    vlSelf->wasmetal_core__DOT___069118_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069069_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069117_))));
    vlSelf->wasmetal_core__DOT___064658_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064342_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064349_))));
    vlSelf->wasmetal_core__DOT___069070_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069069_))));
    vlSelf->wasmetal_core__DOT___064344_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064343_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064342_))));
    vlSelf->wasmetal_core__DOT___069023_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068991_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069022_))));
    vlSelf->wasmetal_core__DOT___064659_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064338_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064343_))));
    vlSelf->wasmetal_core__DOT___064402_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064400_))));
    vlSelf->wasmetal_core__DOT___067576_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067575_))));
    vlSelf->wasmetal_core__DOT___064676_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064400_))));
    vlSelf->wasmetal_core__DOT___067642_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067575_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067641_))));
    vlSelf->wasmetal_core__DOT___065236_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065230_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___067049_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065654_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065658_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065654_)))))));
    vlSelf->wasmetal_core__DOT___065493_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->__VdfgTmp_h14cfefd1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065492_));
    vlSelf->wasmetal_core__DOT___066579_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->wasmetal_core__DOT___065853_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))));
    vlSelf->wasmetal_core__DOT___066836_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065033_))));
    vlSelf->__VdfgTmp_hf00886e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___065033_));
    vlSelf->wasmetal_core__DOT___068387_ = (1U & (0x3700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065964_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064438_)))))));
    vlSelf->wasmetal_core__DOT___064871_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064868_))));
    vlSelf->wasmetal_core__DOT___066445_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066440_)))));
    vlSelf->wasmetal_core__DOT___067005_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))))));
    vlSelf->wasmetal_core__DOT___065514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064710_))));
    vlSelf->wasmetal_core__DOT___068992_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068991_))));
    vlSelf->wasmetal_core__DOT___064345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064339_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064338_))));
    vlSelf->wasmetal_core__DOT___064277_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064270_))));
    vlSelf->wasmetal_core__DOT___067710_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067641_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067709_))));
    vlSelf->wasmetal_core__DOT___064639_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064275_))));
    vlSelf->wasmetal_core__DOT___067789_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067709_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067788_))));
    vlSelf->wasmetal_core__DOT___068925_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068924_))));
    vlSelf->wasmetal_core__DOT___064654_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064330_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064339_))));
    vlSelf->wasmetal_core__DOT___068876_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068875_))));
    vlSelf->wasmetal_core__DOT___064332_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064330_))));
    vlSelf->wasmetal_core__DOT___064276_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064274_))));
    vlSelf->wasmetal_core__DOT___067838_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067837_))));
    vlSelf->wasmetal_core__DOT___068829_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068778_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068828_))));
    vlSelf->wasmetal_core__DOT___064655_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064331_))));
    vlSelf->wasmetal_core__DOT___068729_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068728_))));
    vlSelf->wasmetal_core__DOT___068779_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068728_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068778_))));
    vlSelf->wasmetal_core__DOT___064652_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064320_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064327_))));
    vlSelf->wasmetal_core__DOT___064333_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064326_))));
    vlSelf->wasmetal_core__DOT___064638_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064274_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064281_))));
    vlSelf->wasmetal_core__DOT___067881_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067880_))));
    vlSelf->wasmetal_core__DOT___064287_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064280_))));
    vlSelf->wasmetal_core__DOT___067941_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067880_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067940_))));
    vlSelf->wasmetal_core__DOT___064641_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064285_))));
    vlSelf->wasmetal_core__DOT___068004_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068003_))));
    vlSelf->wasmetal_core__DOT___064286_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064284_))));
    vlSelf->wasmetal_core__DOT___068057_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068003_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068056_))));
    vlSelf->wasmetal_core__DOT___068682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068681_))));
    vlSelf->wasmetal_core__DOT___064322_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064321_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064320_))));
    vlSelf->wasmetal_core__DOT___064640_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064293_))));
    vlSelf->wasmetal_core__DOT___068132_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068131_))));
    vlSelf->wasmetal_core__DOT___064298_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064296_))));
    vlSelf->wasmetal_core__DOT___068271_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068270_))));
    vlSelf->wasmetal_core__DOT___064645_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064292_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064297_))));
    vlSelf->wasmetal_core__DOT___064299_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064293_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064292_))));
    vlSelf->wasmetal_core__DOT___068218_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068183_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068217_))));
    vlSelf->wasmetal_core__DOT___068184_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068183_))));
    vlSelf->wasmetal_core__DOT___064644_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064296_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064303_))));
    vlSelf->wasmetal_core__DOT___068324_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068323_))));
    vlSelf->wasmetal_core__DOT___068632_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068631_))));
    vlSelf->wasmetal_core__DOT___064653_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064316_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064321_))));
    vlSelf->wasmetal_core__DOT___064309_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064302_))));
    vlSelf->wasmetal_core__DOT___068380_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068379_))));
    vlSelf->wasmetal_core__DOT___064323_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064317_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064316_))));
    vlSelf->wasmetal_core__DOT___068582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068581_))));
    vlSelf->wasmetal_core__DOT___064647_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064307_))));
    vlSelf->wasmetal_core__DOT___068455_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068379_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068454_))));
    vlSelf->wasmetal_core__DOT___064646_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064317_))));
    vlSelf->wasmetal_core__DOT___064308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064306_))));
    vlSelf->wasmetal_core__DOT___068518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068517_))));
    vlSelf->wasmetal_core__DOT___068500_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068454_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068499_))));
    vlSelf->wasmetal_core__DOT___069191_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069190_))));
    vlSelf->wasmetal_core__DOT___066187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066185_))));
    vlSelf->wasmetal_core__DOT___070329_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b118__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___068784_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___069793_))))));
    vlSelf->wasmetal_core__DOT___068785_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___068784_))));
    vlSelf->wasmetal_core__DOT___065389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065388_))));
    vlSelf->wasmetal_core__DOT___069728_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___069560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069896_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(wasmetal_core__DOT___069560_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___068385_ = (1U & (IData)(
                                                         (0xffff01ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_heceac102__0)))));
    vlSelf->wasmetal_core__DOT___069857_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xbU 
                                                        >> (IData)(__VdfgTmp_hff1aabe2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069295_ = (1U & (0x440f0f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hff1aabe2__0)))));
    vlSelf->wasmetal_core__DOT___064712_ = (1U & (IData)(
                                                         (0x70777700ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064709_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064707_)))))))));
    vlSelf->wasmetal_core__DOT___066588_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066586_))));
    vlSelf->wasmetal_core__DOT___064876_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064875_))));
    vlSelf->wasmetal_core__DOT___065037_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065036_))));
    vlSelf->wasmetal_core__DOT___069456_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069454_))));
    vlSelf->wasmetal_core__DOT___069794_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___069793_))));
    vlSelf->wasmetal_core__DOT___069960_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                      << 1U)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))));
    vlSelf->wasmetal_core__DOT___069522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069521_))));
    vlSelf->wasmetal_core__DOT___069875_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069874_))));
    vlSelf->wasmetal_core__DOT___066442_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066441_))));
    vlSelf->wasmetal_core__DOT___068997_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h82a2f635__0)))));
    vlSelf->wasmetal_core__DOT___067388_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h82a2f635__0))));
    vlSelf->wasmetal_core__DOT___066921_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff01ffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___065851_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___065495_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfe00000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___067246_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff00ff1fffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___067534_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___066233_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfffe000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___067136_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h6f16836b__0))));
    vlSelf->wasmetal_core__DOT___066034_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h6f16836b__0))));
    vlSelf->wasmetal_core__DOT___068687_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))));
    vlSelf->wasmetal_core__DOT___067003_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___066509_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_he0dd3f12__0))));
    vlSelf->wasmetal_core__DOT___068587_ = (1U & (0xf0f0f77U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_he0dd3f12__0)))));
    vlSelf->__VdfgTmp_hf7093f37__0 = ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 4U)) 
                                      | (IData)(__VdfgTmp_he0dd3f12__0));
    vlSelf->wasmetal_core__DOT___065232_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0U 
                                                         >> (IData)(__VdfgTmp_h183f3794__0))))));
    vlSelf->wasmetal_core__DOT___066753_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0U 
                                                           >> (IData)(__VdfgTmp_h183f3794__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___065770_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h183f3794__0))));
    vlSelf->wasmetal_core__DOT___067794_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065036_))));
    vlSelf->wasmetal_core__DOT___067946_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065388_))));
    vlSelf->wasmetal_core__DOT___067648_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064707_))));
    vlSelf->wasmetal_core__DOT___067715_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064875_)))));
    vlSelf->wasmetal_core__DOT___068276_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065962_)))));
    vlSelf->wasmetal_core__DOT___068506_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064868_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___069028_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff00ff1fffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___068009_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfe00000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h62686ece__0)))))));
    vlSelf->wasmetal_core__DOT___068637_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066586_))));
    vlSelf->wasmetal_core__DOT___068834_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff01ffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0)))))));
    vlSelf->wasmetal_core__DOT___069222_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0)))))));
    vlSelf->wasmetal_core__DOT___068523_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066441_))));
    vlSelf->wasmetal_core__DOT___064711_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064698_))))))))))));
    vlSelf->wasmetal_core__DOT___064836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064835_))));
    vlSelf->wasmetal_core__DOT___066453_ = (1U & (0xcfaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                              << 1U))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064199_))))));
    vlSelf->wasmetal_core__DOT___066175_ = (1U & (0x44f00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                          << 2U) 
                                                         | (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                      << 1U)) 
                                                                    << 1U))) 
                                                               << 1U)))))));
    vlSelf->wasmetal_core__DOT___065448_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065248_ = (1U & (0x35U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064199_))));
    vlSelf->wasmetal_core__DOT___066244_ = (1U & (0x44f00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                          << 2U) 
                                                         | (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     (2U 
                                                                      & ((4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                           << 1U)) 
                                                                         << 1U))) 
                                                                    << 1U))) 
                                                               << 1U)))))));
    vlSelf->wasmetal_core__DOT___064203_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064199_))));
    vlSelf->__VdfgTmp_h3616a991__0 = ((2U & ((1U >> 
                                              (3U & 
                                               (- (IData)(
                                                          (1U 
                                                           & (4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                               << 1U))))))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                << 1U))));
    vlSelf->wasmetal_core__DOT___065109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))));
    vlSelf->wasmetal_core__DOT___064944_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064795_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064616_))));
    vlSelf->wasmetal_core__DOT___064128_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064127_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067547_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064127_))));
    vlSelf->wasmetal_core__DOT___064192_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064189_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___064938_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064189_))));
    vlSelf->wasmetal_core__DOT___064191_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064190_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065102_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064190_))));
    vlSelf->wasmetal_core__DOT___064129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064126_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067514_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064126_))));
    vlSelf->wasmetal_core__DOT___064182_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064179_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065242_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064179_))));
    vlSelf->wasmetal_core__DOT___064124_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064123_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064123_))));
    vlSelf->wasmetal_core__DOT___064181_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064180_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065330_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064180_))));
    vlSelf->wasmetal_core__DOT___064186_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064183_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065441_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064183_))));
    vlSelf->wasmetal_core__DOT___064125_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067370_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064122_))));
    vlSelf->wasmetal_core__DOT___064185_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064184_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065525_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064184_))));
    vlSelf->wasmetal_core__DOT___064118_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064117_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064117_))));
    vlSelf->wasmetal_core__DOT___064114_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064113_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064113_))));
    vlSelf->wasmetal_core__DOT___064119_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064116_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067226_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064116_))));
    vlSelf->wasmetal_core__DOT___064160_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064157_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065665_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064157_))));
    vlSelf->wasmetal_core__DOT___064164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064161_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065860_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064161_))));
    vlSelf->wasmetal_core__DOT___064115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064112_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067055_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064112_))));
    vlSelf->wasmetal_core__DOT___064159_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064158_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
}
