#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__4(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__4\n"); );
    // Body
    vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039426_));
    vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039427_));
    vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039428_));
    vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039429_));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__load_lane__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_unit__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_lane__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_unit__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_source_unit__05b0__05d = 1U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b255__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b254__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b253__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b252__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b251__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b250__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b249__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b248__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b239__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b238__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b237__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b236__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b227__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b226__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b225__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b224__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b191__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b190__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b189__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b188__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b187__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b186__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b185__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b184__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b183__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b182__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b181__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b180__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b143__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b142__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b141__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b140__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b135__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b134__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b133__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b132__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b126__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b121__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b247__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b246__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b245__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b244__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b243__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b242__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b241__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b240__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b235__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b234__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b233__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b232__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b231__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b230__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b229__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b228__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b139__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b138__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b137__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b136__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b131__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b130__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b129__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b128__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b223__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b222__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b221__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b220__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b219__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b218__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b217__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b216__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b207__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b206__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b205__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b204__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b199__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b198__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b197__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b196__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b179__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b178__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b177__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b176__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b175__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b174__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b173__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b172__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b163__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b162__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b161__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b160__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b159__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b158__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b157__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b156__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b155__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b154__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b153__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b152__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b147__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b146__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b145__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b144__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b215__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b214__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b213__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b212__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b211__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b210__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b209__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b208__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b203__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b202__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b201__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b200__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b195__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b194__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b193__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b192__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b171__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b170__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b169__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b168__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b167__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b166__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b165__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b164__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b151__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b150__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b149__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b148__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__fpu__02edivide_wide = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128897___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128896___Q = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_product__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b121__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eis_wide = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129022___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___129002___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128999___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128998___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128997___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128996___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128995___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128994___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128993___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128992___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128991___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128990___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128989___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128988___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128987___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128986___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128985___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128984___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128983___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128982___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128981___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128980___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128979___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128978___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128977___Q = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_lane__05b24__05d 
                = (1U & (vlSelf->insn_y >> 0x18U));
            vlSelf->wasmetal_core__DOT__load_lane__05b23__05d 
                = (1U & (vlSelf->insn_y >> 0x17U));
            vlSelf->wasmetal_core__DOT__load_lane__05b22__05d 
                = (1U & (vlSelf->insn_y >> 0x16U));
            vlSelf->wasmetal_core__DOT__load_lane__05b21__05d 
                = (1U & (vlSelf->insn_y >> 0x15U));
            vlSelf->wasmetal_core__DOT__load_lane__05b20__05d 
                = (1U & (vlSelf->insn_y >> 0x14U));
            vlSelf->wasmetal_core__DOT__load_lane__05b19__05d 
                = (1U & (vlSelf->insn_y >> 0x13U));
            vlSelf->wasmetal_core__DOT__load_lane__05b18__05d 
                = (1U & (vlSelf->insn_y >> 0x12U));
            vlSelf->wasmetal_core__DOT__load_lane__05b17__05d 
                = (1U & (vlSelf->insn_y >> 0x11U));
            vlSelf->wasmetal_core__DOT__load_lane__05b16__05d 
                = (1U & (vlSelf->insn_y >> 0x10U));
            vlSelf->wasmetal_core__DOT__load_lane__05b15__05d 
                = (1U & (vlSelf->insn_y >> 0xfU));
            vlSelf->wasmetal_core__DOT__load_lane__05b14__05d 
                = (1U & (vlSelf->insn_y >> 0xeU));
            vlSelf->wasmetal_core__DOT__load_lane__05b13__05d 
                = (1U & (vlSelf->insn_y >> 0xdU));
            vlSelf->wasmetal_core__DOT__load_lane__05b12__05d 
                = (1U & (vlSelf->insn_y >> 0xcU));
            vlSelf->wasmetal_core__DOT__load_lane__05b11__05d 
                = (1U & (vlSelf->insn_y >> 0xbU));
            vlSelf->wasmetal_core__DOT__load_lane__05b10__05d 
                = (1U & (vlSelf->insn_y >> 0xaU));
            vlSelf->wasmetal_core__DOT__load_lane__05b9__05d 
                = (1U & (vlSelf->insn_y >> 9U));
            vlSelf->wasmetal_core__DOT__load_lane__05b8__05d 
                = (1U & (vlSelf->insn_y >> 8U));
            vlSelf->wasmetal_core__DOT__load_lane__05b7__05d 
                = (1U & (vlSelf->insn_y >> 7U));
            vlSelf->wasmetal_core__DOT__load_lane__05b6__05d 
                = (1U & (vlSelf->insn_y >> 6U));
            vlSelf->wasmetal_core__DOT__load_lane__05b5__05d 
                = (1U & (vlSelf->insn_y >> 5U));
            vlSelf->wasmetal_core__DOT__load_lane__05b4__05d 
                = (1U & (vlSelf->insn_y >> 4U));
            vlSelf->wasmetal_core__DOT__load_lane__05b3__05d 
                = (1U & (vlSelf->insn_y >> 3U));
            vlSelf->wasmetal_core__DOT__load_lane__05b2__05d 
                = (1U & (vlSelf->insn_y >> 2U));
            vlSelf->wasmetal_core__DOT__load_lane__05b1__05d 
                = (1U & (vlSelf->insn_y >> 1U));
            vlSelf->wasmetal_core__DOT__load_lane__05b0__05d 
                = (1U & vlSelf->insn_y);
            vlSelf->wasmetal_core__DOT__load_vector__05b66__05d 
                = vlSelf->wasmetal_core__DOT__top__05b66__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b122__05d 
                = vlSelf->wasmetal_core__DOT__top__05b122__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b106__05d 
                = vlSelf->wasmetal_core__DOT__top__05b106__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b123__05d 
                = vlSelf->wasmetal_core__DOT__top__05b123__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b125__05d 
                = vlSelf->wasmetal_core__DOT__top__05b125__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b101__05d 
                = vlSelf->wasmetal_core__DOT__top__05b101__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b114__05d 
                = vlSelf->wasmetal_core__DOT__top__05b114__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b121__05d 
                = vlSelf->wasmetal_core__DOT__top__05b121__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b117__05d 
                = vlSelf->wasmetal_core__DOT__top__05b117__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b118__05d 
                = vlSelf->wasmetal_core__DOT__top__05b118__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b115__05d 
                = vlSelf->wasmetal_core__DOT__top__05b115__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b113__05d 
                = vlSelf->wasmetal_core__DOT__top__05b113__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b64__05d 
                = vlSelf->wasmetal_core__DOT__top__05b64__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b96__05d 
                = vlSelf->wasmetal_core__DOT__top__05b96__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b72__05d 
                = vlSelf->wasmetal_core__DOT__top__05b72__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b80__05d 
                = vlSelf->wasmetal_core__DOT__top__05b80__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b112__05d 
                = vlSelf->wasmetal_core__DOT__top__05b112__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b127__05d 
                = vlSelf->wasmetal_core__DOT__top__05b127__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b119__05d 
                = vlSelf->wasmetal_core__DOT__top__05b119__05d;
        }
        if (vlSelf->wasmetal_core__DOT___019792_) {
            vlSelf->wasmetal_core__DOT__bulk_source_unit__05b3__05d 
                = (1U & (4U >> (IData)(vlSelf->__VdfgTmp_he0cbb0dc__0)));
            vlSelf->wasmetal_core__DOT__bulk_source_unit__05b2__05d 
                = (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hed859ce1__0)));
            vlSelf->wasmetal_core__DOT__bulk_source_unit__05b0__05d 
                = (1U & (0xf1U >> ((4U & (vlSelf->insn_z 
                                          >> 1U)) | (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050503_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b255__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050502_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b254__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050497_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b253__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050496_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b252__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051258_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b251__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049829_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b250__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049828_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b249__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049826_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b248__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049681_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b239__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051254_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b238__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049682_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b237__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049680_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b236__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050295_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b227__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050270_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b226__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050293_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b225__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050271_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b224__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049593_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b191__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050495_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b190__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049585_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b189__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051263_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b188__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051260_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b187__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051279_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b186__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051262_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b185__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051261_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b184__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051302_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b183__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051259_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b182__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051257_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b181__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051256_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b180__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049349_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b143__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049389_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b142__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049348_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b141__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049346_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b140__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051238_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b135__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051237_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b134__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050747_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b133__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049004_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b132__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051216_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b127__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051215_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b126__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051214_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b125__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051212_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b124__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051208_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b123__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051209_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b122__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049395_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b121__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051207_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b120__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048543_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b111__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048568_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b110__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051194_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b109__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051195_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b108__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051196_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b107__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051140_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b106__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051139_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b105__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051138_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b104__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049827_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b247__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049824_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b246__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049773_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b245__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049774_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b244__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049730_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b243__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049728_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b242__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049729_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b241__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050786_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b240__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049679_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b235__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049929_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b234__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049930_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b233__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050163_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b232__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051250_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b231__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051251_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b230__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050328_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b229__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050267_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b228__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051241_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b139__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051242_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b138__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050157_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b137__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050902_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b136__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048963_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b131__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048692_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b130__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048301_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b129__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048682_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b128__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048512_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b119__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051070_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b118__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051198_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b117__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051197_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b116__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051540_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b115__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048547_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b114__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048544_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b113__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048538_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b112__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051137_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b103__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049941_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b102__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051136_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b101__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051135_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b100__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050562_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b99__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051134_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b98__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051132_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b97__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049947_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b96__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050290_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b223__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050292_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b222__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050288_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b221__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050289_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b220__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050287_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b219__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050286_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b218__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050284_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b217__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050283_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b216__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050070_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b207__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050037_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b206__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051275_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b205__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050036_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b204__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050472_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b199__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050393_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b198__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050477_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b197__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051123_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b196__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050909_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b179__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051255_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b178__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050156_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b177__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050134_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b176__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050133_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b175__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049548_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b174__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049547_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b173__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049546_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b172__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050280_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b163__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050285_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b162__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049445_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b161__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049446_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b160__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049443_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b159__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049442_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b158__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049441_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b157__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050305_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b156__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050298_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b155__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050297_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b154__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048576_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b153__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048574_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b152__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050304_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b147__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050299_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b146__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051247_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b145__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049350_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b144__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049946_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b95__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049948_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b94__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050368_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b93__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050555_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b92__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050556_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b91__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051131_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b90__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051130_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b89__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051129_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b88__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050439_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b79__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050440_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b78__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050436_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b77__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049582_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b76__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050378_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b71__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050377_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b70__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050374_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b69__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050375_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b68__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050370_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b67__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050372_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b66__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049425_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b65__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049426_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b64__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050282_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b215__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050281_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b214__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049604_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b213__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050071_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b212__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049605_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b211__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049862_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b210__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049597_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b209__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049920_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b208__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051273_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b203__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050473_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b202__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050087_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b201__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050474_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b200__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050903_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b195__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050072_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b194__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049592_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b193__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050563_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b192__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049551_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b171__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049544_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b170__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050090_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b169__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051231_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b168__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051249_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b167__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051248_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b166__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050294_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b165__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050296_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b164__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051128_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b87__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049943_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b86__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050469_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b85__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050468_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b84__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050466_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b83__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050465_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b82__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050088_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b81__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050089_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b80__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049058_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b151__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049391_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b150__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049393_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b149__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050306_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b148__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050395_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b75__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050396_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b74__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050391_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b73__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050390_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b72__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049423_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b63__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050355_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b62__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050356_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b61__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050279_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b60__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050333_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b59__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050330_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b58__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050329_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b57__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049583_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b56__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050326_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b55__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050324_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b54__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050323_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b53__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049594_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b52__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051234_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b31__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051213_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b30__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051211_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b29__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050734_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b28__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050376_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b27__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051206_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b26__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051193_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b25__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051192_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b24__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050373_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b19__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050367_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b18__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050345_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b17__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050083_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b16__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051379_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b51__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049935_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b50__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049922_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b49__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049919_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b48__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049951_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b47__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049950_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b46__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049949_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b45__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051378_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b44__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051245_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b39__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051243_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b38__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051244_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b37__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050085_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b36__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050086_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b35__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051233_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b34__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050369_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b33__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051232_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b32__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050910_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b23__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051190_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b22__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050437_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b21__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051133_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b20__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050084_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b15__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051489_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b14__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051490_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b13__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050331_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b12__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050325_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b11__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051377_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b10__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051488_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b9__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051487_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b8__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049612_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b7__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049939_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b6__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049952_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b5__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049937_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b4__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049916_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b43__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049915_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b42__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050471_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b41__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___051246_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b40__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___049940_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b3__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050327_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b2__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050470_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b1__05d = 1U;
        }
        if ((1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___050478_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049422_))))) {
            vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b0__05d = 1U;
        }
        if (vlSelf->wasmetal_core__DOT___053475_) {
            vlSelf->wasmetal_core__DOT__simd_product__05b63__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b62__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b61__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b59__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b57__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b56__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b55__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b54__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b53__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b52__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b60__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b58__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b0__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b1__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b2__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b3__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b4__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b23__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b24__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b25__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b26__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b29__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b30__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b6__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b33__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b12__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b36__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b14__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b7__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b39__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b9__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b8__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b5__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b46__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b28__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b47__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b48__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b49__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b32__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b34__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b21__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b22__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b10__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b35__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b37__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b31__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b11__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b40__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b41__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b38__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b43__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b13__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b42__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b44__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b27__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b45__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b15__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b50__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b16__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b17__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b18__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b19__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b51__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d;
            vlSelf->wasmetal_core__DOT__simd_product__05b20__05d 
                = vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d;
        }
        if (vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) {
            vlSelf->wasmetal_core__DOT__fpu__02edivide_wide 
                = vlSelf->wasmetal_core__DOT__fpu__02ewide;
        }
        if (vlSelf->wasmetal_core__DOT___019806_) {
            vlSelf->wasmetal_core__DOT____Vcellout___128897___Q 
                = (1U & (IData)((0xaaaaf0f0ffccfffcULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___062983_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052995_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___062997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062982_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___062987_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___128896___Q 
                = (1U & (0xffff44f4U >> (((IData)(vlSelf->wasmetal_core__DOT___062988_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___062987_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052995_)))))));
        }
        if (vlSelf->wasmetal_core__DOT___046015_) {
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070388_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070387_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070386_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070381_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068999_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069873_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070170_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070169_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070168_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xee00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070163_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068191_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069519_))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070400_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070399_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070398_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070393_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069030_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069894_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070097_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070096_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070095_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xee00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070090_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067887_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069395_))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070376_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070375_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070374_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070369_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068931_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069855_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070286_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070285_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070284_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070279_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068589_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069705_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069361_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x8acf00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069354_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069353_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h17a5807b__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf4606e0f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90da4ee0__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h799a13b5__0))))))))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069362_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069386_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069385_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x8acf00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069379_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ea85ece__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h720d5baf__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h102f49bb__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd98b4743__0))))))))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069387_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070413_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070412_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070411_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b124__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070406_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xfffe0001ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5851eae3__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069076_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069412_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069411_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x8acf00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069404_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069403_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9616de3d__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb19dabb4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h14a49668__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc01ceff5__0))))))))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069413_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070438_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070437_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070436_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b126__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070431_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x7cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___069190_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069192_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070064_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070063_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 1U)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070066_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070061_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070060_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070057_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067795_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069346_))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067778_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h17a5807b__0))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0xdf0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070081_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070080_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070079_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xe00ee0000ffffULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b100__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070075_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff80007fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9ae21ada__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067843_)))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___070082_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070108_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070107_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 4U)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070110_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070105_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070104_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070101_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067948_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069421_))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xcfaf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067925_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78f256d8__0))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069557_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069556_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xbf333f3f00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069549_) 
                                                                               << 5U) 
                                                                              | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069548_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b75__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x4aU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065851_)))))))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069558_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069972_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069971_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069970_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xfef00000f0f0f0fULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069961_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069960_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067438_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070198_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070197_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 0xaU)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070200_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070195_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070194_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068258_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b108__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3daad387__0))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x5fcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068263_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b108__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50efe2fe__0))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070213_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070212_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 0xbU)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070215_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070210_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070209_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x1f100ffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b109__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcf04e80b__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b109__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070206_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfb15U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd4f38404__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068329_)))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070228_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070227_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 0xcU)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070230_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070225_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070224_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b110__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070221_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x7dU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068385_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068386_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xcfaf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068367_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b110__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf270fd27__0))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069310_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069309_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x8acf00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069303_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069302_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4121b81d__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha5948160__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcbf20e6d__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h46342433__0))))))))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___069311_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070157_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070156_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b105__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070150_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xfb15U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf7093f37__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068137_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070324_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070323_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070322_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070317_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069770_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070336_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070335_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070334_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070329_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068786_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069791_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070298_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070297_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070296_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070291_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068638_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069727_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xfdf0f0f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___069534_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069533_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069532_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___069536_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((0xbb0b0000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___069527_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069526_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (IData)(
                                                                               (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b4a166b__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6f0d7f4__0))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070274_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070273_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070272_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070267_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068524_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069682_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069718_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069717_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069716_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0xaa330f0000000000ULL 
                                                                            >> 
                                                                            ((0x38U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066505_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069705_)))))) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & ((0xfe540000U 
                                                                       >> 
                                                                       ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 1U)) 
                                                                        | ((8U 
                                                                            & ((0x7f0000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heceac102__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066509_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069455_)))))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b82__05d)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xfdf0f0f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___069603_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069602_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069601_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___069605_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069596_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069595_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b77__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab510120__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0afb0546__0))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b77__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbab7bc7d__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc00cbbb6__0))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xfdf0f0f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___069510_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069509_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069508_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___069512_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0xbf333f3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069503_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069502_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b73__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x4aU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065656_)))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069740_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069739_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069738_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x3faf00000f0f0f0fULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069730_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b83__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069728_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066588_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069762_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069761_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069760_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xa0aa303300ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b84__05d) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x7fff80000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9ae21ada__0))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066700_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x5cU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069749_))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069783_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069782_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069781_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x5fcf00000f0f0f0fULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069773_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b85__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066755_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf7f00000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069805_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069804_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069803_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xfef00000f0f0f0fULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069795_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069794_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b86__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066838_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070262_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070261_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070260_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070253_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068505_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069662_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070361_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070360_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 0x16U)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070363_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070358_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070357_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x1000fcffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b120__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066994_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066993_)))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b120__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070353_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfe01ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8c4cb679__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068881_)))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d 
                = (1U & (IData)((0xfffffff8ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070011_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070010_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070009_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x44f4ffff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070005_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070004_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0x153f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___070140_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070139_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & (vlSelf->cmd_data[3U] 
                                                                   >> 6U)) 
                                                               | ((2U 
                                                                   & ((0xf38f2779U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070142_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070136_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070135_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x1f100ffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13c22a42__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070128_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf807ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 4U) 
                                                                                | (0xfU 
                                                                                & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O), 1U)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068063_)))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067588_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070450_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070449_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070448_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070443_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069224_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069979_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070348_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070347_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070346_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070341_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068835_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069814_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069992_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069991_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069990_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0xaa330f0000000000ULL 
                                                                            >> 
                                                                            ((0x38U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067533_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069221_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069979_)))))) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & ((0xfe540000U 
                                                                       >> 
                                                                       ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___069980_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067534_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069455_)))))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b95__05d)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069651_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069650_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069649_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xb0bbU 
                                                              >> 
                                                              ((8U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                               | ((4U 
                                                                   & ((0xaacc0fffU 
                                                                       >> 
                                                                       ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066230_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068459_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___069637_))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b79__05d) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (0x5f4e0000U 
                                                                           >> 
                                                                           ((0x18U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___069639_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___066233_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069455_)))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070245_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070244_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070243_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b111__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070238_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xfc45U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069639_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffe000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d53ab65__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068460_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069827_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069826_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069825_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xdU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0xaa330f0000000000ULL 
                                                                            >> 
                                                                            ((0x38U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069814_)))))) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & ((0xfe540000U 
                                                                       >> 
                                                                       ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___069815_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066921_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069455_)))))) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b87__05d)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))));
        }
        if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)))) {
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b113__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b105__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b105__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b99__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b99__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b97__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b97__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b89__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b89__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b81__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b73__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b73__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b65__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b65__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b57__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b57__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b49__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b41__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b41__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b35__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b35__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b33__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b33__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b25__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b25__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b17__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b9__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b9__05d;
        }
        if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))) {
            vlSelf->wasmetal_core__DOT__divider__02eis_wide 
                = vlSelf->wasmetal_core__DOT__divider__02ewide;
        }
        if (vlSelf->wasmetal_core__DOT___019797_) {
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x19U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x18U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x17U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x16U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054442_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054441_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x15U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054440_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054439_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x14U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054438_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054437_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x13U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054436_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054435_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x12U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054434_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054433_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x11U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054432_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054431_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0x10U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054430_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0xfU)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054428_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054427_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
            vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d 
                = (1U & (IData)((0xf888f888ffff0000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                      << 5U) | ((0x10U 
                                                 & (vlSelf->cmd_data[1U] 
                                                    >> 0xeU)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054426_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054425_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019801_) {
            vlSelf->wasmetal_core__DOT____Vcellout___129022___Q 
                = (1U & (IData)((0xffff7000ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___063079_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___063078_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___053616_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_x 
                                                          >> 0xfU)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
            vlSelf->wasmetal_core__DOT____Vcellout___129002___Q 
                = (1U & (IData)((0xffffa0c0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___063057_) 
                                      << 5U) | ((0x10U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h277c2e25__0)) 
                                                    << 4U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b0__05d)))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019803_) {
            vlSelf->wasmetal_core__DOT____Vcellout___128999___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x1dU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1eU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128441___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128273___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128998___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x1cU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1dU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128441___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128273___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128997___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x1bU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1cU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128441___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128273___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128996___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x1aU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1bU)) 
                                                                | (1U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128441___O))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128273___O) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128995___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x19U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1aU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128440___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128272___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128994___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x18U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x19U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128440___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128272___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128993___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x17U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x18U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128440___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128272___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128992___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x16U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x17U)) 
                                                                | (1U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128440___O))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128272___O) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128991___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x15U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x16U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128439___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128271___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128990___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x14U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x15U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128439___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128271___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128989___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x13U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128439___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128271___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128988___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x12U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x13U)) 
                                                                | (1U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128439___O))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128271___O) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128987___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x11U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x12U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128438___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128270___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128986___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0x10U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x11U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128438___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128270___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128985___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xfU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x10U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128438___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128270___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128984___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xeU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xfU)) 
                                                                | (1U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128438___O))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128270___O) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128983___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xdU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xeU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128437___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128269___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128982___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xcU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xdU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128437___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128269___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128981___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xbU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xcU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128437___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128269___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128980___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 0xaU)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xbU)) 
                                                                | (1U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128437___O))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128269___O) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128979___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 9U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xaU)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128436___O) 
                                                                      >> 3U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128268___O) 
                                           >> 2U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128978___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 8U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 9U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128436___O) 
                                                                      >> 2U))))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128268___O) 
                                           >> 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
            vlSelf->wasmetal_core__DOT____Vcellout___128977___Q 
                = (1U & (0x8fU >> ((4U & ((IData)((0x33305550fff0fffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063021_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_index 
                                                                 >> 7U)) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 8U)) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128436___O) 
                                                                      >> 1U))))))))) 
                                          << 2U)) | 
                                   ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128268___O)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___052986_)))));
        }
    }
    if (vlSelf->wasmetal_core__DOT___020525_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b0__05d 
            = (1U & (IData)((0x7fffffffffffffffULL 
                             >> (((IData)(vlSelf->wasmetal_core__DOT___053611_) 
                                  << 5U) | ((0x10U 
                                             & ((1U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128807___O)) 
                                                << 4U)) 
                                            | ((8U 
                                                & ((1U 
                                                    >> 
                                                    (7U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O))) 
                                                   << 3U)) 
                                               | ((4U 
                                                   & ((1U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128804___O)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042826_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x8000000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053607_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053606_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053605_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128801___O)) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___042824_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053602_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053601_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053600_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053599_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042821_)))))))))))))))))))))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d 
            = vlSelf->wasmetal_core__DOT___019814_;
    }
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040072_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040058_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040057_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040082_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039658_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040081_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039872_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040106_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039714_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040052_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040051_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040075_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039741_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040049_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040048_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039758_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040109_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040046_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040045_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039760_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040044_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040043_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040083_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039761_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040042_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040041_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040085_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040064_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039409_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039647_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d 
        = vlSelf->wasmetal_core__DOT___040078_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040067_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040071_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039563_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040069_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040068_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040079_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040105_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040070_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040066_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039408_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040065_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040086_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039590_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040053_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039596_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040063_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040062_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040108_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___039631_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040061_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040060_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase))) 
           && (IData)(vlSelf->wasmetal_core__DOT___040054_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d 
        = vlSelf->wasmetal_core__DOT___040107_;
    vlSelf->wasmetal_core__DOT__table_sizes__02epending_write 
        = ((1U & (~ (IData)(vlSelf->reset))) && (1U 
                                                 & (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___046019_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___053362_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d 
        = vlSelf->wasmetal_core__DOT___040084_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d 
        = vlSelf->wasmetal_core__DOT___040099_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d 
        = vlSelf->wasmetal_core__DOT___040100_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d 
        = vlSelf->wasmetal_core__DOT___040103_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d 
        = vlSelf->wasmetal_core__DOT___040076_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d 
        = vlSelf->wasmetal_core__DOT___040101_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d 
        = vlSelf->wasmetal_core__DOT___040098_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d 
        = vlSelf->wasmetal_core__DOT___040080_;
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d 
        = vlSelf->wasmetal_core__DOT___040102_;
    if (vlSelf->wasmetal_core__DOT___020523_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b51__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b50__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b49__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b48__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b47__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b46__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b45__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b44__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b43__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b42__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b41__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b40__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b39__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b38__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b37__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b36__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b35__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b34__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b33__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b32__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b31__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b30__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b29__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b28__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b27__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b26__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b25__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b24__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b23__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b22__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b21__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b20__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b19__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b18__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b17__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b16__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b15__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b14__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b13__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b12__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b11__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b10__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b9__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b8__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b7__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b6__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b5__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b4__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b3__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b2__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b1__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d;
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b0__05d 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02emajorExc_Z 
            = (1U & (IData)((0xfffff0f0ffff44ffULL 
                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___058093_) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058092_) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058091_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058089_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d)))))))));
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b11__05d 
            = (1U & (0xf0eeU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                             << 2U) 
                                            | ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                   >> 2U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042788_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b10__05d 
            = (1U & (0xfeeU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                 << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___042788_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b9__05d 
            = (1U & (0xf044U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d) 
                                             << 2U) 
                                            | ((2U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042788_))))));
    }
    vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039857_));
    vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039856_));
    if (vlSelf->wasmetal_core__DOT___019810_) {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d = 0U;
    } else if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)))) {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128814___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128814___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128814___O) 
                     >> 1U));
    }
}
