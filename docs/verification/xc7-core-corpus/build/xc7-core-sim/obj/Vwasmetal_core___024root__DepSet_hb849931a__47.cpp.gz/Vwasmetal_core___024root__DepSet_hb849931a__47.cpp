#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__19(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__19\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___030777_;
    wasmetal_core__DOT___030777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031160_;
    wasmetal_core__DOT___031160_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031448_;
    wasmetal_core__DOT___031448_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031731_;
    wasmetal_core__DOT___031731_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031735_;
    wasmetal_core__DOT___031735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032471_;
    wasmetal_core__DOT___032471_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__ = 0;
    // Body
    wasmetal_core__DOT___031731_ = ((IData)(vlSelf->wasmetal_core__DOT___031795_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d));
    wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034754_));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b1__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___019808_) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b29__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b28__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054571_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b28__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b27__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054570_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b27__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b26__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054569_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b26__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b25__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054568_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b25__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b24__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054567_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b24__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b23__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054566_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b23__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b22__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054565_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b22__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b21__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054564_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b21__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b20__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054563_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b20__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b19__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054562_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b19__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b18__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054561_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b18__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b17__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054560_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b17__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b16__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054559_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b16__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b15__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054558_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b15__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b14__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054557_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b14__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b13__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054556_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b13__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b12__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054555_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b12__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b11__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054554_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b11__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b10__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054553_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b10__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b9__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054552_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b9__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b8__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054551_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b8__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b7__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054550_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b7__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b6__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054549_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b6__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b5__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054548_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b5__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b4__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054547_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b4__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b3__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054546_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b3__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b2__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054545_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b2__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b1__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054544_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b1__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b0__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054543_))))));
    }
    wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030838_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030773_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128335___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031156_)))));
    wasmetal_core__DOT___031160_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128359___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031444_)))));
    wasmetal_core__DOT___031448_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128447___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032535_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032534_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032533_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032532_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032467_)))));
    wasmetal_core__DOT___032471_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032535_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032535_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031796_)
            ? (IData)(wasmetal_core__DOT___031731_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d));
    wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034693_) 
           & (IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030839_)
            ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d));
    wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)
            : (IData)(wasmetal_core__DOT___031160_));
    wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)
            : (IData)(wasmetal_core__DOT___031448_));
    wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032537_)
                  ? (IData)(wasmetal_core__DOT___032471_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032537_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031797_)
            ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128678___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034695_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034692_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                & (IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128678___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034754_)))));
    wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030840_)
            ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d));
    wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)
            : (IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)
            : (IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032538_)
                  ? (IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032538_))));
    wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031798_)
            ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128303___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030841_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030840_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030839_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030838_)))) 
           ^ (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030773_)))));
    wasmetal_core__DOT___030777_ = ((IData)(vlSelf->wasmetal_core__DOT___030841_)
                                     ? (IData)(wasmetal_core__DOT___128303___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128336___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d)
                 : (IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128336___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031160_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128360___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)
                 : (IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128360___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031448_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128448___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032540_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032539_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032538_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032537_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___032539_)
                       ? (IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___032539_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___128448___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___032471_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128383___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031799_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031798_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031796_)))) 
           ^ (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031731_)))));
    wasmetal_core__DOT___031735_ = ((IData)(vlSelf->wasmetal_core__DOT___031799_)
                                     ? (IData)(wasmetal_core__DOT___128383___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d));
    wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030843_)
            ? (IData)(wasmetal_core__DOT___030777_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d));
    wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031801_)
            ? (IData)(wasmetal_core__DOT___031735_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d));
    wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030844_)
            ? (IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d));
    wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031802_)
            ? (IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128304___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030846_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030845_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030844_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030843_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030845_)
                 ? (IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128304___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030777_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128384___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031804_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031803_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031802_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031801_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031803_)
                 ? (IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128384___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031735_)))));
    vlSelf->wasmetal_core__DOT__divider__02edividend__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040035_));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__20(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__20\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___068784_;
    wasmetal_core__DOT___068784_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069560_;
    wasmetal_core__DOT___069560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069793_;
    wasmetal_core__DOT___069793_ = 0;
    CData/*1:0*/ __VdfgTmp_h183f3794__0;
    __VdfgTmp_h183f3794__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6f16836b__0;
    __VdfgTmp_h6f16836b__0 = 0;
    CData/*2:0*/ __VdfgTmp_he0dd3f12__0;
    __VdfgTmp_he0dd3f12__0 = 0;
    CData/*2:0*/ __VdfgTmp_h82a2f635__0;
    __VdfgTmp_h82a2f635__0 = 0;
    CData/*1:0*/ __VdfgTmp_hff1aabe2__0;
    __VdfgTmp_hff1aabe2__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT____Vcellinp__labels_memory__02e0__02e0__ADDRARDADDR 
        = (0x800fU | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
                       << 0xeU) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                    << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                 << 0xcU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                                    << 0xbU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
                                                       << 0xaU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                                          << 9U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d) 
                                                             << 8U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                                                << 7U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                                                                   << 6U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d) 
                                                                      << 5U) 
                                                                     | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                                                        << 4U))))))))))));
    vlSelf->wasmetal_core__DOT___021739_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17767d6e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052014_))));
    vlSelf->wasmetal_core__DOT___021740_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d))));
    vlSelf->wasmetal_core__DOT___021741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052015_))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e14__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e10__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b97__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b93__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b92__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b91__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b90__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e13__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e11__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b103__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e12__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e9__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b88__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b81__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e8__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b78__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b76__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b72__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e7__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b70__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b66__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b64__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b63__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e6__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e5__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e4__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e3__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e2__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e1__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__ADDRARDADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT___000209_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h17767d6e__0)))));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_vector__05b17__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___046015_) {
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b98__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070052_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070051_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070050_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b98__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070043_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xfa23U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064875_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x8000ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heceac102__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067716_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b125__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070425_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070424_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070423_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xbb00f000ff00ffULL 
                                                                      >> 
                                                                      ((0x30U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___070418_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___069125_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069937_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b107__05d 
                = (1U & (IData)((0xffff20f0ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___070184_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___070183_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___070182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xe00ee0000ffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b107__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070177_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xfb15U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe76cb01__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068223_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b116__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0x153f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___070309_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070308_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & (vlSelf->cmd_data[3U] 
                                                                 >> 0x12U)) 
                                                             | ((2U 
                                                                 & ((0xf38f2779U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0x44f4ffff00000000ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___070306_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___070305_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & (IData)(
                                                                              (0xe00ee0000ffffULL 
                                                                               >> 
                                                                               ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b116__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070303_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff80007ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc11d54c0__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068688_)))))))))))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___070310_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b89__05d 
                = (1U & (IData)((0xfffffff2ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069869_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069868_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069867_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xbbb0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___069861_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h8511382f__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xfdf0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___069860_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___069859_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069857_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067051_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069455_)))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b89__05d)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067588_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b80__05d 
                = (1U & (IData)((0xfffffff8ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069673_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069672_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___069671_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xbbb0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___069666_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf3cb0d91__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b71__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xdf0f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___069463_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069462_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069461_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0xfef00000f0f0f0fULL 
                                                                             >> 
                                                                             ((0x20U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069457_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069456_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065495_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xcfaf0f0f00000000ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0xbbb0000U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069464_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce00e764__0))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___069466_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___069202_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___069201_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xafcf0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___069171_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h4fe8c7bc__0))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xdf0f0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___069194_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069193_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069192_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d 
                = (1U & (0xbU >> ((2U & ((IData)((0x1000ffff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068762_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068761_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xafcfU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___068744_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xcfaf0f0f00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068755_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068754_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4b249985__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0fbf0f0ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068751_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0ccf0f0000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002601_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063837_)))))))))))))))) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___068763_))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d 
                = (1U & (0xf2ffU >> ((8U & ((IData)(
                                                    (0xaf3f00000000ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___068283_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068282_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___054209_)))))))) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___068307_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(
                                                               (0xaf8c00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___068305_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068304_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048832_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002729_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002730_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057167_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___067807_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___067806_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaf8c00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067767_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067766_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb4d5b900__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h343b1824__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xaf2300000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___067800_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067799_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067798_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbfff3f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067794_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067778_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h17a5807b__0))))))))))))))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d 
                = (1U & (0xefU >> ((4U & ((IData)((0xaf3f00000000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___067144_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067143_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054158_)))))))) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (0xf0f0f080f0f0f0f0ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___067173_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067172_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___067171_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060927_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___048505_)))))))) 
                                           << 1U)) 
                                    | (IData)(vlSelf->wasmetal_core__DOT___067183_)))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d 
                = (1U & (IData)((0xffffffff4f44ffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___066474_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___066473_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x35f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___066420_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066419_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011731_))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060834_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((IData)(
                                                                               (0xd00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066462_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066461_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066460_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xdfc00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbfa812aa__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h82d7bb11__0)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x30f0200030f030fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066445_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x330f5500000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064667_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064666_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064696_))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066439_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066442_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019390_)))))))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_)))))))))))));
            vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d 
                = (1U & (IData)((0xffffef00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___065637_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___065636_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x70U 
                                                           >> 
                                                           ((4U 
                                                             & ((IData)(
                                                                        (0xf0fd00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___065630_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065629_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002517_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002515_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002516_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056492_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064012_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056492_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (0x1fU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hcb50dc13__0)))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf00eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065632_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011081_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011080_)))))))))))))));
        }
        if (vlSelf->wasmetal_core__DOT___052916_) {
            vlSelf->wasmetal_core__DOT__load_vector__05b98__05d 
                = vlSelf->wasmetal_core__DOT__top__05b98__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b107__05d 
                = vlSelf->wasmetal_core__DOT__top__05b107__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b116__05d 
                = vlSelf->wasmetal_core__DOT__top__05b116__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b89__05d 
                = vlSelf->wasmetal_core__DOT__top__05b89__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b71__05d 
                = vlSelf->wasmetal_core__DOT__top__05b71__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b35__05d 
                = vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d;
            vlSelf->wasmetal_core__DOT__load_vector__05b17__05d 
                = vlSelf->wasmetal_core__DOT___001624_;
        }
    }
    vlSelf->wasmetal_core__DOT___019408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064267_))));
    vlSelf->wasmetal_core__DOT___070309_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b116__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x12U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b116__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->__VdfgTmp_he557a56d__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h673d32f0__0))));
    vlSelf->wasmetal_core__DOT___064247_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064093_))))));
    vlSelf->wasmetal_core__DOT___051016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051013_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___064453_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    vlSelf->wasmetal_core__DOT___064993_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128576___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___048520_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048517_))));
    vlSelf->wasmetal_core__DOT___064696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064680_))));
    vlSelf->wasmetal_core__DOT___064667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064650_))));
    vlSelf->wasmetal_core__DOT___064666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064664_))));
    vlSelf->wasmetal_core__DOT___019392_ = (1U & (0xf800U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065582_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065584_))))));
    vlSelf->wasmetal_core__DOT___019393_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065586_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065584_)))));
    vlSelf->wasmetal_core__DOT___019394_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___064976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064973_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    vlSelf->wasmetal_core__DOT___019390_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128533___O 
        = ((3U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                         << 3U)) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                          << 2U)))) 
           ^ (7U | (8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                          << 3U))));
    vlSelf->wasmetal_core__DOT____Vcellout___128585___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (1U & 
                                               (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___048483_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    wasmetal_core__DOT___069560_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                             << 1U)) 
                                                           << 1U)))))));
    __VdfgTmp_hff1aabe2__0 = ((2U & ((1U >> (3U & (- (IData)(
                                                             (1U 
                                                              & (4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                  << 1U))))))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 1U))));
    __VdfgTmp_h82a2f635__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                               << 2U) | ((2U & ((8U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                                << 1U)) 
                                         | (1U & (0x80U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    __VdfgTmp_h6f16836b__0 = ((4U & ((0x80U >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                     << 2U)) | ((2U 
                                                 & ((8U 
                                                     >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)));
    __VdfgTmp_he0dd3f12__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                               << 2U) | (1U & (0x80U 
                                               >> (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    __VdfgTmp_h183f3794__0 = ((2U & ((0x80U >> (IData)(vlSelf->wasmetal_core__DOT___019408_)) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___064698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___070256_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->cmd_data[3U] 
                                                       >> 0xfU)) 
                                                   | (1U 
                                                      & (0xf38f2779U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he557a56d__0))))));
    vlSelf->__VdfgTmp_ha2ee8e39__0 = ((2U & ((0xf38f2779U 
                                              >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___053281_));
    vlSelf->__VdfgTmp_hf748d2ff__0 = ((2U & ((0xf38f2779U 
                                              >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063459_));
    vlSelf->__VdfgTmp_hb731668a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xfe01ffffU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            << 2U)) 
                                                        | (1U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))))));
    vlSelf->__VdfgTmp_hed3b8a65__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h20f14479__0)))));
    vlSelf->__VdfgTmp_hc9c81b10__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf195595b__0)))));
    vlSelf->__VdfgTmp_ha07de1bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5c1a0f86__0)))));
    vlSelf->__VdfgTmp_h5362ea73__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_had7d0cfa__0)))));
    vlSelf->__VdfgTmp_hfc327362__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x3aU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h484ca1c9__0)))));
    vlSelf->__VdfgTmp_h712d7252__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xa3U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc947a4ab__0)))));
    vlSelf->__VdfgTmp_h07144816__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbfa66a09__0)))));
    vlSelf->__VdfgTmp_heccca597__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xa3U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h14a49668__0)))));
    vlSelf->__VdfgTmp_h612fd420__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9a4c9e67__0)))));
    vlSelf->__VdfgTmp_h5e38b73e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha9829971__0)))));
    vlSelf->__VdfgTmp_ha036a4e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5b846e26__0)))));
    vlSelf->wasmetal_core__DOT___065128_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065113_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065111_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064196_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x5cU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))))))));
    vlSelf->wasmetal_core__DOT___065279_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065253_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065252_)))))))));
    vlSelf->wasmetal_core__DOT___065473_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065450_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065449_)))))))));
    vlSelf->wasmetal_core__DOT___065366_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065342_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065341_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065340_)))))))));
    vlSelf->wasmetal_core__DOT___066379_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066355_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066354_)))))));
    vlSelf->wasmetal_core__DOT___064637_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064634_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064632_)))))))));
    vlSelf->wasmetal_core__DOT___065576_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065533_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065532_)))))))));
    vlSelf->wasmetal_core__DOT___070060_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37cccaef__0))))));
    vlSelf->wasmetal_core__DOT___070104_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4f29c7eb__0))))));
    vlSelf->wasmetal_core__DOT___070135_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h220538c2__0))))));
    vlSelf->wasmetal_core__DOT___070119_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b103__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068001_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068000_)))))));
    vlSelf->wasmetal_core__DOT___069567_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0a030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b76__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50efe2fe__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h051c8ed8__0)))))))));
    vlSelf->wasmetal_core__DOT___068054_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b40__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h220538c2__0))))));
    vlSelf->wasmetal_core__DOT___070224_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b110__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hda165e4b__0))))));
    vlSelf->wasmetal_core__DOT___068463_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068453_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068452_)))))));
    vlSelf->wasmetal_core__DOT___070209_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b109__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068321_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068320_)))))));
    vlSelf->wasmetal_core__DOT___068872_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068867_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068866_)))))));
    vlSelf->wasmetal_core__DOT___068268_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5fcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___068263_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b44__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h50efe2fe__0)))))))))));
    vlSelf->wasmetal_core__DOT___063456_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051016_))));
    vlSelf->wasmetal_core__DOT___052947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045941_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051016_))));
    vlSelf->wasmetal_core__DOT___072258_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045941_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h005ba8bd__0)))));
    vlSelf->__VdfgTmp_hb5acd9d8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___065544_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> 
                                                             (7U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___064079_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (7U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___064984_ = (1U & (IData)(
                                                         (0xe000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___065359_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                      << 2U))));
    vlSelf->wasmetal_core__DOT___066155_ = (1U & (0xfe000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                      << 3U))));
    vlSelf->wasmetal_core__DOT___066058_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | ((4U 
                                                       & ((0x80U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064543_)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064543_)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___064553_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 3U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___066993_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                    << 2U) 
                                                   | (2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)))));
    vlSelf->__VdfgTmp_hb1b9a71b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                  << 1U)) 
                                                                << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))))));
    vlSelf->wasmetal_core__DOT___065467_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 3U)))));
    vlSelf->wasmetal_core__DOT___065684_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                       << 2U) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))))));
    vlSelf->wasmetal_core__DOT___065877_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                              << 4U)))));
    vlSelf->__VdfgTmp_hc1dcc953__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                               << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___065541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->wasmetal_core__DOT___065993_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (- (IData)(
                                                                       (1U 
                                                                        & (8U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064543_)))))))))));
    vlSelf->wasmetal_core__DOT___064786_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064543_))))));
    vlSelf->__VdfgTmp_h01d11789__0 = (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O), 3U)));
    vlSelf->__VdfgTmp_h925d74fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                    << 4U)));
    vlSelf->wasmetal_core__DOT___065273_ = (1U & (0xe000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4f24f30__0))));
    vlSelf->wasmetal_core__DOT___064554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064544_))))))))))));
    vlSelf->wasmetal_core__DOT___065779_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4f24f30__0))));
    vlSelf->wasmetal_core__DOT___064787_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064779_))))))))));
    vlSelf->wasmetal_core__DOT___064985_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064981_))))))));
    vlSelf->wasmetal_core__DOT___065097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065091_))))))));
    vlSelf->wasmetal_core__DOT___065361_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065357_))))));
    vlSelf->wasmetal_core__DOT___065274_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065270_))))));
    vlSelf->wasmetal_core__DOT___066994_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065538_)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066362_)))))));
    vlSelf->wasmetal_core__DOT___065468_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065464_))))));
    vlSelf->wasmetal_core__DOT___065543_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065538_))))));
    vlSelf->__VdfgTmp_h54c4945a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064543_)));
    vlSelf->wasmetal_core__DOT___066156_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066154_))));
    vlSelf->wasmetal_core__DOT___066059_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066057_))));
    vlSelf->__VdfgTmp_h940ea061__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065991_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___066361_)) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h9b0680c9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065680_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066428_))))))));
    vlSelf->__VdfgTmp_h729a2b0d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065876_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066562_))))))));
    vlSelf->__VdfgTmp_hea3a75f9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066429_))))));
    vlSelf->__VdfgTmp_h5ea85090__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065778_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066485_))))))));
    vlSelf->__VdfgTmp_had85000c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065464_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066936_))))));
    vlSelf->__VdfgTmp_h9bb3dbab__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066154_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h53aa4fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064543_)));
    vlSelf->wasmetal_core__DOT___065780_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065778_))));
    vlSelf->wasmetal_core__DOT___066255_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066253_))));
    vlSelf->__VdfgTmp_hb159a4d2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066057_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___066427_)) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h34d9c714__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065091_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066676_))))));
    vlSelf->wasmetal_core__DOT___065681_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065680_))));
    vlSelf->wasmetal_core__DOT___065878_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065876_))));
    vlSelf->__VdfgTmp_hded1dcfc__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064981_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066563_))))));
    vlSelf->__VdfgTmp_h96a0f125__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065270_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066730_))))));
    vlSelf->__VdfgTmp_h72f36192__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065357_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066814_))))));
    vlSelf->__VdfgTmp_h8c50959a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066253_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065994_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065991_))));
    vlSelf->__VdfgTmp_he200cacd__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064779_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066486_))))));
    vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039854_));
    vlSelf->wasmetal_core__DOT___052997_ = (1U & (IData)(
                                                         (0xe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048116_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052995_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052994_)))))))));
    vlSelf->wasmetal_core__DOT__query_table = ((1U 
                                                & (~ (IData)(vlSelf->reset))) 
                                               && (IData)(vlSelf->wasmetal_core__DOT___039415_));
    vlSelf->wasmetal_core__DOT___063465_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063481_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063489_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063497_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063521_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063545_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063569_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063577_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063609_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063617_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063625_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063633_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063641_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063649_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063657_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063665_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063673_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063681_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063689_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063705_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___067588_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_))));
    vlSelf->wasmetal_core__DOT___053000_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052999_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052654_))))));
    vlSelf->wasmetal_core__DOT___067570_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067559_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))))));
    vlSelf->wasmetal_core__DOT___064249_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064247_))))));
    vlSelf->__VdfgTmp_h8c4cb679__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h8d2606de__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 3U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___067580_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___067582_ = (1U & (IData)(
                                                         (0x50f0f030f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___067285_ = (1U & (0xfe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))));
    vlSelf->wasmetal_core__DOT___069639_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     (2U 
                                                                      & ((4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U)) 
                                                                         << 1U))) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->__VdfgTmp_hc11d54c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 2U)) 
                                                 | ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                        << 3U)) 
                                                    | (4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___066701_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))))))));
    vlSelf->wasmetal_core__DOT___067287_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x44f00000U 
                                                         >> 
                                                         ((0x10U 
                                                           & ((1U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 2U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                              << 1U)) 
                                                                            << 1U))) 
                                                                       << 1U)) 
                                                                   | (1U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))))))))));
    vlSelf->wasmetal_core__DOT___069837_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1fe0000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                   << 5U) 
                                                                  | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U))))))));
    vlSelf->wasmetal_core__DOT___070253_ = (1U & (IData)(
                                                         (0xa802aaaaaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 1U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d))))))));
    vlSelf->wasmetal_core__DOT___065230_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (1U 
                                                             & (1U 
                                                                >> 
                                                                (3U 
                                                                 & (- (IData)(
                                                                              (1U 
                                                                               & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))))))));
    vlSelf->wasmetal_core__DOT___069683_ = (1U & (0xcf00aaU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                              << 1U))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___069815_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                      << 1U)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069939_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069980_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->__VdfgTmp_h9ae21ada__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | (0x1cU 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                    << 2U)));
    vlSelf->wasmetal_core__DOT___067845_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> 
                                                                  (1U 
                                                                   & (8U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069454_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    wasmetal_core__DOT___069793_ = (1U & (1U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xbU 
                                                       >> 
                                                       ((4U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 2U)) 
                                                        | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                           << 1U)))))));
    vlSelf->wasmetal_core__DOT___069190_ = (1U & (IData)(
                                                         (0x1ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 4U)) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 1U)))))));
    vlSelf->wasmetal_core__DOT___066746_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (1U 
                                                            & (1U 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->wasmetal_core__DOT___066185_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                               << 4U) 
                                                              | (8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    << 2U)))))));
    vlSelf->wasmetal_core__DOT___069521_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (1U 
                                                            & (1U 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069874_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                               << 1U))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064709_ = (1U & (0x8000bfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                               << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___067438_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | (0x18U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 3U))))));
    wasmetal_core__DOT___068784_ = (1U & (IData)((0xff00ff00ff1fffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                         << 3U))))));
    vlSelf->wasmetal_core__DOT___065388_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                      << 2U))));
    vlSelf->wasmetal_core__DOT___066838_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (4U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    << 2U)))))));
    vlSelf->wasmetal_core__DOT___067134_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                           << 1U))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___066236_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U))) 
                                                                      << 1U))))))))));
    vlSelf->wasmetal_core__DOT___065772_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xeU 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)))))))))))));
    vlSelf->__VdfgTmp_heceac102__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O), 3U)));
    vlSelf->wasmetal_core__DOT___064707_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> 
                                                         (1U 
                                                          & (0x80U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))))));
    vlSelf->wasmetal_core__DOT___066586_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0000000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___066507_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                              << 1U))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066038_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (1U 
                                                                        & (1U 
                                                                           >> 
                                                                           (3U 
                                                                            & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                                      << 1U))))))))));
    vlSelf->wasmetal_core__DOT___064875_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___065036_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0000000U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                          << 2U))))));
    vlSelf->wasmetal_core__DOT___069455_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___066440_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (- (IData)(
                                                                          (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                               << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___065516_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___019408_))))));
    vlSelf->wasmetal_core__DOT___066441_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___065962_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))));
    vlSelf->__VdfgTmp_hfe76cb01__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                         << 4U));
    vlSelf->__VdfgTmp_h62686ece__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                         << 3U));
    vlSelf->__VdfgTmp_h9d53ab65__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                    << 4U)));
    vlSelf->wasmetal_core__DOT___066341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___064868_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064710_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067647_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019408_))));
    vlSelf->wasmetal_core__DOT___069979_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___066579_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->wasmetal_core__DOT___067049_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065654_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065493_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064438_)))));
    vlSelf->__VdfgTmp_h14cfefd1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065492_));
    vlSelf->wasmetal_core__DOT___065658_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065654_)))))));
    vlSelf->wasmetal_core__DOT___065853_ = (1U & (0xaccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))));
    vlSelf->wasmetal_core__DOT___066836_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065033_))));
    vlSelf->wasmetal_core__DOT___065392_ = (1U & (0x5ccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf00886e7__0))))));
    vlSelf->wasmetal_core__DOT___069958_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065034_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf00886e7__0))));
    vlSelf->wasmetal_core__DOT___069937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069855_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069288_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069894_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069344_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069834_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069268_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069873_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069321_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___066193_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0))));
    vlSelf->wasmetal_core__DOT___069705_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069322_))));
    vlSelf->wasmetal_core__DOT___069814_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069451_))));
    vlSelf->wasmetal_core__DOT___067238_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065854_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde8128eb__0)))));
    vlSelf->wasmetal_core__DOT___067286_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065965_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0)))))));
    vlSelf->wasmetal_core__DOT___067382_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066024_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbca1334b__0)))));
    vlSelf->wasmetal_core__DOT___066580_ = (1U & (0xffccf0aaU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065023_))))));
    vlSelf->wasmetal_core__DOT___069749_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069370_))));
    vlSelf->wasmetal_core__DOT___069637_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069220_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___068459_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068458_)))));
    vlSelf->wasmetal_core__DOT___069682_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069289_))));
    vlSelf->wasmetal_core__DOT___069727_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069345_))));
    vlSelf->wasmetal_core__DOT___069770_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069394_))));
    vlSelf->wasmetal_core__DOT___069791_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069420_))));
    vlSelf->wasmetal_core__DOT___069452_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068832_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069451_)))));
    vlSelf->wasmetal_core__DOT___069290_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068521_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069289_)))));
    vlSelf->wasmetal_core__DOT___069346_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069345_)))));
    vlSelf->wasmetal_core__DOT___069395_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069394_)))));
    vlSelf->wasmetal_core__DOT___069421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069420_)))));
    vlSelf->wasmetal_core__DOT___069500_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068928_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069288_)))))));
    vlSelf->wasmetal_core__DOT___069546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069026_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069344_)))))));
    vlSelf->wasmetal_core__DOT___069662_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069269_))));
    vlSelf->wasmetal_core__DOT___068136_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067047_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068135_)))));
    vlSelf->wasmetal_core__DOT___068222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068221_)))));
    vlSelf->wasmetal_core__DOT___068929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068135_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068928_)))));
    vlSelf->wasmetal_core__DOT___069027_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068221_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069026_)))));
    vlSelf->wasmetal_core__DOT___069189_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068383_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069188_)))));
    vlSelf->wasmetal_core__DOT___064867_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064853_)))));
    vlSelf->wasmetal_core__DOT___069371_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069370_)))));
    vlSelf->wasmetal_core__DOT___069519_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068995_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069321_)))))));
    vlSelf->wasmetal_core__DOT___069588_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069121_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___067526_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066222_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h227fe25d__0)))));
    vlSelf->wasmetal_core__DOT___068328_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067387_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068327_)))));
    vlSelf->wasmetal_core__DOT___069611_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069188_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___067793_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067792_)))));
    vlSelf->wasmetal_core__DOT___067885_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067884_)))));
    vlSelf->wasmetal_core__DOT___067945_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067944_)))));
    vlSelf->wasmetal_core__DOT___068384_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068383_)))));
    vlSelf->wasmetal_core__DOT___069480_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068879_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069268_)))))));
    vlSelf->wasmetal_core__DOT___066508_ = (1U & (0xffccf055U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064853_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064866_))))));
    vlSelf->wasmetal_core__DOT___069221_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068458_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069220_)))));
    vlSelf->wasmetal_core__DOT___068188_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068187_)))));
    vlSelf->wasmetal_core__DOT___068833_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068007_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068832_)))));
    vlSelf->wasmetal_core__DOT___068996_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068995_)))));
    vlSelf->wasmetal_core__DOT___069571_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069073_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___067135_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09fbb425__0)))));
    vlSelf->wasmetal_core__DOT___065857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde8128eb__0))));
    vlSelf->wasmetal_core__DOT___067437_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0)))));
    vlSelf->wasmetal_core__DOT___067646_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066438_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067645_)))));
    vlSelf->wasmetal_core__DOT___067842_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066699_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067841_)))));
    vlSelf->wasmetal_core__DOT___068783_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068782_)))));
    vlSelf->wasmetal_core__DOT___069074_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069073_)))));
    vlSelf->wasmetal_core__DOT___065024_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065009_)))));
    vlSelf->wasmetal_core__DOT___068008_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068007_)))));
    vlSelf->wasmetal_core__DOT___068636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067792_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068635_)))));
    vlSelf->wasmetal_core__DOT___068733_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068732_)))));
    vlSelf->wasmetal_core__DOT___068586_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068585_)))));
    vlSelf->wasmetal_core__DOT___068686_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067841_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068685_)))));
    vlSelf->wasmetal_core__DOT___064697_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064667_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064666_)))));
    vlSelf->wasmetal_core__DOT___066224_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h227fe25d__0))));
    vlSelf->wasmetal_core__DOT___065662_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61c930cb__0))));
    vlSelf->wasmetal_core__DOT___068504_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067579_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068503_)))));
    vlSelf->wasmetal_core__DOT___068880_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068879_)))));
    vlSelf->wasmetal_core__DOT___064447_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064361_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064360_)))));
    vlSelf->wasmetal_core__DOT___019406_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068503_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069269_)))));
    vlSelf->wasmetal_core__DOT___069323_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069322_)))));
    vlSelf->wasmetal_core__DOT___068061_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067002_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068060_)))));
    vlSelf->wasmetal_core__DOT___069122_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069121_)))));
    vlSelf->wasmetal_core__DOT___068275_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067282_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068274_)))));
    vlSelf->wasmetal_core__DOT___065767_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09fbb425__0))));
    vlSelf->wasmetal_core__DOT___066026_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbca1334b__0))));
    vlSelf->wasmetal_core__DOT___065768_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064864_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xacU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___065373_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___064858_)))))))));
    vlSelf->wasmetal_core__DOT___065522_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82ca1536__0))));
    vlSelf->wasmetal_core__DOT___067714_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066504_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067713_)))));
    vlSelf->wasmetal_core__DOT___065968_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0))));
    vlSelf->wasmetal_core__DOT___068522_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068521_)))));
    vlSelf->wasmetal_core__DOT___065222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84a28025__0))));
    vlSelf->wasmetal_core__DOT___065379_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h96c6858e__0))));
    vlSelf->wasmetal_core__DOT___066747_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065221_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84a28025__0)))));
    vlSelf->wasmetal_core__DOT___065484_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c0e85cc__0))));
    vlSelf->wasmetal_core__DOT___065141_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f6e42c0__0))));
    vlSelf->wasmetal_core__DOT___066837_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065377_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h96c6858e__0)))));
    vlSelf->wasmetal_core__DOT___064241_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064582_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((~ 
                                                           (1U 
                                                            | (2U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                  << 1U)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064570_)))))));
    vlSelf->__VdfgTmp_h82d7bb11__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xff7f80ffffffffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                 << 3U))))))));
    vlSelf->wasmetal_core__DOT___064956_ = (1U & (0x80000000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))))));
    vlSelf->wasmetal_core__DOT___065260_ = (1U & (0xe000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x80U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064570_)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_))))))));
    vlSelf->__VdfgTmp_hd785ede8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0xe7ffU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (~ 
                                                            (1U 
                                                             | (2U 
                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                   << 1U))))))))));
    vlSelf->__VdfgTmp_h4bfb58f6__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xff07f8ffffffffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                 << 3U))))))));
    vlSelf->wasmetal_core__DOT___065457_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                               << 4U) 
                                                              | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                                 << 3U))))));
    vlSelf->__VdfgTmp_hd652459e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 4U)) 
                                                 | (0xcU 
                                                    & ((~ 
                                                        (1U 
                                                         | (2U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                               << 1U)))) 
                                                       << 2U))));
    vlSelf->__VdfgTmp_h56ef19dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 4U)) 
                                                 | ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 3U)));
    vlSelf->__VdfgTmp_h1427a567__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064570_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x8fU 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))))));
    vlSelf->__VdfgTmp_hfb6148fa__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065348_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x10U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))))));
    vlSelf->__VdfgTmp_hfa5e1cf0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h1578a070__0))));
    vlSelf->__VdfgTmp_ha690191b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h95637c8b__0))));
    vlSelf->__VdfgTmp_h5f9c391b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xe01fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h95637c8b__0))));
    vlSelf->__VdfgTmp_hd64a84f0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h1578a070__0))));
    vlSelf->wasmetal_core__DOT___069317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b66__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xac00000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0))))))));
    vlSelf->wasmetal_core__DOT___064585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064575_))));
    vlSelf->wasmetal_core__DOT___065350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065349_))));
    vlSelf->__VdfgTmp_h97331d2b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065349_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066806_))))));
    vlSelf->__VdfgTmp_h23f4485c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0)))));
    vlSelf->__VdfgTmp_hd4e6b48d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_hadcb4246__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_hd4192dd5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 3U) | ((6U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_he75eceef__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065124_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066667_))))));
    vlSelf->wasmetal_core__DOT___064957_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064954_))));
    vlSelf->wasmetal_core__DOT___065125_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065124_))));
    vlSelf->__VdfgTmp_h1f2f6132__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065346_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___065547_)) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_hd880fa11__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064571_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065640_))))));
    vlSelf->__VdfgTmp_hf93a855f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065639_))))))));
    vlSelf->__VdfgTmp_hf64104f4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064952_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065835_))))));
    vlSelf->__VdfgTmp_h0b08a7c5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064822_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065735_))))));
    vlSelf->__VdfgTmp_h5d3bfbfd__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065455_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h400b74e1__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->wasmetal_core__DOT___069656_ = (1U & (IData)(
                                                         (0x200000003fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b80__05d) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                          >> 2U))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h737b874d__0)))))));
    vlSelf->__VdfgTmp_h400b6e72__0 = ((0xcU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                               << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->__VdfgTmp_h29064caf__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->__VdfgTmp_hbfa812aa__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064575_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066421_))))));
    vlSelf->__VdfgTmp_ha2b9b4b9__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h737b874d__0));
    vlSelf->__VdfgTmp_h312e660c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065456_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066941_))))));
    vlSelf->wasmetal_core__DOT___065264_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065259_))));
    vlSelf->wasmetal_core__DOT___065351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065347_))));
    vlSelf->__VdfgTmp_hf68b7cf3__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h737b874d__0));
    vlSelf->__VdfgTmp_h0696502e__0 = ((2U & ((8U >> 
                                              ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___064828_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___066475_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->__VdfgTmp_h8a2bba7d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064954_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066554_))))));
    vlSelf->__VdfgTmp_hfef6b839__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066722_))))));
    vlSelf->wasmetal_core__DOT___065459_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065456_))));
    vlSelf->__VdfgTmp_ha4f5f30b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065347_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066804_))))));
    vlSelf->__VdfgTmp_h02ac2502__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064828_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066475_))))));
    vlSelf->wasmetal_core__DOT___063021_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))));
    vlSelf->wasmetal_core__DOT___050388_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->busy) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))));
    vlSelf->wasmetal_core__DOT___054480_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054483_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054485_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054487_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054489_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054491_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127843___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127835___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->__VdfgTmp_h4b91004e__0 = (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                       << 1U) | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___051017_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046571_))))));
    vlSelf->wasmetal_core__DOT___048487_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048483_)))));
    vlSelf->wasmetal_core__DOT___054493_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054495_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054497_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054499_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054503_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054505_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054507_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054501_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054509_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054511_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054513_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054515_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054517_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054519_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054521_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054523_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054525_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054527_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054529_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054531_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054533_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054535_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054537_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054539_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___069728_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___069560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___069896_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(wasmetal_core__DOT___069560_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069857_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xbU 
                                                        >> (IData)(__VdfgTmp_hff1aabe2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069295_ = (1U & (0x440f0f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hff1aabe2__0)))));
    vlSelf->wasmetal_core__DOT___068997_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h82a2f635__0)))));
    vlSelf->wasmetal_core__DOT___067388_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h82a2f635__0))));
    vlSelf->wasmetal_core__DOT___067136_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h6f16836b__0))));
    vlSelf->wasmetal_core__DOT___066034_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h6f16836b__0))));
    vlSelf->wasmetal_core__DOT___066509_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_he0dd3f12__0))));
    vlSelf->wasmetal_core__DOT___068587_ = (1U & (0xf0f0f77U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_he0dd3f12__0)))));
    vlSelf->__VdfgTmp_hf7093f37__0 = ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                << 4U)) 
                                      | (IData)(__VdfgTmp_he0dd3f12__0));
    vlSelf->wasmetal_core__DOT___065232_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0U 
                                                         >> (IData)(__VdfgTmp_h183f3794__0))))));
    vlSelf->wasmetal_core__DOT___066753_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0U 
                                                           >> (IData)(__VdfgTmp_h183f3794__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))));
    vlSelf->wasmetal_core__DOT___065770_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h183f3794__0))));
    vlSelf->wasmetal_core__DOT___064711_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064698_))))))))))));
    vlSelf->wasmetal_core__DOT___064836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064835_))));
    vlSelf->wasmetal_core__DOT___065028_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064698_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065027_))));
    vlSelf->wasmetal_core__DOT___065226_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065225_))));
    vlSelf->wasmetal_core__DOT___065653_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065652_))));
    vlSelf->wasmetal_core__DOT___066439_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066438_)))));
    vlSelf->wasmetal_core__DOT___069281_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b64__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069310_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069307_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069306_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b65__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069338_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b66__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[2U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069361_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b67__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069386_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069383_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069382_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b68__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069412_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b69__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069438_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069432_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b70__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069463_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069459_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069458_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b71__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069491_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b72__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 6U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069557_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b75__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069628_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069622_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b78__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069673_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069669_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069668_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b80__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069848_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069843_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069842_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b88__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069869_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069863_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b89__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069889_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069884_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069883_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b90__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069910_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b91__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069930_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069925_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b92__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069951_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069946_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069945_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b93__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___070011_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070007_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b96__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___052956_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052948_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052947_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h005ba8bd__0))))));
    vlSelf->wasmetal_core__DOT___066157_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065683_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha31eaa90__0)))));
    vlSelf->wasmetal_core__DOT___065995_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064055_))));
    vlSelf->wasmetal_core__DOT___064556_ = (1U & (0xcfaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                              << 1U))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                               << 1U)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064072_))))));
    vlSelf->__VdfgTmp_h25573523__0 = (((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                       << 5U) | ((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                 << 4U));
    vlSelf->wasmetal_core__DOT___064986_ = (1U & (IData)(
                                                         (0x1fff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                              << 4U)))));
    vlSelf->wasmetal_core__DOT___065098_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (- (IData)(
                                                                       (1U 
                                                                        & (4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                            << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___064082_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064072_))));
    vlSelf->wasmetal_core__DOT___064788_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha31eaa90__0)))));
    vlSelf->wasmetal_core__DOT___065470_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064989_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9d56b9e6__0))))));
    vlSelf->wasmetal_core__DOT___064994_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | ((4U 
                                                               & ((0x5cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h9d56b9e6__0)) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((0xf0f05533U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064564_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064069_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064060_)))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___064989_)))))));
    vlSelf->wasmetal_core__DOT___065276_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064566_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2cdbdda9__0))))));
    vlSelf->__VdfgTmp_h78f256d8__0 = ((2U & ((0xeU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                << 1U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                            << 1U)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065359_));
    vlSelf->__VdfgTmp_hf270fd27__0 = ((2U & ((0x10U 
                                              >> ((4U 
                                                   & ((4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                             << 1U)) 
                                                           << 1U))) 
                                                      << 2U)) 
                                                  | (2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                        << 1U)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___066155_));
    vlSelf->__VdfgTmp_h892c3f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1b9a71b__0))));
    vlSelf->__VdfgTmp_h18d94502__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1b9a71b__0))));
    vlSelf->__VdfgTmp_h3ea85ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___065096_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                              << 1U))))))))))));
    vlSelf->__VdfgTmp_hf103d5a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065541_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                           << 1U)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___065996_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065993_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb5acd9d8__0))))))));
    vlSelf->__VdfgTmp_h3daad387__0 = (((IData)(vlSelf->wasmetal_core__DOT___065993_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                << 1U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_hc656bac6__0 = ((2U & ((0xbU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((1U 
                                                          >> 
                                                          (3U 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                             << 1U))))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                            << 1U)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064786_));
    vlSelf->__VdfgTmp_ha458d092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h88dfb892__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h6b577092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xe01fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_hf114f092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h17a5807b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064984_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hab510120__0 = (((IData)(vlSelf->wasmetal_core__DOT___066058_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h4121b81d__0 = (((IData)(vlSelf->wasmetal_core__DOT___064553_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h18a1d918__0 = (((IData)(vlSelf->wasmetal_core__DOT___065684_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hfdd57f0a__0 = ((2U & ((IData)(
                                                     (0xfffe000000000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x100000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h1dd3182a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0x80007fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hc97edddd__0 = (((IData)(vlSelf->wasmetal_core__DOT___065467_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1ff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_he6eb1d70__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xff80007fffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_he6a138a7__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xffe0001fffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h4573e872__0 = (((IData)(vlSelf->wasmetal_core__DOT___065877_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h0160c9d2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfe0001ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h085758ad__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfff80007ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hec74e4aa__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xe0001fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h96fdd1ca__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xf80007ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h009830e9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfffe0001ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h9616de3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065273_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_ha5948160__0 = (((IData)(vlSelf->wasmetal_core__DOT___064554_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066429_)))));
    vlSelf->__VdfgTmp_h5ad13fe7__0 = (((IData)(vlSelf->wasmetal_core__DOT___065779_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 3U)) 
                                                     | (3U 
                                                        & (- (IData)(
                                                                     (1U 
                                                                      & (4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                          << 1U))))))))));
    vlSelf->__VdfgTmp_hb4147928__0 = (((IData)(vlSelf->wasmetal_core__DOT___064787_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066486_)))));
    vlSelf->__VdfgTmp_hf4606e0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064985_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066563_)))));
    vlSelf->__VdfgTmp_h720d5baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___065097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066676_)))));
    vlSelf->__VdfgTmp_h0ce087b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___065361_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066814_)))));
    vlSelf->__VdfgTmp_hb19dabb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065274_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066730_)))));
    vlSelf->__VdfgTmp_hd6d71fd2__0 = (((IData)(vlSelf->wasmetal_core__DOT___066993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066994_));
    vlSelf->__VdfgTmp_h55dc4d97__0 = (((IData)(vlSelf->wasmetal_core__DOT___065468_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066936_)))));
    vlSelf->__VdfgTmp_h07d01a7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___065543_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066362_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_hf7e1e4a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___066156_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_h0afb0546__0 = (((IData)(vlSelf->wasmetal_core__DOT___066059_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___066427_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___070000_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000000fcffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0))))))))));
    vlSelf->wasmetal_core__DOT___067573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000000fcffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0))))))))));
    vlSelf->__VdfgTmp_h95565af9__0 = (((IData)(vlSelf->wasmetal_core__DOT___065780_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066485_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_he90c68e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066255_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___069747_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b84__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))));
    vlSelf->wasmetal_core__DOT___068679_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b52__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))));
    vlSelf->__VdfgTmp_h51979f8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065681_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066428_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_h9e5b6509__0 = (((IData)(vlSelf->wasmetal_core__DOT___065878_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066562_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_h134a2a5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___065994_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___066361_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___053002_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048481_))));
    vlSelf->wasmetal_core__DOT___068376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068915_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068982_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___069013_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1bU))))))))));
    vlSelf->wasmetal_core__DOT___069175_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___068678_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067570_))));
    vlSelf->wasmetal_core__DOT___068622_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068719_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068716_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068819_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068816_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___069108_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___065266_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064249_))));
    vlSelf->wasmetal_core__DOT___065570_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065566_))))));
    vlSelf->wasmetal_core__DOT___066371_ = (1U & (0x7f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065558_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)))))))));
    vlSelf->__VdfgTmp_h5851eae3__0 = (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                     << 2U)) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8d2606de__0)));
    vlSelf->wasmetal_core__DOT___069075_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8d2606de__0))))));
    vlSelf->wasmetal_core__DOT___067581_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065236_ = (1U & (0x3a00U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065230_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064438_))))));
    vlSelf->wasmetal_core__DOT___069191_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069190_))));
    vlSelf->wasmetal_core__DOT___066187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066185_))));
    vlSelf->wasmetal_core__DOT___070329_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b118__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___068784_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___069793_))))));
    vlSelf->wasmetal_core__DOT___068785_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___068784_))));
    vlSelf->wasmetal_core__DOT___065389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065388_))));
    vlSelf->wasmetal_core__DOT___068385_ = (1U & (IData)(
                                                         (0xffff01ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_heceac102__0)))));
    vlSelf->wasmetal_core__DOT___066588_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066586_))));
    vlSelf->wasmetal_core__DOT___064876_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064875_))));
    vlSelf->wasmetal_core__DOT___065037_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065036_))));
    vlSelf->wasmetal_core__DOT___069456_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069454_))));
    vlSelf->wasmetal_core__DOT___069794_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___069793_))));
    vlSelf->wasmetal_core__DOT___069960_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069455_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((4U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                      << 1U)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))))));
}
