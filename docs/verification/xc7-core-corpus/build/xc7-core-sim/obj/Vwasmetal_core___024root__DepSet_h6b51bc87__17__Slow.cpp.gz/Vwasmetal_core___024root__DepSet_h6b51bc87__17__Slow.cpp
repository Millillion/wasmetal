#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__43(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__43\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___009186_;
    wasmetal_core__DOT___009186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009238_;
    wasmetal_core__DOT___009238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009239_;
    wasmetal_core__DOT___009239_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009251_;
    wasmetal_core__DOT___009251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009252_;
    wasmetal_core__DOT___009252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009291_;
    wasmetal_core__DOT___009291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009301_;
    wasmetal_core__DOT___009301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009302_;
    wasmetal_core__DOT___009302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009768_;
    wasmetal_core__DOT___009768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009769_;
    wasmetal_core__DOT___009769_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051495_;
    wasmetal_core__DOT___051495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055224_;
    wasmetal_core__DOT___055224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055225_;
    wasmetal_core__DOT___055225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055406_;
    wasmetal_core__DOT___055406_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055564_;
    wasmetal_core__DOT___055564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055565_;
    wasmetal_core__DOT___055565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055571_;
    wasmetal_core__DOT___055571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055574_;
    wasmetal_core__DOT___055574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055621_;
    wasmetal_core__DOT___055621_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055692_;
    wasmetal_core__DOT___055692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___005782_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023183_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023246_));
    vlSelf->wasmetal_core__DOT___018280_ = (1U & (IData)(
                                                         (0xfff08880fff0fff0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058884_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058883_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058882_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058876_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058875_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x700000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058872_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058871_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058870_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x700000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058868_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058867_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058866_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058907_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058905_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058894_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058893_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058892_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61354930__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036420_)))));
    vlSelf->wasmetal_core__DOT___036490_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035960_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d));
    vlSelf->__VdfgTmp_hf5238d18__0 = (((IData)(vlSelf->wasmetal_core__DOT___058305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058306_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058360_))));
    vlSelf->wasmetal_core__DOT___058696_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf3f2f333U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___017195_)))))))))));
    if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)))) {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
    } else {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (IData)(
                                                          (0x5d5d5ddd5d5d5d5fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (IData)(
                                                          (0x7777777f55575555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
    }
    vlSelf->wasmetal_core__DOT___058687_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x55570100ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT___018272_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x222a2223ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058353_))));
    vlSelf->wasmetal_core__DOT___058358_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->wasmetal_core__DOT___058309_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->__VdfgTmp_h0d8c930c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058248_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058341_))));
    vlSelf->wasmetal_core__DOT___016429_ = (1U & (IData)(
                                                         (0xeeeef0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058518_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9a38454b__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058276_)))))))));
    vlSelf->__VdfgTmp_h20c89172__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058321_));
    vlSelf->__VdfgTmp_h8d5d3612__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016448_));
    vlSelf->wasmetal_core__DOT___016444_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058314_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058316_)))))));
    vlSelf->__VdfgTmp_h6df53282__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058316_))));
    vlSelf->__VdfgTmp_h37243dd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058295_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058294_))));
    vlSelf->wasmetal_core__DOT___058337_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058335_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058334_))))));
    vlSelf->wasmetal_core__DOT___058338_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058334_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058335_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058342_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016441_))));
    vlSelf->__VdfgTmp_hba6f19f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058225_));
    vlSelf->__VdfgTmp_heb95d931__0 = ((2U & ((0xe00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hac8f2958__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff100000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058303_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016122_))))))))));
    vlSelf->wasmetal_core__DOT___058343_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))));
    vlSelf->wasmetal_core__DOT___058234_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))))));
    vlSelf->wasmetal_core__DOT___058312_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha2f7036a__0))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)))));
    vlSelf->wasmetal_core__DOT___016452_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                                    ? 
                                                                   (0xeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015896_))))
                                                                    : 
                                                                   (0x53U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd3573026__0))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (0xe0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0))))))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___016007_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha2f7036a__0))))))))));
    vlSelf->wasmetal_core__DOT___058332_ = (1U & (IData)(
                                                         (0x11ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x4000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016007_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))))))));
    vlSelf->wasmetal_core__DOT___058265_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058346_))));
    vlSelf->__VdfgTmp_he7bb7b74__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058275_));
    vlSelf->__VdfgTmp_h6712d737__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058319_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058348_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016447_))));
    vlSelf->__VdfgTmp_h7041ac57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058328_));
    vlSelf->wasmetal_core__DOT___058521_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058354_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058353_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058352_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058351_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058352_))));
    vlSelf->__VdfgTmp_hbca2c4ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016451_));
    vlSelf->__VdfgTmp_he60f6eaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016442_));
    vlSelf->wasmetal_core__DOT___058359_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h240228f9__0)))));
    vlSelf->wasmetal_core__DOT___058344_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h240228f9__0))))));
    vlSelf->__VdfgTmp_hc888fbf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h240228f9__0));
    vlSelf->wasmetal_core__DOT___016431_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x88888888000fffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058324_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058323_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058319_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x3ca5U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058322_))))));
    vlSelf->wasmetal_core__DOT___058350_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf1c161b0__0)))));
    vlSelf->wasmetal_core__DOT___016449_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015597_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xccccf0f000ff00aaULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058238_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_))))))))))
                                                   : 
                                                  (0xaacc0f0fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1c161b0__0))));
    vlSelf->wasmetal_core__DOT___058357_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->wasmetal_core__DOT___058307_ = (1U & (IData)(
                                                         (0xee000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->__VdfgTmp_h787befb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058242_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d 
        = (1U & (0x53acU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058241_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058347_))));
    vlSelf->wasmetal_core__DOT___016433_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058275_))));
    vlSelf->__VdfgTmp_h2a4257a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058279_));
    vlSelf->wasmetal_core__DOT___020523_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT___072257_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048947_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase)))));
    vlSelf->wasmetal_core__DOT___040093_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040095_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040094_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___058092_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058090_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)))))));
    vlSelf->wasmetal_core__DOT___058689_ = (1U & (0x1fU 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc204a2d8__0))));
    vlSelf->wasmetal_core__DOT___013204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057697_))));
    vlSelf->__VdfgTmp_h8fcc0329__0 = (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013206_));
    vlSelf->__VdfgTmp_h917221d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015658_));
    vlSelf->wasmetal_core__DOT___057692_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057689_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)))));
    vlSelf->wasmetal_core__DOT___057698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057689_))));
    vlSelf->wasmetal_core__DOT___040102_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__ 
        = ((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035864_));
    vlSelf->wasmetal_core__DOT___036940_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036952_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134181___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036952_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036951_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036962_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036961_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036948_)))));
    vlSelf->wasmetal_core__DOT___048951_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                       << 1U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___019776_ = (1U & (IData)(
                                                         (0xf7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053573_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___019415_ = (1U & (IData)(
                                                         (0xffff0000bf000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_valid)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063363_)))))))));
    vlSelf->wasmetal_core__DOT___063397_ = (1U & (IData)(
                                                         (0xff00ff004f4f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x4f000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0fd0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063371_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063369_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053087_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052916_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051239_))));
    vlSelf->wasmetal_core__DOT___063403_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___053501_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1205819c__0))));
    vlSelf->wasmetal_core__DOT___009290_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83a675b5__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055000_)))))))));
    wasmetal_core__DOT___009291_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054998_)))))))));
    wasmetal_core__DOT___055621_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84d68e3f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054988_)))))))));
    vlSelf->wasmetal_core__DOT___008935_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ebbc558__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054987_)))))))));
    vlSelf->wasmetal_core__DOT___055617_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054990_)))))))));
    vlSelf->wasmetal_core__DOT___055618_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf65e04e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054989_)))))))));
    vlSelf->wasmetal_core__DOT___009292_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h437f0271__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054996_)))))))));
    vlSelf->wasmetal_core__DOT___009293_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab3c597f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054995_)))))))));
    wasmetal_core__DOT___055574_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc49a285__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054949_)))))))));
    vlSelf->wasmetal_core__DOT___008904_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f14afc9__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054948_)))))))));
    vlSelf->wasmetal_core__DOT___055570_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde99fb2e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054951_)))))))));
    wasmetal_core__DOT___055571_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054950_)))))))));
    wasmetal_core__DOT___055564_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ad74d3e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054959_)))))))));
    wasmetal_core__DOT___055565_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h707c99af__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054958_)))))))));
    vlSelf->wasmetal_core__DOT___055566_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc03ee7e3__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054957_)))))))));
    vlSelf->wasmetal_core__DOT___055567_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb18976f4__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054956_)))))))));
    vlSelf->wasmetal_core__DOT___055544_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054900_)))))))));
    vlSelf->wasmetal_core__DOT___055543_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054898_)))))))));
    vlSelf->wasmetal_core__DOT___008860_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054899_)))))))));
    vlSelf->wasmetal_core__DOT___009771_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6eb17b7a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054901_)))))))));
    wasmetal_core__DOT___009769_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h692f01d1__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054907_)))))))));
    vlSelf->wasmetal_core__DOT___009770_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054906_)))))))));
    vlSelf->wasmetal_core__DOT___055534_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0e7ef094__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054909_)))))))));
    wasmetal_core__DOT___009768_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054908_)))))))));
    vlSelf->wasmetal_core__DOT___009189_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h815644ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051496_)))))))));
    vlSelf->wasmetal_core__DOT___051500_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051498_)))))))));
    vlSelf->wasmetal_core__DOT___008835_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce0059e1__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051493_)))))))));
    vlSelf->wasmetal_core__DOT___009187_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h79bfec12__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054861_)))))))));
    vlSelf->wasmetal_core__DOT___009188_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054860_)))))))));
    vlSelf->wasmetal_core__DOT___009185_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc530df9f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054865_)))))))));
    wasmetal_core__DOT___009186_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb918ea35__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054863_)))))))));
    wasmetal_core__DOT___051495_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86c1a93d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051491_)))))))));
    vlSelf->wasmetal_core__DOT___055448_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb98e230__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054808_)))))))));
    vlSelf->wasmetal_core__DOT___009174_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8916279c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054807_)))))))));
    vlSelf->wasmetal_core__DOT___055444_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054810_)))))))));
    vlSelf->wasmetal_core__DOT___055445_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054809_)))))))));
    vlSelf->wasmetal_core__DOT___009254_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2656e40__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054815_)))))))));
    vlSelf->wasmetal_core__DOT___009253_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f29d017__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054816_)))))))));
    wasmetal_core__DOT___009251_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054820_)))))))));
    wasmetal_core__DOT___009252_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054818_)))))))));
    wasmetal_core__DOT___055406_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7751d301__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054768_)))))))));
    vlSelf->wasmetal_core__DOT___009163_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h890db370__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054767_)))))))));
    vlSelf->wasmetal_core__DOT___055408_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054769_)))))))));
    vlSelf->wasmetal_core__DOT___055407_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054770_)))))))));
    wasmetal_core__DOT___009238_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782800f0__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054781_)))))))));
    wasmetal_core__DOT___009239_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054779_)))))))));
    vlSelf->wasmetal_core__DOT___009240_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc86399cc__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054777_)))))))));
    vlSelf->wasmetal_core__DOT___009241_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f534570__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054775_)))))))));
    vlSelf->wasmetal_core__DOT___055234_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h42498a1f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054698_)))))))));
    vlSelf->wasmetal_core__DOT___055235_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054701_)))))))));
    vlSelf->wasmetal_core__DOT___055236_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2814f082__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054705_)))))))));
    vlSelf->wasmetal_core__DOT___009146_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8893fd49__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054708_)))))))));
    vlSelf->wasmetal_core__DOT___055228_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054688_)))))))));
    vlSelf->wasmetal_core__DOT___055229_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7780ec55__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054691_)))))))));
    wasmetal_core__DOT___055224_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha292c154__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))));
    wasmetal_core__DOT___055225_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054682_)))))))));
    wasmetal_core__DOT___055692_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb4659c85__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055034_)))))))));
    vlSelf->wasmetal_core__DOT___008962_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7a210d44__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055033_)))))))));
    vlSelf->wasmetal_core__DOT___009303_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb69256f0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055042_)))))))));
    vlSelf->wasmetal_core__DOT___009304_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde24342a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055041_)))))))));
    vlSelf->wasmetal_core__DOT___055696_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce01618__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055035_)))))))));
    wasmetal_core__DOT___009301_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0919a607__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))));
    wasmetal_core__DOT___009302_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055044_)))))))));
    vlSelf->wasmetal_core__DOT___055695_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055036_)))))))));
    vlSelf->__VdfgTmp_hb0e57990__0 = (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007872_));
    if (vlSelf->wasmetal_core__DOT___008018_) {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 2U))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 3U))));
    } else {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (0x80bfaaaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 3U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_x)))))))))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008500_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 2U)))))))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 1U)))))))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum))))))));
    }
    vlSelf->wasmetal_core__DOT___007880_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007869_)))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023184_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060363_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O))))))))));
    vlSelf->wasmetal_core__DOT___059464_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            & (IData)(
                                                      (0xff00ff3fff5fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018281_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O))))))))));
    vlSelf->wasmetal_core__DOT___059543_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005745_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059671_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060239_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O)))))))))))));
    vlSelf->wasmetal_core__DOT___019042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060305_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060339_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060397_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___019179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060417_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127605___O)))))))))))));
    vlSelf->wasmetal_core__DOT___019187_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127605___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059574_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059725_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003810_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059777_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006400_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003807_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059829_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059890_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059918_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060103_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005989_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060468_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060464_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___060283_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O))))))))));
    vlSelf->wasmetal_core__DOT___060291_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060317_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___060323_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O))))))))));
    vlSelf->wasmetal_core__DOT___060328_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060210_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005711_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___059318_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059381_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059424_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059700_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059943_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005855_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060057_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006022_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060082_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006171_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060153_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006144_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059505_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            & (IData)(
                                                      (0xff00ff3fff5fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018334_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                          >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059753_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059858_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059974_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060001_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005868_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060033_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060594_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))));
    vlSelf->wasmetal_core__DOT___060189_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006215_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060621_ = (1U & (IData)(
                                                         (0xf0fcf0faULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h78bec42d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058491_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O) 
                                                          >> 1U)))));
    vlSelf->__VdfgTmp_h59bf4fdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___016492_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O) 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036490_));
    vlSelf->wasmetal_core__DOT____Vcellout___128802___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035961_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035960_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036014_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036013_)))) 
           ^ (((IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035957_)))));
    vlSelf->wasmetal_core__DOT___035905_ = ((IData)(vlSelf->wasmetal_core__DOT___035961_)
                                             ? (IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d));
    vlSelf->__VdfgTmp_hb63e733c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058688_));
    vlSelf->wasmetal_core__DOT___059568_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059771_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059799_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059823_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059884_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059746_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059967_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059994_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060182_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->__VdfgTmp_hef0df0fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->__VdfgTmp_h385650d9__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->wasmetal_core__DOT___060301_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___060335_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___059667_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013654_))))));
    vlSelf->wasmetal_core__DOT___019166_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013739_)))))));
    vlSelf->wasmetal_core__DOT___060646_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___019032_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))));
    vlSelf->wasmetal_core__DOT___019046_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013771_)))))));
    vlSelf->wasmetal_core__DOT___059644_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013648_))))));
    vlSelf->wasmetal_core__DOT___019092_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013797_)))))));
    vlSelf->wasmetal_core__DOT___019106_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013796_)))))));
    vlSelf->wasmetal_core__DOT___019116_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))));
    vlSelf->wasmetal_core__DOT___019138_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013787_)))))));
    vlSelf->wasmetal_core__DOT___019157_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013786_)))))));
    vlSelf->wasmetal_core__DOT___019004_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))));
    vlSelf->wasmetal_core__DOT___017183_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    vlSelf->__VdfgTmp_he45ddc74__0 = (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->wasmetal_core__DOT___059911_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060462_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___060578_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))))))))));
    vlSelf->wasmetal_core__DOT___060300_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019033_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019047_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019107_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019117_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019158_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060389_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060404_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060412_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060428_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___059936_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060050_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060075_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060146_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060645_ = (1U & (IData)(
                                                         (0x77ff7777030f0303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018272_)))))))));
    vlSelf->wasmetal_core__DOT___060483_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060500_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060514_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060542_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060556_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060528_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060618_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060258_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060629_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019197_)))));
    vlSelf->__VdfgTmp_h74741c3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058358_))));
    vlSelf->__VdfgTmp_hdd49dc43__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058309_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058308_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015597_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0))));
    vlSelf->__VdfgTmp_ha1b196f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058249_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0)));
    vlSelf->__VdfgTmp_had1ad578__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___058338_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058337_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_heb95d931__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058343_))));
    vlSelf->__VdfgTmp_h8f31d0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058234_));
    vlSelf->wasmetal_core__DOT___016443_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058312_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x1000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))))));
    vlSelf->__VdfgTmp_ha253f9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016452_));
    vlSelf->__VdfgTmp_he2e2fa14__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058332_));
    vlSelf->wasmetal_core__DOT___058345_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))));
    vlSelf->wasmetal_core__DOT___058266_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058264_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))))));
    vlSelf->wasmetal_core__DOT___016458_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058361_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058359_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058359_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058344_))));
    vlSelf->wasmetal_core__DOT___058256_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058254_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc888fbf4__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058350_))));
    vlSelf->__VdfgTmp_hff2cd213__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016449_));
    vlSelf->wasmetal_core__DOT___058524_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (0xffe0001fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058306_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058305_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h787befb5__0))));
    vlSelf->wasmetal_core__DOT___017182_ = (1U & (0x40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058689_))))));
    vlSelf->wasmetal_core__DOT___060587_ = (1U & (IData)(
                                                         (0xfcffffff00540055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___013523_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013205_))))));
    vlSelf->__VdfgTmp_h60102cdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                       << 1U) | (1U 
                                                 & (0xefU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d 
        = (1U & (0x8fU >> (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                            << 2U) | ((2U & ((1U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 1U))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057692_)))));
    vlSelf->wasmetal_core__DOT___057725_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017782_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017794_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017756_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057694_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057701_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057698_))));
    vlSelf->wasmetal_core__DOT___057699_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057698_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128792___O 
        = ((3U & (- (IData)((1U & (1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))) 
           ^ (((((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                 & (IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035864_)));
    vlSelf->wasmetal_core__DOT___042756_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___035721_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048951_))));
    vlSelf->wasmetal_core__DOT___042760_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048951_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))))));
    vlSelf->wasmetal_core__DOT___053008_ = (1U & (IData)(
                                                         (0x8f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052918_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052914_)))))))));
    vlSelf->wasmetal_core__DOT___063412_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00bb00ff000f00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (0xdf0f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063400_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___063433_ = (1U & (0x5fcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063431_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4000ffffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063418_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063428_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfffffff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063392_)))))));
    vlSelf->wasmetal_core__DOT___019800_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053501_)))))))));
    vlSelf->wasmetal_core__DOT___053622_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xf35100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053617_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->mem_ready) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053616_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053619_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053501_))))));
    vlSelf->wasmetal_core__DOT___019784_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053510_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053509_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052712_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053505_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053504_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xd000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053481_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053261_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053480_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053479_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053478_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h66357502__0)))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053491_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053489_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053488_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052695_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053487_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053436_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053016_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053435_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052907_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050450_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052886_)))))))))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007871_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053502_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053501_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053016_)))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053363_))))))))))));
    vlSelf->__VdfgTmp_hbd36bb7c__0 = (((IData)(wasmetal_core__DOT___009291_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009290_));
    vlSelf->__VdfgTmp_ha16fbbbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___055618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055617_));
    vlSelf->__VdfgTmp_hd2b13b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009292_));
    vlSelf->__VdfgTmp_h6e24fc79__0 = (((IData)(wasmetal_core__DOT___055565_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055564_));
    vlSelf->__VdfgTmp_hb785bdc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055566_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055565_));
    vlSelf->__VdfgTmp_h8b31618a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055544_));
    vlSelf->__VdfgTmp_h1ccd197a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009770_));
    vlSelf->__VdfgTmp_hf7b90195__0 = (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009769_));
    vlSelf->__VdfgTmp_hd1825153__0 = (((IData)(wasmetal_core__DOT___009769_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009768_));
    vlSelf->__VdfgTmp_h23e0654e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009188_));
    vlSelf->__VdfgTmp_hbf11cfc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009187_));
    vlSelf->__VdfgTmp_hd63c68ee__0 = (((IData)(wasmetal_core__DOT___009186_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009185_));
    vlSelf->__VdfgTmp_he1badc2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055445_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055444_));
    vlSelf->__VdfgTmp_he6145195__0 = (((IData)(vlSelf->wasmetal_core__DOT___055448_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055445_));
    vlSelf->__VdfgTmp_h52b8127f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009253_));
    vlSelf->__VdfgTmp_h416357e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___009253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009252_));
    vlSelf->__VdfgTmp_h53c22b41__0 = (((IData)(wasmetal_core__DOT___009252_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009251_));
    vlSelf->__VdfgTmp_ha9c0231a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055408_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055407_));
    vlSelf->__VdfgTmp_h10a22e24__0 = (((IData)(wasmetal_core__DOT___009239_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009238_));
    vlSelf->__VdfgTmp_ha4fdb8c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___009240_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009239_));
    vlSelf->__VdfgTmp_h381f02c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009240_));
    vlSelf->__VdfgTmp_h0eab1d01__0 = (((IData)(vlSelf->wasmetal_core__DOT___055235_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055234_));
    vlSelf->__VdfgTmp_h0b92bce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055236_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055235_));
    vlSelf->__VdfgTmp_hef4c4e2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055228_));
    vlSelf->__VdfgTmp_haccd68b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___055228_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055225_));
    vlSelf->__VdfgTmp_h0dc57e5a__0 = (((IData)(wasmetal_core__DOT___055225_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055224_));
    vlSelf->__VdfgTmp_hd3eaf9cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009303_));
    vlSelf->__VdfgTmp_h567718cf__0 = (((IData)(wasmetal_core__DOT___055692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055696_));
    vlSelf->__VdfgTmp_h74bdf3b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009303_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009302_));
    vlSelf->__VdfgTmp_h4ba92f5a__0 = (((IData)(wasmetal_core__DOT___009302_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009301_));
    vlSelf->__VdfgTmp_h2fcb0063__0 = (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009304_));
    vlSelf->__VdfgTmp_h3832b0f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___055696_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055695_));
    vlSelf->wasmetal_core__DOT___008809_ = (1U & (0x8080ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb0e57990__0))))));
    vlSelf->__VdfgTmp_h315e9115__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008962_));
    vlSelf->wasmetal_core__DOT___009762_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009769_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009768_)))))));
    vlSelf->wasmetal_core__DOT___009449_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009187_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009186_)))))));
    vlSelf->__VdfgTmp_h4ad8a46a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007847_)));
    vlSelf->wasmetal_core__DOT___055983_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009290_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___055962_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___009185_))))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009187_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009188_)))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___009186_))))));
    vlSelf->wasmetal_core__DOT___009472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009292_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___009291_)))))))));
    vlSelf->wasmetal_core__DOT___055953_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009251_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->wasmetal_core__DOT___009412_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___055571_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055566_)))))))));
    vlSelf->wasmetal_core__DOT___055822_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055567_)))));
    vlSelf->wasmetal_core__DOT___055768_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009254_)))));
    vlSelf->wasmetal_core__DOT___055738_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009241_)))));
    vlSelf->wasmetal_core__DOT___055718_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055229_)))));
    vlSelf->wasmetal_core__DOT___009745_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055571_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055570_)))));
    vlSelf->wasmetal_core__DOT___009471_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055621_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055618_)))));
    vlSelf->wasmetal_core__DOT___009463_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_hb307080d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055574_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055571_)));
    vlSelf->wasmetal_core__DOT___008877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_ha296f98c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___051495_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051500_)));
    vlSelf->__VdfgTmp_h62e050c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055406_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055408_)));
    vlSelf->wasmetal_core__DOT___055736_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->wasmetal_core__DOT___055719_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h7d874977__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008935_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055621_)));
    vlSelf->__VdfgTmp_ha295f108__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008904_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055574_)));
    vlSelf->wasmetal_core__DOT___009091_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055543_)))));
    vlSelf->__VdfgTmp_h6ca56fa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009768_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055534_)));
    vlSelf->wasmetal_core__DOT___009069_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008835_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___051495_)))));
    vlSelf->wasmetal_core__DOT___009035_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055448_)))));
    vlSelf->__VdfgTmp_hecc250a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055406_)));
    vlSelf->__VdfgTmp_h6b0a05f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055236_)));
    vlSelf->wasmetal_core__DOT___009477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009301_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_he25b62bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008962_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055692_)));
    if (vlSelf->wasmetal_core__DOT___007874_) {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001874_))))))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001886_))))))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001437_))))))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001443_))))))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001475_))))))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001487_))))))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001369_))))))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001381_))))))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001413_))))))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001425_))))))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001524_))))))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001536_))))))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001568_))))))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001580_))))))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001612_))))))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001624_))))))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001646_))))))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000419_))))))));
        vlSelf->wasmetal_core__DOT___008067_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008070_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008069_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000432_))))))));
        vlSelf->wasmetal_core__DOT___008066_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008078_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008077_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000464_))))))));
        vlSelf->wasmetal_core__DOT___008065_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008086_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008085_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000476_))))))));
        vlSelf->wasmetal_core__DOT___008064_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008094_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008093_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000498_))))))));
        vlSelf->wasmetal_core__DOT___008104_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008108_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000520_))))))));
        vlSelf->wasmetal_core__DOT___008103_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008116_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000542_))))))));
        vlSelf->wasmetal_core__DOT___008102_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008124_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000564_))))))));
        vlSelf->wasmetal_core__DOT___008101_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008132_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000591_))))))));
        vlSelf->wasmetal_core__DOT___008142_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008145_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000613_))))))));
        vlSelf->wasmetal_core__DOT___008141_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008153_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000635_))))))));
        vlSelf->wasmetal_core__DOT___008140_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008161_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000657_))))))));
        vlSelf->wasmetal_core__DOT___008139_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008169_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))))))));
        vlSelf->wasmetal_core__DOT___008179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008183_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))))));
        vlSelf->wasmetal_core__DOT___008178_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008191_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))))));
        vlSelf->wasmetal_core__DOT___008177_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008199_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))))))));
        vlSelf->wasmetal_core__DOT___008176_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008207_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))))))));
        vlSelf->wasmetal_core__DOT___008217_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008220_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))))))));
        vlSelf->wasmetal_core__DOT___008216_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008228_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))))))));
        vlSelf->wasmetal_core__DOT___008215_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008236_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))))))));
        vlSelf->wasmetal_core__DOT___008214_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008244_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))))))));
        vlSelf->wasmetal_core__DOT___008254_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008258_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))))))));
        vlSelf->wasmetal_core__DOT___008253_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008266_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))))))));
        vlSelf->wasmetal_core__DOT___008252_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008274_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))))))));
        vlSelf->wasmetal_core__DOT___008251_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008282_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))))))));
        vlSelf->wasmetal_core__DOT___008292_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008295_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))))))));
        vlSelf->wasmetal_core__DOT___008291_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008303_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))))))));
        vlSelf->wasmetal_core__DOT___008290_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008311_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))))))));
        vlSelf->wasmetal_core__DOT___008289_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008319_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))))))));
        vlSelf->wasmetal_core__DOT___008329_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008334_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))))))));
        vlSelf->wasmetal_core__DOT___008328_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008342_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008341_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))))))));
        vlSelf->wasmetal_core__DOT___008327_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008350_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))))))));
        vlSelf->wasmetal_core__DOT___008326_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008358_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008357_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))))));
        vlSelf->wasmetal_core__DOT___008368_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008371_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008370_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001327_))))))));
        vlSelf->wasmetal_core__DOT___008367_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008379_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008378_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000980_))))))));
        vlSelf->wasmetal_core__DOT___008366_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008387_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000992_))))))));
        vlSelf->wasmetal_core__DOT___008365_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008395_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001014_))))))));
        vlSelf->wasmetal_core__DOT___008405_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008409_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001036_))))))));
        vlSelf->wasmetal_core__DOT___008404_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008417_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001058_))))))));
        vlSelf->wasmetal_core__DOT___008403_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008425_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001080_))))))));
        vlSelf->wasmetal_core__DOT___008402_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008433_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001102_))))))));
        vlSelf->wasmetal_core__DOT___008443_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008446_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001124_))))))));
        vlSelf->wasmetal_core__DOT___008442_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008454_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001146_))))))));
        vlSelf->wasmetal_core__DOT___008441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008462_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001168_))))))));
        vlSelf->wasmetal_core__DOT___008440_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008470_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))))));
    } else {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007247_)))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007274_)))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007301_)))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007334_)))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007360_)))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007386_)))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007413_)))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007431_)))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007246_)))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007273_)))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007300_)))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007333_)))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007359_)))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007385_)))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007412_)))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007430_)))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007249_)))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007276_)))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007303_)))));
        vlSelf->wasmetal_core__DOT___008067_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008070_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007336_)))));
        vlSelf->wasmetal_core__DOT___008066_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008078_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007362_)))));
        vlSelf->wasmetal_core__DOT___008065_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008086_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007388_)))));
        vlSelf->wasmetal_core__DOT___008064_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008094_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007415_)))));
        vlSelf->wasmetal_core__DOT___008104_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008108_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007433_)))));
        vlSelf->wasmetal_core__DOT___008103_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008116_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007248_)))));
        vlSelf->wasmetal_core__DOT___008102_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008124_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007275_)))));
        vlSelf->wasmetal_core__DOT___008101_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008132_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007302_)))));
        vlSelf->wasmetal_core__DOT___008142_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008145_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007335_)))));
        vlSelf->wasmetal_core__DOT___008141_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008153_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007361_)))));
        vlSelf->wasmetal_core__DOT___008140_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008161_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007387_)))));
        vlSelf->wasmetal_core__DOT___008139_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008169_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007414_)))));
        vlSelf->wasmetal_core__DOT___008179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008183_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007432_)))));
        vlSelf->wasmetal_core__DOT___008178_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008191_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007252_)))));
        vlSelf->wasmetal_core__DOT___008177_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008199_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007279_)))));
        vlSelf->wasmetal_core__DOT___008176_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008207_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007306_)))));
        vlSelf->wasmetal_core__DOT___008217_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008220_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007339_)))));
        vlSelf->wasmetal_core__DOT___008216_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008228_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007365_)))));
        vlSelf->wasmetal_core__DOT___008215_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008236_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007391_)))));
        vlSelf->wasmetal_core__DOT___008214_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008244_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007418_)))));
        vlSelf->wasmetal_core__DOT___008254_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008258_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007770_)))));
        vlSelf->wasmetal_core__DOT___008253_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008266_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007251_)))));
        vlSelf->wasmetal_core__DOT___008252_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008274_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007278_)))));
        vlSelf->wasmetal_core__DOT___008251_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008282_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007305_)))));
        vlSelf->wasmetal_core__DOT___008292_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008295_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007338_)))));
        vlSelf->wasmetal_core__DOT___008291_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008303_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007364_)))));
        vlSelf->wasmetal_core__DOT___008290_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008311_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007390_)))));
        vlSelf->wasmetal_core__DOT___008289_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008319_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007417_)))));
        vlSelf->wasmetal_core__DOT___008329_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008334_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007772_)))));
        vlSelf->wasmetal_core__DOT___008328_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008342_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007254_)))));
        vlSelf->wasmetal_core__DOT___008327_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008350_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007281_)))));
        vlSelf->wasmetal_core__DOT___008326_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008358_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007308_)))));
        vlSelf->wasmetal_core__DOT___008368_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008371_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007341_)))));
        vlSelf->wasmetal_core__DOT___008367_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008379_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007367_)))));
        vlSelf->wasmetal_core__DOT___008366_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008387_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007393_)))));
        vlSelf->wasmetal_core__DOT___008365_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008395_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007420_)))));
        vlSelf->wasmetal_core__DOT___008405_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008409_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007771_)))));
        vlSelf->wasmetal_core__DOT___008404_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008417_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007253_)))));
        vlSelf->wasmetal_core__DOT___008403_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008425_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007280_)))));
        vlSelf->wasmetal_core__DOT___008402_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008433_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007307_)))));
        vlSelf->wasmetal_core__DOT___008443_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008446_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007340_)))));
        vlSelf->wasmetal_core__DOT___008442_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008454_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007366_)))));
        vlSelf->wasmetal_core__DOT___008441_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008462_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007392_)))));
        vlSelf->wasmetal_core__DOT___008440_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008470_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007419_)))));
    }
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023185_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053600_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035962_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035905_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d));
    vlSelf->wasmetal_core__DOT___017952_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059318_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059312_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018102_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059381_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059375_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018194_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059424_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059418_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018556_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059679_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059673_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018586_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059700_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059694_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018664_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059746_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018777_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059857_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059851_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018848_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059974_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059973_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059967_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002473_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002473_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018868_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060001_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060000_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059994_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005868_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002636_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002636_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018879_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002629_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002629_)))))))))))))));
    vlSelf->wasmetal_core__DOT___059648_ = (1U & (IData)(
                                                         (0xeefe00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0b0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006015_))))))))))));
    vlSelf->wasmetal_core__DOT___060588_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he45ddc74__0))));
    vlSelf->wasmetal_core__DOT___060302_ = (1U & (IData)(
                                                         (0xcaf0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))));
    vlSelf->wasmetal_core__DOT___060336_ = (1U & (IData)(
                                                         (0xcaf0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060334_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))));
    vlSelf->wasmetal_core__DOT___060241_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                               ? 
                                                              (1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019032_))
                                                               : (IData)(
                                                                         (0xf0305000f030f03ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019033_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019032_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___019043_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                               ? 
                                                              (1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___019046_))
                                                               : (IData)(
                                                                         (0xf0305000f030f03ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019047_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019046_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005889_))))));
    vlSelf->wasmetal_core__DOT___019085_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060283_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019092_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019093_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019092_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005802_)))))))));
    vlSelf->wasmetal_core__DOT___019099_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060291_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019106_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019107_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019106_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005882_)))))))));
    vlSelf->wasmetal_core__DOT___060318_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060317_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019116_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019117_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019116_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005948_)))))))));
    vlSelf->wasmetal_core__DOT___019131_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060323_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019138_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019139_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019138_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006051_)))))))));
    vlSelf->wasmetal_core__DOT___019150_ = (1U & (IData)(
                                                         (0xaa0acc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060328_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___017186_)
                                                                             ? 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019157_))
                                                                             : (IData)(
                                                                                (0xf0305000f030f03ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019158_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019157_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006029_)))))))));
    vlSelf->wasmetal_core__DOT___019001_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060210_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))
                                                                             ? (IData)(
                                                                                (0x3310303033333030ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019005_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019004_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_))))))))
                                                                             : 
                                                                            (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___019004_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005711_)))))))));
    vlSelf->wasmetal_core__DOT___060276_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060272_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013795_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005955_)))))));
    vlSelf->wasmetal_core__DOT___060378_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060374_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013738_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006151_)))))));
    vlSelf->wasmetal_core__DOT___060395_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060389_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013918_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006226_)))))));
    vlSelf->wasmetal_core__DOT___019180_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060404_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006274_)))))));
    vlSelf->wasmetal_core__DOT___060419_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060412_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013780_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005823_)))))));
    vlSelf->wasmetal_core__DOT___019188_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060428_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013778_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005903_)))))));
    vlSelf->wasmetal_core__DOT___060446_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060442_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___014245_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005816_)))))));
    vlSelf->wasmetal_core__DOT___018830_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059942_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002472_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018898_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060057_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060056_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060050_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002630_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018914_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060082_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060081_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060075_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002633_)))))))))))))));
    vlSelf->wasmetal_core__DOT___018947_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060128_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060122_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002631_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060163_ = (1U & (IData)(
                                                         (0xfff1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060153_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3af030300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060146_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef0df0fb__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002632_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060648_ = (1U & (0x440f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xeee0fff0fff0ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060646_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060645_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))));
    vlSelf->wasmetal_core__DOT___019163_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcaf0c0cULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060349_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h385650d9__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x111f0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___013737_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006058_)))))));
}
