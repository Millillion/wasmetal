#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__33(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__33\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___007169_;
    wasmetal_core__DOT___007169_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007185_;
    wasmetal_core__DOT___007185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015117_;
    wasmetal_core__DOT___015117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015154_;
    wasmetal_core__DOT___015154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017577_;
    wasmetal_core__DOT___017577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017805_;
    wasmetal_core__DOT___017805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022571_;
    wasmetal_core__DOT___022571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022575_;
    wasmetal_core__DOT___022575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022579_;
    wasmetal_core__DOT___022579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022584_;
    wasmetal_core__DOT___022584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022592_;
    wasmetal_core__DOT___022592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023314_;
    wasmetal_core__DOT___023314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023318_;
    wasmetal_core__DOT___023318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023322_;
    wasmetal_core__DOT___023322_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023327_;
    wasmetal_core__DOT___023327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023331_;
    wasmetal_core__DOT___023331_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023336_;
    wasmetal_core__DOT___023336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023340_;
    wasmetal_core__DOT___023340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023344_;
    wasmetal_core__DOT___023344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023349_;
    wasmetal_core__DOT___023349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023353_;
    wasmetal_core__DOT___023353_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023358_;
    wasmetal_core__DOT___023358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023364_;
    wasmetal_core__DOT___023364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036854_;
    wasmetal_core__DOT___036854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036861_;
    wasmetal_core__DOT___036861_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036862_;
    wasmetal_core__DOT___036862_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036867_;
    wasmetal_core__DOT___036867_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036908_;
    wasmetal_core__DOT___036908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036914_;
    wasmetal_core__DOT___036914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036915_;
    wasmetal_core__DOT___036915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037013_;
    wasmetal_core__DOT___037013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058422_;
    wasmetal_core__DOT___058422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058936_;
    wasmetal_core__DOT___058936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058968_;
    wasmetal_core__DOT___058968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058972_;
    wasmetal_core__DOT___058972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058983_;
    wasmetal_core__DOT___058983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059018_;
    wasmetal_core__DOT___059018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059056_;
    wasmetal_core__DOT___059056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059226_;
    wasmetal_core__DOT___059226_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059229_;
    wasmetal_core__DOT___059229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059230_;
    wasmetal_core__DOT___059230_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059232_;
    wasmetal_core__DOT___059232_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060497_;
    wasmetal_core__DOT___060497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060511_;
    wasmetal_core__DOT___060511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060525_;
    wasmetal_core__DOT___060525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060597_;
    wasmetal_core__DOT___060597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d;
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127444___O;
    wasmetal_core__DOT____Vcellout___127444___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127445___O;
    wasmetal_core__DOT____Vcellout___127445___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127446___O;
    wasmetal_core__DOT____Vcellout___127446___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127447___O;
    wasmetal_core__DOT____Vcellout___127447___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127448___O;
    wasmetal_core__DOT____Vcellout___127448___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127449___O;
    wasmetal_core__DOT____Vcellout___127449___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127536___O;
    wasmetal_core__DOT____Vcellout___127536___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127537___O;
    wasmetal_core__DOT____Vcellout___127537___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127538___O;
    wasmetal_core__DOT____Vcellout___127538___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127539___O;
    wasmetal_core__DOT____Vcellout___127539___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127542___O;
    wasmetal_core__DOT____Vcellout___127542___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127544___O;
    wasmetal_core__DOT____Vcellout___127544___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127546___O;
    wasmetal_core__DOT____Vcellout___127546___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127547___O;
    wasmetal_core__DOT____Vcellout___127547___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127548___O;
    wasmetal_core__DOT____Vcellout___127548___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134170___O;
    wasmetal_core__DOT____Vcellout___134170___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134171___O;
    wasmetal_core__DOT____Vcellout___134171___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134175___O;
    wasmetal_core__DOT____Vcellout___134175___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h1c23bbd1__0;
    __VdfgTmp_h1c23bbd1__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3a48ed75__0;
    __VdfgTmp_h3a48ed75__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf115889b__0;
    __VdfgTmp_hf115889b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h13ac9eb3__0;
    __VdfgTmp_h13ac9eb3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h859eb527__0;
    __VdfgTmp_h859eb527__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7fda4de5__0;
    __VdfgTmp_h7fda4de5__0 = 0;
    CData/*2:0*/ __VdfgTmp_h385c50c6__0;
    __VdfgTmp_h385c50c6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h06108119__0;
    __VdfgTmp_h06108119__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3be775f9__0;
    __VdfgTmp_h3be775f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h35fc6168__0;
    __VdfgTmp_h35fc6168__0 = 0;
    CData/*1:0*/ __VdfgTmp_h38f8e813__0;
    __VdfgTmp_h38f8e813__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4954f743__0;
    __VdfgTmp_h4954f743__0 = 0;
    CData/*1:0*/ __VdfgTmp_h57c36911__0;
    __VdfgTmp_h57c36911__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e008e26__0;
    __VdfgTmp_h0e008e26__0 = 0;
    CData/*4:0*/ __VdfgTmp_h3eda33ce__0;
    __VdfgTmp_h3eda33ce__0 = 0;
    // Body
    if (vlSelf->wasmetal_core__DOT___005696_) {
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___006558_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006559_;
    } else {
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___007078_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006558_;
    }
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035707_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035694_)
            : (IData)(vlSelf->wasmetal_core__DOT___035682_));
    vlSelf->wasmetal_core__DOT___058423_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h00939515__0)))))));
    wasmetal_core__DOT___058422_ = (1U & (IData)((0xff00f0f011111111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058420_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058072_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058073_)))))))));
    vlSelf->wasmetal_core__DOT___058418_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014541_)))));
    vlSelf->wasmetal_core__DOT___058395_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014485_)))));
    vlSelf->__VdfgTmp_h3f743267__0 = (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0x33330f270f0f331bULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0)))
                                                     : (IData)(
                                                               (0xf0f331b33330f27ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0))))));
    vlSelf->__VdfgTmp_h210df1ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0))))));
    vlSelf->__VdfgTmp_h1e28f3c0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0))))));
    vlSelf->wasmetal_core__DOT___015094_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0)))));
    vlSelf->wasmetal_core__DOT___014632_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048942_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99d13f88__0))))))));
    vlSelf->wasmetal_core__DOT___014659_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007156_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980f95b2__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006284_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014570_))))))))));
    wasmetal_core__DOT___059229_ = (1U & (IData)((0x1ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015070_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014949_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058134_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007170_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014488_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014486_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014487_)))))))));
    __VdfgTmp_h38f8e813__0 = (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014488_));
    wasmetal_core__DOT___015117_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014476_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014477_))))));
    vlSelf->wasmetal_core__DOT___014827_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007146_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014573_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014567_))))))))));
    vlSelf->wasmetal_core__DOT___014757_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007136_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014570_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___006609_))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014498_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014499_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf0f335500000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xccaaf0f0U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058380_)))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014514_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014515_)))))))));
    __VdfgTmp_h4954f743__0 = (((IData)(vlSelf->wasmetal_core__DOT___014515_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014514_));
    if (vlSelf->wasmetal_core__DOT___007129_) {
        if (vlSelf->wasmetal_core__DOT___007130_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014499_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014498_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014484_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014502_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014558_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (IData)(__VdfgTmp_h38f8e813__0)));
        }
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (0x33550f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058372_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058374_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058373_)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014557_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014556_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h00939515__0))));
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (1U >> (1U & (0x1111000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h4954f743__0))))))));
    }
    __VdfgTmp_h06108119__0 = (((IData)(vlSelf->wasmetal_core__DOT___014528_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014529_));
    vlSelf->wasmetal_core__DOT___014792_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007124_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058073_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058072_)))))))));
    __VdfgTmp_h1c23bbd1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007124_));
    __VdfgTmp_h57c36911__0 = (((IData)(vlSelf->wasmetal_core__DOT___014543_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014542_));
    vlSelf->wasmetal_core__DOT___014746_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007166_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h088d475b__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006504_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014573_))))))))));
    vlSelf->wasmetal_core__DOT___014602_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048945_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0x110fU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009489_))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009486_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009487_)))) 
                                                  << 1U)) 
                                           | (1U & 
                                              (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xff00f0f011111111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___009490_)))))));
    wasmetal_core__DOT___015154_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014466_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014467_))))));
    vlSelf->wasmetal_core__DOT___014631_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007178_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007180_)))))));
    __VdfgTmp_h3be775f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007178_));
    __VdfgTmp_h385c50c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007158_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007160_)));
    __VdfgTmp_h3a48ed75__0 = (((IData)(vlSelf->wasmetal_core__DOT___007148_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007150_)));
    vlSelf->__VdfgTmp_hce3e66a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___007139_)))))));
    vlSelf->wasmetal_core__DOT___014756_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007140_)))))));
    __VdfgTmp_h13ac9eb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014556_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014557_));
    __VdfgTmp_h35fc6168__0 = (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007126_));
    if (vlSelf->wasmetal_core__DOT___007130_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0)))));
        if (vlSelf->wasmetal_core__DOT___007129_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014527_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014526_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014541_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014540_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014530_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014516_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014544_))));
        }
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009487_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009486_))))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014465_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014464_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007160_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007156_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007150_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007146_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007136_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007170_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007166_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007187_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h99d13f88__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007128_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_h1c23bbd1__0)))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014477_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014476_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014529_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014528_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009488_)))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014467_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014466_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007158_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007148_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007138_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007168_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___007185_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h4954f743__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h57c36911__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h3be775f9__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h35fc6168__0))));
    }
    __VdfgTmp_hf115889b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007126_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007128_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014545_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014542_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014543_)))))))));
    __VdfgTmp_h7fda4de5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007168_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007170_)));
    __VdfgTmp_h859eb527__0 = (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007185_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007187_)));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035708_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035683_));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d));
    vlSelf->__VdfgTmp_h39f326f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0))))));
    vlSelf->__VdfgTmp_h375bf609__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0))))));
    vlSelf->wasmetal_core__DOT___059231_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059229_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014966_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014979_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014878_)))))))));
    vlSelf->wasmetal_core__DOT___058396_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h00939515__0)) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h38f8e813__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d 
        = (1U & (IData)((0xf0feeee00ff00ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 4U) 
                                                     | (((IData)(wasmetal_core__DOT___015117_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xccccaaaa000f000fULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058384_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058382_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058381_)))))))) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0))))))));
    vlSelf->__VdfgTmp_hb48763c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015117_));
    vlSelf->__VdfgTmp_h22db4e96__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((1U 
                                                >> 
                                                ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xe0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h06108119__0)))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014526_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014527_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf1f100ff00000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058408_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xccaa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x7fff0000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___058382_))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h06108119__0))))))));
    vlSelf->wasmetal_core__DOT___058419_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h57c36911__0))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d));
    vlSelf->__VdfgTmp_hd148b96b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014712_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0))))));
    vlSelf->__VdfgTmp_hf41b4843__0 = (((IData)(wasmetal_core__DOT___015154_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014464_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014465_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff4f400000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0x305U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h19cea986__0)))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___058374_)))))))))));
    vlSelf->__VdfgTmp_h52595424__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015154_));
    vlSelf->__VdfgTmp_h7bf425d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014631_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014632_));
    vlSelf->__VdfgTmp_hc1e22c7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3be775f9__0))))));
    vlSelf->__VdfgTmp_h7328e0ec__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->wasmetal_core__DOT___014658_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->__VdfgTmp_he7d53082__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT___014826_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014756_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014757_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d 
        = (1U & (IData)((0xff0f0feeeeeeeeULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050081_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xeU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h13ac9eb3__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xe0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014559_)))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(__VdfgTmp_h13ac9eb3__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h13ac9eb3__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d 
        = (1U & (IData)((0xff00ffeeee0f0fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___058422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(__VdfgTmp_h35fc6168__0)) 
                                                              << 2U)) 
                                                          | (IData)(__VdfgTmp_h1c23bbd1__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->wasmetal_core__DOT___014791_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->__VdfgTmp_h8020f35b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0))))));
    vlSelf->__VdfgTmp_h5b0d2f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->wasmetal_core__DOT___014745_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->__VdfgTmp_h023f0a12__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___014601_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035709_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035709_))));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058395_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058394_))))));
    vlSelf->__VdfgTmp_h7410d216__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0))))));
    vlSelf->__VdfgTmp_h3c2f1975__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058417_))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))));
    vlSelf->__VdfgTmp_hcd6303e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0))))));
    vlSelf->wasmetal_core__DOT___058205_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7328e0ec__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014658_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014659_))));
    vlSelf->wasmetal_core__DOT___058207_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d53082__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014826_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014827_))));
    vlSelf->wasmetal_core__DOT___059242_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (7U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))))));
    vlSelf->__VdfgTmp_h5b356604__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0))))));
    wasmetal_core__DOT___059226_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h52595424__0)))))))))));
    vlSelf->__VdfgTmp_h66dab408__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0))))));
    vlSelf->__VdfgTmp_h943c9679__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0))))));
    vlSelf->wasmetal_core__DOT___059234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014791_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014792_))));
    vlSelf->wasmetal_core__DOT___014590_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8020f35b__0)))));
    vlSelf->wasmetal_core__DOT___058644_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5b0d2f75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014745_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014746_))));
    vlSelf->wasmetal_core__DOT___058203_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h023f0a12__0)))));
    wasmetal_core__DOT___059232_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___005667_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014602_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014602_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128772___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035710_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035709_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035708_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035707_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035694_)))));
    vlSelf->wasmetal_core__DOT___035698_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035710_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___035710_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127535___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023345_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058619_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3c2f1975__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127443___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014712_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022588_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___015439_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcd6303e8__0)))));
    wasmetal_core__DOT___059230_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___059226_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___015540_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66dab408__0)))));
    vlSelf->wasmetal_core__DOT___059235_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059232_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058561_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007129_)))))))));
    vlSelf->wasmetal_core__DOT___060217_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0fffff0bbbb8888ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060214_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)))))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035711_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035698_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035711_))));
    vlSelf->wasmetal_core__DOT___058562_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023345_));
    vlSelf->wasmetal_core__DOT___058946_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___058940_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___058951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___022588_));
    vlSelf->wasmetal_core__DOT___059233_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059231_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059230_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)))))))))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035712_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035712_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035702_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035702_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128773___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035711_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035698_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127540___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023345_)))));
    wasmetal_core__DOT___023364_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127444___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022588_)))));
    wasmetal_core__DOT___022592_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h6ecbbe50__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h7af47ace__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d));
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
           & (IData)(wasmetal_core__DOT___023364_));
    vlSelf->wasmetal_core__DOT___058956_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___058964_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127444___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d)))));
    wasmetal_core__DOT___058968_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))));
    wasmetal_core__DOT___058983_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))));
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___022592_));
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023364_)))));
    wasmetal_core__DOT___023314_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127445___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022592_)))));
    wasmetal_core__DOT___022571_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                    & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hcf32a2f0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d));
    vlSelf->wasmetal_core__DOT___058571_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))));
    vlSelf->__VdfgTmp_h5c254f34__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
           & (IData)(wasmetal_core__DOT___023314_));
    wasmetal_core__DOT___058972_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127445___O))))));
    vlSelf->wasmetal_core__DOT___059014_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059018_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059022_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___022571_));
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127542___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023314_)))));
    wasmetal_core__DOT___023318_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127446___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xeU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022571_)))));
    wasmetal_core__DOT___022575_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hd9e83ce6__0 = ((4U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___015076_))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___015076_)));
    vlSelf->__VdfgTmp_hb3aa193a__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h842e8acf__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___058574_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023318_));
    vlSelf->wasmetal_core__DOT___059027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127446___O))))));
    vlSelf->wasmetal_core__DOT___058992_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___058996_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___059005_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___022575_));
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127543___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023318_)))));
    wasmetal_core__DOT___023322_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                    & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127447___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022575_)))));
    wasmetal_core__DOT___022579_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058575_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O)))))));
    vlSelf->wasmetal_core__DOT___058584_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                               >> 1U)))))));
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
           & (IData)(wasmetal_core__DOT___023322_));
    vlSelf->wasmetal_core__DOT___059000_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127447___O))))));
    vlSelf->wasmetal_core__DOT___059035_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___059040_ = (1U & (IData)(
                                                         (0xff00ff1111f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058395_)))))))));
    vlSelf->wasmetal_core__DOT___059044_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___022579_));
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127544___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023322_)))));
    wasmetal_core__DOT___023327_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                    & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127448___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022579_)))));
    wasmetal_core__DOT___022584_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                    & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hca8853c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127544___O)));
    vlSelf->wasmetal_core__DOT___058589_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127544___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___058590_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___058593_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
           & (IData)(wasmetal_core__DOT___023327_));
    vlSelf->__VdfgTmp_h0da91de8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127448___O)));
    vlSelf->wasmetal_core__DOT___059059_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059056_ = (1U & (IData)((0xff00ff1111f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058417_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058418_)))))))));
    wasmetal_core__DOT____Vcellout___127449___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                      & (IData)(wasmetal_core__DOT___022584_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___022584_)));
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___036915_ = (1U & (0x78U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                            << 2U) 
                                           | ((2U & (IData)(wasmetal_core__DOT____Vcellout___127449___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))));
    wasmetal_core__DOT___036914_ = (1U & (0x3c5aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127449___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036914_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127545___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023327_)))));
    wasmetal_core__DOT___023331_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                    & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036915_) ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d));
    vlSelf->wasmetal_core__DOT___058594_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___058597_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___058598_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d))))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
           & (IData)(wasmetal_core__DOT___023331_));
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134174___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036915_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036914_)))) 
           ^ (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___036908_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT____Vcellout___127546___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023331_)))));
    wasmetal_core__DOT___023336_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                    & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036908_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    wasmetal_core__DOT____Vcellout___134175___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                                                        ? (IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__)
                                                        : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___036908_)));
    vlSelf->__VdfgTmp_hc42a79ae__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d));
    vlSelf->wasmetal_core__DOT___058605_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127546___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014712_)))));
    vlSelf->__VdfgTmp_hfa9cb9e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___058613_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
           & (IData)(wasmetal_core__DOT___023336_));
    vlSelf->wasmetal_core__DOT____Vcellout___134188___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                          << 1U)))));
    wasmetal_core__DOT___037013_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___017805_ = (1U & (7U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127468___O 
        = (((8U & ((~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 1U)))))) 
           ^ (1U | ((((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                          >> 3U)) & (IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    wasmetal_core__DOT___058936_ = (1U & (1U >> ((4U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     << 2U)) 
                                                 | (3U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                 | (IData)(wasmetal_core__DOT___037013_)));
    vlSelf->wasmetal_core__DOT___059236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (2U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d))));
    vlSelf->wasmetal_core__DOT___017493_ = (1U & (IData)(
                                                         (0xfeff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                  << 1U)) 
                                                              | (((IData)(wasmetal_core__DOT___058936_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__)));
    __VdfgTmp_h3eda33ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                          << 3U) | 
                                         ((4U & ((8U 
                                                  >> 
                                                  (2U 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                 << 2U)) 
                                          | (((IData)(wasmetal_core__DOT___017805_) 
                                              << 1U) 
                                             | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___017538_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017495_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (2U 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017493_))))));
    vlSelf->__VdfgTmp_h1a828198__0 = (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (2U 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))));
    wasmetal_core__DOT____Vcellout___127547___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023336_)))));
    wasmetal_core__DOT___023340_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                    & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134189___O 
        = ((((IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d) 
             << 3U) | (((IData)(wasmetal_core__DOT___017805_) 
                        << 2U) | ((2U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)))))) 
           ^ ((8U & (((~ (IData)(wasmetal_core__DOT___017805_)) 
                      | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___037013_)))));
    vlSelf->wasmetal_core__DOT___059065_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___036825_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d))))
                                                   ? (IData)(
                                                             (0xfff4ffff00040000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017806_) 
                                                                << 5U) 
                                                               | (IData)(__VdfgTmp_h3eda33ce__0))))
                                                   : 
                                                  (0x40000U 
                                                   >> (IData)(__VdfgTmp_h3eda33ce__0))));
    vlSelf->wasmetal_core__DOT___060064_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017534_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017549_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017562_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058968_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___059238_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017805_)))));
    wasmetal_core__DOT___017577_ = (1U & (0x1000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___058972_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017664_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017677_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___059018_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017702_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059027_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017611_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017624_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058996_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017729_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059040_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017536_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a828198__0))));
    vlSelf->wasmetal_core__DOT___058612_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d))))));
    vlSelf->wasmetal_core__DOT___058642_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127547___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___058646_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
           & (IData)(wasmetal_core__DOT___023340_));
    vlSelf->wasmetal_core__DOT___060196_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___059550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058968_)))));
    vlSelf->wasmetal_core__DOT___059588_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058983_)))));
    vlSelf->wasmetal_core__DOT___059980_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059056_))));
    vlSelf->wasmetal_core__DOT___059346_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058946_)))));
    vlSelf->wasmetal_core__DOT___018176_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058940_)))));
    vlSelf->wasmetal_core__DOT___059660_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059018_)))));
    vlSelf->wasmetal_core__DOT___059614_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058972_))));
    vlSelf->wasmetal_core__DOT___058950_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058947_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058946_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058945_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058941_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058940_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058987_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058984_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058983_)))))));
    vlSelf->wasmetal_core__DOT___058975_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017579_)
                                                      ? (IData)(
                                                                (0xff00ff00fffbfff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(wasmetal_core__DOT___017577_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5bb2fc7d__0))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(wasmetal_core__DOT___017577_)))));
    vlSelf->wasmetal_core__DOT___059009_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059005_)))))));
    vlSelf->wasmetal_core__DOT___059004_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059001_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059000_)))))));
    vlSelf->wasmetal_core__DOT___059053_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                        & (IData)(
                                                                  (0xa000c00000000ULL 
                                                                   >> 
                                                                   (8U 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0da91de8__0)))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059049_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017536_))))));
    vlSelf->wasmetal_core__DOT___059063_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059060_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059059_)))))));
    vlSelf->wasmetal_core__DOT___018073_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___059056_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059057_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018504_)))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127548___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023340_)))));
    wasmetal_core__DOT___023344_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058649_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___058656_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_h54a2cb2f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                    >> 2U)));
    vlSelf->wasmetal_core__DOT___058660_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
           & (IData)(wasmetal_core__DOT___023344_));
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127536___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0xeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023344_)))));
    wasmetal_core__DOT___023349_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058661_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127536___O))))));
    vlSelf->wasmetal_core__DOT___058631_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___058632_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___058622_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
           & (IData)(wasmetal_core__DOT___023349_));
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127537___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023349_)))));
    wasmetal_core__DOT___023353_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                    & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058625_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(wasmetal_core__DOT____Vcellout___127537___O)))))));
    vlSelf->__VdfgTmp_h2932eeac__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ff1111f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                 << 4U) 
                                                                | ((8U 
                                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))))))));
    vlSelf->wasmetal_core__DOT___058639_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                               >> 3U)))))));
    __VdfgTmp_h0e008e26__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                               << 1U) | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
           & (IData)(wasmetal_core__DOT___023353_));
    vlSelf->wasmetal_core__DOT___060398_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h0e008e26__0))))));
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127538___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023353_)))));
    wasmetal_core__DOT___023358_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                    & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h01fee3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x53U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___127538___O)))))));
    vlSelf->__VdfgTmp_h192fc191__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___058664_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___058665_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
           & (IData)(wasmetal_core__DOT___023358_));
    wasmetal_core__DOT____Vcellout___127539___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                       & (IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___023358_)));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                               >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___058423_))));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___036862_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d))));
    wasmetal_core__DOT___036861_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry))));
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036861_)) 
           & (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036862_) ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d));
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    wasmetal_core__DOT___036854_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036854_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134166___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036862_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036861_)))) 
           ^ (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134167___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                  ? (IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(wasmetal_core__DOT___036854_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134169___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                          << 1U)))));
    wasmetal_core__DOT___036867_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___023670_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                                            & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127583___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_he997ff62__0 = (0x10U | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                << 3U) 
                                               | (2U 
                                                  & ((IData)(
                                                             (0x1000000000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> 
                                                                    (3U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                        >> 1U))) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                           >> 3U))) 
                                                                      << 4U)) 
                                                                  | ((0xeU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                           >> 3U))))))) 
                                                     << 1U))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                 | (IData)(wasmetal_core__DOT___036867_)));
    wasmetal_core__DOT___060497_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060511_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060525_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    vlSelf->wasmetal_core__DOT___060308_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h54a2cb2f__0))))))));
    vlSelf->wasmetal_core__DOT___019073_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                             >> 3U))))))))));
    vlSelf->__VdfgTmp_hdfb00432__0 = ((2U & ((0xff4fffU 
                                              >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___059242_));
    vlSelf->wasmetal_core__DOT___017018_ = (1U & (IData)(
                                                         (0xff4fff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006127_))) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_he997ff62__0)))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060499_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060513_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060511_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058509_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 1U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058359_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060527_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060525_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 2U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059551_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6ecbbe50__0))))));
    vlSelf->wasmetal_core__DOT___018432_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7af47ace__0))))))));
    vlSelf->wasmetal_core__DOT___059517_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___059394_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___059686_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___059435_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___060170_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058605_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb00432__0)))));
    vlSelf->wasmetal_core__DOT___018537_ = (1U & (IData)(
                                                         (0x5030f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c254f34__0))))))));
    vlSelf->wasmetal_core__DOT___060252_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058642_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb00432__0))));
    vlSelf->wasmetal_core__DOT___018492_ = (1U & (0xbf00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058571_))))));
    vlSelf->wasmetal_core__DOT___016587_ = (1U & (IData)(
                                                         (0xf088000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058561_)))))))));
    vlSelf->wasmetal_core__DOT___016538_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016798_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016780_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hca8853c2__0))))));
    vlSelf->wasmetal_core__DOT___016801_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016836_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016848_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016536_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018964_)))))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___016933_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058613_))))));
    vlSelf->wasmetal_core__DOT___016915_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058612_))))));
    vlSelf->wasmetal_core__DOT___017087_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x3355ffff0f0f0f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                                >> 2U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016536_))));
    vlSelf->wasmetal_core__DOT___017068_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058649_))))));
    vlSelf->wasmetal_core__DOT___016995_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2932eeac__0))))));
    vlSelf->wasmetal_core__DOT___017006_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                   ? 
                                                  (0xac00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h0e008e26__0)))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017017_)))));
    vlSelf->wasmetal_core__DOT___017157_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051320_))))));
    wasmetal_core__DOT____Vcellout___134170___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                          >> 3U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                             >> 2U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                >> 1U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036867_)))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ 
        = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                    >> 3U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___060555_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060552_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060569_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060567_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060566_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134170___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060586_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    wasmetal_core__DOT___060597_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (7U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                 | (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060601_ = (1U & (IData)(
                                                         (0xff0f8808ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060598_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060597_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff0077770f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))))))));
    wasmetal_core__DOT____Vcellout___134171___O = (
                                                   (1U 
                                                    | ((4U 
                                                        & ((8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                           << 2U)) 
                                                       | (2U 
                                                          & ((7U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                             << 1U)))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))
                                                          ? (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (8U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (3U 
                                                          & (- (IData)((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)))))));
    vlSelf->wasmetal_core__DOT___060617_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060615_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060614_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060643_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060627_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060624_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060623_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134171___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
}
