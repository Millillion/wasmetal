#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__13(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__13\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___011020_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0)))));
    vlSelf->wasmetal_core__DOT___010770_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0))))));
    vlSelf->__VdfgTmp_h39adae05__0 = (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0));
    vlSelf->__VdfgTmp_hffef1e62__0 = (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010280_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010278_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010279_)))))))));
    vlSelf->wasmetal_core__DOT___019303_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1111f0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054884_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054878_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1327a702__0)))))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054875_)))))))))))))))));
    vlSelf->__VdfgTmp_h69fe2c1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049853_));
    vlSelf->wasmetal_core__DOT___049099_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049097_))));
    vlSelf->wasmetal_core__DOT___050525_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049839_))));
    vlSelf->wasmetal_core__DOT___049266_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049263_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049262_))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
    } else {
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010113_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8d891945__0))))));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (IData)(
                                                          (0x11100000fffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010173_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
    }
    vlSelf->__VdfgTmp_h7fb5afda__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h8d891945__0));
    vlSelf->wasmetal_core__DOT___061971_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061965_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT___056178_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d))));
    vlSelf->wasmetal_core__DOT___055155_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055153_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054913_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4481aac1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054920_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009643_)
                                                   ? 
                                                  (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0x3333555500ff0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054917_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xff33ff550f0f0f0fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9c602ec__0)))))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xc0aU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054914_))))))))))
                                                   : 
                                                  (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xf0f333300ff5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054902_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xff33330f0f5555ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054913_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h4481aac1__0))))))))))));
    vlSelf->__VdfgTmp_h6e22e397__0 = (((IData)(vlSelf->wasmetal_core__DOT___049853_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049852_));
    vlSelf->wasmetal_core__DOT___049483_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049097_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049066_))));
    vlSelf->wasmetal_core__DOT___049843_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049839_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049838_))));
    vlSelf->wasmetal_core__DOT___049458_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049273_))));
    vlSelf->wasmetal_core__DOT___055981_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055979_))));
    vlSelf->wasmetal_core__DOT___056437_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011603_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011997_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010166_));
    vlSelf->wasmetal_core__DOT___011119_ = (1U & (IData)(
                                                         (0xffffff11fffffff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))));
    vlSelf->__VdfgTmp_hd957e182__0 = (((IData)(vlSelf->wasmetal_core__DOT___049852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049854_));
    vlSelf->__VdfgTmp_h9726a7a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049854_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049608_));
    vlSelf->__VdfgTmp_hc8d2269b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049072_));
    vlSelf->wasmetal_core__DOT___049074_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049066_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049065_))));
    vlSelf->wasmetal_core__DOT___049842_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049840_))));
    vlSelf->wasmetal_core__DOT___050524_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049841_))));
    vlSelf->wasmetal_core__DOT___049453_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049276_))));
    vlSelf->wasmetal_core__DOT___049278_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049272_))));
    vlSelf->wasmetal_core__DOT___056594_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011115_)));
    vlSelf->wasmetal_core__DOT___010161_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010159_))
                                                   : (IData)(
                                                             (0xff00ff00fffefff0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010159_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0))))))));
    vlSelf->wasmetal_core__DOT___010972_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0)))));
    vlSelf->__VdfgTmp_hb25114eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012131_));
    vlSelf->__VdfgTmp_hd5a37d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012029_));
    vlSelf->wasmetal_core__DOT___056721_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___056898_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056327_)))))))));
    vlSelf->__VdfgTmp_hda718c9e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)));
    vlSelf->wasmetal_core__DOT___061795_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061796_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061763_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061762_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061674_)))))))));
    vlSelf->wasmetal_core__DOT___054799_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6b3ca0e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfce0919b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054798_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054766_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9869a20__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf3f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054758_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054771_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054786_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___011857_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
    vlSelf->__VdfgTmp_h88263545__0 = (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->__VdfgTmp_hbc86843d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___061512_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061459_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4dc07bf4__0))))))));
    vlSelf->wasmetal_core__DOT___053096_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xbf00bfbf00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053084_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053083_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053082_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050410_)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000e0e00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053078_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053064_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053064_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053022_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053021_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053045_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053066_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfff30004000cfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053066_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053047_)))))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0f0fdfU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (vlSelf->insn_w 
                                                                            >> 1U))))))))))));
    vlSelf->wasmetal_core__DOT___049023_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049013_))));
    vlSelf->wasmetal_core__DOT___049447_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049247_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049249_))));
    vlSelf->__VdfgTmp_h20ec44fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049358_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049357_));
    vlSelf->__VdfgTmp_h15ceac3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___049357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049367_));
    vlSelf->wasmetal_core__DOT___049502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049131_))));
    vlSelf->wasmetal_core__DOT___049132_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049130_))));
    vlSelf->wasmetal_core__DOT___062171_ = (1U & (IData)(
                                                         (0xb3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062164_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062163_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))))));
    if (vlSelf->wasmetal_core__DOT___010312_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
    }
    vlSelf->__VdfgTmp_h362b458b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009653_));
    vlSelf->__VdfgTmp_ha569c0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010044_));
    vlSelf->__VdfgTmp_h375c9c07__0 = (((IData)(vlSelf->wasmetal_core__DOT___056376_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056375_));
    vlSelf->wasmetal_core__DOT___010391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x333355550f0f00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057024_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___011728_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d))))));
    vlSelf->__VdfgTmp_heb18a766__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d));
    vlSelf->wasmetal_core__DOT___056919_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___011194_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))));
    vlSelf->__VdfgTmp_h51371d7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011867_));
    vlSelf->wasmetal_core__DOT___051631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051630_))));
    vlSelf->wasmetal_core__DOT___057540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010722_))));
    vlSelf->wasmetal_core__DOT___011924_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0)))));
    vlSelf->wasmetal_core__DOT___055271_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc16275c3__0))));
    vlSelf->__VdfgTmp_h2133c371__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc16275c3__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009651_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he6780703__0))))))));
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he6780703__0)))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0xf0f0305U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009651_))))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010231_))))));
    }
    vlSelf->__VdfgTmp_hf56802d2__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061504_))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___061491_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___061490_)))));
    vlSelf->__VdfgTmp_hb5edd3cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 2U) | ((2U 
                                                  & ((0xfa330000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha587a88f__0)))))))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019337_)));
    vlSelf->__VdfgTmp_h058d1256__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___019337_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfefeff00ff00ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha587a88f__0))))))))));
    vlSelf->wasmetal_core__DOT___053910_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053689_))));
    vlSelf->wasmetal_core__DOT___053663_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051650_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051549_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051650_))));
    vlSelf->__VdfgTmp_h76242b02__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005823_));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006274_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023480_));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___014037_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023601_));
    vlSelf->wasmetal_core__DOT___065065_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063925_))));
    vlSelf->wasmetal_core__DOT___061513_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061502_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061482_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061475_)))))))));
    vlSelf->__VdfgTmp_h84446dc0__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((IData)(
                                                              (0xaaaaf0f0ff00ccccULL 
                                                               >> 
                                                               ((8U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                                    << 3U)) 
                                                                | ((4U 
                                                                    & ((0xacU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((0xacU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb043089c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048673_));
    vlSelf->wasmetal_core__DOT___049527_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___050789_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0))))));
    vlSelf->wasmetal_core__DOT___047950_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___050850_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049645_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049054_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0))))));
    vlSelf->wasmetal_core__DOT___049226_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049748_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049747_))));
    vlSelf->wasmetal_core__DOT___049885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049884_))));
    vlSelf->wasmetal_core__DOT___049796_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049795_))));
    vlSelf->wasmetal_core__DOT___049699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049698_))));
    vlSelf->wasmetal_core__DOT___049619_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049615_))));
    vlSelf->wasmetal_core__DOT___050048_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050046_))));
    vlSelf->wasmetal_core__DOT___049506_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049499_))));
    vlSelf->wasmetal_core__DOT___049146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049121_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049120_))));
    vlSelf->wasmetal_core__DOT___050694_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048590_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048589_))));
    vlSelf->wasmetal_core__DOT___049887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049616_))));
    vlSelf->wasmetal_core__DOT___050792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050787_))));
    vlSelf->wasmetal_core__DOT___049798_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049500_))));
    vlSelf->wasmetal_core__DOT___049750_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049121_))));
    vlSelf->wasmetal_core__DOT___049371_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047952_))));
    vlSelf->wasmetal_core__DOT___049702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048590_))));
    vlSelf->__VdfgTmp_h10a668fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063925_));
    vlSelf->wasmetal_core__DOT___050476_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049159_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049161_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049159_))));
    vlSelf->wasmetal_core__DOT___051895_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049312_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049314_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049312_))));
    vlSelf->wasmetal_core__DOT___065622_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065621_)))));
    vlSelf->wasmetal_core__DOT___066659_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066653_)))))))));
    vlSelf->wasmetal_core__DOT___065932_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065931_)))));
    vlSelf->wasmetal_core__DOT___066537_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065811_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066531_)))))))));
    vlSelf->wasmetal_core__DOT___065812_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065811_)))));
    vlSelf->wasmetal_core__DOT___066134_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065309_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066133_)))));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028665_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029065_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028977_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128435___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128435___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032283_)))));
    vlSelf->wasmetal_core__DOT___032287_ = ((IData)(vlSelf->wasmetal_core__DOT___001487_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001487_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___045002_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)))))))))));
    vlSelf->wasmetal_core__DOT___045026_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026718_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___070681_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071867_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027188_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127859___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026587_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026584_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026573_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026562_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026529_ = ((IData)(vlSelf->wasmetal_core__DOT___026587_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001887_));
    vlSelf->wasmetal_core__DOT___070784_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071886_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026988_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___066327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O)))));
    vlSelf->wasmetal_core__DOT___034569_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001487_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128663___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128435___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->__VdfgTmp_hf16ebcc9__0) 
                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134217___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h5ad60c71__0) 
           ^ (8U | (((IData)(vlSelf->__VdfgTmp_hf16ebcc9__0) 
                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT___065317_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065313_)))));
    vlSelf->wasmetal_core__DOT___066140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065815_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064754_)))))))));
    vlSelf->wasmetal_core__DOT___064761_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064754_)))));
    vlSelf->wasmetal_core__DOT___065950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065081_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065077_)))));
    vlSelf->wasmetal_core__DOT___065625_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063995_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063982_)))))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011539_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010939_)));
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010749_)));
        vlSelf->wasmetal_core__DOT___011528_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010992_)));
        vlSelf->wasmetal_core__DOT___010339_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011659_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010546_)));
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010961_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___007693_) {
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h9c968075__0)));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xff35U >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010281_)))));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xdU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010231_))));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
        }
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0))));
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf222e899__0)))));
    }
    vlSelf->wasmetal_core__DOT___063997_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063982_)))));
    vlSelf->wasmetal_core__DOT___065911_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064929_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064923_)))))))));
    vlSelf->wasmetal_core__DOT___064931_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064923_)))));
    vlSelf->wasmetal_core__DOT___066271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065423_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065419_)))));
    vlSelf->wasmetal_core__DOT___065198_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065194_)))));
    vlSelf->wasmetal_core__DOT___066095_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065713_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064511_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064498_)))))))));
    vlSelf->wasmetal_core__DOT___064513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064498_)))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030104_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030232_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___068792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068600_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068791_)))));
    vlSelf->wasmetal_core__DOT___068847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068650_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068846_)))));
    vlSelf->wasmetal_core__DOT___068699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068698_)))));
    vlSelf->wasmetal_core__DOT___068601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068397_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068600_)))));
    vlSelf->wasmetal_core__DOT___068748_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068548_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068747_)))));
    vlSelf->wasmetal_core__DOT___068475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068288_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068474_)))));
    vlSelf->wasmetal_core__DOT___068651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068421_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068650_)))));
    vlSelf->wasmetal_core__DOT___068398_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068150_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068397_)))));
    vlSelf->wasmetal_core__DOT___068549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068342_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068548_)))));
    vlSelf->wasmetal_core__DOT___068289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068288_)))));
    vlSelf->wasmetal_core__DOT___068422_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068235_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068421_)))));
    vlSelf->wasmetal_core__DOT___068343_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068099_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068342_)))));
    vlSelf->wasmetal_core__DOT___068075_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068074_)))));
    vlSelf->wasmetal_core__DOT___068151_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068150_)))));
    vlSelf->wasmetal_core__DOT___068236_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068235_)))));
    vlSelf->wasmetal_core__DOT___068027_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068026_)))));
    vlSelf->wasmetal_core__DOT___068100_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068099_)))));
    vlSelf->wasmetal_core__DOT___067970_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067969_)))));
    vlSelf->wasmetal_core__DOT___067817_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067816_)))));
    vlSelf->wasmetal_core__DOT___067904_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067903_)))));
    vlSelf->wasmetal_core__DOT___067732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067731_)))));
    vlSelf->wasmetal_core__DOT___067594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067301_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067593_)))));
    vlSelf->wasmetal_core__DOT___067449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067448_)))));
    vlSelf->wasmetal_core__DOT___067302_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066963_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067301_)))));
    vlSelf->wasmetal_core__DOT___067147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067146_)))));
    vlSelf->wasmetal_core__DOT___066964_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066639_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066963_)))));
    vlSelf->wasmetal_core__DOT___067756_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067755_)))));
    vlSelf->wasmetal_core__DOT___066845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066844_)))));
    vlSelf->wasmetal_core__DOT___067666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067665_)))));
    vlSelf->wasmetal_core__DOT___066640_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066305_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066639_)))));
    vlSelf->wasmetal_core__DOT___067498_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067497_)))));
    vlSelf->wasmetal_core__DOT___067332_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067068_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067331_)))));
    vlSelf->wasmetal_core__DOT___066518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066117_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066517_)))));
    vlSelf->wasmetal_core__DOT___067188_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066885_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067187_)))));
    vlSelf->wasmetal_core__DOT___067069_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067068_)))));
    vlSelf->wasmetal_core__DOT___066306_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066305_)))));
    vlSelf->wasmetal_core__DOT___066886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066885_)))));
    vlSelf->wasmetal_core__DOT___066118_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065794_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066117_)))));
    vlSelf->wasmetal_core__DOT___066762_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066391_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066761_)))));
    vlSelf->wasmetal_core__DOT___066595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066594_)))));
    vlSelf->wasmetal_core__DOT___065927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065596_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065926_)))));
    vlSelf->wasmetal_core__DOT___065795_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065292_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065794_)))));
    vlSelf->wasmetal_core__DOT___066392_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066391_)))));
    vlSelf->wasmetal_core__DOT___066262_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066261_)))));
    vlSelf->wasmetal_core__DOT___066072_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066071_)))));
    vlSelf->wasmetal_core__DOT___065891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065405_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065890_)))));
    vlSelf->wasmetal_core__DOT___065597_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065596_)))));
    vlSelf->wasmetal_core__DOT___065693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065176_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065692_)))));
    vlSelf->wasmetal_core__DOT___065406_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065405_)))));
    vlSelf->wasmetal_core__DOT___064892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064891_))));
    vlSelf->wasmetal_core__DOT___065177_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064483_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065176_)))));
    vlSelf->wasmetal_core__DOT___064484_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064483_))));
    vlSelf->wasmetal_core__DOT___065293_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064724_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065292_)))));
    vlSelf->wasmetal_core__DOT___064725_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064724_))));
    vlSelf->wasmetal_core__DOT___065072_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065071_)))));
    vlSelf->wasmetal_core__DOT___063831_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063829_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128058___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028310_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028307_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028296_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028285_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028278_ = ((IData)(vlSelf->wasmetal_core__DOT___028310_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028245_));
    vlSelf->wasmetal_core__DOT___051460_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))))))));
    vlSelf->wasmetal_core__DOT___051696_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))))))));
    vlSelf->wasmetal_core__DOT___066412_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066405_)))))))));
    vlSelf->wasmetal_core__DOT___065710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065709_)))));
    vlSelf->wasmetal_core__DOT___066781_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066076_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066775_)))))))));
    vlSelf->wasmetal_core__DOT___066077_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066076_)))));
    vlSelf->wasmetal_core__DOT___066905_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066268_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066899_)))))))));
    vlSelf->wasmetal_core__DOT___066269_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066268_)))));
    vlSelf->wasmetal_core__DOT___065908_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065907_)))));
    vlSelf->wasmetal_core__DOT___064904_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___063864_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063835_))));
    vlSelf->wasmetal_core__DOT___064774_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064771_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4fff00ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064748_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063902_)))))));
    vlSelf->wasmetal_core__DOT___065055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0))))));
    vlSelf->wasmetal_core__DOT___064911_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)))));
    vlSelf->wasmetal_core__DOT___063929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127944___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027366_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027355_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027344_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027301_ = ((IData)(vlSelf->wasmetal_core__DOT___027366_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___023238_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffde1553__0))));
    vlSelf->wasmetal_core__DOT___023239_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005731_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))));
    vlSelf->wasmetal_core__DOT___023237_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hba4cc4c7__0))));
    vlSelf->wasmetal_core__DOT___023236_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fccfed0__0))));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___054972_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019319_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f5U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___054939_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8cc03967__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054966_)))))))));
    vlSelf->wasmetal_core__DOT___059205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059201_))));
    vlSelf->wasmetal_core__DOT___060006_ = (1U & (IData)(
                                                         (0xf00ff8800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))));
    vlSelf->wasmetal_core__DOT___069089_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048851_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048852_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h22ba1a50__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___001947_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002288_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b64371c__0))))))));
    vlSelf->__VdfgTmp_h85a07a94__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbd418077__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001964_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5b64371c__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___068967_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002811_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048859_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048860_)))))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h5e317429__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hae207145__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002563_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002562_)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002799_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002811_))));
        vlSelf->wasmetal_core__DOT___002554_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002564_)))));
    }
    vlSelf->__VdfgTmp_h07469665__0 = (((IData)(vlSelf->wasmetal_core__DOT___002564_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0));
    vlSelf->wasmetal_core__DOT___002353_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002851_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002852_)))))))));
    vlSelf->__VdfgTmp_hcbcea2b7__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                 & (IData)(
                                                           (0xfff0ffff1111ffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000163_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001727_)
                                                                               : 
                                                                              (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                             << 1U)) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001726_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb4d5b900__0))))))))));
    vlSelf->__VdfgTmp_h91cc03bd__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h343b1824__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000163_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb4d5b900__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015651_))));
    vlSelf->wasmetal_core__DOT___058931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058693_))));
    vlSelf->wasmetal_core__DOT___061514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061490_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha1796962__0))))));
    vlSelf->wasmetal_core__DOT___061510_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061476_))));
    vlSelf->__VdfgTmp_h4a9b748c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011992_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___011921_ = (1U & (IData)(
                                                         (0xbbf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->__VdfgTmp_hba8ce1a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0)));
    vlSelf->wasmetal_core__DOT___055251_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->wasmetal_core__DOT___061663_ = (1U & (IData)(
                                                         (0xf030a020f0300030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061661_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5f4c554400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061654_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061620_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048270_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061637_)))))))));
    vlSelf->wasmetal_core__DOT___056639_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009842_)))))))));
    vlSelf->wasmetal_core__DOT___011936_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x55550f0f00ff0033ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010540_)))))))));
    vlSelf->wasmetal_core__DOT___012042_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009842_))))));
    vlSelf->wasmetal_core__DOT___010716_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                   ? 
                                                  (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h18547ac4__0))))
                                                   : 
                                                  (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009842_)))))));
    vlSelf->__VdfgTmp_ha7112868__0 = (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h3cc7dcfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010231_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h02606b30__0)));
    vlSelf->wasmetal_core__DOT___068032_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6dac888a__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))))))))))));
    vlSelf->wasmetal_core__DOT___002196_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6dac888a__0)))))));
    vlSelf->wasmetal_core__DOT___055999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055997_))));
    vlSelf->wasmetal_core__DOT___056005_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060758_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1b99479d__0))))))))))));
    vlSelf->wasmetal_core__DOT___062129_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___061448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019277_))));
    vlSelf->wasmetal_core__DOT___055874_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___055016_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055014_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->wasmetal_core__DOT___049530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049528_))));
    vlSelf->wasmetal_core__DOT___051614_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051613_))));
    vlSelf->wasmetal_core__DOT___050254_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050253_))));
    vlSelf->wasmetal_core__DOT___051301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050253_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050175_))));
    vlSelf->wasmetal_core__DOT___051303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050175_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050261_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050260_))));
    vlSelf->wasmetal_core__DOT___051309_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050138_))));
    vlSelf->wasmetal_core__DOT___050139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050275_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050164_))));
    vlSelf->wasmetal_core__DOT___050165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050164_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050277_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050153_))));
    vlSelf->wasmetal_core__DOT___050154_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050153_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051284_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050167_))));
    vlSelf->wasmetal_core__DOT___050168_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050142_))));
    vlSelf->wasmetal_core__DOT___050143_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050142_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___006633_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___006632_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022667_));
    vlSelf->wasmetal_core__DOT___068437_ = (1U & (IData)(
                                                         (0xcc000f000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf11U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9934c93f__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048729_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048730_)))))))));
    vlSelf->wasmetal_core__DOT___003054_ = (1U & ((1U 
                                                   & (0x10000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he03432df__0))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9934c93f__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h162766a7__0)))))));
    vlSelf->wasmetal_core__DOT___066293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002476_))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (0xfdfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___002479_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002478_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002476_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002475_)))))));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002115_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002114_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002113_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002112_))))))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002395_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002394_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002393_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002392_))))))));
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001678_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001677_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd9c0d0dd__0)))))));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001901_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001900_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001899_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001898_))))))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002243_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51461c8e__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002477_)));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002116_))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002396_))));
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001679_))));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001902_))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002244_))));
    }
    vlSelf->wasmetal_core__DOT___009520_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050848_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79a3c79a__0))));
    vlSelf->wasmetal_core__DOT___051582_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051346_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051581_))));
    vlSelf->wasmetal_core__DOT___067822_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb62f452d__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))))))))))));
    vlSelf->wasmetal_core__DOT___001250_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb62f452d__0)))));
    vlSelf->wasmetal_core__DOT___002719_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h22ba1a50__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hdf798121__0)))))));
    vlSelf->wasmetal_core__DOT___002076_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))))));
    vlSelf->wasmetal_core__DOT___068486_ = (1U & (IData)(
                                                         (0xf0ccf0f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___001807_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002068_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))))));
    vlSelf->__VdfgTmp_hf699b114__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha952ad99__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001854_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->__VdfgTmp_h912dcb78__0 = (((IData)(vlSelf->wasmetal_core__DOT___002894_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002893_));
    vlSelf->wasmetal_core__DOT___002516_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfd6c95b6__0)))))));
    vlSelf->wasmetal_core__DOT___002431_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5a517e30__0)))))));
    vlSelf->__VdfgTmp_h54bf9a7e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049815_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049814_))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (IData)(vlSelf->__VdfgTmp_h951148c2__0))));
    vlSelf->wasmetal_core__DOT___049926_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049382_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))));
    vlSelf->wasmetal_core__DOT___049383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049382_))));
    vlSelf->wasmetal_core__DOT___049898_ = (1U & (IData)(
                                                         (0x5555ccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049440_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h35851421__0)))));
    vlSelf->wasmetal_core__DOT___049765_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___051347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051346_))));
    vlSelf->wasmetal_core__DOT___051521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051520_))));
    vlSelf->wasmetal_core__DOT___051327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050692_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051326_))));
    vlSelf->wasmetal_core__DOT___051550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051549_))));
    vlSelf->wasmetal_core__DOT___051367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051366_))));
    vlSelf->__VdfgTmp_he7cac7a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011508_));
    vlSelf->wasmetal_core__DOT___056179_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010045_))))));
    vlSelf->wasmetal_core__DOT___002632_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002761_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002759_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002758_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_))))));
    vlSelf->wasmetal_core__DOT___002634_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002843_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002841_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002840_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002842_))))));
    vlSelf->wasmetal_core__DOT___002630_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002682_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002680_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002679_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002681_))))));
    vlSelf->wasmetal_core__DOT___002629_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002641_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002640_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002642_))))));
    vlSelf->wasmetal_core__DOT___053573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050448_))));
    vlSelf->wasmetal_core__DOT___050452_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050448_)))));
    vlSelf->wasmetal_core__DOT___063399_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063398_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063370_)))));
    vlSelf->wasmetal_core__DOT___063414_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053567_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))))))));
    vlSelf->wasmetal_core__DOT___053363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->wasmetal_core__DOT___053163_ = (1U & (0xb000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052906_))))));
    vlSelf->wasmetal_core__DOT___053440_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))));
    vlSelf->wasmetal_core__DOT___053248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___019787_ = (1U & (IData)(
                                                         (0x770f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)))))))))));
    vlSelf->wasmetal_core__DOT___019808_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((7U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052806_))));
    vlSelf->wasmetal_core__DOT___019809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071471_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))))));
    vlSelf->wasmetal_core__DOT___039935_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039878_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039883_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039882_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039881_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039880_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039871_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039879_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039876_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039875_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039874_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039873_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039884_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039885_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039886_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039893_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039909_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034643_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039898_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039897_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039896_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039895_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039877_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034649_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039894_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034650_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039891_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039890_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039889_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039888_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039899_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039900_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039901_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039908_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034659_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039924_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034660_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039913_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034661_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039912_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034662_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039911_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039910_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039892_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034665_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039887_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039906_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034667_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039905_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034668_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039904_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039903_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039914_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039915_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034673_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039916_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039923_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034675_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039940_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034676_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039928_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039927_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034678_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039926_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039925_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034681_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039907_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034682_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039902_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034683_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039921_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034684_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039920_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034685_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039919_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039918_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039929_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039930_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039931_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039939_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039955_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039944_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039943_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___039998_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039942_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039941_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039922_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039917_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039937_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039936_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039934_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039933_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039945_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039946_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039947_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039954_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039970_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039959_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039958_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039957_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039956_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039938_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039932_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039952_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039951_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039950_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039949_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039960_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039961_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039962_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039969_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039985_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039974_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039973_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039972_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039971_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039953_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039948_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039967_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039966_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039965_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039964_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039975_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039976_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039977_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039984_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___040001_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039989_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039988_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039987_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039986_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039968_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039963_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039982_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039981_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039980_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039979_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039990_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039991_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039992_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___040000_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___040015_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___040005_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___040004_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___040003_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___040002_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___040038_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___040037_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___040032_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___040031_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___040036_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___040035_ = (1U & (IData)(
                                                         (0xa2aea2a2a2a2a2a2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040034_ = (1U & (IData)(
                                                         (0xa2a2aeaeaea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040033_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___002636_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002925_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002923_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002922_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002924_))))));
    vlSelf->wasmetal_core__DOT___062185_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055935_))));
    vlSelf->wasmetal_core__DOT___061221_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061217_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061260_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061155_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061151_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061178_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061075_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061070_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060985_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060981_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061012_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060887_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060929_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060889_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060866_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___060852_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060807_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060779_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___060848_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060717_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69457925__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061322_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055935_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8562240__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061329_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061307_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061303_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___019282_ = ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                            & (IData)(
                                                      (0xfffefff0ff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xac00U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061332_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___055714_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055712_))));
    vlSelf->wasmetal_core__DOT___050493_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049867_))));
    vlSelf->wasmetal_core__DOT___049868_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049867_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051271_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050485_))));
    vlSelf->wasmetal_core__DOT___050487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049917_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049865_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049944_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___050484_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049924_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049921_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___055112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___061252_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055928_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf0027c26__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___002472_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002595_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002593_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002592_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_))))));
    vlSelf->wasmetal_core__DOT___061170_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055917_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___002193_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002318_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002316_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002315_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_))))));
    vlSelf->wasmetal_core__DOT___061088_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___055912_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055910_))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001382_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028868_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT____Vcellout___128077___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028490_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028489_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028488_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028487_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028454_)))));
    vlSelf->wasmetal_core__DOT___028458_ = ((IData)(vlSelf->wasmetal_core__DOT___028490_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->wasmetal_core__DOT___060999_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___060918_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055891_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061724_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055878_))));
    vlSelf->wasmetal_core__DOT___060833_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055878_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___049567_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049088_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049090_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049088_))));
    vlSelf->wasmetal_core__DOT___048979_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048977_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048977_))));
    vlSelf->wasmetal_core__DOT___062067_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062062_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae784e62__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007361_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061941_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28d1a2cd__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfcd73105__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062123_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062118_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d11eb70__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007387_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061877_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061873_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h98124bc4__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007275_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05777dd7__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061990_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb6cab41b__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07c00df2__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061801_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1697357__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1275c5a__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019200_))));
    vlSelf->wasmetal_core__DOT___049564_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049106_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049107_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049106_))));
    vlSelf->wasmetal_core__DOT___048970_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048966_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049254_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048966_))));
    vlSelf->wasmetal_core__DOT___055201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055196_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___049565_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049105_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049105_))));
    vlSelf->wasmetal_core__DOT___048971_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048969_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049255_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048969_))));
    vlSelf->wasmetal_core__DOT___049554_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049102_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049102_))));
    vlSelf->wasmetal_core__DOT___048996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048995_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049256_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048995_))));
    vlSelf->wasmetal_core__DOT___049555_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049101_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049101_))));
    vlSelf->wasmetal_core__DOT___048997_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048992_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049257_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048992_))));
    vlSelf->wasmetal_core__DOT___049552_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049201_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049201_))));
    vlSelf->wasmetal_core__DOT___048988_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048987_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048987_))));
    vlSelf->__VdfgTmp_h2f60644c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(vlSelf->__VdfgTmp_h826c8569__0))));
    vlSelf->wasmetal_core__DOT___036636_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)))))));
    vlSelf->wasmetal_core__DOT___036635_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))))));
    vlSelf->__VdfgTmp_h79b76beb__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))));
    vlSelf->wasmetal_core__DOT___049553_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049200_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049203_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049200_))));
    vlSelf->wasmetal_core__DOT___048989_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048984_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049306_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048984_))));
    vlSelf->wasmetal_core__DOT___049560_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049194_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049198_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049194_))));
    vlSelf->wasmetal_core__DOT___050506_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049303_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049301_))));
    vlSelf->wasmetal_core__DOT___049561_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049197_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049199_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049197_))));
    vlSelf->wasmetal_core__DOT___050507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049304_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049302_))));
    vlSelf->wasmetal_core__DOT___049558_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049184_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049188_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049184_))));
    vlSelf->wasmetal_core__DOT___050504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049295_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049297_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049295_))));
    vlSelf->wasmetal_core__DOT___049559_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049187_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049189_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049187_))));
    vlSelf->wasmetal_core__DOT___050505_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049296_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049298_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049296_))));
    vlSelf->wasmetal_core__DOT___049570_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049179_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049179_))));
    vlSelf->wasmetal_core__DOT___050512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049292_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049293_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049292_))));
    vlSelf->wasmetal_core__DOT___063849_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042451_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048377_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042199_)))))));
    vlSelf->wasmetal_core__DOT___063842_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042072_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042272_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048317_)))))));
    vlSelf->wasmetal_core__DOT___063839_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048367_)))));
    vlSelf->wasmetal_core__DOT___063847_ = (1U & (IData)(
                                                         (0x777ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))))));
    vlSelf->wasmetal_core__DOT___063845_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042391_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048371_))));
    vlSelf->wasmetal_core__DOT___063844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042212_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048363_))));
    vlSelf->wasmetal_core__DOT___049571_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049176_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049181_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049176_))));
    vlSelf->wasmetal_core__DOT___050513_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049291_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049294_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049291_))));
    vlSelf->wasmetal_core__DOT___059206_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051509_))));
    vlSelf->__VdfgTmp_h9e4ff193__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016296_));
    vlSelf->wasmetal_core__DOT___049573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049169_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049167_))));
    vlSelf->wasmetal_core__DOT___050511_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049315_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049318_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049315_))));
    vlSelf->wasmetal_core__DOT___063372_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063365_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063364_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063363_)))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028102_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 1U)));
    vlSelf->wasmetal_core__DOT___061929_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061919_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x555533330f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061912_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habef704b__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061916_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056447_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010182_)))));
    vlSelf->wasmetal_core__DOT___056931_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011658_)))));
    vlSelf->wasmetal_core__DOT___044906_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026480_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026447_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d));
    vlSelf->wasmetal_core__DOT___053498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053496_))));
    vlSelf->wasmetal_core__DOT___063366_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052843_))));
    vlSelf->__VdfgTmp_h554fca93__0 = ((2U & ((IData)(
                                                     (0x7770fff0fffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052844_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff40404000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___053019_))))))))));
    vlSelf->wasmetal_core__DOT___061868_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061849_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaacccc0f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061842_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd50fd36__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061846_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d87626c__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031046_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___050526_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050523_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050522_))));
    vlSelf->wasmetal_core__DOT___049658_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049284_))));
    vlSelf->wasmetal_core__DOT___053210_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->wasmetal_core__DOT___049624_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049073_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049084_))));
    vlSelf->wasmetal_core__DOT___053646_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051706_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___053652_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051719_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051526_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050828_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049044_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049041_))));
    vlSelf->wasmetal_core__DOT___050585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049024_))));
    vlSelf->wasmetal_core__DOT___051402_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050519_))));
    vlSelf->wasmetal_core__DOT___049689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049451_))));
    vlSelf->wasmetal_core__DOT___049454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049450_))));
    vlSelf->wasmetal_core__DOT___049285_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049283_))));
    vlSelf->wasmetal_core__DOT___050053_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___049364_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___051428_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___049493_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049490_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))));
    vlSelf->wasmetal_core__DOT___049706_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049490_))));
    vlSelf->wasmetal_core__DOT___049085_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049083_))));
    vlSelf->wasmetal_core__DOT___011182_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))));
    vlSelf->__VdfgTmp_hee8b18a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0));
    vlSelf->wasmetal_core__DOT___056920_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___010186_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___011973_));
    vlSelf->wasmetal_core__DOT___012990_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010513_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0)))))));
    vlSelf->wasmetal_core__DOT___056350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)) 
                                                           & (IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hfe9a1cba__0)))))))))));
    vlSelf->wasmetal_core__DOT___010197_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010206_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0))));
    vlSelf->wasmetal_core__DOT___062068_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062058_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062057_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___050521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050518_))));
    vlSelf->wasmetal_core__DOT___051401_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050518_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___049252_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049251_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                          << 1U))))));
}
