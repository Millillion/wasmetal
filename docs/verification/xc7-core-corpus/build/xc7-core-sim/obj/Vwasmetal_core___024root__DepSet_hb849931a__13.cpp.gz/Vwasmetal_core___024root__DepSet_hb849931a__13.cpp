#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__19(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__19\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___009831_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd544aedd__0))))));
    vlSelf->__VdfgTmp_h97dd8594__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd544aedd__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_he4fe919e__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h0549af28__0))))));
    vlSelf->__VdfgTmp_hab0a7d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_hda718c9e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)));
    vlSelf->__VdfgTmp_h16c112d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb67d963d__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d 
        = (1U & (0x1100f0U >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15c467ca__0)))));
    vlSelf->wasmetal_core__DOT___011906_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011537_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011519_)))))))));
    vlSelf->__VdfgTmp_hf6c0bd72__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011537_));
    vlSelf->wasmetal_core__DOT___011207_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010298_)))))))));
    vlSelf->__VdfgTmp_h493dc6bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___011992_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
    vlSelf->__VdfgTmp_hd5a37d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012029_));
    vlSelf->wasmetal_core__DOT___009833_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
    vlSelf->wasmetal_core__DOT___012717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010529_)))))))));
    vlSelf->wasmetal_core__DOT___056721_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))));
    vlSelf->wasmetal_core__DOT___055106_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT___056639_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009842_)))))))));
    vlSelf->wasmetal_core__DOT___011936_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x55550f0f00ff0033ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010540_)))))))));
    vlSelf->wasmetal_core__DOT___012042_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009842_))))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d))))));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___012039_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))))));
        vlSelf->wasmetal_core__DOT___056920_ = vlSelf->wasmetal_core__DOT___010186_;
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d))))));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d))))));
    } else {
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___011719_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012039_));
        vlSelf->wasmetal_core__DOT___056920_ = vlSelf->wasmetal_core__DOT___011973_;
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012042_));
    }
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___010716_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h18547ac4__0)))));
        vlSelf->wasmetal_core__DOT___056897_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d))))));
        vlSelf->wasmetal_core__DOT___010718_ = (1U 
                                                & (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010716_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009842_))))));
        vlSelf->wasmetal_core__DOT___056897_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0)))));
        vlSelf->wasmetal_core__DOT___010718_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_))))));
    }
    vlSelf->__VdfgTmp_ha7112868__0 = (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h499272d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010172_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(vlSelf->wasmetal_core__DOT___009806_)) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf00001111ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0)))))))))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010103_)));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010103_)));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
    } else {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010103_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb67d963d__0))))));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010152_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0))))));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010142_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h53247725__0))))));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (IData)(
                                                          (0x11100000fffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010173_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
    }
    vlSelf->wasmetal_core__DOT___011042_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009806_)))))))));
    vlSelf->__VdfgTmp_h3cc7dcfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010231_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h02606b30__0)));
    vlSelf->__VdfgTmp_hc16275c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0)));
    vlSelf->wasmetal_core__DOT___010750_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010761_)));
        vlSelf->wasmetal_core__DOT___011540_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010932_)));
        vlSelf->wasmetal_core__DOT___011528_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010992_)));
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010976_)));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010874_)));
        vlSelf->wasmetal_core__DOT___011530_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010918_)));
        vlSelf->wasmetal_core__DOT___010340_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___011658_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___010339_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011659_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010958_)));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010989_)));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010983_)));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0)));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010999_)));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010546_)));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010735_)));
        vlSelf->wasmetal_core__DOT___011538_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010911_)));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010584_)));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
        vlSelf->wasmetal_core__DOT___011539_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010939_)));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010749_)));
    } else {
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_he4fe919e__0))));
        if (vlSelf->wasmetal_core__DOT___007693_) {
            vlSelf->wasmetal_core__DOT___011540_ = 
                (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0))));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xff35U >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h7edccd87__0)));
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_hc43f9106__0)));
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h9c968075__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011540_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h00532677__0))));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xdU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010231_))));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010253_)))));
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010272_)))));
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010281_)))));
        }
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0))))));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h034bd5a0__0)))));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h1d2a78cf__0)))));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haef445c6__0)))));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1841993__0)));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd610ba85__0)))));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0))))));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0))));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7fb5afda__0))));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc09bd195__0))));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011122_)));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h97dd8594__0))));
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h16c112d2__0))));
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
    }
    vlSelf->wasmetal_core__DOT___009651_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0))))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0xf0f0305U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))))));
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he6780703__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h00532677__0))))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010231_))))));
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009651_))))));
    }
    vlSelf->wasmetal_core__DOT___071983_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012123_)))));
    vlSelf->wasmetal_core__DOT___013047_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012123_))))));
    vlSelf->__VdfgTmp_h7b0cb704__0 = (((IData)(vlSelf->wasmetal_core__DOT___012124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012123_));
    vlSelf->__VdfgTmp_hfe9a1cba__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054855_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054854_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054853_)))))));
    vlSelf->wasmetal_core__DOT___055122_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011520_))));
    vlSelf->wasmetal_core__DOT___056312_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc9e45bda__0)))))));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030121_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030281_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036898_)
            ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036635_));
    vlSelf->wasmetal_core__DOT___067352_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067335_)))));
    vlSelf->wasmetal_core__DOT___067322_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067305_)))));
    vlSelf->wasmetal_core__DOT___053633_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051321_))));
    vlSelf->wasmetal_core__DOT___053220_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053216_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053215_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051833_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))))));
    vlSelf->wasmetal_core__DOT___050657_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049387_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h444aee6e__0)))))));
    vlSelf->wasmetal_core__DOT___053121_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053117_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049859_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049387_))))))));
    vlSelf->wasmetal_core__DOT___051369_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050861_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051368_)))));
    vlSelf->wasmetal_core__DOT___051616_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051615_)))));
    vlSelf->wasmetal_core__DOT___051330_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051329_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051328_)))));
    vlSelf->wasmetal_core__DOT___051552_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050870_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051551_)))));
    vlSelf->wasmetal_core__DOT___051349_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051348_)))));
    vlSelf->__VdfgTmp_h6780f3af__0 = (((IData)(vlSelf->wasmetal_core__DOT___050820_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051522_));
    vlSelf->wasmetal_core__DOT___051291_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050997_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051290_)))));
    vlSelf->wasmetal_core__DOT___051063_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049209_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051060_)))));
    vlSelf->wasmetal_core__DOT___051048_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049326_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051045_)))));
    vlSelf->wasmetal_core__DOT___050067_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049522_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050065_)))));
    vlSelf->wasmetal_core__DOT___051104_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049476_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051101_)))));
    vlSelf->wasmetal_core__DOT___055082_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x5cU 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((0xf0f5533U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___050629_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053117_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049861_))))))));
    vlSelf->wasmetal_core__DOT___009508_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049861_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049860_))))))));
    vlSelf->wasmetal_core__DOT___049524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049508_)))));
    vlSelf->wasmetal_core__DOT___051117_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051115_)))));
    vlSelf->wasmetal_core__DOT___051765_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051116_)))));
    vlSelf->wasmetal_core__DOT___049808_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049802_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049801_)))));
    vlSelf->wasmetal_core__DOT___051709_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049806_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049802_)))));
    vlSelf->wasmetal_core__DOT___050864_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050862_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050861_)))));
    vlSelf->wasmetal_core__DOT___051370_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050862_)))));
    vlSelf->wasmetal_core__DOT___051655_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009538_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051647_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051646_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049710_))))))));
    vlSelf->wasmetal_core__DOT___009537_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049717_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049710_)))));
    vlSelf->wasmetal_core__DOT___049718_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049709_)))));
    vlSelf->wasmetal_core__DOT___051796_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051329_)))));
    vlSelf->wasmetal_core__DOT___050641_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049716_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050635_)))));
    vlSelf->wasmetal_core__DOT___052612_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___050873_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050870_)))));
    vlSelf->wasmetal_core__DOT___051743_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050702_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050698_)))));
    vlSelf->wasmetal_core__DOT___050704_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050698_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050697_)))));
    vlSelf->wasmetal_core__DOT___049895_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049890_)))));
    vlSelf->wasmetal_core__DOT___051722_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049894_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049891_)))));
    vlSelf->wasmetal_core__DOT___053657_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050821_)))));
    vlSelf->wasmetal_core__DOT___050823_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050820_)))));
    vlSelf->wasmetal_core__DOT___051781_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050997_)))));
    vlSelf->wasmetal_core__DOT___050981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049634_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050979_)))));
    vlSelf->wasmetal_core__DOT___049636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049628_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049627_)))));
    vlSelf->wasmetal_core__DOT___051634_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049628_)))));
    vlSelf->wasmetal_core__DOT___049760_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049753_)))));
    vlSelf->wasmetal_core__DOT___051693_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049754_)))));
    vlSelf->wasmetal_core__DOT___050804_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050802_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050801_)))));
    vlSelf->wasmetal_core__DOT___051350_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050803_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050802_)))));
    vlSelf->wasmetal_core__DOT___067403_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053116_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___051587_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049210_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049148_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051583_))))))));
    vlSelf->wasmetal_core__DOT___049211_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049148_)))));
    vlSelf->wasmetal_core__DOT___051062_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051058_)))));
    vlSelf->wasmetal_core__DOT___051753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051059_)))));
    vlSelf->wasmetal_core__DOT___055081_ = (1U & (IData)(
                                                         (0x7fff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff00f0f01111ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051895_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_))))) 
                                                                                << 2U)) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___050632_) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051485_))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))));
    vlSelf->wasmetal_core__DOT___053387_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053373_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050877_))))))))))));
    vlSelf->wasmetal_core__DOT___065172_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x3fff20003fff3fffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065166_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051841_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xfdf0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065165_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065164_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0fff4400000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051468_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051467_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051466_)))))))))))))));
    vlSelf->wasmetal_core__DOT___065400_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___051992_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051991_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052000_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051999_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___051012_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050632_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050637_))))))));
    vlSelf->wasmetal_core__DOT___065506_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x30f0200030f030fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052623_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049578_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049577_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049576_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050542_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050899_))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051782_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051789_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052629_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052628_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049665_))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065049_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050554_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050550_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049545_))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050548_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050514_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050530_))))))))))))))));
    vlSelf->wasmetal_core__DOT___051900_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xff00ff0f0f1111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050514_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050631_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051895_)))))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051898_))))))));
    vlSelf->wasmetal_core__DOT___051437_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051420_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051419_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051418_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))));
    vlSelf->wasmetal_core__DOT___066798_ = (1U & (IData)(
                                                         (0x45cf454545454545ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051051_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051418_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf7f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 5U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 4U))))))))))))))));
    vlSelf->wasmetal_core__DOT___051641_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->__VdfgTmp_h36c85254__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049686_) 
                                          << 1U) | 
                                         (1U & (1U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049690_)))));
    vlSelf->wasmetal_core__DOT___049772_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049686_)))));
    vlSelf->wasmetal_core__DOT___050719_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050713_))));
    vlSelf->__VdfgTmp_h07886821__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (4U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050717_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050713_)));
    vlSelf->__VdfgTmp_hd604be0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050876_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051544_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050876_)))));
    vlSelf->__VdfgTmp_h32fdaf9b__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (8U 
                                                >> 
                                                (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049781_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049777_)));
    vlSelf->wasmetal_core__DOT___051359_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050814_)))));
    vlSelf->__VdfgTmp_hc485c507__0 = (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051101_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051100_))))));
    vlSelf->__VdfgTmp_h8235f0ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049478_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051605_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049478_)))));
    vlSelf->__VdfgTmp_ha03a7afa__0 = ((2U & ((0xacU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051696_));
    vlSelf->__VdfgTmp_h45934da4__0 = (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050807_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___049731_)))));
    vlSelf->wasmetal_core__DOT___051339_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050807_)))));
    vlSelf->__VdfgTmp_hd506ed16__0 = (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051045_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051044_))))));
    vlSelf->wasmetal_core__DOT___051574_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049290_)))));
    vlSelf->__VdfgTmp_hd9ae5f1a__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050784_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051295_)));
    vlSelf->wasmetal_core__DOT___051297_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050784_)))));
    vlSelf->__VdfgTmp_h0f76403b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049667_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051623_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049667_)))));
    vlSelf->wasmetal_core__DOT___051729_ = (1U & (0xf0faaccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049871_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xcaU 
                                                              >> 
                                                              ((2U 
                                                                & ((0xf0faaccU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___049308_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf18161ea__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xccccf0f0ff00aaaaULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049294_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049293_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049317_))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xa3U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___049662_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (0xaacc0f0fU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___049258_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h32efca0f__0))))))))))));
    vlSelf->wasmetal_core__DOT___053724_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049874_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049871_))))));
    vlSelf->wasmetal_core__DOT___051513_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050834_)))));
    vlSelf->wasmetal_core__DOT___065733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065729_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065725_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x20003fff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052738_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050808_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0553300000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051591_))))))))))))));
    vlSelf->wasmetal_core__DOT___065832_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065828_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((4U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050637_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050601_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x7f7f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065823_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20003fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065824_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050812_)))))))))))))))));
    vlSelf->__VdfgTmp_h6383fd4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050814_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049775_))))))));
    vlSelf->__VdfgTmp_h0a242e26__0 = (((IData)(vlSelf->wasmetal_core__DOT___050837_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050834_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049869_))))))));
    vlSelf->wasmetal_core__DOT___066110_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->__VdfgTmp_h0de2f8d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049290_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066210_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff55ccf0U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051995_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2966b870__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x30f0200030f030fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053628_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xa300U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f5533U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050060_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049538_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051867_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xbfff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054849_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049479_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___009499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049637_))));
    vlSelf->wasmetal_core__DOT___009509_ = (1U & (IData)(
                                                         (0xa0f00ff00ff33ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((8U 
                                                                      >> 
                                                                      ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049719_))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049833_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049720_)))))))))));
    vlSelf->__VdfgTmp_hc669ea30__0 = (((IData)(vlSelf->wasmetal_core__DOT___049694_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->wasmetal_core__DOT___055414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049761_))));
    vlSelf->__VdfgTmp_hae9934f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___049740_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))));
    vlSelf->wasmetal_core__DOT___053729_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x550f3300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050895_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___049809_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0880000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)))))))))));
    vlSelf->__VdfgTmp_hc6a436e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049784_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049777_)))));
    vlSelf->wasmetal_core__DOT___066627_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049896_))));
    vlSelf->__VdfgTmp_h2cfc9ba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049877_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049871_)))));
    vlSelf->wasmetal_core__DOT___066713_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050705_))));
    vlSelf->wasmetal_core__DOT___053531_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050720_))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___019019_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016504_))));
    vlSelf->wasmetal_core__DOT___019074_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___070488_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063439_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044240_))))));
    vlSelf->wasmetal_core__DOT___050400_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___051217_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047994_))))));
    vlSelf->wasmetal_core__DOT___052659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___050359_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___048133_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048116_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048115_))));
    vlSelf->wasmetal_core__DOT___017194_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048661_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))));
    vlSelf->wasmetal_core__DOT___048002_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT___019197_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048666_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001168_))))));
    vlSelf->wasmetal_core__DOT___048714_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048651_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001146_))))));
    vlSelf->wasmetal_core__DOT___048712_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048656_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001124_))))));
    vlSelf->wasmetal_core__DOT___048717_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048602_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001102_))))));
    vlSelf->wasmetal_core__DOT___048728_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048597_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001080_))))));
    vlSelf->wasmetal_core__DOT___048711_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048614_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001058_))))));
    vlSelf->wasmetal_core__DOT___048713_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048609_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001036_))))));
    vlSelf->wasmetal_core__DOT___048727_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048626_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001014_))))));
    vlSelf->wasmetal_core__DOT___048726_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000992_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000992_))))));
    vlSelf->wasmetal_core__DOT___048725_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000980_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000980_))))));
    vlSelf->wasmetal_core__DOT___048718_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001327_))))));
    vlSelf->wasmetal_core__DOT___005430_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT___048206_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT___048167_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___048209_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT___048165_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___005431_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT___005432_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___048149_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT___048050_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->wasmetal_core__DOT___048063_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->wasmetal_core__DOT___048052_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->wasmetal_core__DOT___001800_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___001801_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___001802_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___001803_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005731_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b0__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003135_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003134_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003133_)))))))));
    vlSelf->wasmetal_core__DOT___005928_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h47317805__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b1__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003221_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h534a5d27__0)))))));
    vlSelf->wasmetal_core__DOT___000146_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___000147_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005716_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h989e4977__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b2__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004771_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd09f2908__0)))))));
    vlSelf->wasmetal_core__DOT___000148_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___002190_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005935_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b3__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004697_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfcbc0180__0)))))));
    vlSelf->wasmetal_core__DOT___002470_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___048791_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___002636_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002925_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002923_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002922_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002924_))))));
    vlSelf->wasmetal_core__DOT___005738_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b4__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004475_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h627c070d__0)))))));
    vlSelf->wasmetal_core__DOT___002629_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002641_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002640_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002642_))))));
    vlSelf->wasmetal_core__DOT___002630_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002682_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002680_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002679_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002681_))))));
    vlSelf->wasmetal_core__DOT___048792_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___002633_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002801_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002799_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002798_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_))))));
    vlSelf->wasmetal_core__DOT___002634_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002843_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002841_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002840_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002842_))))));
    vlSelf->wasmetal_core__DOT___048790_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005921_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b5__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004327_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h4ff79496__0)))))));
    vlSelf->wasmetal_core__DOT___002631_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002721_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002718_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_))))));
    vlSelf->wasmetal_core__DOT___002632_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002761_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002759_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002758_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_))))));
    vlSelf->wasmetal_core__DOT___013805_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003056_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003054_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003053_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003055_))))));
    vlSelf->wasmetal_core__DOT___002635_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002885_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002883_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002882_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_))))));
    vlSelf->wasmetal_core__DOT___002032_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013770_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048908_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___013771_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048910_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___048917_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___048914_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___002033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___005745_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b6__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004401_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3bba44d5__0)))))));
    vlSelf->wasmetal_core__DOT___013797_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047800_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___013796_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048907_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047809_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___002034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013788_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047827_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___013785_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048905_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047819_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___013787_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047879_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___002469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013786_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___013740_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048897_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047905_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___002031_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013737_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048894_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___005875_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b7__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004549_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb5c2181f__0)))))));
    vlSelf->wasmetal_core__DOT___002191_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___048900_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013738_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___002192_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013918_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047857_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___014037_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047867_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___013780_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048918_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___000145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___013778_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048921_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047933_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___048903_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___048920_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___006092_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b8__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003733_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hbe250e1d__0)))))));
    vlSelf->wasmetal_core__DOT___002193_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002318_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002316_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002315_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_))))));
    vlSelf->wasmetal_core__DOT___005868_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b23__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005117_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc2abfe6d__0)))))));
    vlSelf->wasmetal_core__DOT___002472_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002595_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002593_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002592_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_))))));
    vlSelf->wasmetal_core__DOT___006106_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b24__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005049_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h04914456__0)))))));
    vlSelf->wasmetal_core__DOT___002473_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002556_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002554_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002553_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_))))));
    vlSelf->wasmetal_core__DOT___006022_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b25__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005321_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hea3adbd3__0)))))));
    vlSelf->wasmetal_core__DOT___006015_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b9__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003585_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h74bfec90__0)))))));
    vlSelf->wasmetal_core__DOT___006099_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b26__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0)))))));
    vlSelf->wasmetal_core__DOT___005989_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b27__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004981_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6305c07b__0)))))));
    vlSelf->wasmetal_core__DOT___006171_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b28__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0)))))));
    vlSelf->wasmetal_core__DOT___006085_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4172973d__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b10__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003437_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d126061__0)))))));
    vlSelf->wasmetal_core__DOT___006144_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b29__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0)))))));
    vlSelf->wasmetal_core__DOT___005711_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff1fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005572_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005571_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h92d236ac__0))))))));
    vlSelf->wasmetal_core__DOT___006215_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b30__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0)))))));
    vlSelf->wasmetal_core__DOT___005982_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b11__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003511_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h07f42939__0)))))));
    vlSelf->wasmetal_core__DOT___005795_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b32__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005554_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005553_))))))))));
    vlSelf->wasmetal_core__DOT___005653_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->wasmetal_core__DOT___003809_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b12__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004105_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1f83dfd6__0)))))));
    vlSelf->wasmetal_core__DOT___005788_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b34__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005660_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005659_))))))))));
    vlSelf->wasmetal_core__DOT___005955_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b35__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005648_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005647_))))))))));
    vlSelf->wasmetal_core__DOT___003810_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b13__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004179_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1f7a3fb7__0)))))));
    vlSelf->wasmetal_core__DOT___005802_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b36__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005558_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005557_))))))))));
    vlSelf->wasmetal_core__DOT___006204_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b14__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004623_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcbae1cfc__0)))))));
    vlSelf->wasmetal_core__DOT___005882_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b37__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005542_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005541_))))))))));
    vlSelf->wasmetal_core__DOT___005809_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b38__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005550_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005549_))))))))));
    vlSelf->wasmetal_core__DOT___005948_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b39__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005566_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005565_))))))))));
    vlSelf->wasmetal_core__DOT___006400_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b15__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003659_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_had67ef57__0)))))));
    vlSelf->wasmetal_core__DOT___006051_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b40__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005534_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005533_))))))))));
    vlSelf->wasmetal_core__DOT___006029_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b41__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005530_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005529_))))))))));
    vlSelf->wasmetal_core__DOT___003807_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b16__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003957_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2852ec0c__0)))))));
    vlSelf->wasmetal_core__DOT___006044_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b42__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005505_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005504_))))))))));
    vlSelf->wasmetal_core__DOT___006058_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b43__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005509_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005508_))))))))));
    vlSelf->wasmetal_core__DOT___003811_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b17__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004253_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1fced7c0__0)))))));
    vlSelf->wasmetal_core__DOT___006178_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b44__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005518_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005517_))))))))));
    vlSelf->wasmetal_core__DOT___006151_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b45__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005562_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005561_))))))))));
    vlSelf->wasmetal_core__DOT___003808_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h95830544__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b18__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004031_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d95a729__0)))))));
    vlSelf->wasmetal_core__DOT___006226_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b46__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005522_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005521_))))))))));
    vlSelf->wasmetal_core__DOT___006274_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hac359f24__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b47__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005526_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005525_))))))))));
    vlSelf->wasmetal_core__DOT___003805_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b19__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003815_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he16d2f4f__0)))))));
    vlSelf->wasmetal_core__DOT___005823_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b48__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005656_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005655_))))))))));
    vlSelf->wasmetal_core__DOT___005903_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b49__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005537_))))))))));
    vlSelf->wasmetal_core__DOT___005514_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->wasmetal_core__DOT___005816_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b50__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005546_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005545_))))))))));
    vlSelf->wasmetal_core__DOT___003806_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8476215a__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b20__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0)))))));
    vlSelf->wasmetal_core__DOT___005855_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b21__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0)))))));
    vlSelf->wasmetal_core__DOT___005770_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b22__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0)))))));
    vlSelf->wasmetal_core__DOT___072273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062496_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053488_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072270_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051199_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052895_)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053487_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___007871_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048394_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h508bc82d__0))))))));
    vlSelf->wasmetal_core__DOT___016506_ = (1U & (0xfe3fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))));
    vlSelf->wasmetal_core__DOT___048960_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___058930_ = (1U & (0x6000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))));
    vlSelf->wasmetal_core__DOT___048129_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___060571_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))));
    vlSelf->wasmetal_core__DOT___017174_ = (1U & (IData)(
                                                         (0xc0f01f0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032034_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026482_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036759_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036726_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___063123_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063120_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063119_)))))));
    vlSelf->wasmetal_core__DOT___063129_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063126_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063125_)))))));
    vlSelf->wasmetal_core__DOT___063135_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063131_)))))));
    vlSelf->wasmetal_core__DOT___063141_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063138_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063137_)))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028316_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028251_));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026590_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001476_));
    vlSelf->wasmetal_core__DOT___052848_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052702_))));
    vlSelf->wasmetal_core__DOT___053587_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052701_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052650_)))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128641___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034320_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034319_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034318_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034317_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034379_)))));
    vlSelf->wasmetal_core__DOT___034384_ = ((IData)(vlSelf->wasmetal_core__DOT___034320_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128657___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034540_)))));
    vlSelf->wasmetal_core__DOT___034545_ = ((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027469_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b5__05d));
    vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x12U) & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x40000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x12U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032873_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032840_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___062749_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xcU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))));
    vlSelf->wasmetal_core__DOT___062760_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xdU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062752_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062771_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xeU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062763_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062782_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xfU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062774_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027808_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027775_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d));
    vlSelf->wasmetal_core__DOT___065945_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065939_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065937_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066090_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066082_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066129_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066126_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066125_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066124_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x12U) & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028095_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0xdU)));
    vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x12U)) & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___070643_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O))))));
    vlSelf->wasmetal_core__DOT___070646_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032681_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032648_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037191_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037159_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0))));
    vlSelf->wasmetal_core__DOT___054503_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054505_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054507_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063551_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063559_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063567_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063575_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___054501_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127837___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->__VdfgTmp_hd4f12848__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                    << 4U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O)))))))));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026331_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128403___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031960_)))));
    vlSelf->wasmetal_core__DOT___031964_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029502_));
    vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030718_));
    vlSelf->wasmetal_core__DOT____Vcellinp___134231___B 
        = ((0x38000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039366_))) 
                        << 0xfU)) | ((0x4000U & ((0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                 << 0xeU)) 
                                     | ((0x2000U & 
                                         ((0xf8U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                          << 0xdU)) 
                                        | ((0x1000U 
                                            & ((0xf8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                               << 0xcU)) 
                                           | ((0x800U 
                                               & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xbU)) 
                                              | ((0x400U 
                                                  & ((0xf8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                     << 0xaU)) 
                                                 | ((0x200U 
                                                     & ((0xf8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                        << 9U)) 
                                                    | ((0x100U 
                                                        & ((0xf8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                           << 8U)) 
                                                       | ((0x80U 
                                                           & ((0xf8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                              << 7U)) 
                                                          | ((0x40U 
                                                              & ((0xf8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                 << 6U)) 
                                                             | ((0x20U 
                                                                 & ((0xf8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                    << 5U)) 
                                                                | ((0x10U 
                                                                    & ((0xf8U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                       << 4U)) 
                                                                   | ((8U 
                                                                       & ((0xf8U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & ((0xf8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((0xf8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                                                << 1U)) 
                                                                            | (1U 
                                                                               & (0xf8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134230___B 
        = ((0x10000U & ((0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                    << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                        << 0x10U)) | ((0x8000U & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___039366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054746_)))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((0xfffff888U 
                                            >> (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((0xfffff888U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___001536_)))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((0xfffff888U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001524_)))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((0xfffff888U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___001425_)))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((0xfffff888U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((0xfffff888U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001381_)))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((0xfffff888U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001369_)))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xfffff888U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055712_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___001487_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xf888fffff888f888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055606_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055558_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055467_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054746_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056530_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h394cead1__0))));
    vlSelf->__VdfgTmp_h0812d53d__0 = ((0x10U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                << 4U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h394cead1__0));
    vlSelf->wasmetal_core__DOT___056543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011976_))));
    vlSelf->wasmetal_core__DOT___057497_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___057531_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___057376_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___057235_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))));
    vlSelf->wasmetal_core__DOT___057005_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))));
    vlSelf->wasmetal_core__DOT___057083_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfcd73105__0))))));
    vlSelf->wasmetal_core__DOT___056766_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___056823_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___056542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054675_)))));
    vlSelf->wasmetal_core__DOT___056419_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91a424ff__0))))));
    vlSelf->wasmetal_core__DOT___056539_ = (1U & (0x5f3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007431_)))))));
    vlSelf->wasmetal_core__DOT___057675_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___056437_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011603_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011997_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010166_));
    vlSelf->wasmetal_core__DOT___011119_ = (1U & (IData)(
                                                         (0xffffff11fffffff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))));
    vlSelf->__VdfgTmp_hca8ac9e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_hb25114eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012131_));
    vlSelf->wasmetal_core__DOT___011898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8472195__0))));
    vlSelf->wasmetal_core__DOT___010219_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010254_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7edccd87__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010252_))))))));
    vlSelf->wasmetal_core__DOT___011900_ = (1U & (IData)(
                                                         (0x33335555f0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011513_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011503_)))))))));
    vlSelf->wasmetal_core__DOT___054892_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033390_)))))))));
    if (vlSelf->wasmetal_core__DOT___010312_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
    }
    vlSelf->__VdfgTmp_h362b458b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009653_));
    vlSelf->wasmetal_core__DOT___055063_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010044_)))))))));
    vlSelf->__VdfgTmp_ha569c0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010044_));
    vlSelf->__VdfgTmp_ha5884336__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012124_));
    vlSelf->__VdfgTmp_hbc86843d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___055251_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->__VdfgTmp_he7cac7a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011508_));
    vlSelf->wasmetal_core__DOT___056179_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010045_))))));
    vlSelf->__VdfgTmp_h658ce6a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0));
    vlSelf->wasmetal_core__DOT___010187_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))));
    vlSelf->wasmetal_core__DOT___057066_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0))))))));
    vlSelf->__VdfgTmp_hbe17c4c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0)));
    vlSelf->__VdfgTmp_h00b060af__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0)));
    vlSelf->wasmetal_core__DOT___012177_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0))))))));
    vlSelf->wasmetal_core__DOT___056433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3820fb89__0))));
    vlSelf->__VdfgTmp_hb9280dfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h53247725__0));
    if (vlSelf->wasmetal_core__DOT___010323_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
    }
    vlSelf->__VdfgTmp_had4ae229__0 = ((2U & ((IData)(
                                                     (0xf0f0000aaccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xbU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff4f400000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056308_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))));
    vlSelf->wasmetal_core__DOT___071992_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xccccaaaaf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056324_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xccccaaaaf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))))))));
    vlSelf->wasmetal_core__DOT___012719_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))));
    vlSelf->wasmetal_core__DOT___056723_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->wasmetal_core__DOT___011919_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff003355550f0fULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->wasmetal_core__DOT___011182_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))));
    vlSelf->__VdfgTmp_hee8b18a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0));
    vlSelf->wasmetal_core__DOT___011197_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d))))));
    vlSelf->__VdfgTmp_ha8f305c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056379_));
    vlSelf->wasmetal_core__DOT___056284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___057011_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___056205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056196_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___056925_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)))))))));
    vlSelf->__VdfgTmp_h2994a26e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                               ? (0x305U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf1841993__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                         & (IData)(
                                                   (0x333355550f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0)))));
    vlSelf->__VdfgTmp_h7e112ed5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___056380_))));
    vlSelf->wasmetal_core__DOT___056829_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)))))))));
    vlSelf->__VdfgTmp_h0931b472__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___011198_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010194_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0))));
    vlSelf->wasmetal_core__DOT___056616_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011503_))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___010374_))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a02124a__0))))))));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010045_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6af19a3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0));
    vlSelf->wasmetal_core__DOT___056594_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011115_)));
    if (vlSelf->wasmetal_core__DOT___008974_) {
        vlSelf->wasmetal_core__DOT___010161_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010159_)));
        vlSelf->wasmetal_core__DOT___010209_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010208_)));
    } else {
        vlSelf->wasmetal_core__DOT___010161_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010159_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0)))))));
        vlSelf->wasmetal_core__DOT___010209_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010208_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0)))))));
    }
    vlSelf->wasmetal_core__DOT___010972_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
    vlSelf->__VdfgTmp_h6748fbc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010241_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010241_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb5f0d294__0))))))));
    vlSelf->wasmetal_core__DOT___057557_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010414_)))))))));
    vlSelf->wasmetal_core__DOT___012990_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010513_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0)))))));
    vlSelf->__VdfgTmp_hcef50cee__0 = (((IData)(vlSelf->wasmetal_core__DOT___012131_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013095_));
    vlSelf->wasmetal_core__DOT___011701_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___010166_)) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010197_)))));
    vlSelf->wasmetal_core__DOT___057049_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012043_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7fb5afda__0)))));
    vlSelf->wasmetal_core__DOT___010261_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010273_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc43f9106__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010271_))))))));
    vlSelf->wasmetal_core__DOT___012991_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010500_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc09bd195__0)))))));
    vlSelf->__VdfgTmp_ha4e3e772__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)));
    vlSelf->wasmetal_core__DOT___056500_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011122_)));
    vlSelf->wasmetal_core__DOT___011020_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0)))));
    vlSelf->wasmetal_core__DOT___010770_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0))))));
    vlSelf->__VdfgTmp_h39adae05__0 = (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0));
    vlSelf->__VdfgTmp_hffef1e62__0 = (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010280_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010278_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010279_)))))))));
    vlSelf->wasmetal_core__DOT___012028_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010495_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h97dd8594__0)))))));
    vlSelf->wasmetal_core__DOT___056898_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056327_)))))))));
    vlSelf->wasmetal_core__DOT___056178_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d))));
    vlSelf->__VdfgTmp_ha620249b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0));
    vlSelf->wasmetal_core__DOT___056277_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012293_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h16c112d2__0)))));
    vlSelf->__VdfgTmp_haddc65cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___011906_)) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfaf3f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                            ? 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (2U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011522_)))
                                                                            : 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011518_))))))))));
    vlSelf->__VdfgTmp_h06746976__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0));
    vlSelf->__VdfgTmp_hf037ddb3__0 = ((2U & ((IData)(
                                                     (0xf0faacc00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0))))
                                                : (0xa03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))))));
    vlSelf->wasmetal_core__DOT___011772_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010259_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)))))));
    vlSelf->__VdfgTmp_h1055e951__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056368_)));
    vlSelf->__VdfgTmp_h4a9b748c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011992_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___056636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))));
    vlSelf->wasmetal_core__DOT___011921_ = (1U & (IData)(
                                                         (0xbbf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->__VdfgTmp_hba8ce1a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0)));
    vlSelf->__VdfgTmp_h9c39d480__0 = (((IData)(vlSelf->wasmetal_core__DOT___010715_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010716_));
    vlSelf->wasmetal_core__DOT___010727_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010715_))));
    vlSelf->wasmetal_core__DOT___011857_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
    vlSelf->__VdfgTmp_h88263545__0 = (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___055200_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT___055271_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc16275c3__0))));
    vlSelf->__VdfgTmp_h2133c371__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc16275c3__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009651_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he6780703__0))))))));
    vlSelf->wasmetal_core__DOT___057540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010722_))));
    vlSelf->wasmetal_core__DOT___011924_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0)))));
    vlSelf->__VdfgTmp_h99697672__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0));
    vlSelf->wasmetal_core__DOT___056350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)) 
                                                           & (IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hfe9a1cba__0)))))))))));
    vlSelf->wasmetal_core__DOT___012184_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056375_)))))))));
    vlSelf->__VdfgTmp_h375c9c07__0 = (((IData)(vlSelf->wasmetal_core__DOT___056376_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056375_));
    vlSelf->wasmetal_core__DOT___010391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x333355550f0f00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057024_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___011728_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d))))));
    vlSelf->__VdfgTmp_heb18a766__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d));
    vlSelf->wasmetal_core__DOT___056919_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___011194_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))));
    vlSelf->__VdfgTmp_h51371d7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011867_));
    vlSelf->wasmetal_core__DOT___055126_ = (1U & (IData)(
                                                         (0xffff000000fe0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055118_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054758_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054760_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054759_))))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1111000f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf800U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055122_))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128232___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030122_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030121_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030120_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030119_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030086_)))));
    vlSelf->wasmetal_core__DOT___030090_ = ((IData)(vlSelf->wasmetal_core__DOT___030122_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128246___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030282_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030281_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030276_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030265_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030190_)))));
    vlSelf->wasmetal_core__DOT___030218_ = ((IData)(vlSelf->wasmetal_core__DOT___030282_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036899_)
            ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036636_));
    vlSelf->wasmetal_core__DOT___065922_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053220_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053219_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff80ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053206_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050837_))))))))))));
    vlSelf->wasmetal_core__DOT___053129_ = (1U & (IData)(
                                                         (0x7f7f7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053121_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053120_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))));
    vlSelf->wasmetal_core__DOT___051619_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049523_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049509_))))));
    vlSelf->wasmetal_core__DOT___051554_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050872_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050871_))))));
    vlSelf->wasmetal_core__DOT___051527_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))));
    vlSelf->__VdfgTmp_h34f15f45__0 = (((IData)(vlSelf->wasmetal_core__DOT___051048_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051044_)))));
    vlSelf->wasmetal_core__DOT___066876_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051104_))));
    vlSelf->__VdfgTmp_ha2491a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___051104_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051100_)))));
    vlSelf->wasmetal_core__DOT___051873_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051867_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051866_)))))));
    vlSelf->wasmetal_core__DOT___049540_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049523_))))));
    vlSelf->wasmetal_core__DOT___051119_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051117_)))));
    vlSelf->wasmetal_core__DOT___051776_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051765_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051764_)))))));
    vlSelf->wasmetal_core__DOT___053810_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051765_)))));
    vlSelf->wasmetal_core__DOT___049821_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049808_)))));
    vlSelf->wasmetal_core__DOT___051716_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051709_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051708_)))))));
    vlSelf->wasmetal_core__DOT___053712_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051709_)))));
    vlSelf->wasmetal_core__DOT___051823_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050864_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051817_)))))));
    vlSelf->wasmetal_core__DOT___051660_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050864_)))));
    vlSelf->wasmetal_core__DOT___051373_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051369_)))));
    vlSelf->wasmetal_core__DOT___053702_ = (1U & ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))
                                                   ? 
                                                  (0x800faffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009538_))))))
                                                   : 
                                                  (0x400055ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009537_))))))));
    vlSelf->wasmetal_core__DOT___049723_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049718_)))));
    vlSelf->wasmetal_core__DOT___051801_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051796_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051795_)))))));
    vlSelf->wasmetal_core__DOT___053820_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051796_)))));
    vlSelf->wasmetal_core__DOT___051332_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051330_)))));
    vlSelf->wasmetal_core__DOT___051854_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050873_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051849_)))))));
    vlSelf->wasmetal_core__DOT___050880_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050873_)))));
    vlSelf->wasmetal_core__DOT___051748_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051743_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051742_)))))));
    vlSelf->wasmetal_core__DOT___053798_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051743_)))));
    vlSelf->wasmetal_core__DOT___050710_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050704_)))));
    vlSelf->wasmetal_core__DOT___049902_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049895_)))));
    vlSelf->wasmetal_core__DOT___051739_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051722_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051721_)))))));
    vlSelf->wasmetal_core__DOT___053720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051722_)))));
    vlSelf->wasmetal_core__DOT___051839_ = (1U & (IData)(
                                                         (0x33aa0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051833_)))))))));
    vlSelf->wasmetal_core__DOT___050831_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050822_))))));
    vlSelf->wasmetal_core__DOT___051792_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051781_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051780_)))))));
    vlSelf->wasmetal_core__DOT___053816_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051781_)))));
    vlSelf->wasmetal_core__DOT___066957_ = (1U & (IData)(
                                                         (0xbf00bfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050983_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050982_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050981_)))))))));
    vlSelf->wasmetal_core__DOT___051293_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051291_)))));
    vlSelf->wasmetal_core__DOT___051886_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049636_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051880_)))))));
    vlSelf->wasmetal_core__DOT___049651_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049636_)))));
    vlSelf->wasmetal_core__DOT___053396_ = (1U & (IData)(
                                                         (0xffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053391_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051634_)))))))));
    vlSelf->wasmetal_core__DOT___051638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051633_)))));
    vlSelf->wasmetal_core__DOT___049769_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049760_)))));
    vlSelf->wasmetal_core__DOT___051703_ = (1U & (IData)(
                                                         (0x55cc0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051460_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051692_)))))))));
    vlSelf->wasmetal_core__DOT___053704_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051460_)))));
    vlSelf->wasmetal_core__DOT___051814_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050804_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051809_)))))));
    vlSelf->wasmetal_core__DOT___050858_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050804_)))));
    vlSelf->wasmetal_core__DOT___051807_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051804_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051803_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051350_)))))))));
    vlSelf->wasmetal_core__DOT___051355_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051349_)))));
}
