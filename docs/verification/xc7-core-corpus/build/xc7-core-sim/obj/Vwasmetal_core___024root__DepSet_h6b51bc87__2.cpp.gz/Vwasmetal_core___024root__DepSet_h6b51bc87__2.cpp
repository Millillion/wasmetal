#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__5(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__5\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___050957_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 8U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___050935_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xcU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___050954_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xaU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___050933_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xbU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___031341_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3030300fffffffeULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & (vlSelf->insn_y 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051567_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051569_))))))))))));
    vlSelf->wasmetal_core__DOT___071847_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053427_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051569_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051567_)))));
    vlSelf->wasmetal_core__DOT___053353_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052880_)))));
    vlSelf->wasmetal_core__DOT___009542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052796_))));
    vlSelf->wasmetal_core__DOT___052834_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052796_))));
    vlSelf->wasmetal_core__DOT___052649_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048519_))));
    vlSelf->__VdfgTmp_hbdf577ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048519_));
    vlSelf->wasmetal_core__DOT___053475_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053260_))));
    vlSelf->wasmetal_core__DOT___048797_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048794_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))))))));
    vlSelf->wasmetal_core__DOT___048808_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048805_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))))))));
    vlSelf->wasmetal_core__DOT___048878_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h7cf17ecc__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048875_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))))))));
    vlSelf->wasmetal_core__DOT___048886_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048883_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))))))));
    vlSelf->wasmetal_core__DOT___048893_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048890_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))))))));
    vlSelf->wasmetal_core__DOT___048753_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048750_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))))))));
    vlSelf->wasmetal_core__DOT___048740_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he0c10a9d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048737_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))))))));
    vlSelf->wasmetal_core__DOT___048768_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048765_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))))))));
    vlSelf->wasmetal_core__DOT___048783_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h585a3ceb__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))))))));
    vlSelf->wasmetal_core__DOT___048776_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048773_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))))))));
    vlSelf->wasmetal_core__DOT___048837_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048834_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))))))));
    vlSelf->wasmetal_core__DOT___048813_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h98d262dd__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))))))));
    vlSelf->wasmetal_core__DOT___048826_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048823_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))))))));
    vlSelf->wasmetal_core__DOT___048821_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048818_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))))))));
    vlSelf->wasmetal_core__DOT___048733_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047861_)))))))));
    vlSelf->wasmetal_core__DOT___048760_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048757_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))))))));
    vlSelf->wasmetal_core__DOT___007436_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034308_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034371_));
    vlSelf->__VdfgTmp_ha80d5d1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___034505_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034504_));
    vlSelf->wasmetal_core__DOT__divider__02esign_a 
        = (1U & (0xd0U >> (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___052583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034342_)))));
    vlSelf->wasmetal_core__DOT___052801_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034502_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___034480_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___034503_)))))))));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034476_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034532_));
    vlSelf->wasmetal_core__DOT___052806_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___052805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy))));
    vlSelf->wasmetal_core__DOT___054340_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf4000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052997_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053733_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051277_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->mem_ready) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053000_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052986_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053615_)))));
    vlSelf->wasmetal_core__DOT___053006_ = (1U & (IData)(
                                                         (0xaf2300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052989_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052988_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->mem_ready) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019414_)))))))));
    vlSelf->__VdfgTmp_ha85820a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___053333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045596_));
    vlSelf->wasmetal_core__DOT___053437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053333_))));
    vlSelf->wasmetal_core__DOT___003035_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___002966_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___003014_)
                                                    ? (IData)(
                                                              (0x8000000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0)))
                                                    : (IData)(
                                                              (0x80000000ffffffffULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___003014_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003013_)))));
    vlSelf->wasmetal_core__DOT___044190_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                                                      ? 
                                                     ((~ (IData)(vlSelf->wasmetal_core__DOT___045716_)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044194_))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044170_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (3U 
                                                     & (vlSelf->insn_op 
                                                        >> 0x18U))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___045715_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___045719_)
                                                           ? (IData)(vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__)
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045716_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT___009541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045725_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044180_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128027___O 
        = (0xfU & ((vlSelf->insn_z >> 4U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027954_))))));
    vlSelf->wasmetal_core__DOT___027958_ = ((vlSelf->insn_z 
                                             >> 7U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128267___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 7U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 6U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->mem_rdata[0U] 
                                            >> 5U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 4U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030489_)))));
    vlSelf->wasmetal_core__DOT___030493_ = (1U & ((0x80U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 7U)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___019782_ = (1U & (0xbf000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053563_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053562_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->busy) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052857_)))))));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032893_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___065524_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065518_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065517_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065516_)))))))));
    vlSelf->wasmetal_core__DOT___065657_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065653_))));
    vlSelf->wasmetal_core__DOT___065766_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065765_))));
    vlSelf->wasmetal_core__DOT___065852_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065848_))));
    vlSelf->wasmetal_core__DOT___065963_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065960_))));
    vlSelf->wasmetal_core__DOT___066032_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066031_))));
    vlSelf->wasmetal_core__DOT___066188_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066184_))));
    vlSelf->wasmetal_core__DOT___066230_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066229_))));
    vlSelf->wasmetal_core__DOT___066342_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066340_))));
    vlSelf->wasmetal_core__DOT___066439_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066438_)))));
    vlSelf->wasmetal_core__DOT___066505_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066504_)))));
    vlSelf->wasmetal_core__DOT___066587_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065028_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066585_)))));
    vlSelf->wasmetal_core__DOT___066700_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065145_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066699_)))));
    vlSelf->wasmetal_core__DOT___066754_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065226_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066752_)))));
    vlSelf->wasmetal_core__DOT___066835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065383_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066834_)))));
    vlSelf->wasmetal_core__DOT___066919_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065488_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066918_)))));
    vlSelf->wasmetal_core__DOT___067004_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065512_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067002_)))));
    vlSelf->wasmetal_core__DOT___067048_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067047_)))));
    vlSelf->wasmetal_core__DOT___067133_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067132_)))));
    vlSelf->wasmetal_core__DOT___067245_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065848_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067243_)))));
    vlSelf->wasmetal_core__DOT___067284_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065960_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067282_)))));
    vlSelf->wasmetal_core__DOT___067389_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067387_)))));
    vlSelf->wasmetal_core__DOT___067435_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066184_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067434_)))));
    vlSelf->wasmetal_core__DOT___067533_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066229_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067531_)))));
    vlSelf->wasmetal_core__DOT___019407_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067579_)))));
    vlSelf->wasmetal_core__DOT___067646_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066438_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067645_)))));
    vlSelf->wasmetal_core__DOT___070353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069834_))));
    vlSelf->wasmetal_core__DOT___067714_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066504_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067713_)))));
    vlSelf->wasmetal_core__DOT___067793_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067792_)))));
    vlSelf->wasmetal_core__DOT___069814_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069451_))));
    vlSelf->__VdfgTmp_h3c0e85cc__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065475_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065474_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065478_));
    vlSelf->wasmetal_core__DOT___069791_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069420_))));
    vlSelf->__VdfgTmp_h96c6858e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065368_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065367_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065371_));
    vlSelf->wasmetal_core__DOT___067842_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066699_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067841_)))));
    vlSelf->wasmetal_core__DOT___069770_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069394_))));
    vlSelf->__VdfgTmp_h84a28025__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065213_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065212_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065216_));
    vlSelf->wasmetal_core__DOT___069727_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069345_))));
    vlSelf->wasmetal_core__DOT___069749_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069370_))));
    vlSelf->__VdfgTmp_h2f6e42c0__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065136_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065135_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065139_));
    vlSelf->wasmetal_core__DOT___067885_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067884_)))));
    vlSelf->wasmetal_core__DOT___067945_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067944_)))));
    vlSelf->wasmetal_core__DOT___068008_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068007_)))));
    vlSelf->wasmetal_core__DOT___068061_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067002_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068060_)))));
    vlSelf->wasmetal_core__DOT___069705_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069322_))));
    vlSelf->wasmetal_core__DOT___068136_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067047_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068135_)))));
    vlSelf->wasmetal_core__DOT___065768_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064864_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xacU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___065373_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___064858_)))))))));
    vlSelf->wasmetal_core__DOT___068222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068221_)))));
    vlSelf->wasmetal_core__DOT___068188_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068187_)))));
    vlSelf->wasmetal_core__DOT___068275_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067282_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068274_)))));
    vlSelf->wasmetal_core__DOT___068328_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067387_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068327_)))));
    vlSelf->wasmetal_core__DOT___069682_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069289_))));
    vlSelf->wasmetal_core__DOT___068384_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068383_)))));
    vlSelf->wasmetal_core__DOT___069662_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069269_))));
    vlSelf->wasmetal_core__DOT___068459_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068458_)))));
    vlSelf->wasmetal_core__DOT___067382_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066024_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbca1334b__0)))));
    vlSelf->wasmetal_core__DOT___066026_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbca1334b__0))));
    vlSelf->wasmetal_core__DOT___064697_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064667_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064666_)))));
    vlSelf->wasmetal_core__DOT___065662_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61c930cb__0))));
    vlSelf->wasmetal_core__DOT___067238_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065854_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde8128eb__0)))));
    vlSelf->wasmetal_core__DOT___065857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde8128eb__0))));
    vlSelf->wasmetal_core__DOT___066580_ = (1U & (0xffccf0aaU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065023_))))));
    vlSelf->wasmetal_core__DOT___065024_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065009_)))));
    vlSelf->wasmetal_core__DOT___067526_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066222_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h227fe25d__0)))));
    vlSelf->wasmetal_core__DOT___066224_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h227fe25d__0))));
    vlSelf->wasmetal_core__DOT___066193_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0))));
    vlSelf->wasmetal_core__DOT___067437_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0)))));
    vlSelf->wasmetal_core__DOT___064867_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064853_)))));
    vlSelf->wasmetal_core__DOT___066508_ = (1U & (0xffccf055U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064853_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064866_))))));
    vlSelf->wasmetal_core__DOT___067135_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09fbb425__0)))));
    vlSelf->wasmetal_core__DOT___065767_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09fbb425__0))));
    vlSelf->wasmetal_core__DOT___067286_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065965_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0)))))));
    vlSelf->wasmetal_core__DOT___065968_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0))));
    vlSelf->wasmetal_core__DOT___064447_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064361_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064360_)))));
    vlSelf->wasmetal_core__DOT___065522_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82ca1536__0))));
    vlSelf->wasmetal_core__DOT___069637_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069220_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069221_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068458_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069220_)))));
    vlSelf->wasmetal_core__DOT___069452_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068832_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069451_)))));
    vlSelf->wasmetal_core__DOT___068833_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068007_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068832_)))));
    vlSelf->wasmetal_core__DOT___069546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069026_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069344_)))))));
    vlSelf->wasmetal_core__DOT___069027_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068221_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069026_)))));
    vlSelf->wasmetal_core__DOT___069346_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069345_)))));
    vlSelf->wasmetal_core__DOT___068636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067792_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068635_)))));
    vlSelf->wasmetal_core__DOT___069395_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069394_)))));
    vlSelf->wasmetal_core__DOT___068733_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068732_)))));
    vlSelf->wasmetal_core__DOT___069588_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069121_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069122_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069121_)))));
    vlSelf->wasmetal_core__DOT___069500_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068928_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069288_)))))));
    vlSelf->wasmetal_core__DOT___068929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068135_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068928_)))));
    vlSelf->wasmetal_core__DOT___069290_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068521_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069289_)))));
    vlSelf->wasmetal_core__DOT___068522_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068521_)))));
    vlSelf->wasmetal_core__DOT___069189_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068383_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069188_)))));
    vlSelf->wasmetal_core__DOT___069611_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069188_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069420_)))));
    vlSelf->wasmetal_core__DOT___068783_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068782_)))));
    vlSelf->wasmetal_core__DOT___069519_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068995_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069321_)))))));
    vlSelf->wasmetal_core__DOT___068996_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068995_)))));
    vlSelf->wasmetal_core__DOT___068586_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068585_)))));
    vlSelf->wasmetal_core__DOT___069323_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069322_)))));
    vlSelf->wasmetal_core__DOT___069371_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069370_)))));
    vlSelf->wasmetal_core__DOT___068686_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067841_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068685_)))));
    vlSelf->wasmetal_core__DOT___069571_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069073_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069074_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069073_)))));
    vlSelf->wasmetal_core__DOT___069480_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068879_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069268_)))))));
    vlSelf->wasmetal_core__DOT___068880_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068879_)))));
    vlSelf->wasmetal_core__DOT___068504_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067579_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068503_)))));
    vlSelf->wasmetal_core__DOT___019406_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068503_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069269_)))));
    vlSelf->wasmetal_core__DOT___065869_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064969_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)))))));
    vlSelf->wasmetal_core__DOT___064885_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064834_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->mem_rdata[0U]) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064807_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064806_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064805_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064817_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064188_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064187_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064193_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___065673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065669_))));
    vlSelf->wasmetal_core__DOT___066355_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7f000000ff0000ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064203_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haf6246da__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x3aU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcce0135b__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066352_)))));
    vlSelf->wasmetal_core__DOT___065534_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064197_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcce0135b__0)))))));
    vlSelf->wasmetal_core__DOT___065866_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065864_))));
    vlSelf->wasmetal_core__DOT___065750_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065747_))));
    vlSelf->wasmetal_core__DOT___065984_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065980_))));
    vlSelf->wasmetal_core__DOT___066044_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066043_))));
    vlSelf->wasmetal_core__DOT___066243_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066241_))));
    vlSelf->wasmetal_core__DOT___066174_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066172_))));
    vlSelf->wasmetal_core__DOT___066354_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066350_))));
    vlSelf->wasmetal_core__DOT___066454_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066450_)))));
    vlSelf->wasmetal_core__DOT___066455_ = (1U & (0xf888faffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066453_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064622_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___066451_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> 
                                                                  (3U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___064634_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064622_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064621_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064619_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xff00ff000f0fbbbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064617_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064192_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064616_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___065279_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065253_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065252_)))))))));
    vlSelf->wasmetal_core__DOT___066051_ = (1U & (IData)(
                                                         (0xf7770000f333f333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066048_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066047_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xbb0fU 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 2U) 
                                                                                | (2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U))))))) 
                                                                                << 1U))))))))))))));
    vlSelf->wasmetal_core__DOT___065473_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065450_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065449_)))))))));
    vlSelf->wasmetal_core__DOT___065366_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065342_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065341_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065340_)))))))));
    vlSelf->wasmetal_core__DOT___067061_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065669_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067059_)))));
    vlSelf->__VdfgTmp_h46342433__0 = (((IData)(vlSelf->wasmetal_core__DOT___064632_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066450_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067635_))))));
    vlSelf->wasmetal_core__DOT___067376_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066043_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067374_)))));
    vlSelf->__VdfgTmp_hc01ceff5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065252_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066739_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067874_))))));
    vlSelf->wasmetal_core__DOT___066741_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065245_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066739_)))));
    vlSelf->wasmetal_core__DOT___067232_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065864_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067230_)))));
    vlSelf->__VdfgTmp_h799a13b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___064948_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066572_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067781_))))));
    vlSelf->wasmetal_core__DOT___066574_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064940_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066572_)))));
    vlSelf->__VdfgTmp_h066a303e__0 = (((IData)(vlSelf->wasmetal_core__DOT___065449_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066929_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067996_))))));
    vlSelf->wasmetal_core__DOT___066931_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065444_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066929_)))));
    vlSelf->wasmetal_core__DOT___067520_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066241_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067518_)))));
    vlSelf->wasmetal_core__DOT___067419_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066172_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067416_)))));
    vlSelf->__VdfgTmp_ha0f18469__0 = (((IData)(vlSelf->wasmetal_core__DOT___065340_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066824_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067928_))))));
    vlSelf->wasmetal_core__DOT___066826_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065333_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066824_)))));
    vlSelf->wasmetal_core__DOT___067121_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065747_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067120_)))));
    vlSelf->__VdfgTmp_hd3e9f05a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064806_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066496_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067693_))))));
    vlSelf->wasmetal_core__DOT___066498_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064796_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066496_)))));
    vlSelf->__VdfgTmp_hd98b4743__0 = (((IData)(vlSelf->wasmetal_core__DOT___065112_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066689_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067847_))))));
    vlSelf->wasmetal_core__DOT___066693_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065104_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066689_)))));
    vlSelf->wasmetal_core__DOT___067277_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067276_)))));
    vlSelf->wasmetal_core__DOT___067014_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065528_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067012_)))));
    vlSelf->__VdfgTmp_h01abed45__0 = (((IData)(vlSelf->wasmetal_core__DOT___065532_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067012_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067550_))))))));
    vlSelf->wasmetal_core__DOT___067552_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067551_)))));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027828_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d));
    vlSelf->wasmetal_core__DOT___064455_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064250_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x330faa0fU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064203_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x3aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcce0135b__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064197_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064196_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf030f050f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064111_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                                                << 3U)) 
                                                                                | (3U 
                                                                                & vlSelf->mem_rdata[0U]))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064193_)))))))))))))))))))))));
    vlSelf->__VdfgTmp_ha5948160__0 = (((IData)(vlSelf->wasmetal_core__DOT___064554_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066429_)))));
    vlSelf->__VdfgTmp_hea3a75f9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066429_))))));
    vlSelf->__VdfgTmp_h9b0680c9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065680_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066428_))))))));
    vlSelf->wasmetal_core__DOT___065681_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065680_))));
    vlSelf->wasmetal_core__DOT___066059_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066057_))));
    vlSelf->__VdfgTmp_hb159a4d2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066057_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___066427_)) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_hb19dabb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065274_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066730_)))));
    vlSelf->__VdfgTmp_h96a0f125__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065270_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066730_))))));
    vlSelf->__VdfgTmp_hf4606e0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064985_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066563_)))));
    vlSelf->__VdfgTmp_hded1dcfc__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064981_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066563_))))));
    vlSelf->__VdfgTmp_h729a2b0d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065876_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066562_))))))));
    vlSelf->wasmetal_core__DOT___065878_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065876_))));
    vlSelf->__VdfgTmp_h55dc4d97__0 = (((IData)(vlSelf->wasmetal_core__DOT___065468_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066936_)))));
    vlSelf->__VdfgTmp_had85000c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065464_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066936_))))));
    vlSelf->wasmetal_core__DOT___066255_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066253_))));
    vlSelf->__VdfgTmp_h8c50959a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066253_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h720d5baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___065097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066676_)))));
    vlSelf->__VdfgTmp_h34d9c714__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065091_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066676_))))));
    vlSelf->__VdfgTmp_h940ea061__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065991_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___066361_)) 
                                                                << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065994_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065991_))));
    vlSelf->wasmetal_core__DOT___067020_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x4000cfffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066994_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066993_)))))))))))))));
    vlSelf->__VdfgTmp_hd6d71fd2__0 = (((IData)(vlSelf->wasmetal_core__DOT___066993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066994_));
    vlSelf->__VdfgTmp_h07d01a7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___065543_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066362_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_ha994bb2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___064543_));
    vlSelf->__VdfgTmp_h54c4945a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064543_)));
    vlSelf->__VdfgTmp_h53aa4fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064543_)));
    vlSelf->wasmetal_core__DOT___066156_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066154_))));
    vlSelf->__VdfgTmp_h9bb3dbab__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066154_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_h0ce087b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___065361_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066814_)))));
    vlSelf->__VdfgTmp_h72f36192__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065357_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066814_))))));
    vlSelf->__VdfgTmp_h5ea85090__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065778_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066485_))))))));
    vlSelf->wasmetal_core__DOT___065780_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065778_))));
    vlSelf->__VdfgTmp_hb4147928__0 = (((IData)(vlSelf->wasmetal_core__DOT___064787_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___066486_)))));
    vlSelf->__VdfgTmp_he200cacd__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064779_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066486_))))));
    vlSelf->wasmetal_core__DOT___064996_ = (1U & (0x4500cfcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064977_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xc1dU 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(
                                                                              (0xaa330f00000000ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064578_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd333e317__0))))) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xc01fdf1fe0ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064956_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                                << 4U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 3U))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___064957_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f335500000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064969_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064615_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064614_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064617_))))))))))))))))))));
    vlSelf->__VdfgTmp_h8ba6f27a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064585_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066421_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->__VdfgTmp_hbfa812aa__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064575_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066421_))))));
    vlSelf->wasmetal_core__DOT___067038_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0))))));
    vlSelf->wasmetal_core__DOT___068914_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h7fac6026__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___065646_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd880fa11__0))))));
    vlSelf->wasmetal_core__DOT___065264_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065259_))));
    vlSelf->__VdfgTmp_hfef6b839__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066722_))))));
    vlSelf->wasmetal_core__DOT___067363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0))))));
    vlSelf->wasmetal_core__DOT___068310_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066019_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0))))));
    vlSelf->wasmetal_core__DOT___069107_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf93a855f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h07b43cae__0 = (((IData)(vlSelf->wasmetal_core__DOT___064957_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066554_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->__VdfgTmp_h8a2bba7d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064954_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066554_))))));
    vlSelf->wasmetal_core__DOT___067219_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0))))));
    vlSelf->wasmetal_core__DOT___069012_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h759c5442__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___065841_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf64104f4__0))))));
    vlSelf->__VdfgTmp_h312e660c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065456_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066941_))))));
    vlSelf->wasmetal_core__DOT___065459_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065456_))));
    vlSelf->__VdfgTmp_h007a378e__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->wasmetal_core__DOT___067507_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0))))));
    vlSelf->wasmetal_core__DOT___069204_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d3bfbfd__0))))));
    vlSelf->wasmetal_core__DOT___066684_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066674_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he75eceef__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd785ede8__0)))))))))));
    vlSelf->wasmetal_core__DOT___070301_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070300_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he75eceef__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b116__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd785ede8__0)))))))))));
    vlSelf->wasmetal_core__DOT___065159_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065128_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x7f00U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(
                                                                                (0xffcf0080ffcfffcfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064956_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha92622e4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064224_))))))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065125_))))))))))))));
    vlSelf->__VdfgTmp_h8b2cdea2__0 = (((IData)(vlSelf->wasmetal_core__DOT___065125_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066667_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___067271_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x10000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4e6b48d__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___070195_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070191_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070190_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xaU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x10000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b108__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadcb4246__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___070403_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070402_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000fffcffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b124__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4192dd5__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069064_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000fffcffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4192dd5__0))))))))))))));
    vlSelf->__VdfgTmp_h400b74e1__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->wasmetal_core__DOT___069478_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069473_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x200000003fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b72__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0)))))))))))))));
    vlSelf->__VdfgTmp_h400b6e72__0 = ((0xcU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                               << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->__VdfgTmp_h29064caf__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0));
    vlSelf->wasmetal_core__DOT___065577_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x200000003fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdfb8f5f__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069656_ = (1U & (IData)(
                                                         (0x200000003fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b80__05d) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                          >> 2U))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h737b874d__0)))))));
    vlSelf->__VdfgTmp_ha2b9b4b9__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h737b874d__0));
    vlSelf->__VdfgTmp_hf68b7cf3__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h737b874d__0));
    vlSelf->wasmetal_core__DOT___066166_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0))))));
    vlSelf->wasmetal_core__DOT___068364_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0))))));
    vlSelf->wasmetal_core__DOT___069174_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1f2f6132__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___065351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065347_))));
    vlSelf->__VdfgTmp_ha4f5f30b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065347_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066804_))))));
    vlSelf->__VdfgTmp_h0696502e__0 = ((2U & ((8U >> 
                                              ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___064828_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___066475_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->__VdfgTmp_h02ac2502__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064828_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066475_))))));
    vlSelf->wasmetal_core__DOT___068981_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067107_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0))))));
    vlSelf->__VdfgTmp_hfabdc4bc__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((2U 
                                                 & ((4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      >> 1U))))));
    vlSelf->__VdfgTmp_h8c3c8979__0 = ((2U & ((8U >> 
                                              ((2U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h0b08a7c5__0))))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                | (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128051___O 
        = (0xfU & ((vlSelf->insn_x >> 4U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028180_))))));
    vlSelf->wasmetal_core__DOT___028184_ = ((vlSelf->insn_x 
                                             >> 7U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028113_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128315___O 
        = (((8U & ((~ (vlSelf->function_params >> 7U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 6U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->function_params 
                                            >> 5U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 4U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030971_)))));
    vlSelf->wasmetal_core__DOT___030975_ = ((~ (vlSelf->function_params 
                                                >> 7U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___062994_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052872_)))));
    vlSelf->wasmetal_core__DOT___062981_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___044791_ = (1U & (IData)(
                                                         (0xf0aaf000f0ccfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070633_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___044803_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070633_)))))))));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032701_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037211_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5afc8767__0))));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026384_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d));
    vlSelf->wasmetal_core__DOT___054482_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054480_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->result_index) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054484_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054483_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___052581_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052580_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___051019_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___055109_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053772_))));
    vlSelf->wasmetal_core__DOT___053774_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053771_))));
    vlSelf->wasmetal_core__DOT___042683_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___070632_ = (1U & (0xffff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003045_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003044_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003042_)))))));
    vlSelf->wasmetal_core__DOT___042541_ = (1U & (0x1f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___052733_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052732_))));
    vlSelf->wasmetal_core__DOT___055347_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & vlSelf->insn_x) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052732_))))));
    vlSelf->wasmetal_core__DOT___048389_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048356_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))));
    vlSelf->wasmetal_core__DOT___048354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048344_))));
    vlSelf->wasmetal_core__DOT___048353_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048350_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048349_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048347_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))));
    vlSelf->wasmetal_core__DOT___007042_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048415_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048408_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048410_))))));
    vlSelf->__VdfgTmp_h3900e5db__0 = ((2U & ((IData)(
                                                     (0x4000000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007061_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048417_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048415_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___048414_)))))))) 
                                             << 1U)) 
                                      | (1U & (0x40000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048410_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((4U 
                                                                & ((0xf11ffU 
                                                                    >> 
                                                                    ((0x10U 
                                                                      & ((8U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048405_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048408_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048407_))))))));
    vlSelf->wasmetal_core__DOT___063413_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->mem_fault) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaaaffff0303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_fault)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___045241_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045217_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070684_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___045244_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045220_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070689_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT___045246_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045222_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070699_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070698_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT___045247_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045223_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070704_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054354_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070703_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___045249_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070713_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054366_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045225_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070714_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054370_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x14U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054366_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070713_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U))))))))))))));
    vlSelf->wasmetal_core__DOT___045250_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070718_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054372_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___045226_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070719_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054376_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x17U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054372_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070718_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U))))))))))))));
    vlSelf->wasmetal_core__DOT___045231_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045207_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070729_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___045232_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___045208_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070734_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT___045234_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___045210_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070744_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054402_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070743_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___045235_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045211_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070749_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054408_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070748_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT___045237_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054420_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___045213_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070759_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054424_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054420_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070758_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU))))))))))))));
    vlSelf->wasmetal_core__DOT___045238_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070763_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054426_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___045214_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070764_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054430_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054426_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070763_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU))))))))))))));
    vlSelf->wasmetal_core__DOT___045240_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054438_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___045216_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070774_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054442_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x34U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054438_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070773_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U))))))))))))));
    vlSelf->wasmetal_core__DOT___045242_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___045218_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070779_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___045245_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045221_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070694_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054342_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070693_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT___045248_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045224_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070709_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054360_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070708_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___045251_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045227_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070724_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___045233_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___045209_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070739_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___045236_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054414_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___045212_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070754_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054418_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x29U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054414_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070753_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___045239_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054432_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___045215_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070769_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054436_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x31U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054432_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070768_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 5U)))))))))))));
    vlSelf->wasmetal_core__DOT___044969_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___044945_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070787_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___044972_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___044948_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070792_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT___044974_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___044950_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070802_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054347_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070801_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU))))))))))))));
    vlSelf->wasmetal_core__DOT___044975_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044951_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070807_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054353_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070806_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU))))))))))))));
    vlSelf->wasmetal_core__DOT___044977_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054365_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___044953_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070817_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054369_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x14U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054365_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070816_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U))))))))))))));
    vlSelf->wasmetal_core__DOT___044978_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___044954_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070822_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054375_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x17U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054371_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070821_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U))))))))))))));
    vlSelf->wasmetal_core__DOT___044959_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___044935_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070832_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___044960_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___044936_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070837_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT___044962_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___044938_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054401_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070846_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U))))))))))))));
    vlSelf->wasmetal_core__DOT___044963_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___044939_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070852_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054407_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070851_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U))))))))))))));
    vlSelf->wasmetal_core__DOT___044965_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054419_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___044941_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070862_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054423_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054419_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070861_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU))))))))))))));
    vlSelf->wasmetal_core__DOT___044966_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054425_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___044942_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070867_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054429_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054425_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070866_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU))))))))))))));
    vlSelf->wasmetal_core__DOT___044968_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070876_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___044944_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070877_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054441_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x34U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054437_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070876_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U))))))))))))));
    vlSelf->wasmetal_core__DOT___044970_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___044946_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070882_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___044973_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___044949_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070797_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054341_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070796_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)))))))))))));
    vlSelf->wasmetal_core__DOT___044976_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___044952_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070812_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054359_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070811_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___044979_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___044955_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070827_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___044961_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___044937_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070842_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___044964_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054413_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___044940_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070857_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054417_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x29U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054413_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070856_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___044967_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070871_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___044943_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070872_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054435_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x31U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054431_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070871_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 5U)))))))))))));
    vlSelf->wasmetal_core__DOT___062963_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->__VdfgTmp_hde1d4dea__0 = (((IData)(vlSelf->wasmetal_core__DOT___044260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052853_));
    vlSelf->wasmetal_core__DOT___044405_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063095_))));
    vlSelf->wasmetal_core__DOT___044429_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053990_))));
    vlSelf->wasmetal_core__DOT___044408_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c632a11__0))))))));
    vlSelf->wasmetal_core__DOT___044432_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))))));
    vlSelf->wasmetal_core__DOT___044409_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e211f59__0))))))));
    vlSelf->wasmetal_core__DOT___044433_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))))));
    vlSelf->wasmetal_core__DOT___044410_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df568d0__0))))))));
    vlSelf->wasmetal_core__DOT___044434_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))))));
    vlSelf->wasmetal_core__DOT___044411_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179c0c32__0))))))));
    vlSelf->wasmetal_core__DOT___044435_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))))));
    vlSelf->wasmetal_core__DOT___044412_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h79eb8028__0))))))));
    vlSelf->wasmetal_core__DOT___044436_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))))));
    vlSelf->wasmetal_core__DOT___044413_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed1a6099__0))))))));
    vlSelf->wasmetal_core__DOT___044437_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT___044414_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h351f56c5__0))))))));
    vlSelf->wasmetal_core__DOT___044438_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))))));
    vlSelf->wasmetal_core__DOT___044415_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7c7ad9a__0))))))));
    vlSelf->wasmetal_core__DOT___044439_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))))));
    vlSelf->wasmetal_core__DOT___044417_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7fbee1d__0))))))));
    vlSelf->wasmetal_core__DOT___044441_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->wasmetal_core__DOT___044418_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haaf717df__0))))))));
    vlSelf->wasmetal_core__DOT___044442_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))))));
    vlSelf->wasmetal_core__DOT___044416_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66f1f037__0))))))));
    vlSelf->wasmetal_core__DOT___044440_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063113_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063101_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___044419_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6661b389__0))))))));
    vlSelf->wasmetal_core__DOT___044443_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063119_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))))));
    vlSelf->wasmetal_core__DOT___044420_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb28d3ef__0))))))));
    vlSelf->wasmetal_core__DOT___044444_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063149_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063143_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->wasmetal_core__DOT___044421_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33545cb0__0))))))));
    vlSelf->wasmetal_core__DOT___044445_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063155_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___044422_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc1441d8__0))))))));
    vlSelf->wasmetal_core__DOT___044446_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063185_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063179_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063173_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___044423_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfa74de2f__0))))))));
    vlSelf->wasmetal_core__DOT___044447_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054099_)))))))));
    vlSelf->wasmetal_core__DOT___044424_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5eac1f1__0))))))));
    vlSelf->wasmetal_core__DOT___044448_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063221_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063209_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))))));
    vlSelf->wasmetal_core__DOT___044425_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42ef1750__0))))))));
    vlSelf->wasmetal_core__DOT___044449_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063239_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063227_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))))));
    vlSelf->wasmetal_core__DOT___044426_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6e6c7922__0))))))));
    vlSelf->wasmetal_core__DOT___044450_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063257_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063251_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063245_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))))));
    vlSelf->wasmetal_core__DOT___044406_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3a468d3__0))))))));
    vlSelf->wasmetal_core__DOT___044430_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))))));
    vlSelf->wasmetal_core__DOT___044407_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h561bfeb8__0))))))));
    vlSelf->wasmetal_core__DOT___044431_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))))));
    vlSelf->wasmetal_core__DOT___066327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O)))));
    vlSelf->wasmetal_core__DOT___009691_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053775_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053779_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010005_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053764_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053761_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007196_))));
    vlSelf->wasmetal_core__DOT___009653_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054146_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054145_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048407_)))))))));
    vlSelf->wasmetal_core__DOT___052802_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052761_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4c543443__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052759_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052758_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052757_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f3a812b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremainder_op))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001568_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001612_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000432_))))))))))))))))))))))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x8000000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052780_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052779_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052778_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x4000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034476_))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052776_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))))))))))))))))))))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052583_)))));
    vlSelf->wasmetal_core__DOT___052912_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052903_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052902_))));
    vlSelf->wasmetal_core__DOT___053485_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052903_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052882_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052898_)))));
    vlSelf->__VdfgTmp_h652beeee__0 = (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063857_));
    vlSelf->wasmetal_core__DOT___048396_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048332_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1ffU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048319_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048318_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048317_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048316_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019396_)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 8U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b10__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xaU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xaU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x16U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b24__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x18U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x18U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b20__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x14U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x13U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b21__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x15U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x15U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x1cU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b30__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1eU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x10U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b18__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x12U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x12U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b14__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xeU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xeU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xdU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b15__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xfU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xfU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b26__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1aU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b27__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1bU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___050446_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050394_))));
    vlSelf->wasmetal_core__DOT___050402_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT___062964_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b1__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 1U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 1U))))));
    vlSelf->wasmetal_core__DOT___007044_ = ((IData)(vlSelf->wasmetal_core__DOT___007061_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007057_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048435_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___048434_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007054_))))))))));
    vlSelf->wasmetal_core__DOT___070137_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052847_))));
    vlSelf->wasmetal_core__DOT___053435_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052894_))));
    vlSelf->__VdfgTmp_hae6fbe86__0 = (((IData)(vlSelf->wasmetal_core__DOT___063817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052847_));
    vlSelf->wasmetal_core__DOT___063819_ = (1U & (IData)(
                                                         (0x1ff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063817_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048439_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048490_)))))))));
    vlSelf->wasmetal_core__DOT___063450_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052847_))));
    vlSelf->wasmetal_core__DOT___061519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___055104_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019323_))));
    vlSelf->wasmetal_core__DOT___060678_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8cb32961__0)))));
    vlSelf->wasmetal_core__DOT___060672_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha01e8f2f__0))));
    vlSelf->wasmetal_core__DOT___060656_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___053434_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052840_))));
    vlSelf->wasmetal_core__DOT___062602_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053351_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052901_))))));
    vlSelf->wasmetal_core__DOT___064477_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064476_))));
    vlSelf->__VdfgTmp_hb4ec291e__0 = (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063860_));
    vlSelf->wasmetal_core__DOT___010378_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053776_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x80000000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053770_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053758_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___053755_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007191_)))))));
    vlSelf->wasmetal_core__DOT___019222_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019204_))))));
    vlSelf->wasmetal_core__DOT___060718_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___055322_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & vlSelf->insn_x)))))));
    vlSelf->wasmetal_core__DOT___055319_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___055312_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___010376_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056255_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056254_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053762_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053761_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007192_)))))));
    vlSelf->wasmetal_core__DOT___054845_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___054891_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___055015_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___054749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___019221_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))));
    vlSelf->wasmetal_core__DOT___010077_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056256_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053777_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053768_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007195_)))))))));
    vlSelf->wasmetal_core__DOT___054671_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007196_)))));
    vlSelf->wasmetal_core__DOT___063859_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063855_))));
    vlSelf->wasmetal_core__DOT___065614_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065612_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065611_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065610_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065609_)))))));
    vlSelf->wasmetal_core__DOT___066282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065612_))));
    vlSelf->wasmetal_core__DOT___011740_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048469_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051252_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053761_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048465_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048471_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053753_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054146_)))))))));
    vlSelf->wasmetal_core__DOT___033033_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048284_)))))))));
    vlSelf->wasmetal_core__DOT___000418_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048271_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045642_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___048285_ = (1U & (IData)(
                                                         (7ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048280_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048275_)))))))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030686_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___053015_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053013_))));
    vlSelf->wasmetal_core__DOT___062498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052895_))));
    vlSelf->wasmetal_core__DOT___053271_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047784_)))));
    vlSelf->wasmetal_core__DOT___000157_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047784_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___003093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047784_))))));
    vlSelf->wasmetal_core__DOT___048023_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003151_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003150_)));
    vlSelf->wasmetal_core__DOT___048020_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003190_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003189_)));
    vlSelf->wasmetal_core__DOT___048135_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003234_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003233_)));
    vlSelf->wasmetal_core__DOT___048137_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003270_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003269_)));
    vlSelf->wasmetal_core__DOT___048038_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004784_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004783_)));
    vlSelf->wasmetal_core__DOT___048034_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004818_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001875_)));
    vlSelf->wasmetal_core__DOT___048153_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004710_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004709_)));
    vlSelf->wasmetal_core__DOT___048150_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004744_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001887_)));
    vlSelf->wasmetal_core__DOT___005497_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005130_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005129_)));
    vlSelf->__VdfgTmp_he5858a3c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005176_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001015_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h69848182__0))))));
    vlSelf->wasmetal_core__DOT___005437_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005062_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005061_)));
    vlSelf->__VdfgTmp_hc3acb233__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005108_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001037_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h881dfff7__0))))));
    vlSelf->wasmetal_core__DOT___048031_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004488_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004487_)));
    vlSelf->wasmetal_core__DOT___048028_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004522_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001438_)));
    vlSelf->wasmetal_core__DOT___005447_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005334_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005333_)));
    vlSelf->__VdfgTmp_hcea60642__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005380_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001059_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h60872440__0))))));
    vlSelf->wasmetal_core__DOT___005390_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004926_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004925_)));
    vlSelf->wasmetal_core__DOT___005388_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004972_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001081_)));
    vlSelf->wasmetal_core__DOT___005400_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004994_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004993_)));
    vlSelf->__VdfgTmp_h9462500e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005040_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001103_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h638471cc__0))))));
    vlSelf->wasmetal_core__DOT___005410_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004858_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004857_)));
    vlSelf->wasmetal_core__DOT___005408_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004904_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001125_)));
    vlSelf->wasmetal_core__DOT___005420_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005265_)));
    vlSelf->wasmetal_core__DOT___005418_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005312_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001147_)));
    vlSelf->wasmetal_core__DOT___047990_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005582_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005581_)));
    vlSelf->__VdfgTmp_hb85239a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005636_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001330_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hee23ef9b__0)))))));
    vlSelf->wasmetal_core__DOT___048157_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004340_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004339_)));
    vlSelf->wasmetal_core__DOT___048154_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004374_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001444_)));
    vlSelf->wasmetal_core__DOT___005457_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005198_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005197_)));
    vlSelf->wasmetal_core__DOT___005455_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005244_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001169_)));
    vlSelf->wasmetal_core__DOT___048012_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004414_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004413_)));
    vlSelf->wasmetal_core__DOT___048014_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004448_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001476_)));
    vlSelf->__VdfgTmp_ha59547bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003172_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003091_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha1faee4b__0)))))));
    vlSelf->__VdfgTmp_ha8427a44__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003208_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000665_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h51a3fd4e__0)))))));
    vlSelf->__VdfgTmp_h09328eec__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003252_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003095_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h0a17a2b0__0)))))));
    vlSelf->__VdfgTmp_hf92587e4__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003288_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000693_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2f17a8a4__0)))))));
    vlSelf->__VdfgTmp_h8dbe6334__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004802_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004801_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hdf4f28bb__0)))))));
    vlSelf->__VdfgTmp_h59e987ab__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004832_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000694_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_heeded769__0)))))));
    vlSelf->wasmetal_core__DOT___048067_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004562_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004561_)));
    vlSelf->wasmetal_core__DOT___048064_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004596_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001488_)));
}
