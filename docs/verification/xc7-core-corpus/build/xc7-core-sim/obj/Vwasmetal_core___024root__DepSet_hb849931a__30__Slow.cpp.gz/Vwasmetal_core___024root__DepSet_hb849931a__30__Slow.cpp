#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__48(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__48\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___005700_;
    wasmetal_core__DOT___005700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___005911_;
    wasmetal_core__DOT___005911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006190_;
    wasmetal_core__DOT___006190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006195_;
    wasmetal_core__DOT___006195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006251_;
    wasmetal_core__DOT___006251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006252_;
    wasmetal_core__DOT___006252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006260_;
    wasmetal_core__DOT___006260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006261_;
    wasmetal_core__DOT___006261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006269_;
    wasmetal_core__DOT___006269_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006270_;
    wasmetal_core__DOT___006270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006286_;
    wasmetal_core__DOT___006286_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006287_;
    wasmetal_core__DOT___006287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006293_;
    wasmetal_core__DOT___006293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006294_;
    wasmetal_core__DOT___006294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006302_;
    wasmetal_core__DOT___006302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006303_;
    wasmetal_core__DOT___006303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006312_;
    wasmetal_core__DOT___006312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006313_;
    wasmetal_core__DOT___006313_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006327_;
    wasmetal_core__DOT___006327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006328_;
    wasmetal_core__DOT___006328_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006336_;
    wasmetal_core__DOT___006336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006337_;
    wasmetal_core__DOT___006337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006346_;
    wasmetal_core__DOT___006346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006347_;
    wasmetal_core__DOT___006347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006355_;
    wasmetal_core__DOT___006355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006356_;
    wasmetal_core__DOT___006356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006367_;
    wasmetal_core__DOT___006367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006368_;
    wasmetal_core__DOT___006368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006371_;
    wasmetal_core__DOT___006371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006379_;
    wasmetal_core__DOT___006379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006489_;
    wasmetal_core__DOT___006489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010899_;
    wasmetal_core__DOT___010899_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012428_;
    wasmetal_core__DOT___012428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017488_;
    wasmetal_core__DOT___017488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017508_;
    wasmetal_core__DOT___017508_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017522_;
    wasmetal_core__DOT___017522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017594_;
    wasmetal_core__DOT___017594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017643_;
    wasmetal_core__DOT___017643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017655_;
    wasmetal_core__DOT___017655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017694_;
    wasmetal_core__DOT___017694_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017719_;
    wasmetal_core__DOT___017719_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017745_;
    wasmetal_core__DOT___017745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017759_;
    wasmetal_core__DOT___017759_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017797_;
    wasmetal_core__DOT___017797_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023099_;
    wasmetal_core__DOT___023099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023103_;
    wasmetal_core__DOT___023103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023107_;
    wasmetal_core__DOT___023107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024167_;
    wasmetal_core__DOT___024167_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024172_;
    wasmetal_core__DOT___024172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024185_;
    wasmetal_core__DOT___024185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024298_;
    wasmetal_core__DOT___024298_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024303_;
    wasmetal_core__DOT___024303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024316_;
    wasmetal_core__DOT___024316_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024433_;
    wasmetal_core__DOT___024433_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024438_;
    wasmetal_core__DOT___024438_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024451_;
    wasmetal_core__DOT___024451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024599_;
    wasmetal_core__DOT___024599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024604_;
    wasmetal_core__DOT___024604_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024608_;
    wasmetal_core__DOT___024608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024617_;
    wasmetal_core__DOT___024617_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024850_;
    wasmetal_core__DOT___024850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024854_;
    wasmetal_core__DOT___024854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024868_;
    wasmetal_core__DOT___024868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035319_;
    wasmetal_core__DOT___035319_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035323_;
    wasmetal_core__DOT___035323_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035332_;
    wasmetal_core__DOT___035332_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035490_;
    wasmetal_core__DOT___035490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035494_;
    wasmetal_core__DOT___035494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035499_;
    wasmetal_core__DOT___035499_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035606_;
    wasmetal_core__DOT___035606_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035611_;
    wasmetal_core__DOT___035611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035792_;
    wasmetal_core__DOT___035792_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042782_;
    wasmetal_core__DOT___042782_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048082_;
    wasmetal_core__DOT___048082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048083_;
    wasmetal_core__DOT___048083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048084_;
    wasmetal_core__DOT___048084_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048085_;
    wasmetal_core__DOT___048085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048088_;
    wasmetal_core__DOT___048088_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048089_;
    wasmetal_core__DOT___048089_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048090_;
    wasmetal_core__DOT___048090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048091_;
    wasmetal_core__DOT___048091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048099_;
    wasmetal_core__DOT___048099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048100_;
    wasmetal_core__DOT___048100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048215_;
    wasmetal_core__DOT___048215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048216_;
    wasmetal_core__DOT___048216_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048220_;
    wasmetal_core__DOT___048220_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048221_;
    wasmetal_core__DOT___048221_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048222_;
    wasmetal_core__DOT___048222_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048223_;
    wasmetal_core__DOT___048223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048247_;
    wasmetal_core__DOT___048247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048248_;
    wasmetal_core__DOT___048248_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048249_;
    wasmetal_core__DOT___048249_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048250_;
    wasmetal_core__DOT___048250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048932_;
    wasmetal_core__DOT___048932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048933_;
    wasmetal_core__DOT___048933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048934_;
    wasmetal_core__DOT___048934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048935_;
    wasmetal_core__DOT___048935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059246_;
    wasmetal_core__DOT___059246_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070491_;
    wasmetal_core__DOT___070491_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071849_;
    wasmetal_core__DOT___071849_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071850_;
    wasmetal_core__DOT___071850_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071852_;
    wasmetal_core__DOT___071852_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071853_;
    wasmetal_core__DOT___071853_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071854_;
    wasmetal_core__DOT___071854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071855_;
    wasmetal_core__DOT___071855_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071856_;
    wasmetal_core__DOT___071856_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071858_;
    wasmetal_core__DOT___071858_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071859_;
    wasmetal_core__DOT___071859_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071860_;
    wasmetal_core__DOT___071860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071863_;
    wasmetal_core__DOT___071863_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071866_;
    wasmetal_core__DOT___071866_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071868_;
    wasmetal_core__DOT___071868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071869_;
    wasmetal_core__DOT___071869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071871_;
    wasmetal_core__DOT___071871_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071872_;
    wasmetal_core__DOT___071872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071873_;
    wasmetal_core__DOT___071873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071874_;
    wasmetal_core__DOT___071874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071875_;
    wasmetal_core__DOT___071875_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071877_;
    wasmetal_core__DOT___071877_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071878_;
    wasmetal_core__DOT___071878_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071879_;
    wasmetal_core__DOT___071879_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071882_;
    wasmetal_core__DOT___071882_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071885_;
    wasmetal_core__DOT___071885_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127506___O;
    wasmetal_core__DOT____Vcellout___127506___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127509___O;
    wasmetal_core__DOT____Vcellout___127509___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127525___O;
    wasmetal_core__DOT____Vcellout___127525___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128729___O;
    wasmetal_core__DOT____Vcellout___128729___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128730___O;
    wasmetal_core__DOT____Vcellout___128730___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128732___O;
    wasmetal_core__DOT____Vcellout___128732___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128744___O;
    wasmetal_core__DOT____Vcellout___128744___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128745___O;
    wasmetal_core__DOT____Vcellout___128745___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128746___O;
    wasmetal_core__DOT____Vcellout___128746___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128747___O;
    wasmetal_core__DOT____Vcellout___128747___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128759___O;
    wasmetal_core__DOT____Vcellout___128759___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128760___O;
    wasmetal_core__DOT____Vcellout___128760___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128761___O;
    wasmetal_core__DOT____Vcellout___128761___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127720___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127720___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127720___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127720___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127720___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127720___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127735___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127735___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127735___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127735___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127735___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127735___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hd93d0b50__0;
    __VdfgTmp_hd93d0b50__0 = 0;
    CData/*1:0*/ __VdfgTmp_he3e5ec17__0;
    __VdfgTmp_he3e5ec17__0 = 0;
    CData/*1:0*/ __VdfgTmp_h102458ff__0;
    __VdfgTmp_h102458ff__0 = 0;
    CData/*2:0*/ __VdfgTmp_h25b244b0__0;
    __VdfgTmp_h25b244b0__0 = 0;
    CData/*4:0*/ __VdfgTmp_he4f3e8d5__0;
    __VdfgTmp_he4f3e8d5__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf41e7b3e__0;
    __VdfgTmp_hf41e7b3e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h77ea5fdf__0;
    __VdfgTmp_h77ea5fdf__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d 
        = (1U & (0xf8ffU >> (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                         >> 3U)))))));
    vlSelf->__VdfgTmp_hd215401d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h03fdecb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h2549a40a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hd6af8d62__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128740___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035365_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035310_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128756___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035481_)))));
    vlSelf->wasmetal_core__DOT___035485_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                >> 2U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128756___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035656_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127685___O 
        = (((8U & ((0x4bU >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___010059_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010064_) 
                                          << 1U) | 
                                         (1U & (9U 
                                                >> (IData)(vlSelf->__VdfgTmp_h78c69d21__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024429_)))));
    if ((1U & (0x4bU >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)))) {
        wasmetal_core__DOT___024433_ = vlSelf->wasmetal_core__DOT___127685___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024599_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d;
    } else {
        wasmetal_core__DOT___024433_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d;
        wasmetal_core__DOT___024599_ = vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127652___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024231_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h16107c49__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024163_)))));
    if (vlSelf->wasmetal_core__DOT___024231_) {
        wasmetal_core__DOT___024167_ = vlSelf->wasmetal_core__DOT___127652___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024298_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d;
    } else {
        wasmetal_core__DOT___024167_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d;
        wasmetal_core__DOT___024298_ = vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127669___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024231_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h16107c49__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127669___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024294_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127734___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024846_)))));
    wasmetal_core__DOT___024850_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127734___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127702___O 
        = (((8U & ((~ (0x4bU >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010059_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010064_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h78c69d21__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127718___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024595_)))));
    vlSelf->wasmetal_core__DOT___006392_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006397_)) 
                                                  & (IData)(
                                                            (0x3fafULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___005845_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h5b56c921__0)))))))));
    vlSelf->wasmetal_core__DOT___006407_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006397_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005913_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023187_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O))))))));
    vlSelf->wasmetal_core__DOT___048159_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005850_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005849_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005848_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005847_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005846_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005845_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005843_)))))))))));
    wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023237_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___020525_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048948_)))));
    vlSelf->wasmetal_core__DOT___019814_ = (1U & (IData)(
                                                         (0xf000f000ffff8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he775e720__0))))))));
    vlSelf->wasmetal_core__DOT___040107_ = (1U & (0x7520ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase)))))));
    __VdfgTmp_h77ea5fdf__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase));
    vlSelf->wasmetal_core__DOT___060410_ = (1U & (0xb00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0335500000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058354_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O) 
                                                                                >> 3U))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xc0aU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058505_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128872___O) 
                                                                            >> 3U))))))))))));
    vlSelf->wasmetal_core__DOT___060366_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058351_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O))))))))));
    vlSelf->wasmetal_core__DOT___060381_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058352_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023094_));
    wasmetal_core__DOT___017508_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017488_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O) 
                                                           >> 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017522_ = (1U & (0x8888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128848___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017537_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9110e1f3__0))))));
    vlSelf->wasmetal_core__DOT___017551_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3d32f603__0))))));
    vlSelf->wasmetal_core__DOT___017564_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))));
    wasmetal_core__DOT___017594_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017579_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0))))));
    vlSelf->wasmetal_core__DOT___017666_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7594c868__0))))));
    vlSelf->wasmetal_core__DOT___017679_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3fd333a__0))))));
    wasmetal_core__DOT___017694_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017691_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017704_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h692ab415__0))))));
    vlSelf->wasmetal_core__DOT___017613_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0))))));
    vlSelf->wasmetal_core__DOT___017626_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf223abb4__0))))));
    wasmetal_core__DOT___017655_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017719_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017716_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017643_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    vlSelf->wasmetal_core__DOT___017731_ = (1U & (0x4fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h917221d1__0))))));
    wasmetal_core__DOT___017745_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017759_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017756_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    wasmetal_core__DOT___017797_ = (1U & (0x80888888U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017794_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128853___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___017480_)))))));
    if (vlSelf->wasmetal_core__DOT___017485_) {
        if (vlSelf->wasmetal_core__DOT___017484_) {
            vlSelf->wasmetal_core__DOT___059057_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0))))));
            vlSelf->wasmetal_core__DOT___058947_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0))))));
            vlSelf->wasmetal_core__DOT___058941_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___015777_)))))));
            vlSelf->wasmetal_core__DOT___058952_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0))))));
            vlSelf->wasmetal_core__DOT___059006_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0))))));
            vlSelf->wasmetal_core__DOT___059036_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0))))));
            vlSelf->wasmetal_core__DOT___059001_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0))))));
            vlSelf->wasmetal_core__DOT___059049_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h513c757b__0))))));
            vlSelf->wasmetal_core__DOT___059060_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h310e5162__0))))));
        } else {
            vlSelf->wasmetal_core__DOT___059057_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___017785_));
            vlSelf->wasmetal_core__DOT___058947_ = 
                (1U & (IData)(wasmetal_core__DOT___017508_));
            vlSelf->wasmetal_core__DOT___058941_ = 
                (1U & (IData)(wasmetal_core__DOT___017488_));
            vlSelf->wasmetal_core__DOT___058952_ = 
                (1U & (IData)(wasmetal_core__DOT___017522_));
            vlSelf->wasmetal_core__DOT___059006_ = 
                (1U & (IData)(wasmetal_core__DOT___017655_));
            vlSelf->wasmetal_core__DOT___059036_ = 
                (1U & (IData)(wasmetal_core__DOT___017719_));
            vlSelf->wasmetal_core__DOT___059001_ = 
                (1U & (IData)(wasmetal_core__DOT___017643_));
            vlSelf->wasmetal_core__DOT___059049_ = 
                (1U & (IData)(wasmetal_core__DOT___017759_));
            vlSelf->wasmetal_core__DOT___059060_ = 
                (1U & (IData)(wasmetal_core__DOT___017797_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___059057_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___017785_));
        vlSelf->wasmetal_core__DOT___058947_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017508_));
        vlSelf->wasmetal_core__DOT___058941_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017488_));
        vlSelf->wasmetal_core__DOT___058952_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017522_));
        vlSelf->wasmetal_core__DOT___059006_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017655_));
        vlSelf->wasmetal_core__DOT___059036_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017719_));
        vlSelf->wasmetal_core__DOT___059001_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017643_));
        vlSelf->wasmetal_core__DOT___059049_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017759_));
        vlSelf->wasmetal_core__DOT___059060_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017797_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134163___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036825_) 
                        << 2U) | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O)))))) 
           ^ ((8U & (((~ (IData)(vlSelf->wasmetal_core__DOT___036825_)) 
                      | (IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134163___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___036819_)))));
    wasmetal_core__DOT___059246_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017806_))));
    vlSelf->__VdfgTmp_hd43f4c44__0 = (((IData)(vlSelf->wasmetal_core__DOT___017806_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x7f0000U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___058937_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051539_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017780_) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128856___O) 
                                                                       >> 2U))))))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035366_)
                  ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035485_));
    vlSelf->wasmetal_core__DOT____Vcellout___128758___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035657_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035656_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035655_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035654_)))) 
           ^ (((IData)(wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128758___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035597_)))));
    vlSelf->wasmetal_core__DOT___035602_ = ((IData)(vlSelf->wasmetal_core__DOT___035657_)
                                             ? (IData)(wasmetal_core__DOT___128758___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d));
    vlSelf->wasmetal_core__DOT___012603_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    wasmetal_core__DOT___012428_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___013082_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (0x4bU >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)))) {
        wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024433_;
        wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d;
    } else {
        wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d;
        wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024599_;
    }
    vlSelf->wasmetal_core__DOT___043812_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043836_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___043487_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043486_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043509_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___071849_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071850_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h19ff1492__0)))) {
        wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024167_;
        wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d;
    } else {
        wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d;
        wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024298_;
    }
    vlSelf->wasmetal_core__DOT___043358_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043357_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043746_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043380_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___043770_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___071868_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071869_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043421_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043445_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___127735___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
           & (IData)(wasmetal_core__DOT___024850_));
    wasmetal_core__DOT____Vcellout___127525___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023239_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023238_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023237_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023236_)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___023238_) 
                                                      & (IData)(wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127525___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127525___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023298_)))));
    vlSelf->wasmetal_core__DOT___040078_ = (1U & (IData)(
                                                         (0xffaa5500ffe0ffe0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071561_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h77ea5fdf__0))))))));
    __VdfgTmp_h25b244b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                               << 2U) | (IData)(__VdfgTmp_h77ea5fdf__0));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___017591_) {
        if (vlSelf->wasmetal_core__DOT___017590_) {
            vlSelf->wasmetal_core__DOT___058984_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h46466860__0))))));
            vlSelf->wasmetal_core__DOT___059023_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0))))));
            vlSelf->wasmetal_core__DOT___059045_ = 
                (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017480_) 
                               << 1U) | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0))))));
        } else {
            vlSelf->wasmetal_core__DOT___058984_ = 
                (1U & (IData)(wasmetal_core__DOT___017594_));
            vlSelf->wasmetal_core__DOT___059023_ = 
                (1U & (IData)(wasmetal_core__DOT___017694_));
            vlSelf->wasmetal_core__DOT___059045_ = 
                (1U & (IData)(wasmetal_core__DOT___017745_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058984_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017594_));
        vlSelf->wasmetal_core__DOT___059023_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017694_));
        vlSelf->wasmetal_core__DOT___059045_ = (1U 
                                                & (IData)(wasmetal_core__DOT___017745_));
    }
    vlSelf->wasmetal_core__DOT___060018_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059246_))));
    vlSelf->wasmetal_core__DOT___059248_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___059246_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036825_)))));
    vlSelf->wasmetal_core__DOT___017495_ = (1U & (IData)(
                                                         (0xb000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd43f4c44__0)))))));
    wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035367_)
                  ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035658_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035602_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d));
    vlSelf->wasmetal_core__DOT___057139_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(wasmetal_core__DOT___012428_))
                                                      : (IData)(
                                                                (0xfff3fff5fff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___012428_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012427_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hef87eb38__0))))))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0)))) {
        wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d;
    } else {
        wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d;
        wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043510_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> 
                                                        ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___071850_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071849_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)))) {
        wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d;
    } else {
        wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d;
        wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043381_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> 
                                                        ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___071869_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071868_)))));
    wasmetal_core__DOT___127735___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___005911_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005935_)
                                              ? (IData)(
                                                        (0x2aa00000202ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcdf58d3d__0)))
                                              : (IData)(
                                                        (0xfffffeaafffffefeULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcdf58d3d__0))))));
    vlSelf->wasmetal_core__DOT___005910_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005928_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hcf2773b3__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hcf2773b3__0))))));
    wasmetal_core__DOT___005700_ = (IData)((((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                             >> 3U) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___005731_)
                                                ? (IData)(
                                                          (0x2aa00000202ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))
                                                : (IData)(
                                                          (0xfffffeaafffffefeULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcf316312__0))))));
    vlSelf->wasmetal_core__DOT___040072_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070574_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040064_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058083_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039409_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071476_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040085_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071481_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040041_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071485_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040042_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071489_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040083_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071495_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040043_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071498_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040044_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071501_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039760_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071504_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040045_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071507_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040046_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071510_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040109_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071513_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040048_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071518_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040049_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071520_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039741_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071523_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040075_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071525_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040051_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071527_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040052_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he775e720__0)) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039714_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071531_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040106_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071533_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039872_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071534_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040081_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071535_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039658_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071536_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040082_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071537_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040057_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071538_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040058_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071539_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039647_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071540_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040054_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071542_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040060_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071543_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040061_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071544_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039631_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071545_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040062_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071546_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040063_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071547_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039596_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071548_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039590_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071549_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040086_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071550_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040065_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071551_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039408_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071552_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040066_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071553_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040070_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071554_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040105_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071555_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040068_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071556_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040069_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071557_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___039563_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071558_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040071_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071559_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->wasmetal_core__DOT___040067_ = (1U & (0xffffae00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071560_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h25b244b0__0)))));
    vlSelf->__VdfgTmp_hcfa19df1__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                       << 3U) | (IData)(__VdfgTmp_h25b244b0__0));
    vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059344_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058947_))));
    vlSelf->wasmetal_core__DOT___059586_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058984_))));
    vlSelf->wasmetal_core__DOT___059683_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059023_))));
    vlSelf->wasmetal_core__DOT___059611_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017579_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5bb2fc7d__0)))))));
    vlSelf->wasmetal_core__DOT___059636_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017666_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8d1d0ffb__0)))))));
    vlSelf->wasmetal_core__DOT___059708_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017704_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_haf11557d__0)))))));
    vlSelf->wasmetal_core__DOT___059735_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_heb003047__0)))))));
    vlSelf->wasmetal_core__DOT___059760_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017626_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128851___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h43b37fbe__0)))))));
    vlSelf->wasmetal_core__DOT___059876_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017731_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128852___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h69609ee5__0)))))));
    vlSelf->wasmetal_core__DOT___018304_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e507ca5__0)))))))))));
    vlSelf->wasmetal_core__DOT___018401_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017564_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h71876852__0)))))));
    vlSelf->wasmetal_core__DOT___059658_ = (1U & (IData)(
                                                         (0xfbf0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017679_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6171bc25__0)))))));
    vlSelf->wasmetal_core__DOT___018344_ = (1U & (IData)(
                                                         (0xb00ff00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017551_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128849___O)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6bcf76cf__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128742___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035368_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035367_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035366_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035365_)))) 
           ^ (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035310_)))));
    vlSelf->wasmetal_core__DOT___035314_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035368_)
                                                   ? (IData)(wasmetal_core__DOT___128742___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0))));
    vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
               >> 1U)) & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035659_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b46__05d));
    if (vlSelf->wasmetal_core__DOT___024493_) {
        wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d;
    } else {
        wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d;
        wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_had236f40__0)))) {
        wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d;
    } else {
        wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d;
        wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127735___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__1__KET__));
    __VdfgTmp_h102458ff__0 = (((IData)(wasmetal_core__DOT___005911_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127523___O) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___005982_)
                                                   ? (IData)(
                                                             (0x2aa00000202ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))
                                                   : (IData)(
                                                             (0xfffffeaafffffefeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))))));
    __VdfgTmp_he3e5ec17__0 = (((IData)(vlSelf->wasmetal_core__DOT___005910_) 
                               << 1U) | (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127524___O) 
                                                >> 2U) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___005921_)
                                                   ? (IData)(
                                                             (0x2aa00000202ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))
                                                   : (IData)(
                                                             (0xfffffeaafffffefeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))))));
    vlSelf->wasmetal_core__DOT___006125_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005850_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005849_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005701_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___005700_))))));
    vlSelf->__VdfgTmp_h2af4e7f7__0 = (((IData)(wasmetal_core__DOT___005700_) 
                                       << 1U) | (1U 
                                                 & (((IData)(wasmetal_core__DOT____Vcellout___127525___O) 
                                                     >> 1U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005716_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc8e63fc4__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc8e63fc4__0)))))));
    vlSelf->wasmetal_core__DOT___040108_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071475_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0))))));
    __VdfgTmp_hf41e7b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___071515_) 
                               << 4U) | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0));
    __VdfgTmp_he4f3e8d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___071492_) 
                               << 4U) | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0));
    wasmetal_core__DOT____Vcellout___127506___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023094_)))));
    wasmetal_core__DOT___023099_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hc9bde5b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc3641189__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hcdd8cada__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h152c16b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035370_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035314_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h04542857__0))));
    wasmetal_core__DOT____Vcellout___128744___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035485_)))));
    wasmetal_core__DOT___035490_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                        >> 2U)) & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035660_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127671___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h3b65973b__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0)) 
                                                << 1U)) 
                                         | (1U & (0x4bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127671___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127671___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024433_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h3b65973b__0)))) {
        wasmetal_core__DOT___024438_ = wasmetal_core__DOT___127671___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024604_ = vlSelf->wasmetal_core__DOT___011478_;
    } else {
        wasmetal_core__DOT___024438_ = vlSelf->wasmetal_core__DOT___011478_;
        wasmetal_core__DOT___024604_ = wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127637___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_he7bd57fe__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_had236f40__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x4fb0U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h19ff1492__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127637___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127637___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024167_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_he7bd57fe__0)))) {
        wasmetal_core__DOT___024172_ = wasmetal_core__DOT___127637___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024303_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d;
    } else {
        wasmetal_core__DOT___024172_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d;
        wasmetal_core__DOT___024303_ = wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127654___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_he7bd57fe__0))) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_had236f40__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0x4fb0U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h19ff1492__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127654___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127654___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127654___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024298_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127735___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
           ^ (((IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024850_)))));
    wasmetal_core__DOT___024854_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127735___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127687___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h3b65973b__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024493_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0x4bU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127704___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127704___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127704___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024599_)))));
    vlSelf->wasmetal_core__DOT___006408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006037_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h102458ff__0)))));
    vlSelf->__VdfgTmp_h35bc9263__0 = (((IData)(vlSelf->wasmetal_core__DOT___005975_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005912_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h102458ff__0)));
    vlSelf->wasmetal_core__DOT___048160_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005916_)) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5f6fc6e__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf5f6fc6e__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005913_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005912_) 
                                                                        << 3U) 
                                                                       | (((IData)(wasmetal_core__DOT___005911_) 
                                                                           << 2U) 
                                                                          | (IData)(__VdfgTmp_he3e5ec17__0))))))))));
    vlSelf->__VdfgTmp_hfdd5af20__0 = (((IData)(vlSelf->wasmetal_core__DOT___006132_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006008_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he3e5ec17__0)));
    vlSelf->wasmetal_core__DOT___048264_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006010_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005848_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006009_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006008_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005910_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2af4e7f7__0))))))))));
    __VdfgTmp_hd93d0b50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005702_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005701_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h2af4e7f7__0)));
    vlSelf->wasmetal_core__DOT___039758_ = (1U & (IData)(
                                                         (0xffffffff00ae0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf41e7b3e__0)))));
    vlSelf->wasmetal_core__DOT___040079_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf41e7b3e__0)))));
    vlSelf->wasmetal_core__DOT___039761_ = (1U & (IData)(
                                                         (0xffffffff00ae0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_he4f3e8d5__0)))));
    vlSelf->wasmetal_core__DOT___040053_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_he4f3e8d5__0)))));
    vlSelf->wasmetal_core__DOT___060425_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff007700ff000f00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hb5f365d2__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f0335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058355_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127506___O))))))))))))));
    vlSelf->wasmetal_core__DOT___060451_ = (1U & (IData)(
                                                         (0x3f5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060449_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x11ffffff0f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127506___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___060435_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfcf0faf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058507_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                >> 1U))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058356_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127506___O) 
                                                                           >> 1U))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))));
    vlSelf->wasmetal_core__DOT___060472_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058357_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127506___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d) 
           & (IData)(wasmetal_core__DOT___023099_));
    wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035371_)
                  ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035490_));
    wasmetal_core__DOT____Vcellout___128759___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035661_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035660_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035659_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035658_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035602_)))));
    wasmetal_core__DOT___035606_ = ((IData)(vlSelf->wasmetal_core__DOT___035661_)
                                     ? (IData)(wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d));
    vlSelf->wasmetal_core__DOT___057032_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    wasmetal_core__DOT___010899_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024495_) {
        wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024438_;
        wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d;
    } else {
        wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d;
        wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024604_;
    }
    vlSelf->wasmetal_core__DOT___043814_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043813_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043488_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O)))));
    wasmetal_core__DOT___071852_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071853_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071854_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071857_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h39529667__0)))) {
        wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024172_;
        wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d;
    } else {
        wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d;
        wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024303_;
    }
    vlSelf->wasmetal_core__DOT___043359_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O)))));
    vlSelf->wasmetal_core__DOT___043748_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043747_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___071871_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071872_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071873_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071876_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127720___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
           & (IData)(wasmetal_core__DOT___024854_));
    vlSelf->wasmetal_core__DOT___043423_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043422_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043447_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043446_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___048267_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005977_)) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9fcc5824__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9fcc5824__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005916_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005850_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h35bc9263__0))))))));
    vlSelf->wasmetal_core__DOT___006126_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006009_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                        >> 2U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___006144_)
                                                           ? (IData)(
                                                                     (0x2aa00000202ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb47c9e11__0)))
                                                           : (IData)(
                                                                     (0xfffffeaafffffefeULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb47c9e11__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005843_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfdd5af20__0))))))));
    vlSelf->wasmetal_core__DOT___048161_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005706_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005705_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005703_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hd93d0b50__0))))))));
    vlSelf->wasmetal_core__DOT___006191_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006199_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                        >> 1U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___006204_)
                                                           ? (IData)(
                                                                     (0x2aa00000202ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h16a355a8__0)))
                                                           : (IData)(
                                                                     (0xfffffeaafffffefeULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h16a355a8__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006078_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006077_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hd93d0b50__0))))))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
           & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035372_)
                  ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128759___O)) 
           & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035662_)
            ? (IData)(wasmetal_core__DOT___035606_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d));
    vlSelf->wasmetal_core__DOT___056393_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(wasmetal_core__DOT___010899_))
                                                      : (IData)(
                                                                (0xfff3fff5fff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___010899_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf40000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2c387a2e__0)))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hd6fa80fa__0))))))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc194321c__0)))) {
        wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d;
    } else {
        wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d;
        wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043837_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071849_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071850_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071854_)))));
    vlSelf->wasmetal_core__DOT___043511_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071854_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071853_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071852_)))));
    vlSelf->wasmetal_core__DOT___043838_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071852_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071853_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071857_)))));
    if (vlSelf->wasmetal_core__DOT___024237_) {
        wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d;
    } else {
        wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d;
        wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043382_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071873_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071872_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071871_)))));
    vlSelf->wasmetal_core__DOT___043771_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071868_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071869_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071873_)))));
    vlSelf->wasmetal_core__DOT___043772_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071871_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071872_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071876_)))));
    wasmetal_core__DOT___127720___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___048266_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048265_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048267_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006125_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006124_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006123_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006122_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006126_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___048160_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048159_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048161_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006408_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006407_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hfdd5af20__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006191_)))))))));
    wasmetal_core__DOT___070491_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006191_))));
    vlSelf->__VdfgTmp_h1e09234e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006192_)))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
           & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128729___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035373_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035372_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035371_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035370_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035314_)))));
    wasmetal_core__DOT___035319_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035373_)
                                           ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035663_)
            ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hfe94c053__0)))) {
        wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127705___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d;
    } else {
        wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d;
        vlSelf->wasmetal_core__DOT___127705___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h86dd6551__0)))) {
        wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d;
    } else {
        wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d;
        wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127720___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___006392_) 
                              << 3U) | ((4U & ((1U 
                                                >> (IData)(vlSelf->__VdfgTmp_h35bc9263__0)) 
                                               << 2U)) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___070491_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d 
        = (1U & (0x80U >> (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___070491_)))));
    vlSelf->wasmetal_core__DOT___058412_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006598_)))));
    vlSelf->wasmetal_core__DOT___058397_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006604_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006603_)))));
    vlSelf->wasmetal_core__DOT___058403_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006603_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006596_)))));
    vlSelf->wasmetal_core__DOT___058380_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006602_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006601_)))));
    vlSelf->wasmetal_core__DOT___058388_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006601_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006604_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127507___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023099_)))));
    wasmetal_core__DOT___023103_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h51de0e2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128729___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h783c16d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdd32c6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128729___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h6673ab20__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035374_)
                  ? (IData)(wasmetal_core__DOT___035319_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0))));
    wasmetal_core__DOT____Vcellout___128745___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(wasmetal_core__DOT____Vcellout___128759___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035490_)))));
    wasmetal_core__DOT___035494_ = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035665_)
            ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127672___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024498_) 
             << 3U) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_hfe94c053__0)) 
                              << 2U)) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc194321c__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___024495_)))) 
           ^ (((IData)(wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127672___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127672___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024438_)))));
    if (vlSelf->wasmetal_core__DOT___024498_) {
        vlSelf->wasmetal_core__DOT___024442_ = wasmetal_core__DOT___127672___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024608_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024442_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d;
        wasmetal_core__DOT___024608_ = vlSelf->wasmetal_core__DOT___127705___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127638___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)) 
                   << 3U)) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h86dd6551__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024237_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h39529667__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127638___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127638___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024172_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)))) {
        vlSelf->wasmetal_core__DOT___024176_ = wasmetal_core__DOT___127638___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024307_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024176_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d;
        vlSelf->wasmetal_core__DOT___024307_ = wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127655___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0))) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h86dd6551__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024237_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0x4fb0U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h39529667__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127655___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127655___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127655___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024303_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127720___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
           ^ (((IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024854_)))));
    vlSelf->wasmetal_core__DOT___024859_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127720___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127688___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024498_)) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hfe94c053__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc194321c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024495_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127705___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127705___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127705___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024604_)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    vlSelf->__VdfgTmp_h08354128__0 = ((8U & ((0x7fff0000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___058388_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_hefac2d69__0)));
    vlSelf->wasmetal_core__DOT___060540_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfcf0faf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058511_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 3U))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058361_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 3U)))))))))))));
    wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d) 
           & (IData)(wasmetal_core__DOT___023103_));
    wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035375_)
                  ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h885d0717__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035494_));
    wasmetal_core__DOT____Vcellout___128760___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035666_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035665_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035663_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035662_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035606_)))));
    wasmetal_core__DOT___035611_ = ((IData)(vlSelf->wasmetal_core__DOT___035666_)
                                     ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d));
    vlSelf->wasmetal_core__DOT___012942_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___012443_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___013078_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)))) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024442_;
        wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024608_;
    }
    vlSelf->wasmetal_core__DOT___043815_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O)))));
    vlSelf->wasmetal_core__DOT___043489_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___071855_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071856_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071859_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071860_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if (vlSelf->wasmetal_core__DOT___024240_) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024176_;
        wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024307_;
    }
    vlSelf->wasmetal_core__DOT___043360_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043749_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O)))));
    wasmetal_core__DOT___071874_ = (1U & (9U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071875_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071878_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071879_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024859_));
    vlSelf->wasmetal_core__DOT___043424_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)))));
    vlSelf->wasmetal_core__DOT___043448_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035376_)
                  ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128760___O)) 
           & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035667_)
            ? (IData)(wasmetal_core__DOT___035611_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0)))) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043512_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071857_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071856_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071855_)))));
    vlSelf->wasmetal_core__DOT___043839_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071855_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071856_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071860_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)))) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043383_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071876_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071875_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071874_)))));
    vlSelf->wasmetal_core__DOT___043773_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071874_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071875_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071879_)))));
    wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
           & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128730___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035377_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035376_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035375_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035374_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035319_)))));
    wasmetal_core__DOT___035323_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035377_)
                                           ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)
            : (IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___024501_) {
        wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d;
    } else {
        wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d;
        wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)))) {
        wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d;
    } else {
        wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d;
        wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127508___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023103_)))));
    wasmetal_core__DOT___023107_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hab2a3827__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128730___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc1ac3ed9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h4f4cafcf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128730___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h05032e00__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035378_)
                  ? (IData)(wasmetal_core__DOT___035323_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0))));
    wasmetal_core__DOT____Vcellout___128746___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(wasmetal_core__DOT____Vcellout___128760___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035494_)))));
    wasmetal_core__DOT___035499_ = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128761___O = (
                                                   (4U 
                                                    | ((2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___035667_))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035611_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127673___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024501_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127673___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024442_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)))) {
        vlSelf->wasmetal_core__DOT___024447_ = wasmetal_core__DOT___127673___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024613_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024447_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d;
        vlSelf->wasmetal_core__DOT___024613_ = wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127639___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024244_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___024240_)))) 
           ^ (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127639___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024176_)))));
    if (vlSelf->wasmetal_core__DOT___024244_) {
        vlSelf->wasmetal_core__DOT___024181_ = wasmetal_core__DOT___127639___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024312_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024181_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d;
        vlSelf->wasmetal_core__DOT___024312_ = wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127656___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024244_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_hed15da38__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024240_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127656___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024307_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127721___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
           ^ (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024859_)))));
    vlSelf->wasmetal_core__DOT___024863_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127721___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127689___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h30bed265__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024501_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h356ffba0__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127706___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024608_)))));
    vlSelf->wasmetal_core__DOT___060583_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058362_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060567_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xbfffbfff0000ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ac41acf__0)))))))))))));
    vlSelf->wasmetal_core__DOT___060553_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xbfffbfff0000ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015932_)))))))))))))));
    wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d) 
           & (IData)(wasmetal_core__DOT___023107_));
    wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035379_)
                  ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0))));
    wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035499_));
    wasmetal_core__DOT___042782_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x38U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                       << 3U)) 
                                                   | (7U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                         >> 1U))))));
    vlSelf->wasmetal_core__DOT___012055_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___011733_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0)))) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024447_;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024613_;
    }
    vlSelf->wasmetal_core__DOT___043816_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043491_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043490_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___071858_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071861_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071862_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071863_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024181_;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024312_;
    }
    vlSelf->wasmetal_core__DOT___043362_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043361_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043750_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___071877_ = (1U & (9U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071880_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071881_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071882_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024863_));
    vlSelf->wasmetal_core__DOT___043425_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043449_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035381_)
                  ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0))));
    wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128761___O)) 
           & (IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___042770_ = (1U & ((~ (IData)(wasmetal_core__DOT___042782_)) 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                     >> 2U)));
    if (vlSelf->wasmetal_core__DOT___024504_) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043513_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071860_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071859_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071858_)))));
    vlSelf->wasmetal_core__DOT___043840_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071859_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071863_)))));
    vlSelf->wasmetal_core__DOT___043514_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071863_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071862_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071861_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)))) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043384_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071879_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071878_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071877_)))));
    vlSelf->wasmetal_core__DOT___043385_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071882_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071881_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071880_)))));
    vlSelf->wasmetal_core__DOT___043774_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071877_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___071878_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071882_)))));
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127509___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b63__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                                                      & (IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023107_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128731___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035382_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035381_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035379_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035378_)))) 
           ^ (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035323_)))));
    vlSelf->wasmetal_core__DOT___035328_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035382_)
                                                   ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))));
    wasmetal_core__DOT____Vcellout___128747___O = (
                                                   ((4U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                          >> 1U)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((~ (IData)(wasmetal_core__DOT____Vcellout___128761___O)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (~ 
                                                             ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                              >> 3U))))) 
                                                   ^ 
                                                   ((((~ 
                                                       ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                        >> 1U)) 
                                                      & (IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035499_)))));
    vlSelf->wasmetal_core__DOT___006479_ = (1U & (0xf0f055ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___023239_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h834dc827__0))))));
    vlSelf->wasmetal_core__DOT___035790_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h834dc827__0))));
    wasmetal_core__DOT___048250_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048249_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O))))));
    wasmetal_core__DOT___048223_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048222_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048935_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048934_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O))))));
    wasmetal_core__DOT___048085_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048084_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048089_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048088_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O))))));
    wasmetal_core__DOT___048091_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048090_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048083_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048082_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O))))));
    wasmetal_core__DOT___048221_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048220_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048248_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048247_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O))))));
    wasmetal_core__DOT___048216_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048215_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048932_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048933_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O))))));
    wasmetal_core__DOT___048100_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048099_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___048079_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048078_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O))))));
    vlSelf->wasmetal_core__DOT___048098_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048097_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048087_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048086_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O))))));
    vlSelf->wasmetal_core__DOT___006352_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048168_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006343_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048201_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O))))));
    vlSelf->wasmetal_core__DOT___006333_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006340_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048202_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O))))));
    vlSelf->wasmetal_core__DOT___006309_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006316_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006299_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006306_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128744___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O))))));
    vlSelf->wasmetal_core__DOT___006290_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048077_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006277_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048076_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128745___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128759___O))))));
    vlSelf->wasmetal_core__DOT___048214_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048213_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048246_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006264_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128746___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128760___O))))));
    vlSelf->wasmetal_core__DOT___006255_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 2U))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)))) {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d;
        vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024247_) {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d;
        vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060653_ = (1U & (0xefefefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0f000003355ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058516_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 3U))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0335500000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019014_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058365_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                                >> 3U))))))))))))))));
    vlSelf->wasmetal_core__DOT___060615_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x7f7f00ffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))))))))));
    vlSelf->wasmetal_core__DOT___060639_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058364_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060623_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058363_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h9f7a6ca7__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h7bf8c9f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc3230cc7__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc03ce175__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035328_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d));
    vlSelf->wasmetal_core__DOT___048943_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128747___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048683_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128747___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128761___O))))));
    vlSelf->wasmetal_core__DOT___006246_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128747___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006568_ = (1U & (IData)(
                                                         (0x8000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006479_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))));
    vlSelf->wasmetal_core__DOT___006475_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048250_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hba4cc4c7__0))))));
    vlSelf->wasmetal_core__DOT___006478_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048249_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hffde1553__0))))));
    vlSelf->wasmetal_core__DOT___035789_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048250_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048249_))));
    vlSelf->wasmetal_core__DOT___006469_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048223_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfaf781e7__0))))));
    vlSelf->wasmetal_core__DOT___006474_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048222_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9fccfed0__0))))));
    vlSelf->wasmetal_core__DOT___035788_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048223_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048222_))));
    vlSelf->wasmetal_core__DOT___006463_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048935_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc23424b0__0))))));
    vlSelf->wasmetal_core__DOT___006468_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023233_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048934_)))));
    vlSelf->wasmetal_core__DOT___035787_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048935_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048934_))));
    vlSelf->wasmetal_core__DOT___006457_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023230_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048085_)))));
    vlSelf->wasmetal_core__DOT___006462_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023231_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048084_)))));
    vlSelf->wasmetal_core__DOT___035786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048085_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048084_))));
    vlSelf->wasmetal_core__DOT___006451_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048089_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9fa4f51d__0))))));
    vlSelf->wasmetal_core__DOT___006456_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048088_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc21b3046__0))))));
    vlSelf->wasmetal_core__DOT___035785_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048089_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048088_))));
    vlSelf->wasmetal_core__DOT___006445_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048091_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6ec85b19__0))))));
    vlSelf->wasmetal_core__DOT___006450_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023227_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048090_)))));
    vlSelf->wasmetal_core__DOT___035784_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048091_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048090_))));
    vlSelf->wasmetal_core__DOT___006435_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048083_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6d7fd34d__0))))));
    vlSelf->wasmetal_core__DOT___006444_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023225_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048082_)))));
    vlSelf->wasmetal_core__DOT___035783_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048083_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048082_))));
    vlSelf->wasmetal_core__DOT___006429_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048221_)))));
    vlSelf->wasmetal_core__DOT___006434_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048220_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h445a0824__0))))));
    vlSelf->wasmetal_core__DOT___035781_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048221_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048220_))));
    vlSelf->wasmetal_core__DOT___006423_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023219_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048248_)))));
    vlSelf->wasmetal_core__DOT___006428_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048247_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd90860df__0))))));
    vlSelf->wasmetal_core__DOT___035780_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048248_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048247_))));
    vlSelf->wasmetal_core__DOT___006419_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048216_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbec5a32d__0))))));
    vlSelf->wasmetal_core__DOT___006422_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048215_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbedf9838__0))))));
    vlSelf->wasmetal_core__DOT___035779_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048216_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048215_))));
    vlSelf->wasmetal_core__DOT___006384_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023215_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048932_)))));
    vlSelf->wasmetal_core__DOT___006418_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048933_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcdb7900c__0))))));
    vlSelf->wasmetal_core__DOT___035778_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048933_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048932_))));
    vlSelf->wasmetal_core__DOT___006380_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048100_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4caf4ac4__0))))));
    vlSelf->wasmetal_core__DOT___006383_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023214_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048099_)))));
    vlSelf->wasmetal_core__DOT___035777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048100_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048099_))));
    vlSelf->wasmetal_core__DOT___006372_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023210_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048079_)))));
    wasmetal_core__DOT___006379_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048078_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h454147c9__0))))));
    vlSelf->wasmetal_core__DOT___035776_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048078_))));
    wasmetal_core__DOT___006368_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))))));
    wasmetal_core__DOT___006371_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023209_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048097_)))));
    vlSelf->wasmetal_core__DOT___035775_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048097_))));
    wasmetal_core__DOT___006356_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048087_)))));
    wasmetal_core__DOT___006367_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048086_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))))));
    vlSelf->wasmetal_core__DOT___035774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048086_))));
    wasmetal_core__DOT___006355_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048168_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))))));
    vlSelf->wasmetal_core__DOT___035773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006352_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048168_))));
    wasmetal_core__DOT___006346_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048201_)))));
    vlSelf->wasmetal_core__DOT___035772_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006343_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048201_))));
    vlSelf->wasmetal_core__DOT___035798_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006340_))));
    wasmetal_core__DOT___006327_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048202_)))));
    vlSelf->wasmetal_core__DOT___035797_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006319_))));
    vlSelf->wasmetal_core__DOT___035796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006316_))));
    vlSelf->wasmetal_core__DOT___035795_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006306_))));
    wasmetal_core__DOT___006293_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023192_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048077_)))));
    vlSelf->wasmetal_core__DOT___035794_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006290_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048077_))));
    wasmetal_core__DOT___006286_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048076_)))));
    vlSelf->wasmetal_core__DOT___035793_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048076_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006277_))));
    wasmetal_core__DOT___006261_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048214_)))));
    wasmetal_core__DOT___006269_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023187_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048213_)))));
    wasmetal_core__DOT___035792_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048214_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048213_))));
    wasmetal_core__DOT___006252_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023184_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048246_)))));
    vlSelf->wasmetal_core__DOT___035791_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048246_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127674___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024504_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024447_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)))) {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
    } else {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127640___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                               << 2U) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024181_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)))) {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
    } else {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127657___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024247_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024312_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127722___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024863_)))));
    wasmetal_core__DOT___024868_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127690___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0))) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024504_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024613_)))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035384_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h04659776__0))));
    wasmetal_core__DOT___006489_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048943_)))));
    wasmetal_core__DOT___006190_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048683_)))));
    if (vlSelf->wasmetal_core__DOT___006127_) {
        wasmetal_core__DOT___006347_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))))));
        wasmetal_core__DOT___006337_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h13911493__0))))));
        wasmetal_core__DOT___006328_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))))));
        wasmetal_core__DOT___006336_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))))));
        wasmetal_core__DOT___006313_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))))));
        wasmetal_core__DOT___006303_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))))));
        wasmetal_core__DOT___006312_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))))));
        wasmetal_core__DOT___006294_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0283b263__0))))));
        wasmetal_core__DOT___006302_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))))));
        wasmetal_core__DOT___006287_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))))));
        wasmetal_core__DOT___006270_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))))));
        wasmetal_core__DOT___006260_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))))));
        wasmetal_core__DOT___006251_ = (1U & (0xf0f0077U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_he55adf41__0))))));
        wasmetal_core__DOT___006195_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h21922827__0))))));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006479_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006478_)))))))));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006478_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006475_)))))))));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006475_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006474_)))))))));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006474_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006469_)))))))));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006469_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006468_)))))))));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006468_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006463_)))))))));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006463_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006462_)))))))));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006457_)))))))));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006457_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006456_)))))))));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006456_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006451_)))))))));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006451_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006450_)))))))));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006450_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006445_)))))))));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006445_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006444_)))))))));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006444_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006435_)))))))));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006435_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006434_)))))))));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006434_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006429_)))))))));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006429_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006428_)))))))));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006428_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006423_)))))))));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006423_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006422_)))))))));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006422_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006419_)))))))));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006419_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006418_)))))))));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006384_)))))))));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006384_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006383_)))))))));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006383_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006380_)))))))));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006380_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006379_)))))))));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006379_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006372_)))))))));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006372_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006371_)))))))));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006371_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006368_)))))))));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006368_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006367_)))))))));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006367_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006356_)))))))));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006356_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006355_)))))))));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006355_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006347_)))))))));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006347_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006346_)))))))));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006346_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006337_)))))))));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006337_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006336_)))))))));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006336_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006328_)))))))));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006328_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006327_)))))))));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006327_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006313_)))))))));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006313_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006312_)))))))));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006312_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006303_)))))))));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006303_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006302_)))))))));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006302_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006294_)))))))));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006294_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006293_)))))))));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006293_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006287_)))))))));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006287_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006286_)))))))));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006286_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006270_)))))))));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006270_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006269_)))))))));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006269_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006261_)))))))));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006261_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006260_)))))))));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006260_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006252_)))))))));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006252_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006251_)))))))));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006190_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006489_)))))))));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006195_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006190_)))))))));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006251_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006195_)))))))));
    } else {
        wasmetal_core__DOT___006347_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006352_)));
        wasmetal_core__DOT___006337_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006343_)));
        wasmetal_core__DOT___006328_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006333_)));
        wasmetal_core__DOT___006336_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006340_)));
        wasmetal_core__DOT___006313_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006319_)));
        wasmetal_core__DOT___006303_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006309_)));
        wasmetal_core__DOT___006312_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006316_)));
        wasmetal_core__DOT___006294_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006299_)));
        wasmetal_core__DOT___006302_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006306_)));
        wasmetal_core__DOT___006287_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006290_)));
        wasmetal_core__DOT___006270_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006277_)));
        wasmetal_core__DOT___006260_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006264_)));
        wasmetal_core__DOT___006251_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006255_)));
        wasmetal_core__DOT___006195_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006246_)));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006478_)));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006475_)));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006474_)));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006469_)));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006468_)));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006463_)));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006462_)));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006457_)));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006456_)));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006451_)));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006450_)));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006445_)));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006444_)));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006435_)));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006434_)));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006429_)));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006428_)));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006423_)));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006422_)));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006419_)));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006418_)));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006384_)));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006383_)));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006380_)));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006379_)));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006372_)));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006371_)));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006368_)));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006367_)));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006356_)));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006355_)));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006347_)));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006346_)));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006337_)));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006336_)));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006328_)));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006327_)));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006313_)));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006312_)));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006303_)));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006302_)));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006294_)));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006293_)));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006287_)));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006286_)));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006270_)));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006269_)));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006261_)));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006260_)));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006252_)));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006251_)));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006489_)));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006190_)));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006195_)));
    }
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d 
        = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___048943_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048683_))));
    vlSelf->wasmetal_core__DOT___035782_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006246_))));
    vlSelf->wasmetal_core__DOT___057260_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057256_)))))))));
    if (vlSelf->wasmetal_core__DOT___024507_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024451_;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024617_;
    }
    vlSelf->wasmetal_core__DOT___043818_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043817_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043842_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043492_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)))));
    wasmetal_core__DOT___071866_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024185_;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024316_;
    }
    vlSelf->wasmetal_core__DOT___043363_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)))));
    vlSelf->wasmetal_core__DOT___043752_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043751_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043776_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071885_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           & (IData)(wasmetal_core__DOT___024868_));
    vlSelf->wasmetal_core__DOT___043427_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043426_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043451_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043450_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035385_)
                  ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0))));
    vlSelf->__VdfgTmp_hf3b81358__0 = (((IData)(wasmetal_core__DOT___006489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050073_));
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035782_));
    vlSelf->__VdfgTmp_hb69d909d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006568_));
    vlSelf->__VdfgTmp_h46e4da0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006615_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006614_));
    vlSelf->__VdfgTmp_hc1f8ef63__0 = (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_));
    vlSelf->__VdfgTmp_he99783ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_));
    vlSelf->__VdfgTmp_h8be5cf2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006554_));
    vlSelf->__VdfgTmp_ha20d2c5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006440_));
    vlSelf->__VdfgTmp_h45e8af23__0 = (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006281_));
    vlSelf->__VdfgTmp_h19cea986__0 = (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006501_));
    vlSelf->__VdfgTmp_hc8c3f180__0 = (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006282_));
    vlSelf->__VdfgTmp_h8170b1e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006502_));
    vlSelf->__VdfgTmp_h980f95b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006283_));
    vlSelf->__VdfgTmp_h088d475b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006503_));
    vlSelf->__VdfgTmp_ha3862ccc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005691_));
    vlSelf->__VdfgTmp_hfc403f7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006484_));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)))) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043841_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071862_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071866_)))));
    vlSelf->wasmetal_core__DOT___043515_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071866_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043386_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071885_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    vlSelf->wasmetal_core__DOT___043775_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071880_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071881_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071885_)))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___035332_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035386_)
                                           ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_heb875033__0))));
    wasmetal_core__DOT____Vcellout___128732___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035386_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035385_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035384_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035383_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035328_)))));
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035791_) 
           & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_ha576ac17__0 = (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    vlSelf->__VdfgTmp_h455b45b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    if (vlSelf->wasmetal_core__DOT___024509_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hd481047b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h1c3d35c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf5c220e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf7faa60c__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_ha523ac5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & (((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               ^ (IData)(wasmetal_core__DOT___035332_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128781___O 
        = ((((IData)(wasmetal_core__DOT___035792_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                   << 1U) | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035821_ = ((IData)(wasmetal_core__DOT___035792_) 
                                            & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127675___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010032_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024509_) 
                        << 2U) | ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___024507_)))) 
           ^ (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024451_)))));
    if (vlSelf->wasmetal_core__DOT___010032_) {
        vlSelf->wasmetal_core__DOT___024455_ = wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024621_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024455_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
        vlSelf->wasmetal_core__DOT___024621_ = wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127641___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024185_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)))) {
        vlSelf->wasmetal_core__DOT___024189_ = wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024320_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024189_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
        vlSelf->wasmetal_core__DOT___024320_ = wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127658___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0))) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hde45e173__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024316_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           ^ (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024868_)))));
    vlSelf->wasmetal_core__DOT___024872_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127691___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010032_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024509_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h862c0500__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024507_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024617_)))));
    vlSelf->wasmetal_core__DOT___048226_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                       >> 2U)) 
                                                   | (IData)(wasmetal_core__DOT___035792_))));
    vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035793_) 
           & (IData)(vlSelf->wasmetal_core__DOT___035821_));
    vlSelf->wasmetal_core__DOT___012024_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___010380_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___024455_)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d));
    vlSelf->wasmetal_core__DOT___043819_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O)))));
    vlSelf->wasmetal_core__DOT___043843_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043493_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                            >> 3U))))));
}
