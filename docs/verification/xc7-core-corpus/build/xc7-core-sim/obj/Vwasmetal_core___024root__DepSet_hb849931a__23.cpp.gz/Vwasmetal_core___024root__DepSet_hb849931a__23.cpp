#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__29(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__29\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013498_;
    wasmetal_core__DOT___013498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013543_;
    wasmetal_core__DOT___013543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013544_;
    wasmetal_core__DOT___013544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013554_;
    wasmetal_core__DOT___013554_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013555_;
    wasmetal_core__DOT___013555_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013556_;
    wasmetal_core__DOT___013556_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013557_;
    wasmetal_core__DOT___013557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014102_;
    wasmetal_core__DOT___014102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015691_;
    wasmetal_core__DOT___015691_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015693_;
    wasmetal_core__DOT___015693_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015703_;
    wasmetal_core__DOT___015703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015705_;
    wasmetal_core__DOT___015705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015715_;
    wasmetal_core__DOT___015715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015779_;
    wasmetal_core__DOT___015779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017212_;
    wasmetal_core__DOT___017212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017225_;
    wasmetal_core__DOT___017225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017266_;
    wasmetal_core__DOT___017266_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017267_;
    wasmetal_core__DOT___017267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017272_;
    wasmetal_core__DOT___017272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017293_;
    wasmetal_core__DOT___017293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017294_;
    wasmetal_core__DOT___017294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017317_;
    wasmetal_core__DOT___017317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017346_;
    wasmetal_core__DOT___017346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017347_;
    wasmetal_core__DOT___017347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017368_;
    wasmetal_core__DOT___017368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017380_;
    wasmetal_core__DOT___017380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017382_;
    wasmetal_core__DOT___017382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017422_;
    wasmetal_core__DOT___017422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017428_;
    wasmetal_core__DOT___017428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023277_;
    wasmetal_core__DOT___023277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023925_;
    wasmetal_core__DOT___023925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024052_;
    wasmetal_core__DOT___024052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027462_;
    wasmetal_core__DOT___027462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035753_;
    wasmetal_core__DOT___035753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035970_;
    wasmetal_core__DOT___035970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035981_;
    wasmetal_core__DOT___035981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044837_;
    wasmetal_core__DOT___044837_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048489_;
    wasmetal_core__DOT___048489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057775_;
    wasmetal_core__DOT___057775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057780_;
    wasmetal_core__DOT___057780_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057783_;
    wasmetal_core__DOT___057783_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057813_;
    wasmetal_core__DOT___057813_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057818_;
    wasmetal_core__DOT___057818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057870_;
    wasmetal_core__DOT___057870_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057898_;
    wasmetal_core__DOT___057898_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057917_;
    wasmetal_core__DOT___057917_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057937_;
    wasmetal_core__DOT___057937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057951_;
    wasmetal_core__DOT___057951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058015_;
    wasmetal_core__DOT___058015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058016_;
    wasmetal_core__DOT___058016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058017_;
    wasmetal_core__DOT___058017_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058673_;
    wasmetal_core__DOT___058673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058674_;
    wasmetal_core__DOT___058674_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058676_;
    wasmetal_core__DOT___058676_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058679_;
    wasmetal_core__DOT___058679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058682_;
    wasmetal_core__DOT___058682_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058809_;
    wasmetal_core__DOT___058809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058918_;
    wasmetal_core__DOT___058918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070665_;
    wasmetal_core__DOT___070665_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070666_;
    wasmetal_core__DOT___070666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070667_;
    wasmetal_core__DOT___070667_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127607___O;
    wasmetal_core__DOT____Vcellout___127607___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127608___O;
    wasmetal_core__DOT____Vcellout___127608___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h838bb85c__0;
    __VdfgTmp_h838bb85c__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf266d7f5__0;
    __VdfgTmp_hf266d7f5__0 = 0;
    CData/*1:0*/ __VdfgTmp_h08ed86fa__0;
    __VdfgTmp_h08ed86fa__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfc488d72__0;
    __VdfgTmp_hfc488d72__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4fb57fe8__0;
    __VdfgTmp_h4fb57fe8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h03eaf1be__0;
    __VdfgTmp_h03eaf1be__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf9227657__0;
    __VdfgTmp_hf9227657__0 = 0;
    CData/*2:0*/ __VdfgTmp_h898161e8__0;
    __VdfgTmp_h898161e8__0 = 0;
    CData/*2:0*/ __VdfgTmp_h679b257d__0;
    __VdfgTmp_h679b257d__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9acc022__0;
    __VdfgTmp_hf9acc022__0 = 0;
    CData/*2:0*/ __VdfgTmp_hdaec8d52__0;
    __VdfgTmp_hdaec8d52__0 = 0;
    CData/*2:0*/ __VdfgTmp_h20a7a16d__0;
    __VdfgTmp_h20a7a16d__0 = 0;
    CData/*5:0*/ __VdfgTmp_h6bdbc3d0__0;
    __VdfgTmp_h6bdbc3d0__0 = 0;
    CData/*5:0*/ __VdfgTmp_ha1eca74f__0;
    __VdfgTmp_ha1eca74f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6a06b08d__0;
    __VdfgTmp_h6a06b08d__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd3a62ed9__0;
    __VdfgTmp_hd3a62ed9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd4b8326f__0;
    __VdfgTmp_hd4b8326f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5db557ff__0;
    __VdfgTmp_h5db557ff__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1b18da23__0;
    __VdfgTmp_h1b18da23__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3814f5f0__0;
    __VdfgTmp_h3814f5f0__0 = 0;
    CData/*3:0*/ __VdfgTmp_hdfd93176__0;
    __VdfgTmp_hdfd93176__0 = 0;
    CData/*1:0*/ __VdfgTmp_h37ce14e0__0;
    __VdfgTmp_h37ce14e0__0 = 0;
    CData/*5:0*/ __VdfgTmp_h74f5df1f__0;
    __VdfgTmp_h74f5df1f__0 = 0;
    CData/*5:0*/ __VdfgTmp_h8b0eda81__0;
    __VdfgTmp_h8b0eda81__0 = 0;
    CData/*5:0*/ __VdfgTmp_h61aaf3ff__0;
    __VdfgTmp_h61aaf3ff__0 = 0;
    CData/*1:0*/ __VdfgTmp_h91f24ade__0;
    __VdfgTmp_h91f24ade__0 = 0;
    // Body
    wasmetal_core__DOT___058016_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017426_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017424_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057964_))));
    wasmetal_core__DOT___017317_ = (1U & (IData)((0xf55330000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
    wasmetal_core__DOT___017380_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
    if (vlSelf->wasmetal_core__DOT___013735_) {
        wasmetal_core__DOT___014102_ = (1U & (IData)(
                                                     (0xff33330f0f5555ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014165_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
        if (vlSelf->wasmetal_core__DOT___014330_) {
            vlSelf->wasmetal_core__DOT___017436_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014415_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
            wasmetal_core__DOT___057951_ = (1U & (IData)(
                                                         (0xcc00aa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014394_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
            vlSelf->wasmetal_core__DOT___017435_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014408_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___017436_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014415_)));
            wasmetal_core__DOT___057951_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___014394_)));
            vlSelf->wasmetal_core__DOT___017435_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014408_)));
        }
    } else {
        wasmetal_core__DOT___014102_ = 0U;
        vlSelf->wasmetal_core__DOT___017436_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014415_)));
        wasmetal_core__DOT___057951_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014394_)));
        vlSelf->wasmetal_core__DOT___017435_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014408_)));
    }
    __VdfgTmp_h74f5df1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017284_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017283_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017282_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017281_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017280_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017279_))))));
    vlSelf->wasmetal_core__DOT___058002_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017284_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017281_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017282_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057960_))));
    wasmetal_core__DOT___057780_ = (1U & (IData)((0xeeeef0f0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017259_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017260_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017261_)))))))));
    vlSelf->wasmetal_core__DOT___017338_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013652_))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d 
        = (1U & (0xeU >> ((2U & ((IData)((0x33aa0f0f00000000ULL 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                               << 5U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((0x8000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((1U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017309_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017310_))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017311_)))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057806_)))))));
    vlSelf->wasmetal_core__DOT___057986_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017437_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    wasmetal_core__DOT___017225_ = (1U & (IData)((0x3355f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
    wasmetal_core__DOT___017422_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff33ff55fff0fff0ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017229_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057843_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058001_))));
    wasmetal_core__DOT___057870_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057869_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 2U)) 
                                                            | ((((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                                 & (IData)(
                                                                           (0xff33330f0f5555ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013914_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013913_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013945_))))))))) 
                                                                << 1U) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___013734_)
                                                                   ? (IData)(vlSelf->wasmetal_core__DOT___014266_)
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___014288_))))))))));
    wasmetal_core__DOT___058017_ = (1U & (0xefU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017409_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017407_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017408_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057967_))));
    wasmetal_core__DOT___017212_ = (1U & (IData)((0xf55330000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___017382_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___017272_ = ((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013976_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023545_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023545_));
    wasmetal_core__DOT___015779_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013216_));
    wasmetal_core__DOT___015693_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___006979_));
    wasmetal_core__DOT___015691_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013317_));
    wasmetal_core__DOT___015703_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013387_));
    wasmetal_core__DOT___015705_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013429_));
    wasmetal_core__DOT___015715_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013392_));
    vlSelf->__VdfgTmp_hbb788d21__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d));
    wasmetal_core__DOT___013554_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013423_));
    wasmetal_core__DOT___013556_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013491_));
    wasmetal_core__DOT___013543_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013359_));
    vlSelf->wasmetal_core__DOT___013545_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013460_));
    vlSelf->wasmetal_core__DOT___015610_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013323_));
    wasmetal_core__DOT___017347_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013549_)))));
    wasmetal_core__DOT___013557_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))));
    __VdfgTmp_h679b257d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006658_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0));
    vlSelf->__VdfgTmp_h8523194f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013466_));
    wasmetal_core__DOT___017346_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013466_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013549_)))));
    wasmetal_core__DOT___013544_ = (1U & (0xcf5fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))));
    __VdfgTmp_h20a7a16d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013243_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h003a3400__0));
    vlSelf->__VdfgTmp_h514789fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___013440_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013414_));
    vlSelf->__VdfgTmp_h12c4c12e__0 = (((IData)(vlSelf->wasmetal_core__DOT___013440_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013414_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006652_))));
    vlSelf->wasmetal_core__DOT___013546_ = (1U & (0xcf5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))));
    __VdfgTmp_hdaec8d52__0 = (((IData)(vlSelf->wasmetal_core__DOT___007006_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0));
    vlSelf->wasmetal_core__DOT___015611_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h06545140__0)))));
    vlSelf->wasmetal_core__DOT___015812_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057729_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h06545140__0))))))));
    wasmetal_core__DOT___013555_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))));
    __VdfgTmp_hf9acc022__0 = (((IData)(vlSelf->wasmetal_core__DOT___013563_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0));
    if (vlSelf->wasmetal_core__DOT___006652_) {
        vlSelf->wasmetal_core__DOT___015645_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013605_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))))));
        vlSelf->wasmetal_core__DOT___015647_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013599_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))))));
        vlSelf->wasmetal_core__DOT___015813_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013596_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))))));
        vlSelf->wasmetal_core__DOT___015646_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013602_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))))));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015637_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013565_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h679b257d__0)))))));
            vlSelf->wasmetal_core__DOT___015636_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013572_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h20a7a16d__0)))))));
            vlSelf->wasmetal_core__DOT___015648_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013581_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hdaec8d52__0)))))));
            vlSelf->wasmetal_core__DOT___015635_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013589_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hf9acc022__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___015637_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013565_)));
            vlSelf->wasmetal_core__DOT___015636_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013572_)));
            vlSelf->wasmetal_core__DOT___015648_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013581_)));
            vlSelf->wasmetal_core__DOT___015635_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013589_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___015645_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013605_)));
        vlSelf->wasmetal_core__DOT___015647_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013599_)));
        vlSelf->wasmetal_core__DOT___015813_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013596_)));
        vlSelf->wasmetal_core__DOT___015646_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013602_)));
        vlSelf->wasmetal_core__DOT___015637_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013565_)));
        vlSelf->wasmetal_core__DOT___015636_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013572_)));
        vlSelf->wasmetal_core__DOT___015648_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013581_)));
        vlSelf->wasmetal_core__DOT___015635_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013589_)));
    }
    wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023424_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023424_));
    vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036407_));
    vlSelf->wasmetal_core__DOT___044855_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)))))))))));
    vlSelf->wasmetal_core__DOT___044879_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d)))))))));
    __VdfgTmp_h91f24ade__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___063348_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063350_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063352_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063354_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027457_));
    vlSelf->wasmetal_core__DOT____Vcellout___128547___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                & (IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033473_)))));
    vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023783_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023719_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d));
    wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) {
        wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d;
        vlSelf->wasmetal_core__DOT___023921_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d;
    } else {
        wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023921_ = wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___006602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023241_))));
    vlSelf->wasmetal_core__DOT___006601_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h58a856e0__0))));
    vlSelf->wasmetal_core__DOT___006604_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023235_))));
    vlSelf->wasmetal_core__DOT___006603_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1d759fa4__0))));
    wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022501_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127433___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d 
        = (1U & (0x153f3fU >> (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___057799_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057798_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057769_)))))));
    wasmetal_core__DOT___057898_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfb436b73__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017250_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017251_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d 
        = (1U & (IData)((0xfff4f4f4ff000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___057919_))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___057920_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057835_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057834_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057891_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057890_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057894_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057893_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057847_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057846_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057885_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057884_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057876_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057875_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057999_))));
    __VdfgTmp_h5db557ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___017219_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017218_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017217_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057952_))));
    vlSelf->wasmetal_core__DOT___057770_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017304_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017305_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017306_)))))))));
    vlSelf->__VdfgTmp_hdf4f813b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017304_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014330_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057865_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057864_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058016_))));
    vlSelf->__VdfgTmp_h8c37f2ea__0 = (((IData)(wasmetal_core__DOT___017317_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017316_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017315_)));
    wasmetal_core__DOT___057917_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017383_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017379_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017380_)))));
    vlSelf->wasmetal_core__DOT___057992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___014102_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017436_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058002_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057781_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057780_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017338_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057986_))));
    __VdfgTmp_h1b18da23__0 = (((IData)(wasmetal_core__DOT___017225_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017224_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017223_)));
    __VdfgTmp_h61aaf3ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___017426_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017425_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017424_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017423_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___017422_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017421_))))));
    wasmetal_core__DOT___058015_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017425_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017421_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017422_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057951_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057871_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057870_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058017_))));
    wasmetal_core__DOT___057813_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017212_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017213_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017214_)))))))));
    __VdfgTmp_h8b0eda81__0 = (((IData)(vlSelf->wasmetal_core__DOT___017384_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017383_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___017382_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017381_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___017380_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017379_))))));
    wasmetal_core__DOT___057937_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017384_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017382_)))));
    wasmetal_core__DOT___057775_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017272_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017392_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017393_)))))))));
    vlSelf->wasmetal_core__DOT___057993_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017273_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017272_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017435_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127566___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023546_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023545_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023567_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023565_)))) 
           ^ (((IData)(wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023558_ = ((IData)(vlSelf->wasmetal_core__DOT___023546_)
                                             ? (IData)(wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023546_));
    vlSelf->wasmetal_core__DOT___015678_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xafcfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013420_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006660_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006658_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006657_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006649_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005955_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015678_)))));
    vlSelf->wasmetal_core__DOT___015676_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xafcfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013488_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013212_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013244_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013242_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013464_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005788_))));
    vlSelf->__VdfgTmp_h3f94b345__0 = (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_)))));
    vlSelf->__VdfgTmp_hfacd537a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015780_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015779_));
    vlSelf->__VdfgTmp_h83a6d262__0 = (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___015779_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___015780_))));
    vlSelf->wasmetal_core__DOT___013206_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015696_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015693_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015694_))))));
    vlSelf->wasmetal_core__DOT___013205_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015691_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015692_))))));
    vlSelf->wasmetal_core__DOT___017385_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015707_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015703_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015704_))))));
    vlSelf->wasmetal_core__DOT___057727_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015708_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015705_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015706_))))));
    vlSelf->wasmetal_core__DOT___017427_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015717_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015715_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015716_))))));
    vlSelf->wasmetal_core__DOT___015828_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0x33aaf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff0033330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050259_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050258_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050256_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006649_))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d 
        = (1U & (0x53U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___051320_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017347_))));
    vlSelf->wasmetal_core__DOT___015671_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35000000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013533_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013491_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005948_))));
    __VdfgTmp_h37ce14e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015671_) 
                               << 1U) | (IData)(wasmetal_core__DOT___057870_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_)))));
    vlSelf->wasmetal_core__DOT___017410_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___013556_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___013557_))))));
    wasmetal_core__DOT___058679_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015645_)
                                           ? ((~ (IData)(vlSelf->wasmetal_core__DOT___017396_)) 
                                              & (IData)(
                                                        (0xafffffffcfffffffULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h03d841f5__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___017396_) 
                                              | (IData)(
                                                        (0x5000000030000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h03d841f5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015645_))));
    vlSelf->wasmetal_core__DOT___013319_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006659_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h679b257d__0)))))));
    vlSelf->wasmetal_core__DOT___015763_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0x33aaf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013466_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff0033330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057724_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057723_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057709_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013464_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005816_))));
    vlSelf->wasmetal_core__DOT___017297_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015763_)) 
                                                  & (IData)(
                                                            (0xeefff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017333_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0x8000U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he745277b__0))))))));
    vlSelf->wasmetal_core__DOT___017298_ = ((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                            & (IData)(
                                                      (0xff11ff0fff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0x8000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017333_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he745277b__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057797_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_)))));
    wasmetal_core__DOT___070665_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___017346_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057994_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017346_))));
    vlSelf->wasmetal_core__DOT___015674_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057708_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013215_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013214_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013359_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x3a00U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005809_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017113_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015674_)))));
    vlSelf->__VdfgTmp_h9b65f112__0 = (((IData)(wasmetal_core__DOT___013544_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___013543_));
    vlSelf->wasmetal_core__DOT___017285_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___013543_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___013544_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015647_))));
    vlSelf->wasmetal_core__DOT___013503_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013244_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h20a7a16d__0)))))));
    vlSelf->wasmetal_core__DOT___015681_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013416_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013415_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013414_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005889_))));
    vlSelf->__VdfgTmp_h20099147__0 = (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_)))));
    vlSelf->wasmetal_core__DOT___017339_ = (1U & (0xfdfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015621_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h12c4c12e__0))));
    vlSelf->wasmetal_core__DOT___015677_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057714_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006978_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006977_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013460_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x3a00U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005882_))));
    vlSelf->wasmetal_core__DOT___017233_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015677_)
                                                   ? (IData)(
                                                             (0x3ff000055ffULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h45f4eeab__0)))
                                                   : (IData)(
                                                             (0xfffffc00ffffaa00ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h45f4eeab__0)))));
    vlSelf->__VdfgTmp_hdeec5a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_));
    vlSelf->__VdfgTmp_h46ff4218__0 = (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057839_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_)))));
    vlSelf->wasmetal_core__DOT___017286_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013545_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013546_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015813_))));
    __VdfgTmp_h6bdbc3d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007007_) 
                                           << 3U) | (IData)(__VdfgTmp_hdaec8d52__0))));
    vlSelf->wasmetal_core__DOT___013520_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013325_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057704_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013316_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013315_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013323_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005802_))));
    vlSelf->wasmetal_core__DOT___043098_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017229_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017230_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057834_)))))))));
    vlSelf->__VdfgTmp_h5fa4cdd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017230_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017229_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013520_)))));
    vlSelf->__VdfgTmp_hc4d25f20__0 = (((IData)(vlSelf->wasmetal_core__DOT___015610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015611_));
    vlSelf->wasmetal_core__DOT___043104_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057945_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xbfffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h479b81d6__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057943_)))))))));
    wasmetal_core__DOT___058682_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015812_)
                                           ? (IData)(
                                                     (0xbfffffffULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1d909866__0)))
                                           : (IData)(
                                                     (0xffffffff40000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1d909866__0)))));
    vlSelf->__VdfgTmp_h31f6f19a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015878_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015812_))));
    vlSelf->wasmetal_core__DOT___015672_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35000000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057704_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013316_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013423_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006051_))));
    vlSelf->__VdfgTmp_hb73d1e0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057866_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015672_)))));
    __VdfgTmp_hd3a62ed9__0 = (((IData)(wasmetal_core__DOT___013555_) 
                               << 1U) | (IData)(wasmetal_core__DOT___013554_));
    if (vlSelf->wasmetal_core__DOT___013549_) {
        vlSelf->wasmetal_core__DOT___015697_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015696_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015694_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015693_)))));
        vlSelf->wasmetal_core__DOT___015698_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015695_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015692_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015691_)))));
        vlSelf->wasmetal_core__DOT___015709_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015707_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015704_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015703_)))));
        vlSelf->wasmetal_core__DOT___015710_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015708_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015706_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015705_)))));
        vlSelf->wasmetal_core__DOT___015718_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015717_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015716_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015715_)))));
        vlSelf->wasmetal_core__DOT___015724_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___013557_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___013556_)))));
        vlSelf->wasmetal_core__DOT___015614_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013546_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013545_)))));
        vlSelf->wasmetal_core__DOT___015725_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b65f112__0))));
        vlSelf->wasmetal_core__DOT___015719_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hd3a62ed9__0))));
        vlSelf->wasmetal_core__DOT___013538_ = (1U 
                                                & (IData)(
                                                          (0xeee0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                                                << 4U) 
                                                               | (((IData)(wasmetal_core__DOT___013557_) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___013556_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hd3a62ed9__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015697_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015696_)));
        vlSelf->wasmetal_core__DOT___015698_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015695_)));
        vlSelf->wasmetal_core__DOT___015709_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015707_)));
        vlSelf->wasmetal_core__DOT___015710_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015708_)));
        vlSelf->wasmetal_core__DOT___015718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015717_)));
        vlSelf->wasmetal_core__DOT___015724_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013559_)));
        vlSelf->wasmetal_core__DOT___015614_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013548_)));
        vlSelf->wasmetal_core__DOT___015725_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013547_)));
        vlSelf->wasmetal_core__DOT___015719_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013558_)));
        vlSelf->wasmetal_core__DOT___013538_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013558_))));
    }
    wasmetal_core__DOT___017428_ = (1U & (0xefU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___013554_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___013555_))))));
    vlSelf->__VdfgTmp_h63c4ff94__0 = (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015645_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015646_))));
    vlSelf->__VdfgTmp_he88fe03e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013317_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf0aaccffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 3U) 
                                                                | (IData)(__VdfgTmp_hf9acc022__0)))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xff00ccccf0f0aaaaULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013343_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057704_)))))))))))));
    vlSelf->wasmetal_core__DOT___013335_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013313_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf9acc022__0)))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___015668_ = (1U 
                                                & (0xf0aaccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050169_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013387_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf0aaccffU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h679b257d__0)))))))))));
        vlSelf->wasmetal_core__DOT___015667_ = (1U 
                                                & (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057708_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013215_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013429_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfaa3300U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h20a7a16d__0)))))))))));
        vlSelf->wasmetal_core__DOT___015656_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006653_)
                                                    ? 
                                                   (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013415_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xff0033330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057721_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057720_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057715_))))))))))))
                                                    : 
                                                   (0x23U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h514789fb__0)))));
        vlSelf->wasmetal_core__DOT___015673_ = (1U 
                                                & (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057714_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006978_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013392_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfaa3300U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_hdaec8d52__0)))))))))));
        vlSelf->wasmetal_core__DOT___015658_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013320_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013319_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050258_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050170_)))))))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015668_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006058_)));
        vlSelf->wasmetal_core__DOT___015667_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006044_)));
        vlSelf->wasmetal_core__DOT___015656_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005903_)));
        vlSelf->wasmetal_core__DOT___015673_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006029_)));
        vlSelf->wasmetal_core__DOT___015658_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006274_)));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127549___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023425_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023424_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023446_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023444_)))) 
           ^ (((IData)(wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023437_ = ((IData)(vlSelf->wasmetal_core__DOT___023425_)
                                             ? (IData)(wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023425_));
    vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___044856_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_h91f24ade__0)))))))))));
    vlSelf->wasmetal_core__DOT___044880_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_h91f24ade__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057532_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057284_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___012343_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff00aaaaULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___013002_ = (1U & (IData)(
                                                         (0x3355ff0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127622___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024044_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d) {
        vlSelf->wasmetal_core__DOT___024048_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024048_ = wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023921_;
    }
    vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023784_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127606___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023917_)))));
    vlSelf->__VdfgTmp_hefac2d69__0 = (((IData)(vlSelf->wasmetal_core__DOT___050073_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006602_));
    vlSelf->wasmetal_core__DOT____Vcellout___127433___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022503_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022502_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022501_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022500_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___022502_) 
                & (IData)(wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127433___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022558_)))));
    vlSelf->wasmetal_core__DOT___070669_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057898_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(wasmetal_core__DOT___057898_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057897_))))));
    wasmetal_core__DOT___057818_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_h5db557ff__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057771_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057770_))))));
    __VdfgTmp_hf266d7f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___057987_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hdf4f813b__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | 
                                         (1U & (IData)(
                                                       (0x11110f0fff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 5U) 
                                                         | ((0x10U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8c37f2ea__0))))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057790_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057917_))));
    wasmetal_core__DOT___057783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)
                                           ? (0xdd0f0fU 
                                              >> ((0x10U 
                                                   & ((0x8000U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                      << 4U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014103_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___014102_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & (((IData)(vlSelf->wasmetal_core__DOT___013734_)
                                                                 ? 
                                                                (0xeef0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014110_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xbfff8000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013738_)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xbfff800000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))))))))))
                                                                 : 
                                                                (0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014111_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___014109_))))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___013735_))))))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT___013780_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017830_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057783_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057992_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | 
                                         (1U & (IData)(
                                                       (0x11110f0fff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 5U) 
                                                         | ((0x10U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                                << 3U) 
                                                               | (IData)(__VdfgTmp_h1b18da23__0))))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057858_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058015_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | (IData)(wasmetal_core__DOT___057813_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057812_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057937_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017828_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057775_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057993_))));
    vlSelf->__VdfgTmp_he29625ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O))))));
    vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023547_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023558_)
            : (IData)(vlSelf->wasmetal_core__DOT___023547_));
    vlSelf->__VdfgTmp_hccfff196__0 = (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3f94b345__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057886_) 
                                       << 1U) | (1U 
                                                 & (0xefU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))))));
    vlSelf->wasmetal_core__DOT___017337_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057920_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057919_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013206_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013205_))));
    wasmetal_core__DOT___070667_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017385_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___057937_))));
    wasmetal_core__DOT___017368_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017385_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___013205_)
                                               ? (IData)(
                                                         (0xb0bbULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0)))
                                               : (IData)(
                                                         (0xf0ff4044ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___013205_)
                                               ? (IData)(
                                                         (0xbbbb00000b00ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0)))
                                               : (IData)(
                                                         (0xffff44440f000400ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017385_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057727_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017427_))));
    vlSelf->wasmetal_core__DOT___017203_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)
                                                         ? 
                                                        (0x355fcaaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((0x8000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                 << 3U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017256_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017255_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017254_))))))
                                                         : 
                                                        (9U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013787_)))) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h37ce14e0__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017410_))));
    vlSelf->wasmetal_core__DOT___043105_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058679_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057958_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___057960_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057967_)))))))));
    vlSelf->wasmetal_core__DOT___017371_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057960_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057958_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057816_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015668_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015637_))));
    vlSelf->__VdfgTmp_h12d5b185__0 = (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013319_));
    __VdfgTmp_h3814f5f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___013320_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013319_));
    vlSelf->wasmetal_core__DOT___017275_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013319_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017285_))));
    vlSelf->__VdfgTmp_h2c2f1e15__0 = (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_)))));
    vlSelf->wasmetal_core__DOT___015634_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013503_))))));
    __VdfgTmp_ha1eca74f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013505_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013216_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013503_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xff00ccccf0f0aaaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057723_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___057708_))))))))))))));
    vlSelf->wasmetal_core__DOT___057988_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013503_))))));
    vlSelf->wasmetal_core__DOT___013539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015637_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015636_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017141_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017234_ = (1U 
                                                & (0x1fffe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017246_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017245_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017244_)))))));
        vlSelf->wasmetal_core__DOT___017341_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017365_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017364_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017363_)))))));
        vlSelf->wasmetal_core__DOT___017231_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017251_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017250_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hfb436b73__0)))))))));
    } else {
        vlSelf->wasmetal_core__DOT___017234_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013798_))));
        vlSelf->wasmetal_core__DOT___017341_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013788_))));
        vlSelf->wasmetal_core__DOT___017231_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013771_))));
    }
    vlSelf->wasmetal_core__DOT___070668_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017231_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017234_))));
    vlSelf->wasmetal_core__DOT___017340_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014330_)
                                                   ? (IData)(
                                                             (0x800c40a02f531ULL 
                                                              >> 
                                                              (((IData)(wasmetal_core__DOT___017347_) 
                                                                << 5U) 
                                                               | (((IData)(wasmetal_core__DOT___017346_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017345_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017344_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017321_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___017332_))))))))
                                                   : 
                                                  (0x1248U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___017347_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___017346_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017345_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017344_)))))));
    vlSelf->wasmetal_core__DOT___043123_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017338_)))));
    vlSelf->wasmetal_core__DOT___043109_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___017347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058001_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017338_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017339_))));
    vlSelf->__VdfgTmp_hcc37b29f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d));
    vlSelf->wasmetal_core__DOT___017268_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017286_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017285_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017285_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017286_))));
    wasmetal_core__DOT___058673_ = ((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                    & (IData)((0xfffcffaaff00ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017226_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017224_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017223_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___017225_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057863_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015673_)))));
    vlSelf->wasmetal_core__DOT___015762_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00ccccf0f05555ULL 
                                                                       >> (IData)(__VdfgTmp_h6bdbc3d0__0)))))))));
    wasmetal_core__DOT___013498_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)((0xff33330f0faaaaULL 
                                               >> (IData)(__VdfgTmp_h6bdbc3d0__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___015665_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he88fe03e__0)));
        vlSelf->wasmetal_core__DOT___015657_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013336_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013335_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___006662_)
                                                                    ? 
                                                                   (0xeef0U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x2a2a3f003f003f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006151_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xaccc000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8744bfbd__0))))))))))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013343_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___013341_))))))))))));
        vlSelf->wasmetal_core__DOT___013508_ = (1U 
                                                & (IData)(
                                                          (0xff55ff33ff0fff00ULL 
                                                           >> (IData)(__VdfgTmp_ha1eca74f__0))));
        vlSelf->wasmetal_core__DOT___015765_ = (1U 
                                                & (IData)(
                                                          (0xaa00cc00f000ffULL 
                                                           >> (IData)(__VdfgTmp_ha1eca74f__0))));
    } else {
        vlSelf->wasmetal_core__DOT___015665_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006178_)));
        vlSelf->wasmetal_core__DOT___015657_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005823_)));
        vlSelf->wasmetal_core__DOT___013508_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013505_)));
        vlSelf->wasmetal_core__DOT___015765_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013505_)));
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) {
        wasmetal_core__DOT___058674_ = (1U & (0x355fcaaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((0x8000U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017214_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017213_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___017212_)))))));
        wasmetal_core__DOT___058676_ = (1U & (0xfcaa0355U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((0x8000U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017261_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017260_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___017259_)))))));
        vlSelf->wasmetal_core__DOT___017370_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017393_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017392_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___017272_)))))));
        vlSelf->wasmetal_core__DOT___017299_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017306_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017305_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017304_)))))));
    } else {
        wasmetal_core__DOT___058674_ = (1U & (9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___013737_))));
        wasmetal_core__DOT___058676_ = (1U & (9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___013778_))));
        vlSelf->wasmetal_core__DOT___017370_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014037_))));
        vlSelf->wasmetal_core__DOT___017299_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013918_))));
    }
    vlSelf->wasmetal_core__DOT___015666_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xaacc0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___013498_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006979_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057720_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057714_))))))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006151_))));
    vlSelf->wasmetal_core__DOT___043106_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057952_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057951_)))))))));
    vlSelf->wasmetal_core__DOT___017269_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057951_)))))))));
    vlSelf->__VdfgTmp_h9a784e39__0 = (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015646_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015648_))));
    vlSelf->wasmetal_core__DOT___043117_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017233_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5fa4cdd4__0))));
    __VdfgTmp_h6a06b08d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hc4d25f20__0));
    vlSelf->wasmetal_core__DOT___017372_ = (1U & (0x10010000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058682_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057945_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                              & (IData)(
                                                                        (0xffffffff40000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h479b81d6__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___015878_)) 
                                                                  & (IData)(
                                                                            (0xbfffffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017404_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013973_))))))))))))))));
    wasmetal_core__DOT___070666_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___017428_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___058016_))));
    vlSelf->wasmetal_core__DOT___017374_ = (1U & ((IData)(wasmetal_core__DOT___017428_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017427_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017427_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017428_))));
    vlSelf->__VdfgTmp_hc84aef23__0 = (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0));
    vlSelf->__VdfgTmp_he68a43c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017436_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017435_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015635_))));
    vlSelf->__VdfgTmp_h7d202e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013335_)));
    __VdfgTmp_hd4b8326f__0 = (((IData)(vlSelf->wasmetal_core__DOT___013336_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013335_));
    vlSelf->wasmetal_core__DOT___017276_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013335_))))));
    vlSelf->wasmetal_core__DOT___017270_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014330_)
                                                   ? (IData)(
                                                             (0x100320504fac8ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017273_) 
                                                                         << 2U) 
                                                                        | (((IData)(wasmetal_core__DOT___014102_) 
                                                                            << 1U) 
                                                                           | (IData)(wasmetal_core__DOT___017272_))))))))
                                                   : 
                                                  (0x1248U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017273_)))))));
    vlSelf->wasmetal_core__DOT___043069_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043073_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))))))))));
    vlSelf->wasmetal_core__DOT___057717_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___057695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)))));
    vlSelf->__VdfgTmp_h46c2cf96__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))));
    vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023426_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023437_)
            : (IData)(vlSelf->wasmetal_core__DOT___023426_));
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024048_;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023786_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d));
    vlSelf->__VdfgTmp_h85d2f38f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005896_));
    vlSelf->__VdfgTmp_h9333e746__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_hfab14cf6__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005962_));
    vlSelf->__VdfgTmp_h5c347c33__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hf9e966c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_hf92fc642__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)));
    vlSelf->__VdfgTmp_haf233eab__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022500_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O))));
    __VdfgTmp_hf9227657__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_hb47377e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___022503_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                       >> 3U))));
    vlSelf->wasmetal_core__DOT___023191_ = (1U & (0xf0f00ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))))));
    vlSelf->__VdfgTmp_hc322cfc1__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | (IData)(wasmetal_core__DOT___057818_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057817_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d 
        = (1U & (0xf800U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (IData)(__VdfgTmp_hf266d7f5__0))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135066___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023548_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023548_));
    vlSelf->__VdfgTmp_h6cc9accb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017337_) 
                                       << 1U) | (1U 
                                                 & (0xfdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057920_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057919_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___014330_))))))));
    vlSelf->wasmetal_core__DOT___043112_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013205_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057917_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070667_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___017368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058014_)))))))));
    vlSelf->__VdfgTmp_hb820c59b__0 = ((2U & ((0xefff10U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058013_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058011_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___058012_)))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___017368_));
    vlSelf->wasmetal_core__DOT___043118_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017341_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017203_))));
    vlSelf->wasmetal_core__DOT___043099_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057864_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(__VdfgTmp_h37ce14e0__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057875_)))))))));
    vlSelf->wasmetal_core__DOT___015633_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h12d5b185__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057776_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015658_)))));
    vlSelf->__VdfgTmp_he3b69f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057702_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h3814f5f0__0))));
    vlSelf->wasmetal_core__DOT___015777_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057702_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3814f5f0__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017275_))));
    vlSelf->wasmetal_core__DOT___017264_ = (1U & (0xf800U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057988_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_hf266d7f5__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057988_))));
    vlSelf->__VdfgTmp_h7c001b5f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d));
    vlSelf->__VdfgTmp_ha1f1e621__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d));
    vlSelf->wasmetal_core__DOT___043100_ = (1U & (0xf7755110U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058673_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057818_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___057813_)))))));
    vlSelf->wasmetal_core__DOT___017201_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058674_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058673_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((~ (IData)(vlSelf->wasmetal_core__DOT___015673_)) 
                                                              & (IData)(
                                                                        (0x11ff0fffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017226_) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h1b18da23__0))))))) 
                                                             << 2U)) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                              & (IData)(
                                                                        (0xfffcffaaff00ff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017220_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017218_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017217_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017219_))))))))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___015667_)) 
                                                                  & (IData)(
                                                                            (0x11ff0fffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017220_) 
                                                                               << 5U) 
                                                                              | ((0x10U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h5db557ff__0))))))))))))));
    vlSelf->__VdfgTmp_hb584f1fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___013498_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013549_)));
    vlSelf->wasmetal_core__DOT___013540_ = (1U & (IData)(
                                                         (0xfefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___013498_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6a06b08d__0)))))));
    vlSelf->wasmetal_core__DOT___058006_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h6a06b08d__0))));
    vlSelf->wasmetal_core__DOT___043125_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058017_)))));
    vlSelf->wasmetal_core__DOT___043111_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017427_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058015_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070666_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___058017_)))))))));
    vlSelf->wasmetal_core__DOT___017296_ = ((IData)(vlSelf->wasmetal_core__DOT___015665_) 
                                            & (IData)(
                                                      (0xfffcffaaff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0x8000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017318_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017316_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017315_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___017317_)))))))));
    vlSelf->__VdfgTmp_hb34385bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_)))));
    vlSelf->__VdfgTmp_h7f30fde6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he68a43c0__0)));
    vlSelf->wasmetal_core__DOT___043102_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057783_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___057775_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057780_)))))))));
    vlSelf->wasmetal_core__DOT___017204_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058676_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057783_)))));
    vlSelf->__VdfgTmp_hd1c7c886__0 = (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057784_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015657_)))));
    vlSelf->__VdfgTmp_h9cde2904__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057706_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hd4b8326f__0))));
    vlSelf->wasmetal_core__DOT___015776_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057706_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hd4b8326f__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017276_))));
    vlSelf->__VdfgTmp_h7a977bbe__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d));
    vlSelf->__VdfgTmp_hfe3e676b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d));
    vlSelf->__VdfgTmp_hb08bdf67__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d));
    vlSelf->wasmetal_core__DOT___051336_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d))));
    vlSelf->__VdfgTmp_h45b9122a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023427_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023427_));
    vlSelf->wasmetal_core__DOT____Vcellout___128866___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036407_)))));
    vlSelf->wasmetal_core__DOT___036411_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___027462_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127967___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           ^ (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027457_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127588___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023786_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023784_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023783_)))) 
           ^ (((IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023719_)))));
    vlSelf->wasmetal_core__DOT___023724_ = ((IData)(vlSelf->wasmetal_core__DOT___023787_)
                                             ? (IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d));
    vlSelf->wasmetal_core__DOT___023789_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d))));
    vlSelf->wasmetal_core__DOT___058909_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5220a2be__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)))))))))));
    vlSelf->wasmetal_core__DOT___058766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9333e746__0))))));
    vlSelf->wasmetal_core__DOT___023788_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d))));
    vlSelf->wasmetal_core__DOT___023791_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d))));
    vlSelf->wasmetal_core__DOT___058905_ = (1U & (IData)(
                                                         (0x700000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058899_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0)))))))))));
    wasmetal_core__DOT___058918_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0))))));
    wasmetal_core__DOT___058809_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                  << 2U)) 
                                           | ((4U & 
                                               ((4U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0))))))));
    vlSelf->wasmetal_core__DOT___023790_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d))));
    vlSelf->wasmetal_core__DOT___058882_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058803_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0))))))));
    vlSelf->wasmetal_core__DOT___006596_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf233eab__0))));
    vlSelf->wasmetal_core__DOT___023202_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_hf9227657__0)))))))
                                                   : 
                                                  (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf9227657__0))))));
    vlSelf->wasmetal_core__DOT___006597_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb47377e1__0))));
    vlSelf->wasmetal_core__DOT___006598_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023191_))));
    vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__ 
        = ((~ (0xeU >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
           & (IData)(vlSelf->wasmetal_core__DOT___023191_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135067___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))))))))))));
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023549_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023549_));
    vlSelf->wasmetal_core__DOT___017342_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015777_)
                                                   ? 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))
                                                   : 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015777_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_)))));
    __VdfgTmp_h08ed86fa__0 = ((2U & ((7U >> (((IData)(vlSelf->wasmetal_core__DOT___057987_) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___057988_) 
                                                 << 2U) 
                                                | (IData)(vlSelf->__VdfgTmp_hdf4f813b__0)))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___017264_));
    wasmetal_core__DOT___017293_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015666_)) 
                                          & (IData)(
                                                    (0x11ff0fffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                             << 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___017309_))))))))));
    wasmetal_core__DOT___017294_ = ((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                    & (IData)((0xfffcffaaff00ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017309_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017311_)))))))));
    vlSelf->__VdfgTmp_h10a18780__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->__VdfgTmp_hfcfb0a06__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015666_)))));
    vlSelf->wasmetal_core__DOT___043107_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((7U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017435_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017436_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057986_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (1U & (7U >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))))));
    wasmetal_core__DOT___017266_ = (1U & (0xfdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058005_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058004_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058003_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014330_)))))));
    wasmetal_core__DOT___017267_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h3e2b175e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058006_))));
    vlSelf->wasmetal_core__DOT___017375_ = (1U & ((1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017437_)) 
                                                   & (IData)(
                                                             (0x900990099009ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017437_)
                                                    ? 
                                                   (0x9009U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he68a43c0__0))
                                                    : (IData)(
                                                              (0x9009000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))));
    vlSelf->wasmetal_core__DOT___043120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017204_))));
    vlSelf->wasmetal_core__DOT___043097_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070669_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070668_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057891_)))))))));
    vlSelf->wasmetal_core__DOT___017232_ = (1U & (0xefff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057887_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057888_)))))));
    vlSelf->__VdfgTmp_h649aadfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_)))));
    vlSelf->wasmetal_core__DOT___043108_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057993_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057992_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017264_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017270_)))))))));
    vlSelf->wasmetal_core__DOT___036956_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___036955_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b50__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b49__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b44__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b43__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b42__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b41__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b40__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b39__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b38__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b37__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b36__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b35__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b30__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b29__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b28__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b27__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b26__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b25__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b24__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b23__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b21__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b19__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b18__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b17__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b16__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b14__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b12__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b11__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b10__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b9__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b8__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b7__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b6__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b5__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b4__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b3__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b2__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d)))))));
    vlSelf->__VdfgTmp_h9a302586__0 = (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051336_));
    vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___036954_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45b9122a__0))));
    vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128775___S 
        = ((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))) 
                  << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))) 
                                    << 2U)) | ((2U 
                                                & ((~ 
                                                    (6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))));
    vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d)));
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023428_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023428_));
    vlSelf->__VdfgTmp_ha7b11bb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O)))));
    vlSelf->__VdfgTmp_hf552ae6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036411_));
    vlSelf->wasmetal_core__DOT____Vcellout___127968___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                              >> 2U) 
                                             & ((IData)(wasmetal_core__DOT___027462_) 
                                                << 1U))) 
                             | (IData)(wasmetal_core__DOT___027462_)));
    vlSelf->__VdfgTmp_h1660624e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))));
    vlSelf->__VdfgTmp_habbe61e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d;
        wasmetal_core__DOT___023925_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___023925_ = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023788_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023724_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d));
    vlSelf->wasmetal_core__DOT___058920_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058919_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058918_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058811_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___006595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023202_))));
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023202_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127567___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023550_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023549_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023548_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023547_)))) 
           ^ (((IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023558_)))));
    vlSelf->wasmetal_core__DOT___023562_ = ((IData)(vlSelf->wasmetal_core__DOT___023550_)
                                             ? (IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023550_));
    vlSelf->wasmetal_core__DOT___043115_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0))));
    vlSelf->wasmetal_core__DOT___043096_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057885_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057894_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017342_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b33__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b31__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b48__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b46__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___043122_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h08ed86fa__0))));
    vlSelf->wasmetal_core__DOT___043101_ = (1U & (IData)(
                                                         (0xf4fff4f400ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057770_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___017293_)))))))));
    vlSelf->__VdfgTmp_h182596d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                       << 3U) | ((4U 
                                                  & (((~ (IData)(vlSelf->wasmetal_core__DOT___015665_)) 
                                                      & (IData)(
                                                                (0x11ff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017318_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h8c37f2ea__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___017293_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b47__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b45__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b15__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b13__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135069___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb788d21__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___043124_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017267_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017266_)))));
    vlSelf->wasmetal_core__DOT___043110_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017286_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017285_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058002_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057999_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___017267_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017268_)))))))));
    vlSelf->wasmetal_core__DOT___017205_ = ((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                            & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017269_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___017267_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___017266_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h08ed86fa__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b22__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b20__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___043116_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070668_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b34__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b32__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135073___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___036005_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b50__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___036004_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b49__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___035998_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071832_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b44__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___035997_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071831_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b43__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___035996_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b42__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___035995_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b41__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___035994_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071828_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b40__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___035993_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b39__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___035991_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071826_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b38__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___035990_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff0077ffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b37__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___035989_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b36__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___035988_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071823_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b35__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___035983_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b30__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___035982_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071817_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b29__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___035980_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071816_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b28__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___035979_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b27__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___035978_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071814_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b26__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___035977_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071813_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___035976_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b24__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___035975_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071811_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b23__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___035973_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b21__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___035971_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___035969_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071806_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___035968_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b17__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___035967_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071804_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b16__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___035965_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b14__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___035963_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b12__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___035962_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b11__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___035961_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071798_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___035960_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071797_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b9__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___036014_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b8__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___036013_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___036012_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b6__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___036011_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff00bbffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b5__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___036010_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071792_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b4__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___036003_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b3__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___035992_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b2__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d 
        = (1U & (0x4f44U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b53__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT___036006_ = (1U & (0xf8ff0700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071839_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b0__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)))) {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036954_)) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127550___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023429_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023428_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023427_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023426_)))) 
           ^ (((IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023437_)))));
    vlSelf->wasmetal_core__DOT___023441_ = ((IData)(vlSelf->wasmetal_core__DOT___023429_)
                                             ? (IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023429_));
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___044858_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044882_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d))))))));
    vlSelf->wasmetal_core__DOT___044859_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)))))))))));
    vlSelf->wasmetal_core__DOT___044883_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127623___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024048_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
    } else {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___023925_;
    }
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023789_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d));
    vlSelf->wasmetal_core__DOT___058923_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058921_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058920_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058813_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058811_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0))))));
    wasmetal_core__DOT____Vcellout___127607___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023921_)))));
    vlSelf->__VdfgTmp_h180177b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006595_));
    vlSelf->wasmetal_core__DOT____Vcellout___127519___O 
        = (((8U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023191_) 
                                          << 1U) | 
                                         (1U & (0xeU 
                                                >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (0xeU 
                                              >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___023277_ = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                                    & (IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))))));
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023551_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023562_)
            : (IData)(vlSelf->wasmetal_core__DOT___023551_));
    vlSelf->wasmetal_core__DOT___035986_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b33__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___035984_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b31__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___036002_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___036000_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071834_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b46__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___043119_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h182596d5__0))));
    vlSelf->wasmetal_core__DOT___036001_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b47__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___035999_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b45__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___035966_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071803_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b15__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___035964_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071801_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___035974_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___035972_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b20__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___035987_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b34__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___035985_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b32__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___036008_ = (1U & (0xf807U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0))))))));
    wasmetal_core__DOT___035981_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071789_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b1__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d)))))))));
    wasmetal_core__DOT___035970_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071788_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b0__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)))) {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
    } else {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036955_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___058532_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT___043070_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043074_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O))))));
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023430_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023441_)
            : (IData)(vlSelf->wasmetal_core__DOT___023430_));
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___044837_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044883_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044882_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044880_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044879_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044878_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044877_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044876_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044875_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044874_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044873_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044872_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044871_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044891_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044890_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044889_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044888_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044887_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044886_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044885_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044884_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044881_)
                                                                     ? 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044870_))
                                                                     : 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044881_)))
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044884_)))
                                                                   : 
                                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044885_)))
                                                                  : 
                                                                 (~ (IData)(vlSelf->wasmetal_core__DOT___044886_)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044863_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044864_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044865_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044866_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044867_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044847_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044848_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044849_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044850_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044851_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044852_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044853_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044854_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044855_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044856_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___044858_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___044859_)));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d) {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
    } else {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024052_;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023790_)
            ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d));
    vlSelf->wasmetal_core__DOT___060557_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___060543_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127607___O)))));
    vlSelf->wasmetal_core__DOT___058758_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->wasmetal_core__DOT___058761_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127607___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d))));
    vlSelf->__VdfgTmp_ha2ad37d5__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005996_));
    vlSelf->__VdfgTmp_h43f5f2ec__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_));
    vlSelf->wasmetal_core__DOT___006232_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))));
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)) 
           & (IData)(wasmetal_core__DOT___023277_));
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023552_)
            ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023552_));
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035970_) ? (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128789___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (((IData)(wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)))) {
        vlSelf->wasmetal_core__DOT___035869_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
        wasmetal_core__DOT___035753_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d;
        vlSelf->wasmetal_core__DOT___035725_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035869_ = wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___035753_ = wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035725_ = wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134179___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036956_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036955_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036954_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__) 
               << 3U) | ((IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__) 
                         << 2U)));
    vlSelf->wasmetal_core__DOT___036944_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036956_)
                                                   ? (IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128779___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128775___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->__VdfgTmp_h7cb02621__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051266_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 3U)))))));
    vlSelf->__VdfgTmp_hc2af737a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 2U)))))));
    __VdfgTmp_hfc488d72__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d));
    __VdfgTmp_h4fb57fe8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d));
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023431_)
            ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023431_));
    vlSelf->wasmetal_core__DOT____Vcellout___128867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036411_)))));
    vlSelf->wasmetal_core__DOT___036416_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
                                            & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048489_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___044837_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                                        >> 2U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            : (IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127589___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023791_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023790_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023789_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023788_)))) 
           ^ (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023724_)))));
    vlSelf->wasmetal_core__DOT___023728_ = ((IData)(vlSelf->wasmetal_core__DOT___023791_)
                                             ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d));
    vlSelf->wasmetal_core__DOT___023793_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d))));
    vlSelf->wasmetal_core__DOT___023792_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060543_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))));
    vlSelf->wasmetal_core__DOT___058875_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___058767_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058761_))));
    vlSelf->wasmetal_core__DOT___023795_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___023794_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d))));
    vlSelf->wasmetal_core__DOT___058874_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___058773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0))))));
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023235_) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127568___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023566_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023552_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023551_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023566_)
                       ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023566_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023562_)))));
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035981_) ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d));
    vlSelf->wasmetal_core__DOT___036960_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT___036959_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_hfc488d72__0))));
    if ((1U & (6U >> (IData)(__VdfgTmp_h4fb57fe8__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035869_;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___035753_;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035725_;
    }
    vlSelf->wasmetal_core__DOT___036958_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_hfc488d72__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT___036957_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_h4fb57fe8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    __VdfgTmp_h03eaf1be__0 = ((2U & ((~ (6U >> (IData)(__VdfgTmp_hfc488d72__0))) 
                                     << 1U)) | (1U 
                                                & (~ 
                                                   (6U 
                                                    >> (IData)(__VdfgTmp_h4fb57fe8__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127551___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023445_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023431_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023430_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023445_)
                       ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023445_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023441_)))));
    vlSelf->__VdfgTmp_h460f8c4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___060014_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036416_));
    vlSelf->wasmetal_core__DOT___053574_ = (1U & (IData)(
                                                         (0x8b8bff00bbbbff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053572_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___048489_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___053489_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048489_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->__VdfgTmp_h1205819c__0 = (((IData)(wasmetal_core__DOT___048489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009544_));
    vlSelf->wasmetal_core__DOT___007872_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009541_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048489_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127624___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024052_)))));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023792_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023728_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d));
    wasmetal_core__DOT____Vcellout___127608___O = (
                                                   ((4U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       : (IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023925_)))));
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h540d21cf__0 = ((2U & ((0x4fU 
                                              >> ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                           >> 3U))))) 
                                             << 1U)) 
                                      | (1U & (0x4fU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                            >> 2U)))))));
    vlSelf->wasmetal_core__DOT___005680_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005682_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_h59f45271__0 = ((8U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                >> 2U))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                 >> 1U)))));
    vlSelf->wasmetal_core__DOT___051264_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128795___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035992_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035981_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035970_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035936_ = ((IData)(vlSelf->wasmetal_core__DOT___035992_)
                                             ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d));
    if ((1U & (6U >> (IData)(__VdfgTmp_hfc488d72__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036957_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036944_)
                  : (6U >> (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128780___O 
        = ((IData)(__VdfgTmp_h03eaf1be__0) ^ (((((1U 
                                                  & (6U 
                                                     >> (IData)(__VdfgTmp_hfc488d72__0)))
                                                  ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)
                                                  : (IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__)) 
                                                << 2U) 
                                               | ((IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__) 
                                                  << 1U)) 
                                              | (IData)(wasmetal_core__DOT___035753_)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128776___S 
        = ((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))) 
                  << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))) 
                                    << 2U)) | (IData)(__VdfgTmp_h03eaf1be__0)));
    vlSelf->wasmetal_core__DOT___043071_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    vlSelf->wasmetal_core__DOT___043075_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    __VdfgTmp_hdfd93176__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                 >> 2U)))));
    __VdfgTmp_h898161e8__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                        >> 2U)) | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                      >> 1U))));
    __VdfgTmp_h838bb85c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d 
        = (1U & (0xbfff0000U >> ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT___048704_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__ 
        = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___019776_ = (1U & (IData)(
                                                         (0xf7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053573_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___019415_ = (1U & (IData)(
                                                         (0xffff0000bf000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_valid)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063363_)))))))));
    vlSelf->wasmetal_core__DOT___063397_ = (1U & (IData)(
                                                         (0xff00ff004f4f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x4f000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0fd0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063371_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063369_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053087_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052916_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051239_))));
    vlSelf->wasmetal_core__DOT___063403_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___053501_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1205819c__0))));
    vlSelf->__VdfgTmp_hb0e57990__0 = (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007872_));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023793_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d));
    vlSelf->__VdfgTmp_h5b8de47f__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006238_));
    vlSelf->__VdfgTmp_hab870e45__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127608___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006155_));
    vlSelf->__VdfgTmp_ha55183ab__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006159_));
    vlSelf->wasmetal_core__DOT____Vcellout___127526___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023241_) 
             << 3U) | ((4U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___023235_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023277_)))));
    vlSelf->wasmetal_core__DOT___023305_ = ((IData)(vlSelf->wasmetal_core__DOT___023241_) 
                                            & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h647f0add__0 = (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005683_));
    vlSelf->__VdfgTmp_hd339b1da__0 = (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005681_));
    vlSelf->wasmetal_core__DOT___005678_ = (1U & (0xf0d50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59f45271__0))));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036003_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035936_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036958_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(__VdfgTmp_hfc488d72__0))));
    vlSelf->wasmetal_core__DOT___015607_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___015606_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___051535_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005663_)
                                                   ? (IData)(
                                                             (0x3f01010101010101ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                                      << 3U) 
                                                                     | (IData)(__VdfgTmp_h898161e8__0))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(__VdfgTmp_h898161e8__0))));
    vlSelf->wasmetal_core__DOT___015613_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                     >> 3U) 
                                                    & (0xbfffffff00000000ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h838bb85c__0))))))));
    vlSelf->wasmetal_core__DOT___005686_ = (1U & (0x4000ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h838bb85c__0))))));
    vlSelf->__VdfgTmp_hb5be14c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                       << 5U) | ((0x1cU 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
}
