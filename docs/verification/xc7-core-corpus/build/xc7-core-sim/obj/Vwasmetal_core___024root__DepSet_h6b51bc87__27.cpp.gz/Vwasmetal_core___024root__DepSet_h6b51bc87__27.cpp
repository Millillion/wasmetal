#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__25(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__25\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___015659_;
    wasmetal_core__DOT___015659_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015679_;
    wasmetal_core__DOT___015679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015682_;
    wasmetal_core__DOT___015682_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015683_;
    wasmetal_core__DOT___015683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015687_;
    wasmetal_core__DOT___015687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015736_;
    wasmetal_core__DOT___015736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015759_;
    wasmetal_core__DOT___015759_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015766_;
    wasmetal_core__DOT___015766_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015767_;
    wasmetal_core__DOT___015767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015834_;
    wasmetal_core__DOT___015834_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015846_;
    wasmetal_core__DOT___015846_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015847_;
    wasmetal_core__DOT___015847_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015860_;
    wasmetal_core__DOT___015860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015869_;
    wasmetal_core__DOT___015869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015876_;
    wasmetal_core__DOT___015876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015902_;
    wasmetal_core__DOT___015902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015947_;
    wasmetal_core__DOT___015947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015948_;
    wasmetal_core__DOT___015948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017266_;
    wasmetal_core__DOT___017266_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017267_;
    wasmetal_core__DOT___017267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017293_;
    wasmetal_core__DOT___017293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017294_;
    wasmetal_core__DOT___017294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023277_;
    wasmetal_core__DOT___023277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023925_;
    wasmetal_core__DOT___023925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024052_;
    wasmetal_core__DOT___024052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027462_;
    wasmetal_core__DOT___027462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035753_;
    wasmetal_core__DOT___035753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045872_;
    wasmetal_core__DOT___045872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045873_;
    wasmetal_core__DOT___045873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045896_;
    wasmetal_core__DOT___045896_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045897_;
    wasmetal_core__DOT___045897_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058768_;
    wasmetal_core__DOT___058768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058774_;
    wasmetal_core__DOT___058774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058809_;
    wasmetal_core__DOT___058809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058908_;
    wasmetal_core__DOT___058908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058918_;
    wasmetal_core__DOT___058918_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127607___O;
    wasmetal_core__DOT____Vcellout___127607___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127608___O;
    wasmetal_core__DOT____Vcellout___127608___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h838bb85c__0;
    __VdfgTmp_h838bb85c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h08ed86fa__0;
    __VdfgTmp_h08ed86fa__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfc488d72__0;
    __VdfgTmp_hfc488d72__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4fb57fe8__0;
    __VdfgTmp_h4fb57fe8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h03eaf1be__0;
    __VdfgTmp_h03eaf1be__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf9227657__0;
    __VdfgTmp_hf9227657__0 = 0;
    CData/*2:0*/ __VdfgTmp_h898161e8__0;
    __VdfgTmp_h898161e8__0 = 0;
    CData/*3:0*/ __VdfgTmp_hdfd93176__0;
    __VdfgTmp_hdfd93176__0 = 0;
    CData/*5:0*/ __VdfgTmp_hf2bf1435__0;
    __VdfgTmp_hf2bf1435__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6b2d1b17__0;
    __VdfgTmp_h6b2d1b17__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5e2f8bee__0;
    __VdfgTmp_h5e2f8bee__0 = 0;
    CData/*3:0*/ __VdfgTmp_h19b58510__0;
    __VdfgTmp_h19b58510__0 = 0;
    CData/*1:0*/ __VdfgTmp_h91f24ade__0;
    __VdfgTmp_h91f24ade__0 = 0;
    // Body
    wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128244___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030275_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030274_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030273_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030272_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030207_)))));
    vlSelf->wasmetal_core__DOT___030211_ = ((IData)(vlSelf->wasmetal_core__DOT___030275_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d));
    vlSelf->wasmetal_core__DOT___044854_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha6d1ccdb__0)))))))))));
    vlSelf->wasmetal_core__DOT___044878_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha6d1ccdb__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d))))))));
    vlSelf->__VdfgTmp_h0f43979c__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027453_));
    vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027390_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b61__05d));
    vlSelf->__VdfgTmp_hf9e966c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_hf92fc642__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)));
    vlSelf->__VdfgTmp_haf233eab__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022500_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O))));
    __VdfgTmp_hf9227657__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_hb47377e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___022503_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                       >> 3U))));
    vlSelf->wasmetal_core__DOT___023191_ = (1U & (0xf0f00ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))))));
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023786_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d));
    vlSelf->__VdfgTmp_h85d2f38f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005896_));
    vlSelf->__VdfgTmp_h9333e746__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_hfab14cf6__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005962_));
    vlSelf->__VdfgTmp_h5c347c33__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023921_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024048_;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012305_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff00aaaaULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009832_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                >> 3U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___056420_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff55550f0f3333ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                           << 5U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff55550f0f3333ULL 
                                                                       >> 
                                                                       ((0x20U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                            << 5U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d))))))))))))));
    vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033473_));
    vlSelf->wasmetal_core__DOT___017342_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015777_)
                                                   ? 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))
                                                   : 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015777_)))));
    vlSelf->wasmetal_core__DOT___017299_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)
                                                   ? 
                                                  (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017306_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017305_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017304_))))))
                                                   : 
                                                  (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013918_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_)))));
    wasmetal_core__DOT___017293_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015666_)) 
                                          & (IData)(
                                                    (0x11ff0fffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                             << 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___017309_))))))))));
    wasmetal_core__DOT___017294_ = ((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                    & (IData)((0xfffcffaaff00ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017309_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017311_)))))))));
    vlSelf->__VdfgTmp_h10a18780__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->__VdfgTmp_hfcfb0a06__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015666_)))));
    vlSelf->wasmetal_core__DOT___043107_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((7U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017435_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017436_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057986_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (1U & (7U >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))))));
    wasmetal_core__DOT___017266_ = (1U & (0xfdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058005_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058004_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058003_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014330_)))))));
    wasmetal_core__DOT___017267_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h3e2b175e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058006_))));
    vlSelf->wasmetal_core__DOT___017375_ = (1U & ((1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017437_)) 
                                                   & (IData)(
                                                             (0x900990099009ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017437_)
                                                    ? 
                                                   (0x9009U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he68a43c0__0))
                                                    : (IData)(
                                                              (0x9009000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))));
    vlSelf->wasmetal_core__DOT___043120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017204_))));
    vlSelf->wasmetal_core__DOT___043097_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070669_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070668_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057891_)))))))));
    vlSelf->wasmetal_core__DOT___017232_ = (1U & (0xefff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057887_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057888_)))))));
    vlSelf->__VdfgTmp_h649aadfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_)))));
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023428_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023428_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135067___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___043108_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057993_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057992_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017264_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017270_)))))))));
    __VdfgTmp_h08ed86fa__0 = ((2U & ((7U >> (((IData)(vlSelf->wasmetal_core__DOT___057987_) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___057988_) 
                                                 << 2U) 
                                                | (IData)(vlSelf->__VdfgTmp_hdf4f813b__0)))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___017264_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___036956_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___036955_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___036954_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45b9122a__0))));
    vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128775___S 
        = ((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))) 
                  << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))) 
                                    << 2U)) | ((2U 
                                                & ((~ 
                                                    (6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))));
    vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d)));
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023549_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023549_));
    vlSelf->wasmetal_core__DOT____Vcellout___127882___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026722_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127882___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127882___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127882___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026722_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026721_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026720_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026719_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127882___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026652_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127933___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027192_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127933___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127933___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127933___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027192_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027191_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027190_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027189_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127933___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027122_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127916___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026992_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127916___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026992_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026991_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026990_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026989_)))) 
           ^ (((IData)(wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026922_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127899___CO 
        = ((((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)))
              ? (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127899___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___026856_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026855_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026854_)))) 
           ^ (((IData)(wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026787_)));
    vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030277_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030211_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d));
    vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027391_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b62__05d));
    vlSelf->wasmetal_core__DOT___006596_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf233eab__0))));
    vlSelf->wasmetal_core__DOT___023202_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_hf9227657__0)))))))
                                                   : 
                                                  (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf9227657__0))))));
    vlSelf->wasmetal_core__DOT___006597_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb47377e1__0))));
    vlSelf->wasmetal_core__DOT___006598_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023191_))));
    vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__ 
        = ((~ (0xeU >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
           & (IData)(vlSelf->wasmetal_core__DOT___023191_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127588___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023786_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023784_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023783_)))) 
           ^ (((IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023719_)))));
    vlSelf->wasmetal_core__DOT___023724_ = ((IData)(vlSelf->wasmetal_core__DOT___023787_)
                                             ? (IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d));
    vlSelf->wasmetal_core__DOT___023789_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d))));
    vlSelf->wasmetal_core__DOT___058909_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5220a2be__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)))))))))));
    vlSelf->wasmetal_core__DOT___058766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9333e746__0))))));
    vlSelf->wasmetal_core__DOT___023788_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d))));
    vlSelf->wasmetal_core__DOT___023791_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d))));
    vlSelf->wasmetal_core__DOT___058905_ = (1U & (IData)(
                                                         (0x700000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058899_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0)))))))))));
    wasmetal_core__DOT___058918_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0))))));
    wasmetal_core__DOT___058809_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                  << 2U)) 
                                           | ((4U & 
                                               ((4U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0))))))));
    vlSelf->wasmetal_core__DOT___023790_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d))));
    vlSelf->wasmetal_core__DOT___058882_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058803_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128866___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036407_)))));
    vlSelf->wasmetal_core__DOT___036411_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___043115_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0))));
    vlSelf->wasmetal_core__DOT___043096_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057885_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057894_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017342_)))))))));
    vlSelf->wasmetal_core__DOT___043101_ = (1U & (IData)(
                                                         (0xf4fff4f400ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057770_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___017293_)))))))));
    vlSelf->__VdfgTmp_h182596d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                       << 3U) | ((4U 
                                                  & (((~ (IData)(vlSelf->wasmetal_core__DOT___015665_)) 
                                                      & (IData)(
                                                                (0x11ff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017318_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h8c37f2ea__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___017293_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135069___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb788d21__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___043124_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017267_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017266_)))));
    vlSelf->wasmetal_core__DOT___043110_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017286_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017285_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058002_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057999_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___017267_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017268_)))))))));
    vlSelf->wasmetal_core__DOT___043116_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070668_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135073___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127550___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023429_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023428_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023427_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023426_)))) 
           ^ (((IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023437_)))));
    vlSelf->wasmetal_core__DOT___023441_ = ((IData)(vlSelf->wasmetal_core__DOT___023429_)
                                             ? (IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023429_));
    vlSelf->wasmetal_core__DOT___043122_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h08ed86fa__0))));
    vlSelf->wasmetal_core__DOT___017205_ = ((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                            & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017269_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___017267_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___017266_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h08ed86fa__0))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)))) {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036954_)) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127567___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023550_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023549_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023548_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023547_)))) 
           ^ (((IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023558_)))));
    vlSelf->wasmetal_core__DOT___023562_ = ((IData)(vlSelf->wasmetal_core__DOT___023550_)
                                             ? (IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023550_));
    vlSelf->wasmetal_core__DOT___071908_ = (1U & (0x1000afbfU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___CO) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__decoded_table)))))));
    vlSelf->wasmetal_core__DOT___045015_ = (1U & (IData)(
                                                         (0xfcfc4054fcfcfcfcULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___CO) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0xaf3f0000U 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054247_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___071338_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071337_))));
    vlSelf->wasmetal_core__DOT___054450_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___045219_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045243_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___054446_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054448_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___044947_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___044971_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___054445_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054447_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___045872_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbd97d07b__0)))))));
    wasmetal_core__DOT___045873_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045897_ = (1U & (0x41000041U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                  << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                           >> 2U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045896_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030278_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d));
    wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___006595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023202_))));
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023202_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d;
        wasmetal_core__DOT___023925_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___023925_ = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023788_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023724_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d));
    vlSelf->wasmetal_core__DOT___058920_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058919_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058918_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058811_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_ha7b11bb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O)))));
    vlSelf->__VdfgTmp_hf552ae6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036411_));
    vlSelf->wasmetal_core__DOT____Vcellout___128547___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                & (IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033473_)))));
    vlSelf->wasmetal_core__DOT___043119_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h182596d5__0))));
    vlSelf->wasmetal_core__DOT___058532_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O))))));
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023430_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023441_)
            : (IData)(vlSelf->wasmetal_core__DOT___023430_));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)))) {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
    } else {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036955_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___043070_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043074_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))))));
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023551_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023562_)
            : (IData)(vlSelf->wasmetal_core__DOT___023551_));
    vlSelf->wasmetal_core__DOT___045039_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071908_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___071339_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071338_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___070777_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___070880_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___045851_ = ((IData)(wasmetal_core__DOT___045897_)
                                             ? ((IData)(wasmetal_core__DOT___045896_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045894_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045893_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045892_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045891_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045890_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045889_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045888_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045887_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045886_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045885_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045905_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045904_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045903_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045902_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045901_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045900_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045899_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045898_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045895_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045884_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045860_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045871_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045874_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045875_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045876_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045877_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045878_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045879_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045880_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045881_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045861_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045862_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045863_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045864_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045865_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045866_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045867_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045868_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045869_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045870_))
                                                 : (IData)(wasmetal_core__DOT___045872_))
                                             : (IData)(wasmetal_core__DOT___045873_));
    vlSelf->wasmetal_core__DOT____Vcellout___128245___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030280_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030279_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030278_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030277_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030279_)
                 ? (IData)(wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030211_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127966___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
           ^ (((IData)(wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027453_)))));
    vlSelf->wasmetal_core__DOT___027457_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127950___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027392_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127950___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027392_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027391_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027390_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027389_)))) 
           ^ (((IData)(wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027322_)));
    vlSelf->__VdfgTmp_h180177b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006595_));
    vlSelf->wasmetal_core__DOT____Vcellout___127519___O 
        = (((8U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023191_) 
                                          << 1U) | 
                                         (1U & (0xeU 
                                                >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (0xeU 
                                              >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___023277_ = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                                    & (IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127623___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024048_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
    } else {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___023925_;
    }
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023789_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d));
    vlSelf->wasmetal_core__DOT___058923_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058921_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058920_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058813_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058811_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0))))));
    wasmetal_core__DOT____Vcellout___127607___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023921_)))));
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057532_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057284_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___012343_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff00aaaaULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___013002_ = (1U & (IData)(
                                                         (0x3355ff0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                             >> 3U))))))))));
    vlSelf->__VdfgTmp_h7cb02621__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051266_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 3U)))))));
    vlSelf->__VdfgTmp_hc2af737a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 2U)))))));
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023431_)
            ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023431_));
    vlSelf->wasmetal_core__DOT____Vcellout___128789___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (((IData)(wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)))) {
        vlSelf->wasmetal_core__DOT___035869_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
        wasmetal_core__DOT___035753_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d;
        vlSelf->wasmetal_core__DOT___035725_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035869_ = wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___035753_ = wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035725_ = wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134179___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036956_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036955_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036954_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__) 
               << 3U) | ((IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__) 
                         << 2U)));
    vlSelf->wasmetal_core__DOT___036944_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036956_)
                                                   ? (IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128779___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128775___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    __VdfgTmp_hfc488d72__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d));
    __VdfgTmp_h4fb57fe8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d));
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023552_)
            ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023552_));
    vlSelf->wasmetal_core__DOT___045038_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___045014_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054241_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071337_))))));
    vlSelf->wasmetal_core__DOT___070779_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070778_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___070882_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070881_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___053957_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045851_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052649_)))));
    vlSelf->wasmetal_core__DOT___044855_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)))))))))));
    vlSelf->wasmetal_core__DOT___044879_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d)))))))));
    __VdfgTmp_h91f24ade__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___063348_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063350_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063352_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063354_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027457_));
    vlSelf->wasmetal_core__DOT___006232_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))));
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)) 
           & (IData)(wasmetal_core__DOT___023277_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d) {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
    } else {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024052_;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023790_)
            ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d));
    vlSelf->wasmetal_core__DOT___060557_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___060543_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127607___O)))));
    vlSelf->wasmetal_core__DOT___058758_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->wasmetal_core__DOT___058761_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127607___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d))));
    vlSelf->__VdfgTmp_ha2ad37d5__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005996_));
    vlSelf->__VdfgTmp_h43f5f2ec__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_));
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___036960_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127551___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023445_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023431_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023430_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023445_)
                       ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023445_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023441_)))));
    vlSelf->wasmetal_core__DOT___036959_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_hfc488d72__0))));
    if ((1U & (6U >> (IData)(__VdfgTmp_h4fb57fe8__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035869_;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___035753_;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035725_;
    }
    vlSelf->wasmetal_core__DOT___036958_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_hfc488d72__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT___036957_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_h4fb57fe8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    __VdfgTmp_h03eaf1be__0 = ((2U & ((~ (6U >> (IData)(__VdfgTmp_hfc488d72__0))) 
                                     << 1U)) | (1U 
                                                & (~ 
                                                   (6U 
                                                    >> (IData)(__VdfgTmp_h4fb57fe8__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127568___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023566_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023552_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023551_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023566_)
                       ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023566_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023562_)))));
    vlSelf->wasmetal_core__DOT___044993_ = ((IData)(vlSelf->wasmetal_core__DOT___045039_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045038_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045036_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045035_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045034_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045033_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045032_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045031_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045030_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045029_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045028_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045027_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045047_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045046_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045045_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045044_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045043_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045042_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045041_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045040_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045037_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045026_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045002_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045013_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045016_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045017_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045018_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045019_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045020_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045021_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045022_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045023_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045003_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045004_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045005_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045006_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045007_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045008_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045009_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045010_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045011_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045012_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045014_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045015_));
    vlSelf->wasmetal_core__DOT___045242_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___045218_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070779_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___044970_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___044946_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070882_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___044856_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_h91f24ade__0)))))))))));
    vlSelf->wasmetal_core__DOT___044880_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_h91f24ade__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023235_) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            : (IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127589___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023791_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023790_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023789_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023788_)))) 
           ^ (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023724_)))));
    vlSelf->wasmetal_core__DOT___023728_ = ((IData)(vlSelf->wasmetal_core__DOT___023791_)
                                             ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d));
    vlSelf->wasmetal_core__DOT___023793_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d))));
    vlSelf->wasmetal_core__DOT___023792_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060543_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))));
    vlSelf->wasmetal_core__DOT___058875_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___058767_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058761_))));
    vlSelf->wasmetal_core__DOT___023795_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___023794_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d))));
    vlSelf->wasmetal_core__DOT___058874_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___058773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036411_)))));
    vlSelf->wasmetal_core__DOT___036416_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
                                            & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__));
    __VdfgTmp_hdfd93176__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                 >> 2U)))));
    __VdfgTmp_h898161e8__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                        >> 2U)) | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                      >> 1U))));
    __VdfgTmp_h838bb85c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d 
        = (1U & (0xbfff0000U >> ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT___048704_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))));
    if ((1U & (6U >> (IData)(__VdfgTmp_hfc488d72__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036957_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036944_)
                  : (6U >> (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128780___O 
        = ((IData)(__VdfgTmp_h03eaf1be__0) ^ (((((1U 
                                                  & (6U 
                                                     >> (IData)(__VdfgTmp_hfc488d72__0)))
                                                  ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)
                                                  : (IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__)) 
                                                << 2U) 
                                               | ((IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__) 
                                                  << 1U)) 
                                              | (IData)(wasmetal_core__DOT___035753_)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128776___S 
        = ((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))) 
                  << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))) 
                                    << 2U)) | (IData)(__VdfgTmp_h03eaf1be__0)));
    vlSelf->wasmetal_core__DOT___043071_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    vlSelf->wasmetal_core__DOT___043075_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    vlSelf->__VdfgTmp_h540d21cf__0 = ((2U & ((0x4fU 
                                              >> ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                           >> 3U))))) 
                                             << 1U)) 
                                      | (1U & (0x4fU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                            >> 2U)))))));
    vlSelf->wasmetal_core__DOT___005680_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005682_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_h59f45271__0 = ((8U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                >> 2U))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                 >> 1U)))));
    vlSelf->wasmetal_core__DOT___051264_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O))))));
    vlSelf->wasmetal_core__DOT___045197_ = ((IData)(vlSelf->wasmetal_core__DOT___045243_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045242_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045240_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045239_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045238_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045237_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045236_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045235_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045234_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045233_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045232_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045231_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045251_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045250_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045249_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045248_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045247_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045246_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045245_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045244_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045241_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045230_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045206_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045217_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045220_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045221_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045222_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045223_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045224_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045225_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045226_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045227_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045207_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045208_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045209_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045210_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045211_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045212_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045213_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045214_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045215_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045216_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045218_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045219_));
    vlSelf->wasmetal_core__DOT___044925_ = ((IData)(vlSelf->wasmetal_core__DOT___044971_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044970_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044968_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044967_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044966_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044965_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044964_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044963_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044962_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044961_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044960_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044959_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044979_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044978_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044977_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044976_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044975_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044974_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044973_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044972_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044969_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___044958_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___044934_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044945_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044948_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044949_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044950_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044951_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044952_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044953_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044954_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044955_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044935_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044936_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044937_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044938_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044939_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044940_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044941_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044942_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044943_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044944_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044946_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044947_));
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127624___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024052_)))));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023792_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023728_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d));
    wasmetal_core__DOT____Vcellout___127608___O = (
                                                   ((4U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       : (IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023925_)))));
    vlSelf->__VdfgTmp_h460f8c4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___060014_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036416_));
    vlSelf->wasmetal_core__DOT___015607_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___015606_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___051535_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005663_)
                                                   ? (IData)(
                                                             (0x3f01010101010101ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                                      << 3U) 
                                                                     | (IData)(__VdfgTmp_h898161e8__0))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(__VdfgTmp_h898161e8__0))));
    vlSelf->wasmetal_core__DOT___015613_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                     >> 3U) 
                                                    & (0xbfffffff00000000ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h838bb85c__0))))))));
    vlSelf->wasmetal_core__DOT___005686_ = (1U & (0x4000ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h838bb85c__0))))));
    vlSelf->__VdfgTmp_hb5be14c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                       << 5U) | ((0x1cU 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___018504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d 
        = (1U & (0x4fcfcfcU >> (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036958_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(__VdfgTmp_hfc488d72__0))));
    vlSelf->__VdfgTmp_h647f0add__0 = (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005683_));
    vlSelf->__VdfgTmp_hd339b1da__0 = (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005681_));
    vlSelf->wasmetal_core__DOT___005678_ = (1U & (0xf0d50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59f45271__0))));
    vlSelf->__VdfgTmp_h97610f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051264_));
    vlSelf->wasmetal_core__DOT___036647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d))));
    vlSelf->wasmetal_core__DOT___051203_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045197_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___050371_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044925_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                            >> 3U))))));
    wasmetal_core__DOT___027462_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127967___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           ^ (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027457_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127526___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023241_) 
             << 3U) | ((4U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___023235_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023277_)))));
    vlSelf->wasmetal_core__DOT___023305_ = ((IData)(vlSelf->wasmetal_core__DOT___023241_) 
                                            & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023793_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d));
    vlSelf->__VdfgTmp_h5b8de47f__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006238_));
    vlSelf->__VdfgTmp_hab870e45__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127608___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006155_));
    vlSelf->__VdfgTmp_ha55183ab__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006159_));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__ 
        = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h1a6a5523__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015607_));
    __VdfgTmp_h6b2d1b17__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_)));
    __VdfgTmp_h5e2f8bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_))));
    wasmetal_core__DOT___015759_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___015634_));
    __VdfgTmp_h19b58510__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_))));
    vlSelf->__VdfgTmp_h5ba5065d__0 = (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                       << 1U) | (1U 
                                                 & (0x80U 
                                                    >> 
                                                    ((4U 
                                                      & ((0xf0d5U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h540d21cf__0)))));
    vlSelf->wasmetal_core__DOT___017325_ = (1U & (0x2b00d4ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf0d5U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058677_))))));
    vlSelf->wasmetal_core__DOT___058269_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))))));
    vlSelf->wasmetal_core__DOT___015730_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))))));
    vlSelf->wasmetal_core__DOT___058221_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___058226_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015651_)))))));
    vlSelf->wasmetal_core__DOT___058245_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_h6d3ce6b7__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015763_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015613_));
    wasmetal_core__DOT___015876_ = (1U & (0x503U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h9a784e39__0)))));
    if (vlSelf->wasmetal_core__DOT___015613_) {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h46ff4218__0)))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0)))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0)))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb34385bd__0)))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015636_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015635_))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___015651_)));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x23U >> (IData)(vlSelf->__VdfgTmp_h7d202e30__0)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015611_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___015610_)))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015622_)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015612_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h12d5b185__0)))));
        wasmetal_core__DOT___015736_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015621_)) 
                                              & (0xfdfU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h12c4c12e__0))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006651_)))));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015614_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015724_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015719_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015698_;
        wasmetal_core__DOT___015869_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015697_));
        vlSelf->wasmetal_core__DOT___015910_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___015897_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015762_));
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015656_))))));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xc0afU 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
    } else {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015676_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015673_))))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015674_))))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015666_))))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015637_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015654_));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x203U >> (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015621_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h514789fb__0)))));
            wasmetal_core__DOT___015869_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015621_)));
            wasmetal_core__DOT___015869_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___015781_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7d202e30__0))));
        wasmetal_core__DOT___015736_ = (1U & (0x23U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013466_)))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0xe0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc4d25f20__0)))));
        vlSelf->wasmetal_core__DOT___015604_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015614_));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015724_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015719_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015698_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015697_;
        vlSelf->wasmetal_core__DOT___015910_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015633_));
        vlSelf->wasmetal_core__DOT___015897_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xafcfU 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
    }
    vlSelf->__VdfgTmp_hffe7d15f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    __VdfgTmp_hf2bf1435__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    vlSelf->wasmetal_core__DOT___058243_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0))))))));
    vlSelf->wasmetal_core__DOT___016018_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0))))))));
    vlSelf->wasmetal_core__DOT___015992_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015676_)))))))));
    wasmetal_core__DOT___015847_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xf0f5555333300ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->wasmetal_core__DOT___016043_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015771_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h20099147__0))))))));
    vlSelf->wasmetal_core__DOT___016020_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff55550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015665_)))))))));
    vlSelf->wasmetal_core__DOT___015994_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015848_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb34385bd__0))))))));
    vlSelf->wasmetal_core__DOT___058244_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___015818_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0))))))));
    vlSelf->wasmetal_core__DOT___016116_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015671_)))))))));
    wasmetal_core__DOT___015948_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0))))))));
    vlSelf->wasmetal_core__DOT___015926_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015928_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0))))))));
    vlSelf->wasmetal_core__DOT___015909_ = (1U & (IData)(
                                                         (0xfff8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))))));
    vlSelf->wasmetal_core__DOT___015896_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015635_))))));
    vlSelf->wasmetal_core__DOT___058246_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))));
    vlSelf->wasmetal_core__DOT___015605_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015634_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015633_)));
    vlSelf->wasmetal_core__DOT___015943_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015762_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015634_)));
    vlSelf->__VdfgTmp_hf420cd01__0 = (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_));
    wasmetal_core__DOT___015834_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015671_))))));
    wasmetal_core__DOT___015679_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015677_))))));
    wasmetal_core__DOT___015902_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015667_))))));
    wasmetal_core__DOT___015766_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0)))));
    wasmetal_core__DOT___015767_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015665_))))));
    vlSelf->wasmetal_core__DOT___015603_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))));
    wasmetal_core__DOT___015682_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    wasmetal_core__DOT___015683_ = (1U & (IData)((0xf3f5f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    vlSelf->wasmetal_core__DOT___015684_ = (1U & (IData)(
                                                         (0xf3f5f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___015659_ = ((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013508_));
    vlSelf->wasmetal_core__DOT___016021_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                   >> 1U) 
                                                  & (IData)(
                                                            (0x7000000000000ULL 
                                                             >> 
                                                             ((0x30U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))))))))));
    vlSelf->__VdfgTmp_h1a0326f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_));
    wasmetal_core__DOT___015860_ = (1U & (IData)((0x550f33ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015656_)))))))));
    vlSelf->wasmetal_core__DOT___015597_ = (1U & (IData)(
                                                         (0xbfff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048132_)))))))));
    vlSelf->wasmetal_core__DOT___015596_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT___015594_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_)))));
    vlSelf->wasmetal_core__DOT___017936_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018504_))));
    vlSelf->wasmetal_core__DOT___017193_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___058529_ = (1U & (1U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___043072_ = (1U & (IData)(
                                                         (0x5757577f01010115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf0d5U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h540d21cf__0))))))));
    vlSelf->wasmetal_core__DOT___017196_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf0d5U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))));
    vlSelf->wasmetal_core__DOT___043076_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x700000000070ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0x3300000000700000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x7000088888fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0xcc00000000070000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))));
    vlSelf->wasmetal_core__DOT___006589_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)
                                                   ? (IData)(
                                                             (0xfff03330aaa02220ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005687_))))));
    vlSelf->wasmetal_core__DOT___005679_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005689_)) 
                                                  & (IData)(
                                                            (0xfc54f000f000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005686_))))))))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128790___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035869_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)))) {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036959_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__)
                  : (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128776___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035725_)))));
    vlSelf->wasmetal_core__DOT___049341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))))));
    vlSelf->__VdfgTmp_hfa042eae__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0))));
    vlSelf->__VdfgTmp_h07e5b5ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005677_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d 
        = (1U & (IData)((0x111f111f111fffffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd339b1da__0))))))));
    vlSelf->wasmetal_core__DOT___058087_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005678_))));
    vlSelf->wasmetal_core__DOT___036961_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036647_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___067605_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054478_))))));
    vlSelf->wasmetal_core__DOT___068554_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067748_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068019_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068078_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068154_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068239_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068292_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068346_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068401_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067896_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067962_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067809_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068425_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068477_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068103_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___063790_ = (1U & (IData)(
                                                         (0xc5f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048277_)))))))));
    vlSelf->wasmetal_core__DOT___068606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054478_))));
    vlSelf->wasmetal_core__DOT___065935_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066080_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067311_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065799_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066398_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066524_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066646_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066768_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066892_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065410_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065186_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065697_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066275_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066312_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066851_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067453_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065895_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067341_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066122_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064896_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065061_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065300_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067074_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067152_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067193_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066969_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067479_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064729_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064464_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050371_)))));
    vlSelf->wasmetal_core__DOT___050383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050371_))));
    vlSelf->wasmetal_core__DOT___067604_ = (1U & (0xf00088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x39U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___053362_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050382_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127968___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                              >> 2U) 
                                             & ((IData)(wasmetal_core__DOT___027462_) 
                                                << 1U))) 
                             | (IData)(wasmetal_core__DOT___027462_)));
    vlSelf->__VdfgTmp_h1660624e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))));
    vlSelf->__VdfgTmp_habbe61e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___005977_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xff03fe02ff03aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))));
    vlSelf->wasmetal_core__DOT___006038_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))));
    vlSelf->wasmetal_core__DOT___006039_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xff03fe02ff03aaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023305_));
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023794_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d));
    vlSelf->wasmetal_core__DOT___023799_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d))));
    vlSelf->wasmetal_core__DOT___023798_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))));
    wasmetal_core__DOT___058908_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))));
    wasmetal_core__DOT___058768_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058760_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058759_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)))))))))));
    vlSelf->wasmetal_core__DOT___023797_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))));
    vlSelf->wasmetal_core__DOT___058876_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___058912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)))))))));
    wasmetal_core__DOT___058774_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0))))));
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058267_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))));
    vlSelf->wasmetal_core__DOT___015949_ = (1U & (0x3f0050U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h6b2d1b17__0)))));
    vlSelf->wasmetal_core__DOT___017300_ = ((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015828_)
                                                ? (IData)(
                                                          (0xfcff0000aaffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))
                                                : (IData)(
                                                          (0xffff0300ffff5500ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))));
    if (vlSelf->wasmetal_core__DOT___015606_) {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015645_))))));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015834_));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015679_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0)))));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015766_));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015902_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
    } else {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015636_))))));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015834_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015902_));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015657_))))));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015766_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3f94b345__0)))));
    }
    vlSelf->wasmetal_core__DOT___015982_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> (IData)(__VdfgTmp_hf2bf1435__0))));
    vlSelf->wasmetal_core__DOT___058276_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058245_)))));
    vlSelf->__VdfgTmp_hf69e15ee__0 = (((IData)(wasmetal_core__DOT___015847_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015846_));
    vlSelf->__VdfgTmp_h0dbc0f0f__0 = (((IData)(wasmetal_core__DOT___015846_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015847_));
    vlSelf->__VdfgTmp_hcaafbee5__0 = (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016044_));
    vlSelf->__VdfgTmp_h70395930__0 = (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016043_));
    vlSelf->wasmetal_core__DOT___016122_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015772_))));
    vlSelf->wasmetal_core__DOT___015953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015948_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015947_))));
    vlSelf->__VdfgTmp_h0d424198__0 = (((IData)(wasmetal_core__DOT___015947_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015948_));
    vlSelf->__VdfgTmp_ha6796979__0 = (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058246_));
    vlSelf->wasmetal_core__DOT___058224_ = (1U & (0xeef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0aaaaccccff00ULL 
                                                                   >> (IData)(__VdfgTmp_hf2bf1435__0))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015606_))))));
    vlSelf->__VdfgTmp_ha298e6e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___015878_)))));
    vlSelf->wasmetal_core__DOT___058286_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_hc102c9b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015602_));
    vlSelf->__VdfgTmp_hd3573026__0 = (((IData)(wasmetal_core__DOT___015736_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015735_));
    vlSelf->__VdfgTmp_h7f4536ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015736_));
    vlSelf->__VdfgTmp_he2a347e4__0 = (((IData)(wasmetal_core__DOT___015687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015686_));
    vlSelf->__VdfgTmp_h12dd4af8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015867_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015839_));
    vlSelf->__VdfgTmp_hc3174423__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015687_));
    vlSelf->__VdfgTmp_h29141d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015688_));
    if (vlSelf->wasmetal_core__DOT___015607_) {
        vlSelf->wasmetal_core__DOT___015850_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015867_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015868_))));
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015602_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___015850_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___015869_))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h649aadfd__0)))));
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015603_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015737_))))));
    }
    vlSelf->__VdfgTmp_h7369d2e1__0 = ((2U & ((IData)(
                                                     (0xf0f335500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                              << 3U) 
                                                             | (((IData)(wasmetal_core__DOT___015869_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h649aadfd__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h20099147__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015678_))))))));
    vlSelf->__VdfgTmp_h766529e2__0 = (((IData)(wasmetal_core__DOT___015869_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015868_));
    vlSelf->wasmetal_core__DOT___016030_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___015683_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___015682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015689_)))))));
    vlSelf->__VdfgTmp_ha302ee77__0 = (((IData)(wasmetal_core__DOT___015683_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015682_));
    vlSelf->wasmetal_core__DOT___015816_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f55553333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->__VdfgTmp_h36951d10__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                        & (IData)((0xfff0fff0ffff1111ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                        << 4U) 
                                                       | (((IData)(wasmetal_core__DOT___015683_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___015682_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3f94b345__0))))
                                                     : (IData)(wasmetal_core__DOT___015679_))));
    vlSelf->wasmetal_core__DOT___016046_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55553333ff00ff0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015950_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0))))))));
    vlSelf->wasmetal_core__DOT___015831_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015659_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015658_))))));
    vlSelf->__VdfgTmp_h6c8cc102__0 = ((2U & ((0x3050000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                         & (IData)(
                                                   (0xff33330f0f5555ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015763_))))))))));
    vlSelf->wasmetal_core__DOT___015969_ = (IData)(
                                                   ((0xcU 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015851_ = (IData)(
                                                   ((4U 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015927_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___015860_));
    vlSelf->wasmetal_core__DOT___058326_ = (1U & (IData)(
                                                         (0x3a00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))))));
    vlSelf->wasmetal_core__DOT___058260_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058226_)))));
    vlSelf->wasmetal_core__DOT___015995_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3f005000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h6b2d1b17__0)))))));
    vlSelf->wasmetal_core__DOT___016132_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___015736_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))))));
    vlSelf->wasmetal_core__DOT___016125_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))))));
    vlSelf->__VdfgTmp_h2acad42a__0 = ((2U & ((IData)(
                                                     (0xf0fff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___015602_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))
                                                : (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___015687_))))))));
    vlSelf->wasmetal_core__DOT___016072_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058246_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))))));
    vlSelf->wasmetal_core__DOT___016063_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015981_))))));
    vlSelf->__VdfgTmp_h2eec3533__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                       ? 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))
                                                       : 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015648_)))))) 
                                                     << 1U)) 
                                                 | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    & (IData)(
                                                              (0x5555333300ff0f0fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))))));
    vlSelf->wasmetal_core__DOT___058253_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))));
    vlSelf->__VdfgTmp_h2900ee3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0)))))));
    vlSelf->wasmetal_core__DOT___015840_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015839_))))));
    vlSelf->wasmetal_core__DOT___015806_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015686_))))));
    vlSelf->__VdfgTmp_h75158e97__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d));
    vlSelf->__VdfgTmp_h8e7aae2a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))));
    vlSelf->wasmetal_core__DOT___019014_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017936_))));
    vlSelf->__VdfgTmp_hf6eff41b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017193_));
    vlSelf->wasmetal_core__DOT___018505_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10000000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 4U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                            | ((4U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058529_))));
    vlSelf->wasmetal_core__DOT___058531_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058529_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___043068_ = ((IData)(vlSelf->wasmetal_core__DOT___043076_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043075_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043074_)
                                                  ? 
                                                 ((~ (IData)(vlSelf->wasmetal_core__DOT___043073_)) 
                                                  & (IData)(vlSelf->wasmetal_core__DOT___043069_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043070_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043071_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043072_));
    vlSelf->wasmetal_core__DOT___017411_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043073_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043075_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043076_))))));
    vlSelf->wasmetal_core__DOT___058093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT___036647_) {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035873_;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035729_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134180___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036960_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036959_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036958_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036957_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036944_)))));
    vlSelf->wasmetal_core__DOT___036948_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036960_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___006583_ = (1U & (IData)(
                                                         (0xeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0))))))));
    vlSelf->wasmetal_core__DOT___005666_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005683_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005679_))
                                                   : (IData)(
                                                             (0xf0f0f0f0f0f0f01ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0)))))))));
    vlSelf->wasmetal_core__DOT___058086_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135064___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___058089_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049341_))));
    vlSelf->__VdfgTmp_hcbf9eea7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058087_));
    vlSelf->wasmetal_core__DOT___063821_ = (1U & (IData)(
                                                         (0x3f15151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
    vlSelf->wasmetal_core__DOT___065938_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001520_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001521_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004174_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31a231e1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066083_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001532_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001533_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004248_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000609_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000610_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001120_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001121_))))))))))));
    vlSelf->wasmetal_core__DOT___065605_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001365_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001366_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003802_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07a3b670__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065803_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001409_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001410_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003506_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066401_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001620_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001621_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004322_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39926e96__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066527_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066524_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001642_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001643_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004100_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hccc0d080__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066649_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000429_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001323_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001324_))))))))))));
    vlSelf->wasmetal_core__DOT___066771_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066768_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000460_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000461_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000976_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000977_))))))))))));
    vlSelf->wasmetal_core__DOT___066895_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000494_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000495_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001010_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001011_))))))))))));
    vlSelf->wasmetal_core__DOT___065414_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001483_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001484_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004618_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0dafd81__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065189_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001439_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001440_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004396_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065701_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001377_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001378_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003654_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he23a6b26__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066279_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066275_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001576_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001577_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003728_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b219d07__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001608_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001609_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066604_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000412_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000413_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003884_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066854_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000472_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000473_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000988_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000989_))))))))))));
    vlSelf->wasmetal_core__DOT___067457_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067453_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000653_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000654_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001164_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001165_))))))))))));
    vlSelf->wasmetal_core__DOT___065899_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001421_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001422_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003580_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067345_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000631_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000632_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001142_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001143_))))))))))));
    vlSelf->wasmetal_core__DOT___066125_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066122_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001564_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001565_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h21caabb4__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064900_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001882_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001883_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065063_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001433_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001434_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004544_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50f5670e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065304_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001471_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001472_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004470_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b977022__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067077_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000539_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001054_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001055_))))))))))));
    vlSelf->wasmetal_core__DOT___067155_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000560_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000561_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001076_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001077_))))))))))));
    vlSelf->wasmetal_core__DOT___067196_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000588_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001098_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001099_))))))))))));
    vlSelf->wasmetal_core__DOT___066972_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066969_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000517_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001032_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001033_))))))))))));
    vlSelf->wasmetal_core__DOT___067482_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067479_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067478_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067477_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054178_))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_imm[0U] 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___064732_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064729_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001870_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001871_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004840_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cb51258__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064467_ = (1U & (IData)(
                                                         (0x4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064463_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___053588_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->wasmetal_core__DOT___051222_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050382_))));
    vlSelf->wasmetal_core__DOT___068557_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068554_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067608_ = (1U & (IData)(
                                                         (0xfdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067605_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))))));
    vlSelf->wasmetal_core__DOT___068607_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068656_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068704_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068753_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068752_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068797_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068852_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068851_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068898_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067751_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067748_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068022_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068019_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068081_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068078_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068157_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068242_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068239_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068295_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068292_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068349_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068404_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068401_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067965_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067962_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067726_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067724_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067812_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068428_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068425_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068480_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068477_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067658_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068106_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068943_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068942_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069041_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069091_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069090_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069140_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069139_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068969_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068968_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069233_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069232_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069159_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___053370_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053364_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053362_)))))));
    vlSelf->wasmetal_core__DOT___044858_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044882_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d))))))));
    vlSelf->wasmetal_core__DOT___044859_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)))))))))));
    vlSelf->wasmetal_core__DOT___044883_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d))))))));
    vlSelf->wasmetal_core__DOT___006122_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006232_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023243_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127590___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023794_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023793_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023792_)))) 
           ^ (((IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023728_)))));
    vlSelf->wasmetal_core__DOT___023732_ = ((IData)(vlSelf->wasmetal_core__DOT___023795_)
                                             ? (IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d));
    vlSelf->wasmetal_core__DOT___058910_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058909_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058908_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h85736cb0__0)))))))))));
    vlSelf->wasmetal_core__DOT___058783_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058766_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___058784_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058773_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
                        << 2U) | ((2U & ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036416_)))));
    vlSelf->wasmetal_core__DOT___036420_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hee741df9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015596_)));
    vlSelf->__VdfgTmp_h14009f5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015909_));
    vlSelf->wasmetal_core__DOT___015731_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015897_))));
    vlSelf->__VdfgTmp_hbb3c60ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016019_))));
    vlSelf->wasmetal_core__DOT___058262_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016020_)))));
    vlSelf->wasmetal_core__DOT___015964_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015821_))));
    vlSelf->wasmetal_core__DOT___043121_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017297_)))));
    vlSelf->wasmetal_core__DOT___043103_ = (1U & (IData)(
                                                         (0xffffffffff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057798_)))))))));
    vlSelf->wasmetal_core__DOT___017206_ = ((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017297_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h182596d5__0)))))));
    vlSelf->wasmetal_core__DOT___015979_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___015982_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015981_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015606_)))))));
    vlSelf->wasmetal_core__DOT___058238_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0f335500000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                          ? 
                                                         (0x503U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))
                                                          : 
                                                         (0x305U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015645_))))))))));
    vlSelf->__VdfgTmp_h7f6f5bfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015991_));
    vlSelf->wasmetal_core__DOT___058331_ = (1U & (IData)(
                                                         (0xeeee0000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016018_)))))))));
    vlSelf->__VdfgTmp_hf1a5f561__0 = (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016017_));
    vlSelf->__VdfgTmp_h5b5b6b1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015848_));
    vlSelf->wasmetal_core__DOT___058283_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015771_)))))))));
    vlSelf->wasmetal_core__DOT___058230_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016116_)))));
    vlSelf->wasmetal_core__DOT___015931_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015926_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015925_))));
    vlSelf->__VdfgTmp_h86126eef__0 = (((IData)(vlSelf->wasmetal_core__DOT___015925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015926_));
    vlSelf->__VdfgTmp_h4f78e4d3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                        & (IData)((0xfff0fff055553333ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    vlSelf->__VdfgTmp_h1811098d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd3573026__0));
    vlSelf->__VdfgTmp_h9a38454b__0 = ((2U & ((0x3500U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha6796979__0)))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))
                                                : (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))))));
    vlSelf->wasmetal_core__DOT___015978_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))))));
}
