#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__11(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__11\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044382_;
    wasmetal_core__DOT___044382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044564_;
    wasmetal_core__DOT___044564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044584_;
    wasmetal_core__DOT___044584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045536_;
    wasmetal_core__DOT___045536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045545_;
    wasmetal_core__DOT___045545_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045548_;
    wasmetal_core__DOT___045548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045557_;
    wasmetal_core__DOT___045557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063679_;
    wasmetal_core__DOT___063679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063687_;
    wasmetal_core__DOT___063687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063695_;
    wasmetal_core__DOT___063695_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063703_;
    wasmetal_core__DOT___063703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064043_;
    wasmetal_core__DOT___064043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064044_;
    wasmetal_core__DOT___064044_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064054_;
    wasmetal_core__DOT___064054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064065_;
    wasmetal_core__DOT___064065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064560_;
    wasmetal_core__DOT___064560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064563_;
    wasmetal_core__DOT___064563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064951_;
    wasmetal_core__DOT___064951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064980_;
    wasmetal_core__DOT___064980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065090_;
    wasmetal_core__DOT___065090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065121_;
    wasmetal_core__DOT___065121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065256_;
    wasmetal_core__DOT___065256_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065268_;
    wasmetal_core__DOT___065268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065344_;
    wasmetal_core__DOT___065344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065355_;
    wasmetal_core__DOT___065355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065453_;
    wasmetal_core__DOT___065453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065462_;
    wasmetal_core__DOT___065462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065536_;
    wasmetal_core__DOT___065536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065677_;
    wasmetal_core__DOT___065677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065775_;
    wasmetal_core__DOT___065775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065873_;
    wasmetal_core__DOT___065873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065988_;
    wasmetal_core__DOT___065988_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066054_;
    wasmetal_core__DOT___066054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066151_;
    wasmetal_core__DOT___066151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066250_;
    wasmetal_core__DOT___066250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070660_;
    wasmetal_core__DOT___070660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070663_;
    wasmetal_core__DOT___070663_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128203___O;
    wasmetal_core__DOT____Vcellout___128203___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128717___O;
    wasmetal_core__DOT____Vcellout___128717___O = 0;
    CData/*2:0*/ wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__ = 0;
    // Body
    wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___063289_ = (1U & (8U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___029769_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__)
                                                      : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d)) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___044578_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                     << 1U)) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                          >> 3U)))))))));
    wasmetal_core__DOT___045536_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                << 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                  >> 2U)))))))));
    wasmetal_core__DOT___045545_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___045548_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                >> 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                     >> 2U))))))))));
    wasmetal_core__DOT___045557_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___070661_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___070660_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070658_)))))))));
    wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128717___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035108_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035107_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035105_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035104_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035039_)))));
    vlSelf->wasmetal_core__DOT___035044_ = ((IData)(vlSelf->wasmetal_core__DOT___035108_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d));
    wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___044598_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___054533_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054535_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054537_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054539_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    wasmetal_core__DOT___063679_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063687_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063695_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063703_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___044382_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                  >> 2U)))))))));
    wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032822_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032789_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O)));
    wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030801_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d));
    wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128342___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128366___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063220_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063217_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063226_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063224_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063223_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063232_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063230_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063229_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063238_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063236_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063235_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032498_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128454___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032498_))));
    wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031759_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d));
    vlSelf->wasmetal_core__DOT___065228_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065226_))))));
    vlSelf->wasmetal_core__DOT___065385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065383_))))));
    vlSelf->wasmetal_core__DOT___065490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065488_))))));
    vlSelf->wasmetal_core__DOT___065653_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065652_))));
    vlSelf->wasmetal_core__DOT___065765_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065764_))));
    vlSelf->wasmetal_core__DOT___065848_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065028_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065847_))));
    vlSelf->wasmetal_core__DOT___065960_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065145_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065959_))));
    vlSelf->wasmetal_core__DOT___066031_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066030_))));
    vlSelf->wasmetal_core__DOT___066184_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066183_))));
    vlSelf->wasmetal_core__DOT___066229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066228_))));
    vlSelf->wasmetal_core__DOT___066438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066437_))));
    vlSelf->wasmetal_core__DOT___066504_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065764_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066503_))));
    vlSelf->wasmetal_core__DOT___066585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066584_))));
    vlSelf->wasmetal_core__DOT___066699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066698_))));
    vlSelf->wasmetal_core__DOT___066752_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066030_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066751_))));
    vlSelf->wasmetal_core__DOT___066834_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066183_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066833_))));
    vlSelf->wasmetal_core__DOT___066918_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066228_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066917_))));
    vlSelf->wasmetal_core__DOT___067002_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066339_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067001_))));
    vlSelf->wasmetal_core__DOT___067047_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067046_))));
    vlSelf->wasmetal_core__DOT___067132_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067131_))));
    vlSelf->wasmetal_core__DOT___067243_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067242_))));
    vlSelf->wasmetal_core__DOT___067282_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067281_))));
    vlSelf->wasmetal_core__DOT___067387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066751_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067386_))));
    vlSelf->wasmetal_core__DOT___070406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069915_))));
    vlSelf->wasmetal_core__DOT___067434_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066833_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067433_))));
    vlSelf->wasmetal_core__DOT___067531_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066917_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067530_))));
    vlSelf->wasmetal_core__DOT___069894_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069344_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069031_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069029_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065007_)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))))));
    vlSelf->wasmetal_core__DOT___069873_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069321_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069000_ = (1U & (0x33207f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068998_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064851_)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067134_)))))));
    vlSelf->wasmetal_core__DOT___069855_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069288_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064445_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064407_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064406_))));
    vlSelf->wasmetal_core__DOT___067579_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067001_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067578_))));
    vlSelf->wasmetal_core__DOT___064696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064680_))));
    vlSelf->wasmetal_core__DOT___067645_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067046_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067644_))));
    vlSelf->wasmetal_core__DOT___064879_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064873_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065153_ = (1U & (IData)(
                                                         (0x7fff00007fff7fffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))))));
    vlSelf->wasmetal_core__DOT___069834_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069268_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064866_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064859_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064858_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xaacc0f0fU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___064370_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdbf4091d__0))))))));
    vlSelf->wasmetal_core__DOT___067713_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067712_))));
    vlSelf->wasmetal_core__DOT___065023_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065015_))));
    vlSelf->wasmetal_core__DOT___067792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067791_))));
    vlSelf->wasmetal_core__DOT___069451_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065478_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065477_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___069420_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069187_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065371_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065134_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065130_))));
    vlSelf->wasmetal_core__DOT___067841_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067840_))));
    vlSelf->wasmetal_core__DOT___069394_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069120_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069287_))))));
    vlSelf->wasmetal_core__DOT___065216_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065215_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064662_))))));
    vlSelf->wasmetal_core__DOT___069345_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069025_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069344_))));
    vlSelf->wasmetal_core__DOT___069370_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069072_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069267_))))));
    vlSelf->wasmetal_core__DOT___065009_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065008_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065007_))));
    vlSelf->wasmetal_core__DOT___065139_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064356_))))));
    vlSelf->wasmetal_core__DOT___065221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065218_))));
    vlSelf->wasmetal_core__DOT___067884_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067883_))));
    vlSelf->wasmetal_core__DOT___065377_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065376_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065375_))));
    vlSelf->wasmetal_core__DOT___067944_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067943_))));
    vlSelf->wasmetal_core__DOT___065483_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065481_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065480_))));
    vlSelf->wasmetal_core__DOT___068007_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067530_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068006_))));
    vlSelf->wasmetal_core__DOT___065519_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064406_))));
    vlSelf->wasmetal_core__DOT___068060_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068059_))));
    vlSelf->wasmetal_core__DOT___069322_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069321_))));
    vlSelf->wasmetal_core__DOT___064853_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064852_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064851_))));
    vlSelf->wasmetal_core__DOT___065659_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064680_))));
    vlSelf->wasmetal_core__DOT___068135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068134_))));
    vlSelf->wasmetal_core__DOT___065854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065002_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065015_))));
    vlSelf->wasmetal_core__DOT___065758_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064859_))));
    vlSelf->wasmetal_core__DOT___065965_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065136_))));
    vlSelf->wasmetal_core__DOT___068221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067791_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068220_))));
    vlSelf->wasmetal_core__DOT___068187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068186_))));
    vlSelf->wasmetal_core__DOT___068274_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068273_))));
    vlSelf->wasmetal_core__DOT___066024_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065213_))));
    vlSelf->wasmetal_core__DOT___068327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067883_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068326_))));
    vlSelf->wasmetal_core__DOT___069289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069288_))));
    vlSelf->wasmetal_core__DOT___064666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064664_))));
    vlSelf->wasmetal_core__DOT___066190_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065368_))));
    vlSelf->wasmetal_core__DOT___068383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067943_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068382_))));
    vlSelf->wasmetal_core__DOT___064360_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064358_))));
    vlSelf->wasmetal_core__DOT___069269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068878_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069268_))));
    vlSelf->wasmetal_core__DOT___066222_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065480_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065475_))));
    vlSelf->wasmetal_core__DOT___068458_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068006_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068457_))));
    vlSelf->__VdfgTmp_hbca1334b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065212_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065215_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064662_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064650_))));
    vlSelf->__VdfgTmp_h61c930cb__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064650_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064665_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064664_))));
    vlSelf->__VdfgTmp_hde8128eb__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065001_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065008_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___065007_))));
    vlSelf->wasmetal_core__DOT___065010_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065002_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065001_))));
    vlSelf->__VdfgTmp_h227fe25d__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065474_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065477_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                               << 1U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->__VdfgTmp_he8d6e4f5__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065367_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065370_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064854_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064845_))));
    vlSelf->__VdfgTmp_h09fbb425__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064845_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064852_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064851_))));
    vlSelf->__VdfgTmp_ha81b0ca8__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065135_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065138_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064356_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064312_))));
    vlSelf->__VdfgTmp_h82ca1536__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064312_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064359_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064358_))));
    vlSelf->wasmetal_core__DOT___069220_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068831_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069219_))));
    vlSelf->wasmetal_core__DOT___068832_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068457_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068831_))));
    vlSelf->wasmetal_core__DOT___069026_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069025_))));
    vlSelf->wasmetal_core__DOT___068635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068220_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068634_))));
    vlSelf->wasmetal_core__DOT___068732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068731_))));
    vlSelf->wasmetal_core__DOT___069121_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069120_))));
    vlSelf->wasmetal_core__DOT___068928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068927_))));
    vlSelf->wasmetal_core__DOT___068521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068520_))));
    vlSelf->wasmetal_core__DOT___069188_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068781_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069187_))));
    vlSelf->wasmetal_core__DOT___068782_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068781_))));
    vlSelf->wasmetal_core__DOT___068995_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068994_))));
    vlSelf->wasmetal_core__DOT___068585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068584_))));
    vlSelf->wasmetal_core__DOT___068685_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068684_))));
    vlSelf->wasmetal_core__DOT___069073_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068684_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069072_))));
    vlSelf->wasmetal_core__DOT___068879_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068878_))));
    vlSelf->wasmetal_core__DOT___068503_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068502_))));
    vlSelf->wasmetal_core__DOT___065517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065512_))))));
    vlSelf->wasmetal_core__DOT___066340_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066339_))));
    vlSelf->wasmetal_core__DOT___064948_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064940_))))))));
    vlSelf->wasmetal_core__DOT___065245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065244_))));
    vlSelf->wasmetal_core__DOT___065333_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064796_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065332_))));
    vlSelf->wasmetal_core__DOT___065444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065443_))));
    vlSelf->wasmetal_core__DOT___067291_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067288_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064132_)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                           << 1U))))))))));
    vlSelf->wasmetal_core__DOT___064964_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064963_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___067780_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064606_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064605_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___064812_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064811_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064130_))))));
    vlSelf->wasmetal_core__DOT___067634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067633_))));
    vlSelf->wasmetal_core__DOT___067692_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067414_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067548_))))));
    vlSelf->wasmetal_core__DOT___065668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065244_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065667_))));
    vlSelf->wasmetal_core__DOT___064156_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067274_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067549_))));
    vlSelf->wasmetal_core__DOT___065863_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065862_))));
    vlSelf->wasmetal_core__DOT___065746_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065332_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065745_))));
    vlSelf->wasmetal_core__DOT___065979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065978_))));
    vlSelf->__VdfgTmp_hf24dfeba__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064960_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064963_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067228_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067516_))));
    vlSelf->wasmetal_core__DOT___066042_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065667_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066041_))));
    vlSelf->__VdfgTmp_hedd7926b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064808_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064811_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064130_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067414_))));
    vlSelf->wasmetal_core__DOT___064197_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064177_))));
    vlSelf->wasmetal_core__DOT___066240_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066239_))));
    vlSelf->wasmetal_core__DOT___066171_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066170_))));
    vlSelf->wasmetal_core__DOT___066349_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066348_))));
    vlSelf->__VdfgTmp_ha0b0298a__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064605_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___067373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067372_))));
    vlSelf->wasmetal_core__DOT___064621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___066449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066448_))));
    vlSelf->__VdfgTmp_h0f450401__0 = ((2U & ((0xf0f0aaccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_he8a45048__0))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067228_))));
    vlSelf->wasmetal_core__DOT___067119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066822_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067118_))));
    vlSelf->wasmetal_core__DOT___067275_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067274_))));
    vlSelf->wasmetal_core__DOT___064607_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064598_))));
    vlSelf->wasmetal_core__DOT___065239_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___065438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064966_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064961_))));
    vlSelf->wasmetal_core__DOT___064969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064966_))));
    vlSelf->wasmetal_core__DOT___065327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064814_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064809_))));
    vlSelf->wasmetal_core__DOT___064817_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064814_))));
    vlSelf->wasmetal_core__DOT___065114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064177_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064154_))));
    vlSelf->wasmetal_core__DOT___067058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067057_))));
    vlSelf->wasmetal_core__DOT___066738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066737_))));
    vlSelf->wasmetal_core__DOT___066571_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066239_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066570_))));
    vlSelf->wasmetal_core__DOT___066928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066927_))));
    vlSelf->wasmetal_core__DOT___066823_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066822_))));
    vlSelf->wasmetal_core__DOT___066495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066170_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066494_))));
    vlSelf->wasmetal_core__DOT___066688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066687_))));
    vlSelf->wasmetal_core__DOT___067011_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066687_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067010_))));
    vlSelf->__VdfgTmp_h07144816__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbfa66a09__0)))));
    vlSelf->__VdfgTmp_h712d7252__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xa3U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc947a4ab__0)))));
    vlSelf->wasmetal_core__DOT___065675_ = (1U & (IData)(
                                                         (0x3f5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065672_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064199_)))))))));
    vlSelf->__VdfgTmp_heccca597__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0xa3U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h14a49668__0)))));
    vlSelf->__VdfgTmp_h5e38b73e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha9829971__0)))));
    vlSelf->__VdfgTmp_h612fd420__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9a4c9e67__0)))));
    vlSelf->__VdfgTmp_ha036a4e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5b846e26__0)))));
    vlSelf->wasmetal_core__DOT___068176_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b4a166b__0))));
    vlSelf->wasmetal_core__DOT___065112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065104_))))))));
    vlSelf->wasmetal_core__DOT___065528_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065104_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065527_))));
    vlSelf->wasmetal_core__DOT___065275_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf7f000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h25573523__0)))))));
    vlSelf->wasmetal_core__DOT___065469_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ff000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h25573523__0)))))));
    vlSelf->wasmetal_core__DOT___065683_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha31eaa90__0)))));
    vlSelf->wasmetal_core__DOT___064788_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha31eaa90__0)))));
    vlSelf->wasmetal_core__DOT___064053_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064052_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064051_))));
    vlSelf->wasmetal_core__DOT___066360_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066249_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066359_))));
    wasmetal_core__DOT___064980_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064778_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064979_))));
    wasmetal_core__DOT___064560_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064047_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064052_))));
    wasmetal_core__DOT___066250_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066150_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066249_))));
    vlSelf->wasmetal_core__DOT___064076_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064070_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064069_))));
    wasmetal_core__DOT___065090_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064979_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065089_))));
    wasmetal_core__DOT___064054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064048_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064047_))));
    wasmetal_core__DOT___066151_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066053_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066150_))));
    wasmetal_core__DOT___065268_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065089_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065267_))));
    vlSelf->wasmetal_core__DOT___064557_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064048_))));
    wasmetal_core__DOT___066054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065987_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066053_))));
    wasmetal_core__DOT___064043_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064042_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064041_))));
    wasmetal_core__DOT___065988_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065872_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065987_))));
    vlSelf->wasmetal_core__DOT___064066_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064060_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064059_))));
    wasmetal_core__DOT___065355_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065267_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065354_))));
    vlSelf->wasmetal_core__DOT___064564_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064064_))));
    wasmetal_core__DOT___065462_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065354_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065461_))));
    vlSelf->wasmetal_core__DOT___064558_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064042_))));
    wasmetal_core__DOT___065873_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065774_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065872_))));
    wasmetal_core__DOT___064044_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064037_))));
    wasmetal_core__DOT___065775_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065676_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065774_))));
    wasmetal_core__DOT___064563_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___064065_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064064_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___065677_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065535_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065676_))));
    wasmetal_core__DOT___065536_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065461_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065535_))));
    vlSelf->__VdfgTmp_h78f256d8__0 = ((2U & ((0xeU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                << 1U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                            << 1U)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065359_));
    vlSelf->__VdfgTmp_hf270fd27__0 = ((2U & ((0x10U 
                                              >> ((4U 
                                                   & ((4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                             << 1U)) 
                                                           << 1U))) 
                                                      << 2U)) 
                                                  | (2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                        << 1U)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___066155_));
    vlSelf->__VdfgTmp_h892c3f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1b9a71b__0))));
    vlSelf->__VdfgTmp_h18d94502__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1b9a71b__0))));
    vlSelf->__VdfgTmp_h3ea85ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___065096_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                              << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___065545_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064082_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065541_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb5acd9d8__0)))))));
    vlSelf->__VdfgTmp_hf103d5a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065541_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                           << 1U)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___065996_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065993_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb5acd9d8__0))))))));
    vlSelf->__VdfgTmp_h3daad387__0 = (((IData)(vlSelf->wasmetal_core__DOT___065993_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                << 1U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_hc656bac6__0 = ((2U & ((0xbU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((1U 
                                                          >> 
                                                          (3U 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                             << 1U))))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                            << 1U)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064786_));
    vlSelf->wasmetal_core__DOT___065273_ = (1U & (0xe000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4f24f30__0))));
    vlSelf->wasmetal_core__DOT___065779_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4f24f30__0))));
    vlSelf->__VdfgTmp_ha458d092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h88dfb892__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h6b577092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0xe01fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_hf114f092__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h01d11789__0))));
    vlSelf->__VdfgTmp_h17a5807b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064984_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hab510120__0 = (((IData)(vlSelf->wasmetal_core__DOT___066058_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h4121b81d__0 = (((IData)(vlSelf->wasmetal_core__DOT___064553_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h18a1d918__0 = (((IData)(vlSelf->wasmetal_core__DOT___065684_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hfdd57f0a__0 = ((2U & ((IData)(
                                                     (0xfffe000000000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x100000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h1dd3182a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0x80007fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hc97edddd__0 = (((IData)(vlSelf->wasmetal_core__DOT___065467_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1ff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_he6eb1d70__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xff80007fffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_he6a138a7__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xffe0001fffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h4573e872__0 = (((IData)(vlSelf->wasmetal_core__DOT___065877_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h0160c9d2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfe0001ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h085758ad__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfff80007ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_hec74e4aa__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xe0001fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h96fdd1ca__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xf80007ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h009830e9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (IData)(
                                                      (0xfffe0001ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->wasmetal_core__DOT___064554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064544_))))))))))));
    vlSelf->wasmetal_core__DOT___064779_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064778_))));
    vlSelf->wasmetal_core__DOT___066941_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064237_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064235_))));
    vlSelf->wasmetal_core__DOT___065547_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065546_))));
    wasmetal_core__DOT___064951_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064821_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064950_))));
    vlSelf->__VdfgTmp_hd333e317__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064231_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064236_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                << 1U))));
    wasmetal_core__DOT___065453_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065343_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065452_))));
    wasmetal_core__DOT___065344_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065255_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065343_))));
    vlSelf->wasmetal_core__DOT___064578_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064222_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064232_))));
    vlSelf->wasmetal_core__DOT___064228_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064222_))));
    wasmetal_core__DOT___065256_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065120_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065255_))));
    wasmetal_core__DOT___065121_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064950_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065120_))));
    vlSelf->__VdfgTmp_h729278ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___064582_) 
                                       << 1U) | (1U 
                                                 & (0x4fU 
                                                    >> 
                                                    ((0x10U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0x8fU 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                                 << 2U)) 
                                                               << 2U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                              << 1U)))))));
    vlSelf->wasmetal_core__DOT___065263_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065260_)))));
    vlSelf->__VdfgTmp_hb2a5d28a__0 = (((IData)(vlSelf->wasmetal_core__DOT___065260_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                              << 5U) 
                                                             | ((0x10U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                    << 4U)) 
                                                                | (0xfU 
                                                                   & (~ 
                                                                      (7U 
                                                                       | (8U 
                                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                             << 3U)))))))))));
    vlSelf->__VdfgTmp_h7592c2bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4bfb58f6__0))));
    vlSelf->wasmetal_core__DOT___065458_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065457_)))));
    vlSelf->__VdfgTmp_h2ca328d2__0 = ((2U & ((IData)(
                                                     (0xe000000000000000ULL 
                                                      >> 
                                                      ((0x20U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           << 5U)) 
                                                       | ((0x18U 
                                                           & ((~ 
                                                               (1U 
                                                                | (2U 
                                                                   & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                      << 1U)))) 
                                                              << 3U)) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1f00000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd652459e__0)))));
    vlSelf->__VdfgTmp_h285454e8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xffe01fffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd652459e__0)))));
    vlSelf->__VdfgTmp_he391eb62__0 = (((IData)(vlSelf->wasmetal_core__DOT___065457_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x100000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h56ef19dd__0)))));
    vlSelf->__VdfgTmp_h9bcef377__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (IData)(
                                                      (0xfffe01ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h56ef19dd__0)))));
    vlSelf->__VdfgTmp_h5ef74162__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h1427a567__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___067106_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1427a567__0))))));
    vlSelf->__VdfgTmp_hdfea75fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___064827_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0x8fU 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                            << 2U)))))));
    vlSelf->__VdfgTmp_hfb6148fa__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065348_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x10U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                             << 2U))))))));
    vlSelf->wasmetal_core__DOT___065349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065348_))));
    vlSelf->__VdfgTmp_ha690191b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h95637c8b__0))));
    vlSelf->__VdfgTmp_h5f9c391b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xe01fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h95637c8b__0))));
    vlSelf->__VdfgTmp_hfa5e1cf0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h1578a070__0))));
    vlSelf->__VdfgTmp_hd64a84f0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h1578a070__0))));
    vlSelf->wasmetal_core__DOT___064575_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064571_))))))))));
    vlSelf->wasmetal_core__DOT___064822_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064821_))));
    wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128175___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029483_)))));
    vlSelf->wasmetal_core__DOT___029487_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128295___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030699_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b23__05d) {
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___031950_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031950_ = wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063555_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063553_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063563_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063562_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063561_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063571_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063579_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063578_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063577_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036776_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036743_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031347_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128522___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033121_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___033125_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033219_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033991_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033125_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033219_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033991_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128530___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033215_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128607___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033987_)))));
    vlSelf->wasmetal_core__DOT___062925_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1cU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062917_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))));
    vlSelf->wasmetal_core__DOT___062936_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1dU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062947_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1eU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062939_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062958_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1fU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062950_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128220___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029938_)
              ? (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128220___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029938_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029937_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029935_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029934_)))) 
           ^ (((IData)(wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029900_)));
    wasmetal_core__DOT____Vcellout___128203___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029769_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029768_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029766_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029765_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___029731_)));
    wasmetal_core__DOT___044564_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044578_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044577_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044576_)
                                                   ? 
                                                  (0xcU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h93fa449d__0))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044576_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044577_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044578_))));
    vlSelf->wasmetal_core__DOT___053257_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045550_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___045547_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___045554_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045549_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045551_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045556_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___045548_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045555_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___045525_ = ((IData)(wasmetal_core__DOT___045548_)
                                             ? ((IData)(wasmetal_core__DOT___045557_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045556_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045554_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045553_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045552_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045551_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045550_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045549_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045547_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045535_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045537_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045538_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045539_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045540_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045541_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045542_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045543_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045544_))
                                                 : (IData)(wasmetal_core__DOT___045545_))
                                             : (IData)(wasmetal_core__DOT___045536_));
    wasmetal_core__DOT___070663_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070661_)))))))));
    vlSelf->wasmetal_core__DOT___044813_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070660_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___044801_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070660_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070658_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128684___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034655_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034652_)))) 
           ^ (((IData)(wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034715_)))));
    vlSelf->wasmetal_core__DOT___034719_ = ((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                            & (IData)(wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034660_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___034659_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___034657_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128717___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___034656_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035109_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035044_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128701___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034911_)))));
    vlSelf->wasmetal_core__DOT___034916_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)) 
                                            & (IData)(wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___044584_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044598_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044597_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044596_)
                                                   ? 
                                                  (0xcU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he2c88566__0))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044596_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044597_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044598_))));
    vlSelf->wasmetal_core__DOT___054534_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054533_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054536_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054535_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054538_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1cU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054540_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054539_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063680_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063688_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063696_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063704_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___044368_ = (1U & ((IData)(wasmetal_core__DOT___044382_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044381_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044380_)
                                                     ? 
                                                    (0xcU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd4f12848__0))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044380_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044381_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044382_))));
    wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032823_)
                  ? (IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128309___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030802_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030801_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030800_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030799_)))) 
           ^ (((IData)(wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030733_)))));
    vlSelf->wasmetal_core__DOT___030738_ = ((IData)(vlSelf->wasmetal_core__DOT___030802_)
                                             ? (IData)(wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d));
    wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)
            : (IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032499_)
                  ? (IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032499_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128389___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031757_)))) 
           ^ (((IData)(wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031691_)))));
    vlSelf->wasmetal_core__DOT___031696_ = ((IData)(vlSelf->wasmetal_core__DOT___031760_)
                                             ? (IData)(wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d));
    vlSelf->wasmetal_core__DOT___065657_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065653_))));
    vlSelf->wasmetal_core__DOT___065766_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065765_))));
    vlSelf->wasmetal_core__DOT___065852_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065848_))));
    vlSelf->wasmetal_core__DOT___065963_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065960_))));
    vlSelf->wasmetal_core__DOT___066032_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066031_))));
    vlSelf->wasmetal_core__DOT___066188_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066184_))));
    vlSelf->wasmetal_core__DOT___066230_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066229_))));
    vlSelf->wasmetal_core__DOT___066439_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066438_)))));
    vlSelf->wasmetal_core__DOT___066505_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066504_)))));
    vlSelf->wasmetal_core__DOT___066587_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065028_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066585_)))));
    vlSelf->wasmetal_core__DOT___066700_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065145_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066699_)))));
    vlSelf->wasmetal_core__DOT___066754_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065226_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066752_)))));
    vlSelf->wasmetal_core__DOT___066835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065383_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066834_)))));
    vlSelf->wasmetal_core__DOT___066919_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065488_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066918_)))));
    vlSelf->wasmetal_core__DOT___067004_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065512_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067002_)))));
    vlSelf->wasmetal_core__DOT___067048_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067047_)))));
    vlSelf->wasmetal_core__DOT___067133_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067132_)))));
    vlSelf->wasmetal_core__DOT___067245_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065848_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067243_)))));
    vlSelf->wasmetal_core__DOT___067284_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065960_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067282_)))));
    vlSelf->wasmetal_core__DOT___067389_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067387_)))));
    vlSelf->wasmetal_core__DOT___067435_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066184_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067434_)))));
    vlSelf->wasmetal_core__DOT___067533_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066229_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067531_)))));
    vlSelf->wasmetal_core__DOT___067646_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066438_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067645_)))));
    vlSelf->wasmetal_core__DOT___070353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069834_))));
    vlSelf->wasmetal_core__DOT___067714_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066504_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067713_)))));
    vlSelf->wasmetal_core__DOT___067793_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067792_)))));
    vlSelf->wasmetal_core__DOT___069814_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069451_))));
    vlSelf->__VdfgTmp_h3c0e85cc__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065475_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065474_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065478_));
    vlSelf->wasmetal_core__DOT___069791_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069420_))));
    vlSelf->__VdfgTmp_h96c6858e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065368_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065367_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065371_));
    vlSelf->wasmetal_core__DOT___067842_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066699_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067841_)))));
    vlSelf->wasmetal_core__DOT___069770_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069394_))));
    vlSelf->__VdfgTmp_h84a28025__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065213_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065212_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065216_));
    vlSelf->wasmetal_core__DOT___069727_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069345_))));
    vlSelf->wasmetal_core__DOT___069749_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069370_))));
    vlSelf->__VdfgTmp_h2f6e42c0__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065136_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065135_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065139_));
    vlSelf->wasmetal_core__DOT___067885_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067884_)))));
    vlSelf->wasmetal_core__DOT___067945_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067944_)))));
    vlSelf->wasmetal_core__DOT___068008_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068007_)))));
    vlSelf->wasmetal_core__DOT___068061_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067002_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068060_)))));
    vlSelf->wasmetal_core__DOT___069705_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069322_))));
    vlSelf->wasmetal_core__DOT___068136_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067047_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068135_)))));
    vlSelf->wasmetal_core__DOT___065768_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064864_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xacU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___065373_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___064858_)))))))));
    vlSelf->wasmetal_core__DOT___068222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068221_)))));
    vlSelf->wasmetal_core__DOT___068188_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068187_)))));
    vlSelf->wasmetal_core__DOT___068275_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067282_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068274_)))));
    vlSelf->wasmetal_core__DOT___068328_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067387_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068327_)))));
    vlSelf->wasmetal_core__DOT___069682_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069289_))));
    vlSelf->wasmetal_core__DOT___068384_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068383_)))));
    vlSelf->wasmetal_core__DOT___069662_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069269_))));
    vlSelf->wasmetal_core__DOT___068459_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068458_)))));
    vlSelf->wasmetal_core__DOT___067382_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066024_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbca1334b__0)))));
    vlSelf->wasmetal_core__DOT___066026_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbca1334b__0))));
    vlSelf->wasmetal_core__DOT___064697_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064667_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064666_)))));
    vlSelf->wasmetal_core__DOT___065662_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61c930cb__0))));
    vlSelf->wasmetal_core__DOT___067238_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065854_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde8128eb__0)))));
    vlSelf->wasmetal_core__DOT___065857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde8128eb__0))));
    vlSelf->wasmetal_core__DOT___066580_ = (1U & (0xffccf0aaU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065009_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065023_))))));
    vlSelf->wasmetal_core__DOT___065024_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065010_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065009_)))));
    vlSelf->wasmetal_core__DOT___067526_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066222_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h227fe25d__0)))));
    vlSelf->wasmetal_core__DOT___066224_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h227fe25d__0))));
    vlSelf->wasmetal_core__DOT___066193_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0))));
    vlSelf->wasmetal_core__DOT___067437_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8d6e4f5__0)))));
    vlSelf->wasmetal_core__DOT___064867_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064853_)))));
    vlSelf->wasmetal_core__DOT___066508_ = (1U & (0xffccf055U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064854_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064853_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064866_))))));
    vlSelf->wasmetal_core__DOT___067135_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065758_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09fbb425__0)))));
    vlSelf->wasmetal_core__DOT___065767_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09fbb425__0))));
    vlSelf->wasmetal_core__DOT___067286_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065965_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0)))))));
    vlSelf->wasmetal_core__DOT___065968_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha81b0ca8__0))));
    vlSelf->wasmetal_core__DOT___064447_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064361_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064360_)))));
    vlSelf->wasmetal_core__DOT___065522_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82ca1536__0))));
    vlSelf->wasmetal_core__DOT___069637_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069220_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                            << 1U)) 
                                                                          << 1U))) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069221_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068458_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069220_)))));
    vlSelf->wasmetal_core__DOT___069452_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068832_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069451_)))));
    vlSelf->wasmetal_core__DOT___068833_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068007_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068832_)))));
    vlSelf->wasmetal_core__DOT___069546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069026_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069344_)))))));
    vlSelf->wasmetal_core__DOT___069027_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068221_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069026_)))));
    vlSelf->wasmetal_core__DOT___069346_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069345_)))));
    vlSelf->wasmetal_core__DOT___068636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067792_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068635_)))));
    vlSelf->wasmetal_core__DOT___069395_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069394_)))));
    vlSelf->wasmetal_core__DOT___068733_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068732_)))));
    vlSelf->wasmetal_core__DOT___069588_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069121_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069122_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069121_)))));
    vlSelf->wasmetal_core__DOT___069500_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068928_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069288_)))))));
    vlSelf->wasmetal_core__DOT___068929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068135_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068928_)))));
    vlSelf->wasmetal_core__DOT___069290_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068521_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069289_)))));
    vlSelf->wasmetal_core__DOT___068522_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068521_)))));
    vlSelf->wasmetal_core__DOT___069189_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068383_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069188_)))));
    vlSelf->wasmetal_core__DOT___069611_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069188_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                     << 1U))) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069420_)))));
    vlSelf->wasmetal_core__DOT___068783_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068782_)))));
    vlSelf->wasmetal_core__DOT___069519_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068995_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069321_)))))));
    vlSelf->wasmetal_core__DOT___068996_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068995_)))));
    vlSelf->wasmetal_core__DOT___068586_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068585_)))));
    vlSelf->wasmetal_core__DOT___069323_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069322_)))));
    vlSelf->wasmetal_core__DOT___069371_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069370_)))));
    vlSelf->wasmetal_core__DOT___068686_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067841_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068685_)))));
    vlSelf->wasmetal_core__DOT___069571_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069073_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___069074_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069073_)))));
    vlSelf->wasmetal_core__DOT___069480_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068879_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___069268_)))))));
    vlSelf->wasmetal_core__DOT___068880_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068879_)))));
    vlSelf->wasmetal_core__DOT___068504_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067579_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068503_)))));
    vlSelf->wasmetal_core__DOT___019406_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068503_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069269_)))));
    vlSelf->wasmetal_core__DOT___065524_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065518_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065517_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065516_)))))))));
    vlSelf->wasmetal_core__DOT___066342_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066340_))));
    vlSelf->wasmetal_core__DOT___019407_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067579_)))));
    vlSelf->wasmetal_core__DOT___064977_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064947_)))))))));
    vlSelf->wasmetal_core__DOT___065252_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065245_))))));
    vlSelf->wasmetal_core__DOT___065340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065333_))))));
    vlSelf->wasmetal_core__DOT___065449_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065444_))))));
    vlSelf->__VdfgTmp_h11c2cb19__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064961_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064960_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064964_));
    vlSelf->wasmetal_core__DOT___067125_ = (1U & (IData)(
                                                         (0xffcf0040ffcfffcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064812_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          (3U 
                                                                           & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))));
    vlSelf->__VdfgTmp_ha9e0ea4b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064809_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064808_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064812_));
    vlSelf->wasmetal_core__DOT___065669_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065668_))));
    vlSelf->__VdfgTmp_hcce0135b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064156_) 
                                       << 1U) | (1U 
                                                 & (0x55330f0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___064154_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he8a45048__0)))));
    vlSelf->wasmetal_core__DOT___065864_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064940_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065863_))));
    vlSelf->wasmetal_core__DOT___065747_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064796_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065746_))));
    vlSelf->wasmetal_core__DOT___065980_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065104_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065979_))));
    vlSelf->wasmetal_core__DOT___067996_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067517_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066042_))));
    vlSelf->wasmetal_core__DOT___067928_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067415_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066240_))));
    vlSelf->wasmetal_core__DOT___066172_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066171_))));
    vlSelf->wasmetal_core__DOT___067874_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067633_))))));
    vlSelf->wasmetal_core__DOT___066450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065668_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066449_))));
    vlSelf->wasmetal_core__DOT___066694_ = (1U & (IData)(
                                                         (0xf7770000f333f333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x5cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U))))))))))))))));
    vlSelf->wasmetal_core__DOT___067781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067780_))));
    vlSelf->wasmetal_core__DOT___067693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067692_))));
    vlSelf->wasmetal_core__DOT___067847_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067549_))))));
    vlSelf->wasmetal_core__DOT___065674_ = (1U & (IData)(
                                                         (0x330f5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064606_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___064621_))))))));
    vlSelf->wasmetal_core__DOT___064622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064606_))));
    vlSelf->wasmetal_core__DOT___065254_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064619_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065239_))))))));
    vlSelf->wasmetal_core__DOT___066048_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065239_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)))));
    vlSelf->wasmetal_core__DOT___065451_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064614_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065438_))))))));
    vlSelf->wasmetal_core__DOT___066246_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065438_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)))))));
    vlSelf->wasmetal_core__DOT___066177_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065327_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hedd7926b__0)))))));
    vlSelf->wasmetal_core__DOT___065342_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hedd7926b__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064187_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065327_))))))));
    vlSelf->wasmetal_core__DOT___065986_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))));
    vlSelf->wasmetal_core__DOT___067059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066449_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067058_))));
    vlSelf->wasmetal_core__DOT___067635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067634_))));
    vlSelf->wasmetal_core__DOT___067374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067373_))));
    vlSelf->wasmetal_core__DOT___066739_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066738_))));
    vlSelf->wasmetal_core__DOT___067230_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067229_))));
    vlSelf->wasmetal_core__DOT___066572_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066571_))));
    vlSelf->wasmetal_core__DOT___066929_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066928_))));
    vlSelf->wasmetal_core__DOT___067518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067517_))));
    vlSelf->wasmetal_core__DOT___067416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066823_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067415_))));
    vlSelf->wasmetal_core__DOT___066824_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066823_))));
    vlSelf->wasmetal_core__DOT___067120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066495_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067119_))));
    vlSelf->wasmetal_core__DOT___066496_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066495_))));
    vlSelf->wasmetal_core__DOT___066689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066688_))));
    vlSelf->wasmetal_core__DOT___067276_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066688_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067275_))));
    vlSelf->wasmetal_core__DOT___067012_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067011_))));
    vlSelf->wasmetal_core__DOT___067551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067011_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067550_))));
    vlSelf->wasmetal_core__DOT___065128_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065113_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065111_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064196_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x5cU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))))))));
    vlSelf->wasmetal_core__DOT___065532_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065528_))))));
    vlSelf->wasmetal_core__DOT___066350_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066349_))));
    vlSelf->wasmetal_core__DOT___064981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064544_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064980_))));
    vlSelf->wasmetal_core__DOT___064561_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064560_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___066427_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066250_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066151_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066360_))));
    vlSelf->wasmetal_core__DOT___065269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064980_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065268_))));
    vlSelf->__VdfgTmp_h9d56b9e6__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064557_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064560_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                     << 1U)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___066251_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066054_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066250_))));
    vlSelf->__VdfgTmp_h23108600__0 = ((2U & ((0xacU 
                                              >> (((IData)(wasmetal_core__DOT___064043_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064054_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066152_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065988_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066151_))));
    vlSelf->wasmetal_core__DOT___065356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065090_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065355_))));
    vlSelf->wasmetal_core__DOT___065463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065268_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065462_))));
    vlSelf->wasmetal_core__DOT___066055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065873_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066054_))));
    vlSelf->wasmetal_core__DOT___064056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064043_))));
    vlSelf->wasmetal_core__DOT___065989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065775_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065988_))));
    vlSelf->wasmetal_core__DOT___064566_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064564_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064563_))));
    vlSelf->wasmetal_core__DOT___064989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064558_))));
    vlSelf->wasmetal_core__DOT___064789_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___064077_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064066_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___065678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065462_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065677_))));
    vlSelf->wasmetal_core__DOT___065874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065677_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065873_))));
    vlSelf->wasmetal_core__DOT___065537_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065355_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065536_))));
    vlSelf->wasmetal_core__DOT___065776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065536_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065775_))));
    vlSelf->__VdfgTmp_h9616de3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065273_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))));
    vlSelf->__VdfgTmp_h5ad13fe7__0 = (((IData)(vlSelf->wasmetal_core__DOT___065779_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         << 3U)) 
                                                     | (3U 
                                                        & (- (IData)(
                                                                     (1U 
                                                                      & (4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064543_) 
                                                                          << 1U))))))))));
    vlSelf->__VdfgTmp_h67fa8c87__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha458d092__0))));
    vlSelf->__VdfgTmp_h4223b487__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h88dfb892__0))));
    vlSelf->__VdfgTmp_h2428cf91__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he6eb1d70__0))));
    vlSelf->__VdfgTmp_h25e3345e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he6a138a7__0))));
    vlSelf->__VdfgTmp_hc8a29b47__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0160c9d2__0))));
    vlSelf->__VdfgTmp_hc3e51450__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h085758ad__0))));
    vlSelf->__VdfgTmp_hdf86f0af__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0))));
    vlSelf->__VdfgTmp_h744d834f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0))));
    vlSelf->wasmetal_core__DOT___064787_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064779_))))))))));
    vlSelf->wasmetal_core__DOT___065091_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064779_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065090_))));
    vlSelf->wasmetal_core__DOT___065352_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                         << 1U)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064237_))));
    vlSelf->__VdfgTmp_ha92622e4__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064232_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064231_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064237_));
    vlSelf->wasmetal_core__DOT___066804_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065547_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064952_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064571_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064951_))));
    vlSelf->wasmetal_core__DOT___065639_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065453_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065547_))));
    vlSelf->wasmetal_core__DOT___065257_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064951_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065256_))));
    vlSelf->wasmetal_core__DOT___065454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065256_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065453_))));
    vlSelf->wasmetal_core__DOT___065345_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065121_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065344_))));
    vlSelf->wasmetal_core__DOT___065265_ = (1U & (IData)(
                                                         (0xf0ffe000f0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065263_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x5cU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd333e317__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                             << 1U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                              << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___065460_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065458_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                                          << 1U)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                           << 1U))))))))));
    vlSelf->__VdfgTmp_h90ebf68e__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h285454e8__0))));
    vlSelf->__VdfgTmp_h056e943f__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9bcef377__0))));
    vlSelf->wasmetal_core__DOT___069317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b66__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xac00000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0))))))));
    vlSelf->__VdfgTmp_h23f4485c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0)))));
    vlSelf->wasmetal_core__DOT___066165_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0))))));
    vlSelf->wasmetal_core__DOT___068363_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___067408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0))))));
    vlSelf->__VdfgTmp_h460c2b6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfb6148fa__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___065350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065349_))));
    vlSelf->__VdfgTmp_h97331d2b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065349_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066806_))))));
    vlSelf->wasmetal_core__DOT___067362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha690191b__0))))));
    vlSelf->wasmetal_core__DOT___068309_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha690191b__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066018_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha690191b__0))))));
    vlSelf->__VdfgTmp_h0ae37f35__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_ha690191b__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->__VdfgTmp_h99c00636__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)))))));
    vlSelf->__VdfgTmp_hca367735__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___065840_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5f9c391b__0))))));
    vlSelf->wasmetal_core__DOT___067037_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0))))));
    vlSelf->__VdfgTmp_h06351ce7__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                           >> 1U))))));
    vlSelf->wasmetal_core__DOT___065645_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfa5e1cf0__0))))));
    vlSelf->__VdfgTmp_h1c76f20b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)))))));
    vlSelf->wasmetal_core__DOT___069203_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___066216_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd64a84f0__0))))));
    vlSelf->wasmetal_core__DOT___064585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064575_))));
    vlSelf->wasmetal_core__DOT___064828_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064822_))))))));
    vlSelf->wasmetal_core__DOT___065122_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064822_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065121_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128407___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031945_)))));
    vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029487_));
    vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030704_));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036777_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031348_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033125_));
        vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033219_));
        vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033991_));
    }
    vlSelf->wasmetal_core__DOT___063265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063271_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128203___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063277_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063431_ = (1U & (IData)(
                                                         (0x11fff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbbbbfffff0ff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053257_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b3__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063375_)))))))));
    vlSelf->wasmetal_core__DOT___053258_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053257_))));
    vlSelf->wasmetal_core__DOT___044804_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070663_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___044792_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070661_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128685___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034719_));
    vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035110_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d));
    vlSelf->wasmetal_core__DOT___128702___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034916_));
    vlSelf->__VdfgTmp_h005ba8bd__0 = (((IData)(wasmetal_core__DOT___044584_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___044564_));
    vlSelf->wasmetal_core__DOT___053499_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052847_)))));
    vlSelf->wasmetal_core__DOT___053480_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050363_)))))))));
    vlSelf->wasmetal_core__DOT___052849_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128481___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032826_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032825_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032823_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032822_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___032825_)
                       ? (IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__)
                       : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                          >> 2U)) << 3U)) | (((IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__) 
                                              << 2U) 
                                             | (((IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___032789_)))));
    vlSelf->wasmetal_core__DOT___128310___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030803_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030738_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128342___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128342___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031121_)))));
    vlSelf->wasmetal_core__DOT___031125_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128366___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128366___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031409_)))));
    vlSelf->wasmetal_core__DOT___031413_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128454___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032500_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032499_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032498_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032497_)))) 
           ^ (((IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128454___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032432_)))));
    vlSelf->wasmetal_core__DOT___032436_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032500_)
                                                   ? (IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032500_))));
    vlSelf->wasmetal_core__DOT___128390___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031696_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d));
    vlSelf->wasmetal_core__DOT___065859_ = (1U & (0x33207f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065853_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065851_)))))));
    vlSelf->wasmetal_core__DOT___066511_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066505_))));
    vlSelf->wasmetal_core__DOT___066590_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066588_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066587_)))))));
    vlSelf->wasmetal_core__DOT___066757_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066755_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066754_)))))));
    vlSelf->wasmetal_core__DOT___066840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066835_))));
    vlSelf->wasmetal_core__DOT___067019_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xcfff4000cfffcfffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067005_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067003_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xaa330f00000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              >> 2U))) 
                                                                         << 5U)) 
                                                                     | ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065519_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h82ca1536__0)))))))))));
    vlSelf->wasmetal_core__DOT___067064_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067054_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61c930cb__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___067048_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067051_)))))))));
    vlSelf->wasmetal_core__DOT___067138_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067133_))));
    vlSelf->wasmetal_core__DOT___067440_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067435_))));
    vlSelf->wasmetal_core__DOT___067649_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067646_)))));
    vlSelf->wasmetal_core__DOT___067716_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067714_)))));
    vlSelf->wasmetal_core__DOT___067795_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067793_)))));
    vlSelf->wasmetal_core__DOT___066933_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066924_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x55330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065483_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c0e85cc__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___066919_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066921_)))))))));
    vlSelf->wasmetal_core__DOT___065484_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c0e85cc__0))));
    vlSelf->wasmetal_core__DOT___065379_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h96c6858e__0))));
    vlSelf->wasmetal_core__DOT___066837_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065377_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h96c6858e__0)))));
    vlSelf->wasmetal_core__DOT___067843_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067842_)))));
    vlSelf->wasmetal_core__DOT___065222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84a28025__0))));
    vlSelf->wasmetal_core__DOT___066747_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065221_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84a28025__0)))));
    vlSelf->wasmetal_core__DOT___070303_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069749_))));
    vlSelf->wasmetal_core__DOT___065141_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f6e42c0__0))));
    vlSelf->wasmetal_core__DOT___067887_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067885_)))));
    vlSelf->wasmetal_core__DOT___067948_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067945_)))));
    vlSelf->wasmetal_core__DOT___068010_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068008_)))));
    vlSelf->wasmetal_core__DOT___068063_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068061_)))));
    vlSelf->wasmetal_core__DOT___068137_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068136_)))));
    vlSelf->wasmetal_core__DOT___068223_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068222_)))));
    vlSelf->wasmetal_core__DOT___068191_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068188_)))));
    vlSelf->wasmetal_core__DOT___068277_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065963_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068275_)))));
    vlSelf->wasmetal_core__DOT___068329_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066032_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068328_)))));
    vlSelf->wasmetal_core__DOT___068386_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066188_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068384_)))));
    vlSelf->wasmetal_core__DOT___068460_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066230_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068459_)))));
    vlSelf->wasmetal_core__DOT___064713_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064696_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf050f030f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 3U)) 
                                                                                | ((2U 
                                                                                & vlSelf->mem_rdata[0U]) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064690_))))))))))))))));
    vlSelf->wasmetal_core__DOT___067650_ = (1U & (IData)(
                                                         (0xfbfff3f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064709_)))))))));
    vlSelf->wasmetal_core__DOT___065687_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((0x33207f7fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065658_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065656_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064694_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065662_)))))))));
    vlSelf->wasmetal_core__DOT___067798_ = (1U & (0x7033U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065024_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065034_)))))));
    vlSelf->wasmetal_core__DOT___065773_ = (1U & (IData)(
                                                         (0x70707777ff00ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065767_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065766_)))))))));
    vlSelf->wasmetal_core__DOT___070238_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069637_))));
    vlSelf->wasmetal_core__DOT___069224_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067533_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069221_)))));
    vlSelf->wasmetal_core__DOT___069457_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068008_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069452_))))));
    vlSelf->wasmetal_core__DOT___068835_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066919_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068833_)))));
    vlSelf->wasmetal_core__DOT___070177_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069546_))));
    vlSelf->wasmetal_core__DOT___069548_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069546_))))));
    vlSelf->wasmetal_core__DOT___069030_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067245_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069027_)))));
    vlSelf->wasmetal_core__DOT___069900_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067245_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069027_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069894_)))))));
    vlSelf->wasmetal_core__DOT___069353_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067793_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069346_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065037_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069730_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068636_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069727_))))));
    vlSelf->wasmetal_core__DOT___068638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068636_)))));
    vlSelf->wasmetal_core__DOT___069403_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067885_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069395_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa23fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065232_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf8ff00ff00ff00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62686ece__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069773_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068733_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069770_))))));
    vlSelf->wasmetal_core__DOT___068735_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068733_)))));
    vlSelf->wasmetal_core__DOT___070206_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069588_))));
    vlSelf->wasmetal_core__DOT___069595_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b77__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066032_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068328_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069588_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4ea0U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hd4f38404__0)))))))));
    vlSelf->wasmetal_core__DOT___069941_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067389_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069122_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069937_)))))));
    vlSelf->wasmetal_core__DOT___069125_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067389_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069122_)))));
    vlSelf->wasmetal_core__DOT___070150_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069500_))));
    vlSelf->wasmetal_core__DOT___069502_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069500_))))));
    vlSelf->wasmetal_core__DOT___068931_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068929_)))));
    vlSelf->wasmetal_core__DOT___069859_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068929_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069855_)))))));
    vlSelf->wasmetal_core__DOT___069302_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067646_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069290_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa27fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064707_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___069295_)))))))))));
    vlSelf->wasmetal_core__DOT___069685_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068522_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069682_))))));
    vlSelf->wasmetal_core__DOT___068524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068522_)))));
    vlSelf->wasmetal_core__DOT___069192_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067435_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069189_)))));
    vlSelf->wasmetal_core__DOT___069961_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067435_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069958_))))));
    vlSelf->wasmetal_core__DOT___070221_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069611_))));
    vlSelf->wasmetal_core__DOT___069618_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b78__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066188_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068384_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069611_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4aU 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___066185_)))))))))));
    vlSelf->wasmetal_core__DOT___069428_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b70__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067945_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069421_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065389_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069795_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069791_))))));
    vlSelf->wasmetal_core__DOT___068786_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068783_)))));
    vlSelf->wasmetal_core__DOT___069523_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069519_))))));
    vlSelf->wasmetal_core__DOT___068999_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068996_)))));
    vlSelf->wasmetal_core__DOT___069876_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069873_))))));
    vlSelf->wasmetal_core__DOT___068589_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068586_)))));
    vlSelf->wasmetal_core__DOT___070043_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069323_))));
    vlSelf->wasmetal_core__DOT___069326_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067714_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069323_))))));
    vlSelf->wasmetal_core__DOT___070075_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069371_))));
    vlSelf->wasmetal_core__DOT___069378_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067842_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069371_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h5851eae3__0))))))))));
    vlSelf->wasmetal_core__DOT___068688_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066700_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068686_)))));
    vlSelf->wasmetal_core__DOT___069573_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065963_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068275_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069571_))))));
    vlSelf->wasmetal_core__DOT___070186_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069571_))));
    vlSelf->wasmetal_core__DOT___069917_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067284_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069915_))))));
    vlSelf->wasmetal_core__DOT___069076_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067284_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069074_)))));
    vlSelf->wasmetal_core__DOT___070128_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069480_))));
    vlSelf->wasmetal_core__DOT___069838_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068880_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069834_)))))));
    vlSelf->wasmetal_core__DOT___068881_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068880_)))));
    vlSelf->wasmetal_core__DOT___066378_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066343_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066341_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x330f5500000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              >> 2U))) 
                                                                         << 5U)) 
                                                                     | ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064361_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064360_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___064445_))))))))))));
    vlSelf->wasmetal_core__DOT___068505_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066342_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068504_)))));
    vlSelf->wasmetal_core__DOT___065869_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064969_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)))))));
    vlSelf->wasmetal_core__DOT___065673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065669_))));
}
