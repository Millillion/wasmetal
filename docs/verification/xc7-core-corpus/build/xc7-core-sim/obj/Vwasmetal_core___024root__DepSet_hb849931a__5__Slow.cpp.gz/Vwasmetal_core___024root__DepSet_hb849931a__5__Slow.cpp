#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__4(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__4\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___046019_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
    vlSelf->wasmetal_core__DOT___053751_ = (1U & (IData)(
                                                         (0xf4ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_ready) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052986_)))))))));
    vlSelf->wasmetal_core__DOT___050456_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050454_))));
    vlSelf->wasmetal_core__DOT___053752_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_ready)))))));
    vlSelf->wasmetal_core__DOT___070619_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003039_)))));
    vlSelf->wasmetal_core__DOT___061665_ = (1U & (IData)(
                                                         (0xfeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048412_)))))))));
    vlSelf->wasmetal_core__DOT___052732_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052731_))));
    vlSelf->wasmetal_core__DOT___007057_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019203_))));
    vlSelf->wasmetal_core__DOT___019242_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019203_))));
    vlSelf->wasmetal_core__DOT___048356_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048345_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048349_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048323_))));
    vlSelf->wasmetal_core__DOT___048330_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048323_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048322_)))));
    vlSelf->wasmetal_core__DOT___048410_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048404_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048323_))));
    vlSelf->wasmetal_core__DOT___039792_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039763_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039764_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039765_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039762_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039410_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039767_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039768_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039769_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039770_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039771_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039772_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039773_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039774_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039796_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039785_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039784_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039783_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039782_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039766_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039412_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039781_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039779_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039778_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039777_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039776_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039786_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039787_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039788_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039805_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039800_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039799_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___063410_ = (1U & (IData)(
                                                         (0xccf05500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))));
    vlSelf->wasmetal_core__DOT___053334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053332_))));
    vlSelf->wasmetal_core__DOT___062617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062629_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062651_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062662_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___007207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007190_))));
    vlSelf->wasmetal_core__DOT___052853_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff01ffffffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((0xfffeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((0x1000U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000366_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052851_))));
    vlSelf->__VdfgTmp_h4abf7b91__0 = (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048443_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048270_)));
    vlSelf->wasmetal_core__DOT___007196_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053755_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053754_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))))));
    vlSelf->wasmetal_core__DOT___072270_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052902_))));
    vlSelf->wasmetal_core__DOT___007193_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053780_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053779_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053776_)))))))));
    vlSelf->wasmetal_core__DOT___052907_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052905_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___007058_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048475_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048467_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048464_))))));
    vlSelf->wasmetal_core__DOT__divider__02eremainder_op 
        = (1U & (IData)((0xf888ffff00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052746_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048343_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048365_)))))))));
    vlSelf->wasmetal_core__DOT___052903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052901_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052900_))));
    vlSelf->wasmetal_core__DOT___063857_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048312_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007031_))));
    vlSelf->wasmetal_core__DOT___048332_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048313_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048312_)))));
    vlSelf->wasmetal_core__DOT___052680_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fifth_ready))));
    vlSelf->wasmetal_core__DOT___048518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048514_))));
    vlSelf->wasmetal_core__DOT___007055_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048401_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048400_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048316_)))));
    vlSelf->wasmetal_core__DOT___052847_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052845_))));
    vlSelf->wasmetal_core__DOT___062496_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052893_))));
    vlSelf->wasmetal_core__DOT___052913_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052893_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052892_))));
    vlSelf->wasmetal_core__DOT___054746_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048448_))));
    vlSelf->wasmetal_core__DOT___060719_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019246_))));
    vlSelf->wasmetal_core__DOT___019323_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054677_))));
    vlSelf->wasmetal_core__DOT___009643_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_x 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->insn_op 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___009642_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_x) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb32961__0))))));
    vlSelf->wasmetal_core__DOT___054696_ = (1U & (IData)(
                                                         (0xf0fbbbb00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbec427aa__0))))))));
    vlSelf->wasmetal_core__DOT___054685_ = (1U & (IData)(
                                                         (0xefffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0xfU))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054680_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054679_) 
                                                                     << 2U) 
                                                                    | (3U 
                                                                       & (vlSelf->insn_x 
                                                                          >> 0x1bU)))))))));
    vlSelf->wasmetal_core__DOT___009543_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053009_)))));
    vlSelf->wasmetal_core__DOT___060664_ = (1U & (0x5ff01fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048448_)))))));
    vlSelf->wasmetal_core__DOT___060655_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019246_))));
    vlSelf->wasmetal_core__DOT___050451_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050449_))));
    vlSelf->wasmetal_core__DOT___053350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052889_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052886_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052884_))))));
    vlSelf->wasmetal_core__DOT___063446_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052884_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052897_))));
    vlSelf->wasmetal_core__DOT___061645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061644_))));
    vlSelf->wasmetal_core__DOT___061653_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048401_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048513_)))));
    vlSelf->wasmetal_core__DOT___061646_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048514_)))));
    vlSelf->wasmetal_core__DOT___062618_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062630_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062641_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___052915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052879_))));
    vlSelf->wasmetal_core__DOT___053351_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052900_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052882_))));
    vlSelf->wasmetal_core__DOT___064476_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007033_))));
    vlSelf->__VdfgTmp_ha5ccee3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048369_));
    vlSelf->__VdfgTmp_h42143724__0 = (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048369_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007031_))));
    vlSelf->wasmetal_core__DOT___063855_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007032_))));
    vlSelf->wasmetal_core__DOT___007191_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x1515153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052904_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053762_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053761_)))));
    vlSelf->wasmetal_core__DOT___019204_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048323_)))));
    vlSelf->wasmetal_core__DOT___007043_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048443_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048306_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048304_)))))));
    vlSelf->wasmetal_core__DOT___063999_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007035_))));
    vlSelf->wasmetal_core__DOT___048355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048341_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b7__05d) {
        wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___031902_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
    } else {
        wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___031902_ = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___007192_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053770_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053769_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053768_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053766_)))))));
    vlSelf->wasmetal_core__DOT___064466_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052895_))));
    vlSelf->wasmetal_core__DOT___052910_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052895_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052894_)))));
    vlSelf->wasmetal_core__DOT___054745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007054_))));
    vlSelf->__VdfgTmp_h27b70ff4__0 = (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007034_));
    vlSelf->wasmetal_core__DOT___066281_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065609_))));
    vlSelf->wasmetal_core__DOT___033032_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054145_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048407_)))))));
    vlSelf->__VdfgTmp_h058312bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019396_));
    vlSelf->__VdfgTmp_ha02e1627__0 = (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019396_));
    vlSelf->wasmetal_core__DOT___019293_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019336_))));
    vlSelf->wasmetal_core__DOT___019291_ = (1U & (0xfff80000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055311_)))))));
    vlSelf->wasmetal_core__DOT___019278_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048448_))));
    vlSelf->wasmetal_core__DOT___007195_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1515153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053757_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053758_))));
    vlSelf->wasmetal_core__DOT___063856_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048352_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048333_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063854_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048348_))))));
    vlSelf->wasmetal_core__DOT___065612_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063854_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048339_))));
    vlSelf->wasmetal_core__DOT___019385_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064017_))));
    vlSelf->wasmetal_core__DOT___048471_ = (1U & (IData)(
                                                         (0x1f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048470_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048383_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048284_)))))))));
    vlSelf->wasmetal_core__DOT___051252_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048455_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048466_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048454_))))));
    vlSelf->wasmetal_core__DOT___048271_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044072_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045662_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044082_))))));
    vlSelf->wasmetal_core__DOT___048280_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045734_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044220_))));
    vlSelf->wasmetal_core__DOT___030686_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003147_)))));
    vlSelf->wasmetal_core__DOT___003031_ = (1U & (IData)(
                                                         (0x40ff000000ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (vlSelf->insn_op 
                                                                                >> 0x1aU))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___042542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___053014_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053011_))));
    vlSelf->__VdfgTmp_h44c20413__0 = (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044240_));
    vlSelf->wasmetal_core__DOT___051199_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050366_))));
    vlSelf->wasmetal_core__DOT___062497_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->wasmetal_core__DOT___051220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->__VdfgTmp_h8a2b49a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050381_));
    vlSelf->wasmetal_core__DOT___047785_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002966_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002965_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002963_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002968_)))))))));
    vlSelf->wasmetal_core__DOT___003146_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047792_)))))));
    vlSelf->wasmetal_core__DOT___009501_ = ((IData)(vlSelf->wasmetal_core__DOT___002969_) 
                                            & (IData)(
                                                      (0x8000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002968_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002966_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002965_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002964_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___002963_)))))))));
    vlSelf->__VdfgTmp_h50379cea__0 = ((2U & ((0x80000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___047966_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047985_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003009_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x777ffffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((0x4000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                                         << 3U)) 
                                                                     | ((4U 
                                                                         & ((0x8000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))))))) 
                                             << 1U)) 
                                      | (1U & (0x80000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___047983_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047982_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1ffffffU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x1000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___002984_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1110fffffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070599_ = (1U & (0xf88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___002965_))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x4000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___070596_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___070595_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_phase))))))))))))));
    vlSelf->wasmetal_core__DOT___047978_ = (1U & (IData)(
                                                         (0x80000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047977_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002977_)))))))));
    vlSelf->wasmetal_core__DOT___051570_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051567_))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036767_) 
                 | (6U >> (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___053016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053010_))));
    vlSelf->wasmetal_core__DOT___063094_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052839_))));
    vlSelf->wasmetal_core__DOT___062601_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052894_)))));
    vlSelf->__VdfgTmp_h5c8f7b91__0 = (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052839_));
    vlSelf->wasmetal_core__DOT___052885_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052880_))));
    vlSelf->wasmetal_core__DOT___053567_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052888_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052881_))));
    vlSelf->wasmetal_core__DOT___052911_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052899_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052898_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052897_)))));
    vlSelf->wasmetal_core__DOT___053089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051200_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050366_))));
    vlSelf->wasmetal_core__DOT___063787_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hced715c6__0))));
    vlSelf->wasmetal_core__DOT___052644_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hced715c6__0))));
    vlSelf->__VdfgTmp_h2157de83__0 = (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___062976_));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc52368c6__0))));
    vlSelf->wasmetal_core__DOT___053973_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 8U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_y 
                                                             >> 9U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_x 
                                                               >> 0xaU)))))));
    vlSelf->wasmetal_core__DOT___053966_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x12U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h94eb0193__0))))));
    vlSelf->wasmetal_core__DOT___053980_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x1cU)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1dU)) 
                                                         | ((2U 
                                                             & (vlSelf->insn_y 
                                                                >> 0x19U)) 
                                                            | (1U 
                                                               & (vlSelf->insn_x 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd0f5eb35__0))));
    vlSelf->wasmetal_core__DOT___050764_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 6U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd6f0d46f__0))));
    vlSelf->wasmetal_core__DOT___049400_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hefae6eba__0))));
    vlSelf->wasmetal_core__DOT___048524_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hec90fad7__0))));
    vlSelf->wasmetal_core__DOT___048526_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc3828814__0))));
    vlSelf->wasmetal_core__DOT___048522_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->insn_x)))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd3ff3db1__0))));
    vlSelf->wasmetal_core__DOT___050766_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he98db662__0))));
    vlSelf->wasmetal_core__DOT___049402_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1a8ff62f__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h19a3d105__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h134dac5a__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3c4e434c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3d708201__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h2660b6cc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h273da3c5__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he4692376__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3a2be217__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he16c95bc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h26a9e557__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h16f85c0c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hedbed4ea__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he08305af__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h272aca04__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_heb8306fa__0))));
    vlSelf->__VdfgTmp_he7cea807__0 = (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h265c757d__0));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he580b887__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he366744c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he081d797__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_heb713746__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h10bdd4bc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1fc2f2ef__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1585cf87__0))));
    vlSelf->wasmetal_core__DOT___050924_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1eU)) 
                                                      | (vlSelf->insn_x 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___050945_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94eb0193__0))));
    vlSelf->wasmetal_core__DOT___050947_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xfU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___050959_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 7U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___050952_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x15U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___050937_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1cU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___050927_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x18U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___050919_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1bU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___050950_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x16U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___050943_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x10U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___050957_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 8U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___050935_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xcU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___050954_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xaU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___050933_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xbU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___031341_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3030300fffffffeULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & (vlSelf->insn_y 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051567_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051569_))))))))))));
    vlSelf->wasmetal_core__DOT___071847_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053427_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051569_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051567_)))));
    vlSelf->wasmetal_core__DOT___053353_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052880_)))));
    vlSelf->wasmetal_core__DOT___009542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052796_))));
    vlSelf->wasmetal_core__DOT___052834_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052796_))));
    vlSelf->wasmetal_core__DOT___052649_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048519_))));
    vlSelf->__VdfgTmp_hbdf577ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048519_));
    vlSelf->wasmetal_core__DOT___053617_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019414_))));
    vlSelf->__VdfgTmp_h56fc5986__0 = (((IData)(vlSelf->wasmetal_core__DOT___052939_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019414_));
    if (vlSelf->wasmetal_core__DOT__sp__05b6__05d) {
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___053475_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053260_))));
    vlSelf->wasmetal_core__DOT___007436_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___052806_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___052805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy))));
    vlSelf->__VdfgTmp_ha85820a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___053333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045596_));
    vlSelf->wasmetal_core__DOT___053437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053333_))));
    vlSelf->wasmetal_core__DOT___003035_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___002966_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___003014_)
                                                    ? (IData)(
                                                              (0x8000000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0)))
                                                    : (IData)(
                                                              (0x80000000ffffffffULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h223d2b22__0))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___003014_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003013_)))));
    vlSelf->wasmetal_core__DOT___044190_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                                                      ? 
                                                     ((~ (IData)(vlSelf->wasmetal_core__DOT___045716_)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044194_))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044170_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (3U 
                                                     & (vlSelf->insn_op 
                                                        >> 0x18U))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___045715_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___045719_)
                                                           ? (IData)(vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__)
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045716_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT___009541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045725_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044180_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128027___O 
        = (0xfU & ((vlSelf->insn_z >> 4U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027954_))))));
    vlSelf->wasmetal_core__DOT___027958_ = ((vlSelf->insn_z 
                                             >> 7U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128267___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 7U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 6U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->mem_rdata[0U] 
                                            >> 5U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 4U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030489_)))));
    vlSelf->wasmetal_core__DOT___030493_ = (1U & ((0x80U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 7U)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128003___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027729_)))));
    vlSelf->wasmetal_core__DOT___027733_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128035___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028019_)))));
    vlSelf->wasmetal_core__DOT___028023_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128156___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029310_)))));
    vlSelf->wasmetal_core__DOT___029314_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128189___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029672_)))));
    vlSelf->wasmetal_core__DOT___029676_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128206___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029841_)))));
    vlSelf->wasmetal_core__DOT___029845_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128371___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031611_)))));
    vlSelf->wasmetal_core__DOT___031615_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128419___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032092_)))));
    vlSelf->wasmetal_core__DOT___032096_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128275___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030584_)))));
    vlSelf->wasmetal_core__DOT___030588_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128223___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030010_)))));
    vlSelf->wasmetal_core__DOT___030014_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029941_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032893_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127995___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027664_)))));
    vlSelf->wasmetal_core__DOT___027668_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d));
    vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029409_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027828_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128256___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030370_)))));
    vlSelf->wasmetal_core__DOT___030374_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128051___O 
        = (0xfU & ((vlSelf->insn_x >> 4U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028180_))))));
    vlSelf->wasmetal_core__DOT___028184_ = ((vlSelf->insn_x 
                                             >> 7U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029248_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128019___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027890_)))));
    vlSelf->wasmetal_core__DOT___027894_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128315___O 
        = (((8U & ((~ (vlSelf->function_params >> 7U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 6U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->function_params 
                                            >> 5U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 4U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030971_)))));
    vlSelf->wasmetal_core__DOT___030975_ = ((~ (vlSelf->function_params 
                                                >> 7U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071582_ = (1U & (1U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))));
    vlSelf->wasmetal_core__DOT___071588_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8fU 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071578_))));
    vlSelf->wasmetal_core__DOT___019592_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b68__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfffe7fffffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___071677_ = (1U & (0xbffdffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h53b39b5e__0))));
    vlSelf->__VdfgTmp_hb8bcf48d__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (0xbdffU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h91551c13__0)))));
    vlSelf->wasmetal_core__DOT___071594_ = (1U & (IData)(
                                                         (0xe000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                 << 2U))))));
    vlSelf->wasmetal_core__DOT___071587_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x80U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))))));
    vlSelf->wasmetal_core__DOT___071606_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x80U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___071583_)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___071583_))))))));
    vlSelf->wasmetal_core__DOT___071616_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                    << 3U)))))));
    vlSelf->wasmetal_core__DOT___071642_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___071656_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->__VdfgTmp_h79139d38__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     << 4U)) 
                                                 | (0xfU 
                                                    & (~ 
                                                       (7U 
                                                        | (8U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                              << 3U)))))));
    vlSelf->wasmetal_core__DOT___071602_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071583_))));
    vlSelf->__VdfgTmp_he7466e08__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                  << 4U) 
                                                 | (8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U))));
    vlSelf->__VdfgTmp_hce5a5a6e__0 = ((2U & ((8U >> 
                                              (1U & 
                                               (8U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))) 
                                             << 1U)) 
                                      | (1U & (0x8fU 
                                               >> ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                   << 2U))));
    vlSelf->wasmetal_core__DOT___071610_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___071583_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___071583_))))));
    vlSelf->__VdfgTmp_h3a1fe2e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                       << 4U) | (0xfU 
                                                 & (~ 
                                                    (7U 
                                                     | (8U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                           << 3U))))));
    vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032221_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___062994_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052872_)))));
    vlSelf->wasmetal_core__DOT___062981_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___044791_ = (1U & (IData)(
                                                         (0xf0aaf000f0ccfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070633_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___044803_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070633_)))))))));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032701_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___065573_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065560_)))));
    vlSelf->wasmetal_core__DOT___066374_ = (1U & (0x4404ff0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066372_)))))));
    vlSelf->wasmetal_core__DOT___066369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065568_))));
    vlSelf->wasmetal_core__DOT___070365_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___070377_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___070389_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___070439_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___070130_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___070144_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___070171_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___070158_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___070232_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___070248_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___069765_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___069786_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067557_))))));
    vlSelf->wasmetal_core__DOT___068494_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___064249_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064247_))))));
    vlSelf->wasmetal_core__DOT___069676_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069699_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->wasmetal_core__DOT___069743_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))));
    vlSelf->__VdfgTmp_hede308eb__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065567_));
    vlSelf->__VdfgTmp_haa81a95c__0 = (((IData)(vlSelf->wasmetal_core__DOT___067557_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))));
    vlSelf->wasmetal_core__DOT___069260_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___070203_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xbU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070218_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xcU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___067622_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067703_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->wasmetal_core__DOT___067567_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))))));
    vlSelf->__VdfgTmp_h76d711b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))));
    vlSelf->wasmetal_core__DOT___066457_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067216_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___066943_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066375_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066556_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066724_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04a3d61f__0))));
    vlSelf->wasmetal_core__DOT___066996_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))));
    vlSelf->wasmetal_core__DOT___069585_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___067360_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___067504_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))));
    vlSelf->wasmetal_core__DOT___069608_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067428_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___066809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067264_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___066670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___067110_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___066480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___070014_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___069997_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___070053_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___070112_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___070036_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___070350_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___067623_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067935_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067772_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___067704_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___067569_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___067833_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___067986_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___067864_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___068051_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___068492_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___065586_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065581_))));
    vlSelf->wasmetal_core__DOT___070191_ = (1U & (IData)(
                                                         (0x503000305030f030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x47U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065566_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 4U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->__VdfgTmp_h625a9757__0 = (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1936621__0))));
    vlSelf->wasmetal_core__DOT___067566_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___067558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066370_))));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037211_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5afc8767__0))));
    vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034647_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035139_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034925_));
    vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026288_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d));
    vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026192_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026384_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d));
    vlSelf->wasmetal_core__DOT___054482_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054480_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->result_index) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054484_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054483_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___052581_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052580_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___051019_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032824_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128499___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032988_)))));
    vlSelf->wasmetal_core__DOT___032992_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046797_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___031170_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__))));
    vlSelf->wasmetal_core__DOT___031458_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))));
    vlSelf->wasmetal_core__DOT___032481_ = (1U & (0x5030afcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032353_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))))));
    vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046930_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___066629_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                    << 4U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                 << 1U)) 
                                                               << 1U))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc31691c0__0)))));
    vlSelf->wasmetal_core__DOT___051008_ = (1U & (0xcfaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> 
                                                              (3U 
                                                               & (- (IData)(
                                                                            (1U 
                                                                             & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc31691c0__0))))));
    vlSelf->wasmetal_core__DOT___053125_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xe0U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053122_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                    << 1U))))))))));
    vlSelf->wasmetal_core__DOT___065161_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (- (IData)(
                                                                       (1U 
                                                                        & (4U 
                                                                           >> 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                            << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___052738_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf4f400ffU 
                                                           >> 
                                                           ((0x10U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049006_)))));
    vlSelf->__VdfgTmp_h558c6a5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0));
    vlSelf->wasmetal_core__DOT___066715_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048563_)))));
    vlSelf->wasmetal_core__DOT___049848_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048563_)))));
    vlSelf->wasmetal_core__DOT___049049_ = (1U & (0xe000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___048562_)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048563_))))));
    vlSelf->wasmetal_core__DOT___066106_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066104_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049333_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))));
    vlSelf->__VdfgTmp_h8e945c96__0 = (((IData)(vlSelf->wasmetal_core__DOT___049333_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf0f0f080ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                              << 5U) 
                                                             | (4U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                   << 2U)))))));
    vlSelf->wasmetal_core__DOT___053186_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xbf00bfbfbfbfbfbfULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                             << 1U)) 
                                                                           << 1U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___051607_)))))))))));
    vlSelf->__VdfgTmp_h41349efa__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                               << 1U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051607_));
    vlSelf->wasmetal_core__DOT___053726_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049791_)))));
    vlSelf->wasmetal_core__DOT___066877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xbfbfbfbfbfULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                              << 1U))) 
                                                                         << 4U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                              << 1U)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                               << 1U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051107_))))))))))));
    vlSelf->wasmetal_core__DOT___051998_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051767_)))));
    vlSelf->wasmetal_core__DOT___054847_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049480_)))));
    vlSelf->__VdfgTmp_h808d3d88__0 = (((IData)(vlSelf->wasmetal_core__DOT___049480_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048562_));
    vlSelf->__VdfgTmp_h6af6bfd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___051006_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049787_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048562_))))));
    vlSelf->__VdfgTmp_h9b387498__0 = (((IData)(vlSelf->wasmetal_core__DOT___049791_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049787_)))));
    vlSelf->__VdfgTmp_h72fb59a4__0 = ((2U & ((1U >> 
                                              ((2U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___051105_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051107_));
    vlSelf->__VdfgTmp_hf722c8bb__0 = ((2U & ((0xc5U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051105_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051767_));
    vlSelf->wasmetal_core__DOT___051051_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051049_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___051407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051049_))));
    vlSelf->__VdfgTmp_he13a5cf9__0 = ((2U & ((0xf0880000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff80ffff0000ffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0)))));
    vlSelf->__VdfgTmp_hd52a210e__0 = ((2U & ((0xc0aU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((0x10U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                << 2U)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xffff01ffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0)))));
    vlSelf->wasmetal_core__DOT___051982_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff00ff1fffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h06d4437a__0)))))));
    vlSelf->wasmetal_core__DOT___052626_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfe00000000000000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h06d4437a__0))))))));
    vlSelf->__VdfgTmp_h937c72cf__0 = ((2U & ((0x5333U 
                                              >> ((8U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 3U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (4U 
                                                           >> 
                                                           (2U 
                                                            & ((0x10U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                 << 2U)) 
                                                               << 1U))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfe00000000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h06d4437a__0)))));
    vlSelf->__VdfgTmp_h27becb7d__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049878_)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff00ff00ff1fffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h06d4437a__0)))));
    vlSelf->__VdfgTmp_hb744a8fa__0 = ((2U & ((0x35U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049878_)) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfef0000000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0)))));
    vlSelf->__VdfgTmp_h53aec20d__0 = ((2U & ((0xa333U 
                                              >> ((8U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 3U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049878_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___050548_));
    vlSelf->__VdfgTmp_h73a0c82f__0 = ((2U & ((0x30aU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049878_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___049879_));
    vlSelf->wasmetal_core__DOT___050812_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h25023fb5__0))))));
    vlSelf->wasmetal_core__DOT___051361_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h25023fb5__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___051576_ = (1U & (0xf0f0f11U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25023fb5__0)))));
    vlSelf->wasmetal_core__DOT___053393_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x1ffffffffULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h84873f61__0))))))));
    vlSelf->wasmetal_core__DOT___055064_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfffe000000000000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h84873f61__0))))))));
    vlSelf->__VdfgTmp_ha2558491__0 = (((IData)(vlSelf->wasmetal_core__DOT___050482_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x80000000ffffffffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->__VdfgTmp_h073e4ce8__0 = ((2U & ((0x35U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((0x10U 
                                                                    >> 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                     << 2U)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfffe000000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->__VdfgTmp_habfc584e__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                               << 2U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1ffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->__VdfgTmp_h37fa163f__0 = (((IData)(vlSelf->wasmetal_core__DOT___049743_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x7fff00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->__VdfgTmp_h2290cda0__0 = ((2U & ((0xf0f0f77U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x7f00000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->wasmetal_core__DOT___051842_ = (1U & (IData)(
                                                         (0x80ffffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                  << 3U) 
                                                                 | (4U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 2U))))))));
    vlSelf->wasmetal_core__DOT___051618_ = (1U & (0xefff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x10U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                            << 2U)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                          << 2U) 
                                                         | (2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 1U)))))));
    vlSelf->wasmetal_core__DOT___065166_ = (1U & (IData)(
                                                         (0x7fff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O), 2U)))))));
    vlSelf->wasmetal_core__DOT___051585_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> 
                                                             (1U 
                                                              & (0x8fU 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                  << 2U)))) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))));
    vlSelf->wasmetal_core__DOT___067176_ = (1U & (0x44f00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (1U 
                                                                  & (0x8fU 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                      << 2U)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))));
    vlSelf->wasmetal_core__DOT___053113_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> 
                                                             (1U 
                                                              & (0x8fU 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                  << 2U)))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___053390_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((0x10U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                   << 2U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___066711_ = (1U & (IData)(
                                                         (0xf7f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0fa5f18f__0))))));
    vlSelf->wasmetal_core__DOT___051923_ = (1U & (0x8000bfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 3U)) 
                                                      | (1U 
                                                         & (0x8fU 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                             << 2U)))))));
    vlSelf->wasmetal_core__DOT___050561_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049537_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (2U 
                                                      & ((0x10U 
                                                          >> 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                           << 2U)) 
                                                         << 1U)))));
    vlSelf->wasmetal_core__DOT___051066_ = (1U & (0x35U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (1U 
                                                         & (0x8fU 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                             << 2U)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048676_))));
    vlSelf->wasmetal_core__DOT___050793_ = (1U & (0x35U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((0x10U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                              << 2U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048676_))));
    vlSelf->__VdfgTmp_ha09ba029__0 = ((2U & ((0x8fU 
                                              >> ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                  << 2U)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048676_));
    vlSelf->__VdfgTmp_h5eca347b__0 = (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                       << 1U) | (1U 
                                                 & (0x8fU 
                                                    >> 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                     << 2U))));
    vlSelf->wasmetal_core__DOT___049599_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___048679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049607_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051553_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O), 2U)))))));
    vlSelf->wasmetal_core__DOT___048681_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0fa5f18f__0))))));
    vlSelf->wasmetal_core__DOT___053383_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & (- (IData)(
                                                                      (1U 
                                                                       & (8U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))))))));
    vlSelf->wasmetal_core__DOT___053855_ = (1U & (IData)(
                                                         (0xa802aaaaaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d))))));
    vlSelf->wasmetal_core__DOT___051654_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009534_))));
    vlSelf->wasmetal_core__DOT___051841_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))))));
    vlSelf->wasmetal_core__DOT___051617_ = (1U & (IData)(
                                                         (0x1ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 5U) 
                                                           | (0x18U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                 << 3U))))));
    vlSelf->wasmetal_core__DOT___051701_ = (1U & (0x8000bfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 3U)) 
                                                      | (1U 
                                                         & (0x8fU 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                             << 2U)))))));
    vlSelf->wasmetal_core__DOT___051884_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((0x10U 
                                                                     >> 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                      << 2U)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___053192_ = (1U & (IData)(
                                                         (0xfffe000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (4U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    << 2U)))))));
    vlSelf->wasmetal_core__DOT___051758_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (1U 
                                                             & (0x8fU 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                 << 2U)))))))));
    vlSelf->wasmetal_core__DOT___053582_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((0x10U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                 << 2U)) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___053553_ = (1U & (0xf4U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x10U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 2U)) 
                                                          << 2U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                         << 1U)))));
    vlSelf->wasmetal_core__DOT___051790_ = (1U & (0x5333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((0x10U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                  << 2U)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___050041_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                               << 4U) 
                                                              | (4U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    << 2U)))))));
    vlSelf->wasmetal_core__DOT___049525_ = (1U & (IData)(
                                                         (0xffff01ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                               << 4U) 
                                                              | (0xfU 
                                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O), 3U)))))));
    vlSelf->wasmetal_core__DOT___053695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((0x10U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                   << 2U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___052601_ = (1U & (0xfe000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 3U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))));
    vlSelf->wasmetal_core__DOT___050798_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))));
    vlSelf->wasmetal_core__DOT___053684_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> 
                                                             (1U 
                                                              & (0x8fU 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                  << 2U)))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->__VdfgTmp_h52e200a0__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                             << 2U)) 
                                      | ((2U & ((1U 
                                                 >> 
                                                 (1U 
                                                  & (0x8fU 
                                                     >> 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                      << 2U)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___009534_)));
    vlSelf->__VdfgTmp_h4795829e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O), 1U)));
    vlSelf->wasmetal_core__DOT___051700_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (0x80U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))))))));
    vlSelf->wasmetal_core__DOT___051773_ = (1U & (0xe0000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                      << 2U))));
    vlSelf->__VdfgTmp_h7a8eb480__0 = ((0x30U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                << 4U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                         << 3U));
    vlSelf->wasmetal_core__DOT___050904_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))));
    vlSelf->wasmetal_core__DOT___049897_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (0xe000U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                << 2U)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___050846_ = (1U & (0xac00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->__VdfgTmp_hc1e7aa45__0 = ((0x18U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                          << 2U) | 
                                         (1U & (0x80U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___049764_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (0x80U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->__VdfgTmp_h9e2bcde2__0 = ((2U & ((0x8fU 
                                              >> ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                  << 2U)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_));
    vlSelf->wasmetal_core__DOT___049595_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (0xe000U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 2U))))))));
    vlSelf->wasmetal_core__DOT___051351_ = (1U & (0x3335U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (0x80U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))));
    vlSelf->wasmetal_core__DOT___051659_ = (1U & (IData)(
                                                         (0xfe00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 3U)))));
    vlSelf->wasmetal_core__DOT___051523_ = (1U & (0x3335U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xe000U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                             << 2U)))))));
    vlSelf->wasmetal_core__DOT___050825_ = (1U & (0xac00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((2U 
                                                       & ((0xe000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___050794_ = (1U & (IData)(
                                                         (0xffff01ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 5U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 4U)))));
    vlSelf->__VdfgTmp_h25173009__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                       << 1U) | (1U 
                                                 & (0x8fU 
                                                    >> 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                     << 2U))));
    vlSelf->__VdfgTmp_h05f5edae__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                       << 5U) | (0x1cU 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                    << 2U)));
    vlSelf->wasmetal_core__DOT___051735_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___051788_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___049720_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009534_))));
    vlSelf->__VdfgTmp_h0467adbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                    << 4U)));
    vlSelf->wasmetal_core__DOT___049215_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___009534_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))));
    vlSelf->wasmetal_core__DOT___049217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009534_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128577___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128395___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031898_)))));
    vlSelf->wasmetal_core__DOT___055109_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053772_))));
    vlSelf->wasmetal_core__DOT___053774_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053771_))));
    vlSelf->wasmetal_core__DOT___053563_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052858_))));
    vlSelf->wasmetal_core__DOT___053438_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050389_))));
    vlSelf->wasmetal_core__DOT___042683_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___070632_ = (1U & (0xffff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003045_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003044_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003042_)))))));
    vlSelf->wasmetal_core__DOT___042541_ = (1U & (0x1f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___052733_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052732_))));
    vlSelf->wasmetal_core__DOT___055347_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & vlSelf->insn_x) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052732_))))));
    vlSelf->wasmetal_core__DOT___048389_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048356_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))));
    vlSelf->wasmetal_core__DOT___048354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048344_))));
    vlSelf->wasmetal_core__DOT___048353_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048350_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048349_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048347_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))));
    vlSelf->wasmetal_core__DOT___007042_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048415_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048408_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048410_))))));
    vlSelf->__VdfgTmp_h3900e5db__0 = ((2U & ((IData)(
                                                     (0x4000000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007061_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048417_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048415_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___048414_)))))))) 
                                             << 1U)) 
                                      | (1U & (0x40000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048410_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((4U 
                                                                & ((0xf11ffU 
                                                                    >> 
                                                                    ((0x10U 
                                                                      & ((8U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048405_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048408_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048407_))))))));
    vlSelf->wasmetal_core__DOT___063413_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->mem_fault) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaaaffff0303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_fault)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___062963_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->__VdfgTmp_hde1d4dea__0 = (((IData)(vlSelf->wasmetal_core__DOT___044260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052853_));
    vlSelf->wasmetal_core__DOT___009691_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053775_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053779_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010005_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053764_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053761_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007196_))));
    vlSelf->wasmetal_core__DOT___009653_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054146_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054145_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048407_)))))))));
    vlSelf->wasmetal_core__DOT___052912_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052903_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052902_))));
    vlSelf->wasmetal_core__DOT___053485_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052903_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052882_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052898_)))));
    vlSelf->__VdfgTmp_h652beeee__0 = (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063857_));
    vlSelf->wasmetal_core__DOT___048396_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048332_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1ffU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048319_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048318_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048317_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048316_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019396_)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 8U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b10__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xaU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xaU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x16U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b24__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x18U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x18U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b20__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x14U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x13U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b21__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x15U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x15U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x1cU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b30__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1eU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x10U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b18__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x12U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x12U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b14__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xeU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xeU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xdU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b15__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xfU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xfU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b26__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1aU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b27__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x1bU))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___062964_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((IData)((0x333333330f0f0f55ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & (vlSelf->insn_y 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b1__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->insn_x 
                                                                    >> 1U))))))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 1U))))));
    vlSelf->wasmetal_core__DOT___007044_ = ((IData)(vlSelf->wasmetal_core__DOT___007061_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007057_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048435_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___048434_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007054_))))))))));
    vlSelf->wasmetal_core__DOT___053435_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052894_))));
    vlSelf->__VdfgTmp_hae6fbe86__0 = (((IData)(vlSelf->wasmetal_core__DOT___063817_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052847_));
    vlSelf->wasmetal_core__DOT___063819_ = (1U & (IData)(
                                                         (0x1ff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063817_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048439_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048490_)))))))));
    vlSelf->wasmetal_core__DOT___063450_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052847_))));
    vlSelf->wasmetal_core__DOT___061519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___055104_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019323_))));
    vlSelf->wasmetal_core__DOT___060678_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8cb32961__0)))));
    vlSelf->wasmetal_core__DOT___060672_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha01e8f2f__0))));
    vlSelf->wasmetal_core__DOT___060656_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___053434_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052840_))));
    vlSelf->wasmetal_core__DOT___062602_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053351_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052901_))))));
    vlSelf->__VdfgTmp_hb4ec291e__0 = (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063860_));
    vlSelf->wasmetal_core__DOT___010378_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053776_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x80000000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053770_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053758_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___053755_)))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007191_)))))));
    vlSelf->wasmetal_core__DOT___019222_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019204_))))));
    vlSelf->wasmetal_core__DOT___060718_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___055322_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & vlSelf->insn_x)))))));
    vlSelf->wasmetal_core__DOT___055319_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT___055312_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055311_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019204_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128459___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032633_)))));
    vlSelf->wasmetal_core__DOT___032637_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
                                             : (IData)(wasmetal_core__DOT___128459___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___010376_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056255_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056254_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053762_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053761_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007192_)))))));
    vlSelf->wasmetal_core__DOT___054845_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___054891_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___055015_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___054749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054745_))));
    vlSelf->wasmetal_core__DOT___019221_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))));
    vlSelf->wasmetal_core__DOT___010077_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056256_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053777_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053768_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007195_)))))))));
    vlSelf->wasmetal_core__DOT___054671_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007196_)))));
    vlSelf->wasmetal_core__DOT___063859_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063855_))));
    vlSelf->wasmetal_core__DOT___065614_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065612_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065611_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065610_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065609_)))))));
    vlSelf->wasmetal_core__DOT___066282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065612_))));
    vlSelf->wasmetal_core__DOT___011740_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048469_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051252_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053761_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048465_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048471_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053753_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054146_)))))))));
    vlSelf->wasmetal_core__DOT___033033_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048284_)))))))));
    vlSelf->wasmetal_core__DOT___000418_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048271_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045642_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___048285_ = (1U & (IData)(
                                                         (7ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048280_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048275_)))))))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030686_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___053015_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053013_))));
    vlSelf->wasmetal_core__DOT___062498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052895_))));
    vlSelf->wasmetal_core__DOT___053271_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047784_)))));
    vlSelf->wasmetal_core__DOT___000157_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047784_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___003093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047785_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047784_))))));
    vlSelf->wasmetal_core__DOT___048391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003146_))));
    vlSelf->wasmetal_core__DOT___053373_ = (1U & (IData)(
                                                         (0xff00e000ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053122_)))))))));
    vlSelf->wasmetal_core__DOT___003030_ = (1U & (IData)(
                                                         (0xff00ff0f0f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_op 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x53ffffffffffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_op 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_op 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_op) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11a2e1d4__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047792_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((0x777ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002984_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002981_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002980_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002979_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___003028_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047955_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0))))))))))))));
    vlSelf->wasmetal_core__DOT___003033_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->wasmetal_core__DOT___070600_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047979_))));
    vlSelf->wasmetal_core__DOT___070606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070599_))));
    vlSelf->wasmetal_core__DOT___003029_ = (1U & (0xf0fff88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047978_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___051571_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051569_))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036778_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___062960_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052879_)))));
    vlSelf->wasmetal_core__DOT___052890_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052885_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052884_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052882_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h93f3e051__0))))))));
    vlSelf->wasmetal_core__DOT___053355_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052911_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x100000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052910_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053351_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053350_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___052901_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052893_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___052902_))))))))))));
    vlSelf->wasmetal_core__DOT___053090_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053089_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051201_))));
    vlSelf->wasmetal_core__DOT___062967_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053089_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052845_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051201_)))))))));
    vlSelf->wasmetal_core__DOT___063788_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    vlSelf->wasmetal_core__DOT___046221_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052645_)))));
    vlSelf->__VdfgTmp_h7f45eb21__0 = (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052644_));
    vlSelf->wasmetal_core__DOT___052646_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->wasmetal_core__DOT___063447_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050381_)))));
    vlSelf->__VdfgTmp_he0cbb0dc__0 = ((2U & (vlSelf->insn_z 
                                             >> 5U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->__VdfgTmp_heaa2bcd7__0 = ((2U & (vlSelf->insn_z 
                                             >> 3U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->__VdfgTmp_hed859ce1__0 = ((2U & (vlSelf->insn_z 
                                             >> 4U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b7__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 6U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050764_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 7U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b5__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 4U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049400_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 5U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b2__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048524_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 2U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b3__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048526_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 3U))))));
    vlSelf->wasmetal_core__DOT___051172_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5760b542__0))))));
    vlSelf->wasmetal_core__DOT___050125_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6e193d9b__0))))));
    vlSelf->wasmetal_core__DOT___051180_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h79496643__0))))));
    vlSelf->wasmetal_core__DOT___050665_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb256bb9f__0))))));
    vlSelf->wasmetal_core__DOT___050746_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3eb04205__0))))));
    vlSelf->wasmetal_core__DOT___051127_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a6ef80c__0))))));
    vlSelf->wasmetal_core__DOT___051156_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h40ae3a4f__0))))));
    vlSelf->wasmetal_core__DOT___051160_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he25b67d8__0))))));
    vlSelf->wasmetal_core__DOT___051164_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h89ddcfc9__0))))));
    vlSelf->wasmetal_core__DOT___050969_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a9f8029__0))))));
    vlSelf->wasmetal_core__DOT___050991_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ec6b47d__0))))));
    vlSelf->wasmetal_core__DOT___050973_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8555f3e8__0))))));
    vlSelf->wasmetal_core__DOT___050908_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0d4cc40__0))))));
    vlSelf->wasmetal_core__DOT___050914_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a192e7e__0))))));
    vlSelf->wasmetal_core__DOT___051090_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5864b2ba__0))))));
    vlSelf->wasmetal_core__DOT___050890_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc7c61c07__0))))));
    vlSelf->wasmetal_core__DOT___050783_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcafe333f__0))))));
    vlSelf->wasmetal_core__DOT___050779_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h236ea405__0))))));
    vlSelf->wasmetal_core__DOT___050244_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___050236_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b99__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b98__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b97__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___050240_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b119__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b116__05d)))))))));
    vlSelf->wasmetal_core__DOT___050196_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___049912_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b131__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b130__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b129__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b128__05d)))))))));
    vlSelf->wasmetal_core__DOT___050204_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___050220_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b195__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b194__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b193__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b192__05d)))))))));
    vlSelf->wasmetal_core__DOT___050216_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b235__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b234__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b233__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b232__05d)))))))));
    vlSelf->wasmetal_core__DOT___050212_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b247__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b246__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b245__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b244__05d)))))))));
    vlSelf->wasmetal_core__DOT___049976_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___049980_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b99__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b98__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b97__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___049984_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b119__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b116__05d)))))))));
    vlSelf->wasmetal_core__DOT___050000_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___049996_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b131__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b130__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b129__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b128__05d)))))))));
    vlSelf->wasmetal_core__DOT___050004_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___050016_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b195__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b194__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b193__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b192__05d)))))))));
    vlSelf->wasmetal_core__DOT___050020_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b235__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b234__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b233__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b232__05d)))))))));
    vlSelf->wasmetal_core__DOT___050024_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b247__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b246__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b245__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b244__05d)))))))));
    vlSelf->wasmetal_core__DOT___051176_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd8443bfe__0))))));
    vlSelf->wasmetal_core__DOT___051144_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1aa87dc1__0))))));
    vlSelf->wasmetal_core__DOT___051152_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h139eafce__0))))));
    vlSelf->wasmetal_core__DOT___050987_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hef41fa97__0))))));
    vlSelf->wasmetal_core__DOT___051086_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h47e0de34__0))))));
    vlSelf->wasmetal_core__DOT___050886_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc408f28d__0))))));
    vlSelf->wasmetal_core__DOT___050310_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h02a1ae9a__0))))));
    vlSelf->wasmetal_core__DOT___050303_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c9e90c9__0))))));
    vlSelf->wasmetal_core__DOT___050318_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8546e85d__0))))));
    vlSelf->wasmetal_core__DOT___051005_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefac84ff__0))))));
    vlSelf->wasmetal_core__DOT___051078_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf782be94__0))))));
    vlSelf->wasmetal_core__DOT___051001_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6727edf3__0))))));
    vlSelf->wasmetal_core__DOT___050232_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b86__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b85__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___050200_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b171__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b170__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b169__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b168__05d)))))))));
    vlSelf->wasmetal_core__DOT___050224_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b215__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b214__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b213__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b212__05d)))))))));
    vlSelf->wasmetal_core__DOT___049972_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b86__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b85__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___049992_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b171__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b170__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b169__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b168__05d)))))))));
    vlSelf->wasmetal_core__DOT___050012_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b215__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b214__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b213__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b212__05d)))))))));
    vlSelf->wasmetal_core__DOT___050314_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf05a0261__0))))));
    vlSelf->wasmetal_core__DOT___051074_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf724a20__0))))));
    vlSelf->wasmetal_core__DOT___050184_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___050188_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___050180_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___049956_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___049964_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___049960_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___050174_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___049934_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b0__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048522_)))))) 
                                     << 1U)) | (1U 
                                                & vlSelf->cmd_index)))));
    vlSelf->__VdfgTmp_h2f11896e__0 = (((IData)(vlSelf->wasmetal_core__DOT___048522_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b6__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 5U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050766_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 6U))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__ADDRARDADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b4__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 3U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049402_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 4U))))));
    vlSelf->wasmetal_core__DOT___053972_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050766_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049402_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d))))));
    vlSelf->wasmetal_core__DOT___053987_ = (1U & (0x99900999U 
                                                  >> 
                                                  ((0x10U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x1cU)) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7cea807__0)))));
    vlSelf->wasmetal_core__DOT___044486_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___044485_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044487_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he7cea807__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___044479_ = (1U & (0xfffffffeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b31__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1eU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050924_)))))) 
                                     << 1U)) | (vlSelf->cmd_index 
                                                >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b19__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x12U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050945_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x13U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b16__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xfU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050947_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x10U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b8__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 7U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050959_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 8U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b22__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x15U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050952_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x16U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b29__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1cU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050937_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b25__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x18U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050927_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___053971_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050927_))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b28__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1bU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050919_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___070592_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050937_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050919_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050924_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b23__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x16U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050950_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___053964_ = (1U & (IData)(
                                                         (0xa2a200a28a008a8aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x12U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x13U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050950_))))))))))));
    vlSelf->wasmetal_core__DOT___070591_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050950_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050927_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x17U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b17__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x10U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050943_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___053986_ = (1U & (IData)(
                                                         (0x1428000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_he16c95bc__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050943_)))))))));
    vlSelf->wasmetal_core__DOT___070590_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050947_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050945_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x12U))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b9__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 8U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050957_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 9U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b13__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xcU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050935_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xdU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b11__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xaU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050954_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___053979_ = (1U & (IData)(
                                                         (0x4141410000414141ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 7U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_x 
                                                                  >> 8U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x14U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050954_))))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b12__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xbU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050933_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___070589_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050933_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050954_))));
    vlSelf->wasmetal_core__DOT___031354_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1eU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031353_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1dU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031351_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1cU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031350_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1bU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031349_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1aU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031348_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x19U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031347_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x18U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031346_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x17U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031345_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x16U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031344_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x15U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031343_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x14U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031342_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x13U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031340_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x12U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031339_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031338_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x10U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031337_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xfU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031336_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xeU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031335_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xdU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031334_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xcU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031333_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xbU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031332_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xaU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031331_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 9U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031361_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 8U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031360_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 7U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031359_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 6U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031358_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031357_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
}
