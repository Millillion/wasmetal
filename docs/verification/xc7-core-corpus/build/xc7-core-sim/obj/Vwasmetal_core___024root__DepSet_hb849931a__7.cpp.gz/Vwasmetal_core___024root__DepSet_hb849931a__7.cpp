#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__13(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__13\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___070182_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070175_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b107__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed3b8a65__0))))))));
    vlSelf->wasmetal_core__DOT___069649_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069635_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069634_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b79__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83912db0__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h482142a8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___070243_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070236_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068453_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b111__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068452_)))))))));
    vlSelf->wasmetal_core__DOT___068279_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068269_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068268_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068267_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x10000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b44__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadcb4246__0))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___068069_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068065_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065522_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065516_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b40__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064871_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068063_)))))))));
    vlSelf->wasmetal_core__DOT___070168_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070162_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068177_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068176_)))))))));
    vlSelf->wasmetal_core__DOT___067893_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heccca597__0))))))));
    vlSelf->wasmetal_core__DOT___070095_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070089_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b101__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heccca597__0))))))));
    vlSelf->wasmetal_core__DOT___066068_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066062_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x20003fffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                                   << 4U) 
                                                                  | ((0xcU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066059_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___066058_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xe00000fff0ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (7U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064561_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069131_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069127_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b61__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069124_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064662_)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069125_)))))))));
    vlSelf->wasmetal_core__DOT___065887_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065881_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x20003fffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                                   << 4U) 
                                                                  | ((0xcU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065878_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___065877_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf4ff000000ff00ffULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (7U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                                                << 1U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d56b9e6__0)) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 1U)))))))))))))));
    vlSelf->wasmetal_core__DOT___068016_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068002_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068001_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068000_)))))))));
    vlSelf->wasmetal_core__DOT___066259_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066258_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x20003fffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                                   << 4U) 
                                                                  | ((0xcU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066255_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xfffe000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h925d74fa__0)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x20000fff3ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (7U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                              | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)))))))))))))));
    vlSelf->wasmetal_core__DOT___067957_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067939_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067937_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbf300000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b38__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f29c7eb__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 6U))))))))));
    vlSelf->wasmetal_core__DOT___067722_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067718_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ffb000f0fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b34__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067715_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064867_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064872_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067716_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128052___O 
        = (0xfU & ((vlSelf->insn_x >> 8U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028184_))))));
    vlSelf->wasmetal_core__DOT___028157_ = ((vlSelf->insn_x 
                                             >> 0xbU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028119_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 6U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128316___O 
        = (((8U & ((~ (vlSelf->function_params >> 0xbU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0xaU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 9U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 8U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030975_)))));
    vlSelf->wasmetal_core__DOT___030948_ = ((~ (vlSelf->function_params 
                                                >> 0xbU)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070639_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070637_)))))))));
    vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032705_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128468___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___044805_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___044793_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134208___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070634_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134209___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037215_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134210___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h14007945__0))));
    vlSelf->wasmetal_core__DOT___063488_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063487_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063496_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063495_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063504_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063512_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063511_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054486_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054485_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054488_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054487_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 3U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054490_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054492_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054491_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 5U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127827___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127844___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d));
    vlSelf->wasmetal_core__DOT___067614_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067590_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067589_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbf00bfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067582_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064447_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019407_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___068665_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068645_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068638_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068637_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80b000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066579_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065009_)))))))))))))));
    vlSelf->wasmetal_core__DOT___068762_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068734_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80b000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066746_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065216_)))))))))))))));
    vlSelf->wasmetal_core__DOT___068864_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068843_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068842_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068834_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000fcffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065478_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h14cfefd1__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070033_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070029_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070028_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b97__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___066012_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066007_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 0xcU))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))));
    vlSelf->wasmetal_core__DOT___067299_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067296_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))));
    vlSelf->wasmetal_core__DOT___066473_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066467_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054103_)))))));
    vlSelf->wasmetal_core__DOT___066553_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066548_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054107_)))))));
    vlSelf->wasmetal_core__DOT___068339_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))));
    vlSelf->wasmetal_core__DOT___065637_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054067_)))))))));
    vlSelf->wasmetal_core__DOT___066720_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066710_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054115_)))))));
    vlSelf->wasmetal_core__DOT___066802_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066793_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054119_)))))));
    vlSelf->wasmetal_core__DOT___066960_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054127_)))))));
    vlSelf->wasmetal_core__DOT___069647_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069642_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069714_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069710_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069709_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b82__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x10U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069758_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069754_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069753_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b84__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x12U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069801_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069797_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b86__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x14U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___066388_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066385_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054099_)))))));
    vlSelf->wasmetal_core__DOT___066636_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066624_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))));
    vlSelf->wasmetal_core__DOT___066883_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066875_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))));
    vlSelf->wasmetal_core__DOT___069779_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069774_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b85__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069988_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069984_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069983_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b95__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___067400_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067397_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054170_)))))));
    vlSelf->wasmetal_core__DOT___067102_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067099_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))));
    vlSelf->wasmetal_core__DOT___067028_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067025_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054131_)))))));
    vlSelf->wasmetal_core__DOT___067260_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067253_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054162_)))))));
    vlSelf->wasmetal_core__DOT___065050_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065047_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065046_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x30f0200030f030fULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065040_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f01111ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065024_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065023_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f00003355ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065020_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064689_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064690_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___065019_)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065031_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065037_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___065173_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065160_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065159_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x5550fff0fff0cccULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 3U)) 
                                                                          | ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065153_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065134_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064429_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064436_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065132_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065141_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065148_))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___067543_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))));
    vlSelf->wasmetal_core__DOT___064461_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xc0cca0aa00ff00ffULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((1U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                              << 5U)) 
                                                                          | ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064447_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064444_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000077ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064437_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & vlSelf->mem_rdata[0U])))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064436_))))))))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___053073_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053046_)))));
    vlSelf->wasmetal_core__DOT___053062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053061_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053060_))));
    vlSelf->wasmetal_core__DOT___053082_ = (1U & (IData)(
                                                         (0xff11fff0ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053069_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053071_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053070_)))))))));
    vlSelf->wasmetal_core__DOT___053063_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053044_))));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031967_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___069309_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069304_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b4e7e80__0))))))));
    vlSelf->wasmetal_core__DOT___069360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069355_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb8b9d9d__0))))))));
    vlSelf->wasmetal_core__DOT___069385_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069380_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9699bb18__0))))))));
    vlSelf->wasmetal_core__DOT___070063_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h103d8e23__0))))))));
    vlSelf->wasmetal_core__DOT___070080_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbbacc71f__0))))))));
    vlSelf->wasmetal_core__DOT___070107_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h880089dc__0))))))));
    vlSelf->wasmetal_core__DOT___070139_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070137_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 6U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h350dca3c__0))))))));
    vlSelf->wasmetal_core__DOT___070197_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc85d0f69__0))))))));
    vlSelf->wasmetal_core__DOT___070212_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9d0797f2__0))))))));
    vlSelf->wasmetal_core__DOT___070227_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he9b54a3e__0))))))));
    vlSelf->wasmetal_core__DOT___070308_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x13U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h063ae0f2__0))))))));
    vlSelf->wasmetal_core__DOT___070360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x17U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h24206284__0))))))));
    vlSelf->wasmetal_core__DOT___070052_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070046_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053335_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b98__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & vlSelf->cmd_data[3U]) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070044_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_imm[3U]) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h79a44c81__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___070262_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070256_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070255_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b112__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[3U] 
                                                                              >> 0xeU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h26689d2d__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h154ca593__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___070092_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b621180__0))))))));
    vlSelf->wasmetal_core__DOT___070152_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0))))))));
    vlSelf->wasmetal_core__DOT___070165_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45475158__0))))))));
    vlSelf->wasmetal_core__DOT___070179_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1dfe6e3d__0))))))));
    vlSelf->wasmetal_core__DOT___070240_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4b62075b__0))))))));
    vlSelf->wasmetal_core__DOT___070269_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcbd0c1b7__0))))))));
    vlSelf->wasmetal_core__DOT___070281_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x11U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0fc0fcd7__0))))))));
    vlSelf->wasmetal_core__DOT___070293_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x12U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbe45befc__0))))))));
    vlSelf->wasmetal_core__DOT___070319_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x14U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha36008d9__0))))))));
    vlSelf->wasmetal_core__DOT___070331_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x15U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab2bfea3__0))))))));
    vlSelf->wasmetal_core__DOT___070343_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x16U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb797e152__0))))))));
    vlSelf->wasmetal_core__DOT___070371_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x18U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb476a254__0))))))));
    vlSelf->wasmetal_core__DOT___070383_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x19U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c9d0618__0))))))));
    vlSelf->wasmetal_core__DOT___070395_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1aU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h928bb96c__0))))))));
    vlSelf->wasmetal_core__DOT___070408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1bU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf0d36e17__0))))))));
    vlSelf->wasmetal_core__DOT___070420_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1cU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h778ea1a1__0))))))));
    vlSelf->wasmetal_core__DOT___070433_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1dU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha95ffc90__0))))))));
    vlSelf->wasmetal_core__DOT___070445_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1eU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbd4ae96e__0))))))));
    vlSelf->wasmetal_core__DOT___062609_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x4000000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___062603_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062601_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052645_)))))))))))));
    vlSelf->wasmetal_core__DOT___051210_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050441_))));
    vlSelf->wasmetal_core__DOT___050443_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___050363_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030722_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___007473_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->wasmetal_core__DOT___054780_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->__VdfgTmp_h4d98d40a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054987_));
    vlSelf->wasmetal_core__DOT___007489_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbda9acd7__0)))));
    vlSelf->__VdfgTmp_h24bf73d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054988_));
    vlSelf->wasmetal_core__DOT___054997_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc57757c5__0)))));
    vlSelf->wasmetal_core__DOT___055001_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->wasmetal_core__DOT___007372_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h40471efb__0)))));
    vlSelf->__VdfgTmp_hbb17ca10__0 = (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054948_));
    vlSelf->__VdfgTmp_h2eb2dfca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054956_));
    vlSelf->__VdfgTmp_h112f9280__0 = (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054949_));
    vlSelf->wasmetal_core__DOT___007731_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h40b73a73__0)))));
    vlSelf->wasmetal_core__DOT___007346_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h624c4f06__0)))));
    vlSelf->wasmetal_core__DOT___007729_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2e0ea116__0)))));
    vlSelf->wasmetal_core__DOT___007470_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0)))));
    vlSelf->wasmetal_core__DOT___009846_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc3b7ffa9__0)))));
    vlSelf->__VdfgTmp_h4b751076__0 = (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054906_));
    vlSelf->wasmetal_core__DOT___007471_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he34a288c__0)))));
    vlSelf->wasmetal_core__DOT___007720_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hffa75465__0)))));
    vlSelf->wasmetal_core__DOT___007718_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h127745a0__0)))));
    vlSelf->__VdfgTmp_hd70fe4ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051493_));
    vlSelf->wasmetal_core__DOT___007462_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h41aaabca__0)))));
    vlSelf->__VdfgTmp_h721400e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051491_));
    vlSelf->wasmetal_core__DOT___054862_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8f363e22__0)))));
    vlSelf->wasmetal_core__DOT___007286_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h878f9978__0)))));
    vlSelf->wasmetal_core__DOT___054866_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5ba532b7__0)))));
    vlSelf->wasmetal_core__DOT___061478_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007258_))));
    vlSelf->__VdfgTmp_hfd8d7c51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054807_));
    vlSelf->wasmetal_core__DOT___007453_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7690c014__0)))));
    vlSelf->wasmetal_core__DOT___061480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007257_))));
    vlSelf->__VdfgTmp_h78fd8e0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054808_));
    vlSelf->wasmetal_core__DOT___054817_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1dc222f__0)))));
    vlSelf->wasmetal_core__DOT___007259_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h01d6394a__0)))));
    vlSelf->wasmetal_core__DOT___054821_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ee5998b__0)))));
    vlSelf->wasmetal_core__DOT___007447_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc18298c4__0)))));
    vlSelf->wasmetal_core__DOT___007232_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->__VdfgTmp_he2e8a11a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054767_));
    vlSelf->__VdfgTmp_ha7d64f39__0 = (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054768_));
    vlSelf->wasmetal_core__DOT___054782_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88de5544__0)))));
    vlSelf->__VdfgTmp_h597612ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054989_));
    vlSelf->wasmetal_core__DOT___054999_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7146d025__0)))));
    vlSelf->__VdfgTmp_h642b0391__0 = (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054950_));
    vlSelf->__VdfgTmp_h13d2f137__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007484_));
    vlSelf->wasmetal_core__DOT___027489_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007367_)))))))));
    vlSelf->__VdfgTmp_hd27b8df6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054958_));
    vlSelf->__VdfgTmp_hc98b4d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007472_));
    vlSelf->__VdfgTmp_hf21032c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054908_));
    vlSelf->__VdfgTmp_he6aadab7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051498_));
    vlSelf->wasmetal_core__DOT___054864_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4fcd3c01__0)))));
    vlSelf->wasmetal_core__DOT___061484_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007260_))));
    vlSelf->__VdfgTmp_hc5dd9afa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054809_));
    vlSelf->wasmetal_core__DOT___054819_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h15014ab6__0)))));
    vlSelf->__VdfgTmp_h5e3b944f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054769_));
    vlSelf->wasmetal_core__DOT___061479_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007371_))));
    vlSelf->__VdfgTmp_h064a3607__0 = (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055033_));
    vlSelf->wasmetal_core__DOT___007497_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h62d1863a__0)))));
    vlSelf->wasmetal_core__DOT___061995_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007396_))));
    vlSelf->wasmetal_core__DOT___061481_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007370_))));
    vlSelf->__VdfgTmp_he97c005b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055034_));
    vlSelf->wasmetal_core__DOT___055043_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4a43ab44__0)))));
    vlSelf->wasmetal_core__DOT___007398_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h69484b9c__0)))));
    vlSelf->wasmetal_core__DOT___055047_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->wasmetal_core__DOT___061485_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007373_))));
    vlSelf->__VdfgTmp_h72b22246__0 = (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055035_));
    vlSelf->wasmetal_core__DOT___055045_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6127a0a0__0)))));
    vlSelf->__VdfgTmp_h73281823__0 = (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hffdded68__0)));
    vlSelf->wasmetal_core__DOT___060688_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->wasmetal_core__DOT___060795_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff6b6a1f__0)))));
    vlSelf->__VdfgTmp_hfc1711e0__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))))));
    vlSelf->wasmetal_core__DOT___060689_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha89e6386__0)))));
    vlSelf->wasmetal_core__DOT___060726_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h014e1215__0)))));
    vlSelf->wasmetal_core__DOT___061627_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))));
    vlSelf->wasmetal_core__DOT___054735_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))));
    vlSelf->__VdfgTmp_h73a9d128__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))));
    vlSelf->__VdfgTmp_heab1a15e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)));
    vlSelf->wasmetal_core__DOT___061759_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8763693__0))));
    vlSelf->wasmetal_core__DOT___061831_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5af86920__0))));
    vlSelf->__VdfgTmp_h4dc07bf4__0 = ((2U & ((IData)(
                                                     (0x1000000000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___061452_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061451_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007333_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___061450_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061449_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007334_))))))))));
    vlSelf->wasmetal_core__DOT___061899_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))));
    vlSelf->wasmetal_core__DOT___019245_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h64194573__0))))));
    vlSelf->wasmetal_core__DOT___019257_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h744f9b35__0))))));
    vlSelf->wasmetal_core__DOT___019268_ = (1U & (0xafcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0))))));
    vlSelf->__VdfgTmp_h07c00df2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007340_));
    vlSelf->__VdfgTmp_h1c7a54d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    vlSelf->wasmetal_core__DOT___061473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007253_))));
    vlSelf->__VdfgTmp_h91a424ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007771_));
    vlSelf->wasmetal_core__DOT___027492_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054699_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054675_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007771_)))))))));
    vlSelf->__VdfgTmp_h4a046d69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008408_));
    vlSelf->wasmetal_core__DOT___061469_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___061758_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h551248b6__0))));
    vlSelf->__VdfgTmp_hf6b3ca0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0)));
    vlSelf->wasmetal_core__DOT___061830_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))));
    vlSelf->__VdfgTmp_hcd50fd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0)));
    vlSelf->wasmetal_core__DOT___061898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))));
    vlSelf->__VdfgTmp_habef704b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0)));
    vlSelf->__VdfgTmp_h7208d2a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0)));
    vlSelf->__VdfgTmp_h9e64b929__0 = (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0)));
    vlSelf->__VdfgTmp_h1e1103c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0)));
    vlSelf->__VdfgTmp_hd03398e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007340_))));
    vlSelf->__VdfgTmp_h91f4b3ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008370_));
    vlSelf->__VdfgTmp_hb587b232__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h05980b33__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))));
    vlSelf->__VdfgTmp_h107cea9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h797b2590__0)));
    vlSelf->__VdfgTmp_h4ae2b9ea__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h37472320__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))));
    vlSelf->__VdfgTmp_h5e79b823__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)));
    vlSelf->__VdfgTmp_h90c7fdf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)));
    vlSelf->__VdfgTmp_h99d3b9a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h447558a7__0)));
    vlSelf->__VdfgTmp_h422a580d__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h860ce20a__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca913760__0)))));
    vlSelf->__VdfgTmp_hfce0919b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hca913760__0)));
    vlSelf->wasmetal_core__DOT___061460_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007335_)))))))));
    vlSelf->wasmetal_core__DOT___061468_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
    vlSelf->wasmetal_core__DOT___061621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))));
    vlSelf->wasmetal_core__DOT___061459_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007336_)))))))));
    vlSelf->__VdfgTmp_h27ece1ce__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_hd163f969__0))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0)))));
    vlSelf->wasmetal_core__DOT___061471_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007254_))));
    vlSelf->wasmetal_core__DOT___027478_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->__VdfgTmp_h1b99479d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008333_));
    vlSelf->__VdfgTmp_hcc135002__0 = (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007772_));
    vlSelf->wasmetal_core__DOT___061654_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))));
    vlSelf->__VdfgTmp_h1dd2f13b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0)));
    vlSelf->__VdfgTmp_h28180847__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)));
    vlSelf->wasmetal_core__DOT___063821_ = (1U & (IData)(
                                                         (0x3f15151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
    vlSelf->wasmetal_core__DOT___065938_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001520_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001521_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004174_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31a231e1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066083_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001532_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001533_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004248_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000609_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000610_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001120_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001121_))))))))))));
    vlSelf->wasmetal_core__DOT___065605_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001365_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001366_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003802_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07a3b670__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065803_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001409_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001410_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003506_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066401_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001620_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001621_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004322_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39926e96__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066527_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066524_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001642_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001643_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004100_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hccc0d080__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066649_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000429_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001323_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001324_))))))))))));
    vlSelf->wasmetal_core__DOT___066771_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066768_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000460_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000461_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000976_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000977_))))))))))));
    vlSelf->wasmetal_core__DOT___066895_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000494_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000495_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001010_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001011_))))))))))));
    vlSelf->wasmetal_core__DOT___065414_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001483_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001484_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004618_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0dafd81__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065189_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001439_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001440_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004396_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065701_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001377_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001378_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003654_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he23a6b26__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066279_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066275_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001576_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001577_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003728_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b219d07__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001608_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001609_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066604_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000412_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000413_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003884_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066854_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000472_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000473_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000988_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000989_))))))))))));
    vlSelf->wasmetal_core__DOT___067457_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067453_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000653_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000654_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001164_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001165_))))))))))));
    vlSelf->wasmetal_core__DOT___065899_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001421_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001422_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003580_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067345_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000631_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000632_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001142_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001143_))))))))))));
    vlSelf->wasmetal_core__DOT___066125_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066122_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001564_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001565_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h21caabb4__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064900_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001882_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001883_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065063_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001433_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001434_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004544_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50f5670e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065304_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001471_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001472_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004470_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b977022__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067077_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000539_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001054_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001055_))))))))))));
    vlSelf->wasmetal_core__DOT___067155_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000560_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000561_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001076_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001077_))))))))))));
    vlSelf->wasmetal_core__DOT___067196_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000588_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001098_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001099_))))))))))));
    vlSelf->wasmetal_core__DOT___066972_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066969_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000517_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001032_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001033_))))))))))));
    vlSelf->wasmetal_core__DOT___064732_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064729_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001870_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001871_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004840_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cb51258__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064467_ = (1U & (IData)(
                                                         (0x4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064463_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___053588_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->wasmetal_core__DOT___068557_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068554_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067608_ = (1U & (IData)(
                                                         (0xfdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067605_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))))));
    vlSelf->wasmetal_core__DOT___068607_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068656_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068704_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068753_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068752_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068797_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068852_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068851_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068898_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067751_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067748_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068022_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068019_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068081_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068078_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068157_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068242_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068239_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068295_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068292_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068349_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068404_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068401_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067965_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067962_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067726_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067724_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067812_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068428_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068425_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068480_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068477_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067658_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068106_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068943_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068942_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069041_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069091_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069090_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069140_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069139_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068969_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068968_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069233_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069232_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069159_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___053498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053496_))));
    vlSelf->wasmetal_core__DOT___063366_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052843_))));
    vlSelf->wasmetal_core__DOT___061193_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054958_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054950_))))))))))))));
    vlSelf->wasmetal_core__DOT___060776_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054682_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054701_))))))))))))));
    vlSelf->wasmetal_core__DOT___061348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019220_))));
    vlSelf->wasmetal_core__DOT___055433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055422_)))));
    vlSelf->wasmetal_core__DOT___055432_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055424_)))));
    vlSelf->wasmetal_core__DOT___055431_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055426_)))));
    vlSelf->__VdfgTmp_h949b8002__0 = (((IData)(vlSelf->wasmetal_core__DOT___055429_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055428_));
    vlSelf->wasmetal_core__DOT___055421_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055416_)))));
    vlSelf->wasmetal_core__DOT___055420_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055418_)))));
    vlSelf->wasmetal_core__DOT___055764_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055416_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055419_)))));
    vlSelf->wasmetal_core__DOT___055324_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055317_)))));
    vlSelf->wasmetal_core__DOT___055726_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055317_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055321_)))));
    vlSelf->wasmetal_core__DOT___055323_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055320_)))));
    vlSelf->wasmetal_core__DOT___055725_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055320_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055327_)))));
    vlSelf->wasmetal_core__DOT___055338_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055326_)))));
    vlSelf->__VdfgTmp_h1f7f3a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___055326_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055329_));
    vlSelf->wasmetal_core__DOT___055337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055329_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055328_)))));
    vlSelf->wasmetal_core__DOT___055727_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055328_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055331_)))));
    vlSelf->wasmetal_core__DOT___055336_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055330_)))));
    vlSelf->__VdfgTmp_h3d8d5ec6__0 = ((4U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055330_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055333_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___055332_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055319_)));
    vlSelf->wasmetal_core__DOT___055335_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055333_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055332_)))));
    vlSelf->wasmetal_core__DOT___055378_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055367_)))));
    vlSelf->wasmetal_core__DOT___055752_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055370_)))));
    vlSelf->wasmetal_core__DOT___055377_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055369_)))));
    vlSelf->wasmetal_core__DOT___055751_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055369_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055372_)))));
    vlSelf->wasmetal_core__DOT___055376_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055371_)))));
    vlSelf->wasmetal_core__DOT___055749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055373_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055750_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055371_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055374_)))));
    vlSelf->wasmetal_core__DOT___055375_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055374_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055373_)))));
    vlSelf->wasmetal_core__DOT___055503_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055492_)))));
    vlSelf->wasmetal_core__DOT___055782_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055495_)))));
    vlSelf->wasmetal_core__DOT___055502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055494_)))));
    vlSelf->wasmetal_core__DOT___055781_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055497_)))));
    vlSelf->wasmetal_core__DOT___055501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055496_)))));
    vlSelf->wasmetal_core__DOT___055779_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055499_)))));
    vlSelf->wasmetal_core__DOT___055500_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055498_)))));
    vlSelf->wasmetal_core__DOT___055523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055512_)))));
    vlSelf->wasmetal_core__DOT___055794_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055512_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055515_)))));
    vlSelf->wasmetal_core__DOT___055522_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055515_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055514_)))));
    vlSelf->wasmetal_core__DOT___055793_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055514_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055517_)))));
    vlSelf->wasmetal_core__DOT___055521_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055516_)))));
    vlSelf->wasmetal_core__DOT___055791_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055792_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055516_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055519_)))));
    vlSelf->wasmetal_core__DOT___055520_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055519_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055518_)))));
    vlSelf->wasmetal_core__DOT___055599_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055588_)))));
    vlSelf->wasmetal_core__DOT___055810_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055588_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055591_)))));
    vlSelf->wasmetal_core__DOT___055598_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055590_)))));
    vlSelf->wasmetal_core__DOT___055809_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055590_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055593_)))));
    vlSelf->wasmetal_core__DOT___055597_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055592_)))));
    vlSelf->wasmetal_core__DOT___055807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055808_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055595_)))));
    vlSelf->wasmetal_core__DOT___055596_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055594_)))));
    vlSelf->wasmetal_core__DOT___055643_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055638_)))));
    vlSelf->wasmetal_core__DOT___055828_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055641_)))));
    vlSelf->wasmetal_core__DOT___055642_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055640_)))));
    vlSelf->wasmetal_core__DOT___055655_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055644_)))));
    vlSelf->wasmetal_core__DOT___055654_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055646_)))));
    vlSelf->__VdfgTmp_h6b713560__0 = (((IData)(vlSelf->wasmetal_core__DOT___055646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055649_));
    vlSelf->wasmetal_core__DOT___055653_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055649_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055648_)))));
    vlSelf->wasmetal_core__DOT___055829_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055830_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055651_)))));
    vlSelf->wasmetal_core__DOT___055652_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055650_)))));
    vlSelf->wasmetal_core__DOT___055670_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055663_)))));
    vlSelf->wasmetal_core__DOT___055669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055665_)))));
    vlSelf->wasmetal_core__DOT___055858_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055663_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055666_)))));
    vlSelf->wasmetal_core__DOT___055682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055672_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055671_)))));
    vlSelf->wasmetal_core__DOT___055857_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055672_)))));
    vlSelf->wasmetal_core__DOT___055681_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055674_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055673_)))));
    vlSelf->wasmetal_core__DOT___055862_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055671_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055674_)))));
    vlSelf->wasmetal_core__DOT___055680_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055676_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055675_)))));
    vlSelf->wasmetal_core__DOT___055861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055673_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055676_)))));
    vlSelf->wasmetal_core__DOT___055859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___055679_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055678_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055677_)))));
    vlSelf->wasmetal_core__DOT___055860_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055678_)))));
    vlSelf->wasmetal_core__DOT___055957_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055427_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055429_))))))))))));
    vlSelf->wasmetal_core__DOT___055989_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f555500ff3333ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055645_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055647_))))))))))));
    vlSelf->wasmetal_core__DOT___055870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055339_))));
    vlSelf->wasmetal_core__DOT___054717_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054685_))));
    vlSelf->wasmetal_core__DOT___055089_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3265141f__0)))));
    vlSelf->wasmetal_core__DOT___054727_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff3355fffff0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hebcfe313__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff3355fffff0f0ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h284fdec6__0))))))))))));
    vlSelf->wasmetal_core__DOT___054713_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc63c8631__0)))));
    vlSelf->wasmetal_core__DOT___054714_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84d44246__0)))));
    vlSelf->wasmetal_core__DOT___054720_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0)))));
    vlSelf->wasmetal_core__DOT___054721_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69457925__0)))));
    vlSelf->wasmetal_core__DOT___054757_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))));
    vlSelf->wasmetal_core__DOT___054758_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0)))));
    vlSelf->wasmetal_core__DOT___054759_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0)))));
    vlSelf->wasmetal_core__DOT___054760_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))));
    vlSelf->wasmetal_core__DOT___054761_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))));
    vlSelf->wasmetal_core__DOT___054762_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))));
    vlSelf->wasmetal_core__DOT___054828_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h03e9ae47__0)))));
    vlSelf->wasmetal_core__DOT___054829_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0)))));
    vlSelf->wasmetal_core__DOT___054830_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))));
    vlSelf->wasmetal_core__DOT___054832_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))));
    vlSelf->wasmetal_core__DOT___054833_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))));
    vlSelf->wasmetal_core__DOT___054834_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0)))));
    vlSelf->wasmetal_core__DOT___054835_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))));
    vlSelf->wasmetal_core__DOT___054873_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h64194573__0)))));
    vlSelf->wasmetal_core__DOT___054875_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2596a796__0)))));
    vlSelf->wasmetal_core__DOT___054876_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0)))));
    vlSelf->wasmetal_core__DOT___054877_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))));
    vlSelf->wasmetal_core__DOT___054878_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))));
    vlSelf->wasmetal_core__DOT___054879_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2577a83c__0)))));
    vlSelf->wasmetal_core__DOT___054880_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))));
    vlSelf->wasmetal_core__DOT___054896_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h413b142d__0)))));
    vlSelf->wasmetal_core__DOT___054914_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h169cd931__0)))));
    vlSelf->wasmetal_core__DOT___054915_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0)))));
    vlSelf->wasmetal_core__DOT___054916_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))));
    vlSelf->wasmetal_core__DOT___054917_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))));
    vlSelf->wasmetal_core__DOT___054937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h584cbf3b__0)))));
    vlSelf->wasmetal_core__DOT___054938_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0)))));
    vlSelf->wasmetal_core__DOT___054934_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h744f9b35__0)))));
    vlSelf->wasmetal_core__DOT___054940_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))));
    vlSelf->wasmetal_core__DOT___054941_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0)))));
    vlSelf->wasmetal_core__DOT___054942_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))));
    vlSelf->wasmetal_core__DOT___054943_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))));
    vlSelf->wasmetal_core__DOT___054976_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0)))));
    vlSelf->wasmetal_core__DOT___054977_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf0027c26__0)))));
    vlSelf->wasmetal_core__DOT___054978_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7102b895__0)))));
    vlSelf->wasmetal_core__DOT___054979_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))));
    vlSelf->wasmetal_core__DOT___054980_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))));
    vlSelf->wasmetal_core__DOT___054981_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb79381c2__0)))));
    vlSelf->wasmetal_core__DOT___054982_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))));
    vlSelf->__VdfgTmp_h2ba92b9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6deef1cd__0)));
    vlSelf->wasmetal_core__DOT___055017_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69142c13__0)))));
    vlSelf->wasmetal_core__DOT___055019_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))));
    vlSelf->wasmetal_core__DOT___055020_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))));
    vlSelf->wasmetal_core__DOT___055021_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))));
    vlSelf->wasmetal_core__DOT___055022_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))));
    vlSelf->wasmetal_core__DOT___055027_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8562240__0)))));
    vlSelf->wasmetal_core__DOT___055028_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0)))));
    vlSelf->wasmetal_core__DOT___035269_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128506___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___033032_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008810_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128726___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___063834_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030093_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030221_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___064470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064469_))));
    vlSelf->wasmetal_core__DOT___064015_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063728_))));
    vlSelf->wasmetal_core__DOT___065075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064734_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065074_)))));
    vlSelf->wasmetal_core__DOT___064735_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064734_)))));
    vlSelf->wasmetal_core__DOT___064902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064469_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064901_)))));
    vlSelf->wasmetal_core__DOT___064768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))));
    vlSelf->wasmetal_core__DOT___064523_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___065200_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065199_)))));
    vlSelf->wasmetal_core__DOT___065620_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065307_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065619_)))));
    vlSelf->wasmetal_core__DOT___065308_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065307_)))));
    vlSelf->wasmetal_core__DOT___042178_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___042097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063948_))));
    vlSelf->wasmetal_core__DOT___063988_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063984_)))));
    vlSelf->wasmetal_core__DOT___065425_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065199_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065424_)))));
    vlSelf->__VdfgTmp_h0791be06__0 = (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))));
    vlSelf->wasmetal_core__DOT___001859_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001340_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x33550f0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hf4328824__0)))))))))));
    vlSelf->wasmetal_core__DOT___064503_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064502_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064501_)))));
    vlSelf->wasmetal_core__DOT___064756_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063990_)))));
    vlSelf->wasmetal_core__DOT___065708_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065424_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065707_)))));
    vlSelf->wasmetal_core__DOT___001343_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001341_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001339_))))));
    vlSelf->wasmetal_core__DOT___064928_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064501_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064506_)))));
    vlSelf->wasmetal_core__DOT___065810_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065619_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065809_)))));
    vlSelf->wasmetal_core__DOT___001727_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001725_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001723_))))));
    vlSelf->wasmetal_core__DOT___063994_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063989_)))));
    vlSelf->wasmetal_core__DOT___065906_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065707_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065905_)))));
    vlSelf->wasmetal_core__DOT___001344_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001340_))))));
    vlSelf->wasmetal_core__DOT___064510_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064505_)))));
    vlSelf->wasmetal_core__DOT___065930_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065929_)))));
    vlSelf->wasmetal_core__DOT___001728_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001724_))))));
    vlSelf->wasmetal_core__DOT___064758_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063992_)))));
    vlSelf->wasmetal_core__DOT___066075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065905_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066074_)))));
    vlSelf->wasmetal_core__DOT___001770_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001341_))))));
    vlSelf->wasmetal_core__DOT___064926_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064508_)))));
    vlSelf->wasmetal_core__DOT___066132_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065929_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066131_)))));
    vlSelf->wasmetal_core__DOT___002225_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001725_))))));
    vlSelf->wasmetal_core__DOT___063993_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063992_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063991_)))));
    vlSelf->wasmetal_core__DOT___066267_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066266_)))));
    vlSelf->wasmetal_core__DOT___069097_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x8000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8926b37c__0))))));
    vlSelf->wasmetal_core__DOT___019400_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8926b37c__0))));
    vlSelf->__VdfgTmp_h563f0a85__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072045_))))));
    vlSelf->__VdfgTmp_h4ea6bbba__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d)))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072034_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0))))))))));
    vlSelf->__VdfgTmp_h982d8c02__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h3a315b1c__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96696996U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0x96U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdbb03d5c__0)) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hab155f14__0))))))));
    vlSelf->wasmetal_core__DOT___063894_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063891_))));
    vlSelf->wasmetal_core__DOT___002460_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001342_))))));
    vlSelf->wasmetal_core__DOT___002142_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001729_))))));
    vlSelf->wasmetal_core__DOT___002106_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001496_))))));
    vlSelf->wasmetal_core__DOT___066652_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066529_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066651_)))));
    vlSelf->wasmetal_core__DOT___064497_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064493_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064492_)))));
    vlSelf->wasmetal_core__DOT___066774_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066773_)))));
    vlSelf->wasmetal_core__DOT___064753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063976_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063979_)))));
    vlSelf->wasmetal_core__DOT___066861_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066860_)))));
    vlSelf->wasmetal_core__DOT___064922_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064495_)))));
    vlSelf->__VdfgTmp_h2135b46c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_))));
    vlSelf->wasmetal_core__DOT___066898_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066773_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066897_)))));
    vlSelf->wasmetal_core__DOT___063980_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063978_)))));
    vlSelf->wasmetal_core__DOT___001896_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001498_))))));
    vlSelf->wasmetal_core__DOT___066980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066979_)))));
    vlSelf->wasmetal_core__DOT___064496_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064494_)))));
    vlSelf->wasmetal_core__DOT___048770_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001731_)))))))));
    vlSelf->wasmetal_core__DOT___000183_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000176_))))));
    vlSelf->wasmetal_core__DOT___067084_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066897_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067083_)))));
    vlSelf->wasmetal_core__DOT___064752_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063978_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063973_)))));
    vlSelf->wasmetal_core__DOT___048786_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001498_)))))))));
    vlSelf->wasmetal_core__DOT___001658_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001654_))))));
    vlSelf->wasmetal_core__DOT___067162_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067161_)))));
    vlSelf->wasmetal_core__DOT___064921_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064489_)))));
    vlSelf->wasmetal_core__DOT___048778_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000176_)))))))));
    vlSelf->wasmetal_core__DOT___000184_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000177_))))));
    vlSelf->wasmetal_core__DOT___067203_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067083_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067202_)))));
    vlSelf->wasmetal_core__DOT___063974_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063973_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063972_)))));
    vlSelf->wasmetal_core__DOT___042104_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7da480c4__0))));
    vlSelf->wasmetal_core__DOT___042185_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0))))));
    vlSelf->__VdfgTmp_h4598addd__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2e3bd00c__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf0c7a5d6__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)))));
    vlSelf->wasmetal_core__DOT___048831_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001654_)))))))));
    vlSelf->wasmetal_core__DOT___001659_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001655_))))));
    vlSelf->wasmetal_core__DOT___064490_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064489_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064488_)))));
    vlSelf->wasmetal_core__DOT___048815_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000178_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000177_)))))))));
    vlSelf->__VdfgTmp_h8c923865__0 = (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000179_));
    vlSelf->wasmetal_core__DOT___001734_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000178_))))));
    vlSelf->wasmetal_core__DOT___064750_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063972_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___048828_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001656_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001655_)))))))));
    vlSelf->wasmetal_core__DOT___001853_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001657_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001656_)))))))));
    vlSelf->__VdfgTmp_h8bf08b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001657_));
    vlSelf->wasmetal_core__DOT___001773_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001660_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001656_))))));
    vlSelf->__VdfgTmp_hf20b3c9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001660_));
    vlSelf->wasmetal_core__DOT___064919_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064488_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___064491_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___048735_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000572_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000179_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000178_)))))))));
    vlSelf->wasmetal_core__DOT___001720_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000573_)))))))));
    vlSelf->__VdfgTmp_h436041ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000572_));
    vlSelf->wasmetal_core__DOT___002144_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000573_))))));
    vlSelf->wasmetal_core__DOT___065420_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___064524_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064522_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e505808__0))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h00f9b844__0 = (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2e505808__0))));
    vlSelf->wasmetal_core__DOT___064751_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063971_))));
    vlSelf->wasmetal_core__DOT___063975_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063971_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___042295_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042317_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042083_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___042116_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___063967_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042167_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___042176_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042172_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___042171_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___042170_))))))))))));
    vlSelf->__VdfgTmp_h868ae0cf__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4a43881d__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0))))))))));
    vlSelf->wasmetal_core__DOT___063923_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063915_))));
    vlSelf->wasmetal_core__DOT___063924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063921_))));
    vlSelf->wasmetal_core__DOT___042153_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042208_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042387_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___042354_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___064770_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064538_))));
    vlSelf->wasmetal_core__DOT___001312_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))))));
    vlSelf->wasmetal_core__DOT___001781_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had66fb55__0)))));
    vlSelf->wasmetal_core__DOT___001930_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))));
    vlSelf->wasmetal_core__DOT___063909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063901_))));
    vlSelf->wasmetal_core__DOT___001850_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))));
    vlSelf->wasmetal_core__DOT___000924_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000920_))))));
    vlSelf->wasmetal_core__DOT___001314_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))))));
    vlSelf->wasmetal_core__DOT___001784_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78a92bf8__0)))));
    vlSelf->__VdfgTmp_hf5f2577b__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)))));
    vlSelf->wasmetal_core__DOT___002851_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000920_)))))))));
    vlSelf->__VdfgTmp_he7245d4a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000922_));
    vlSelf->wasmetal_core__DOT___002770_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001707_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001708_)))))))));
    vlSelf->wasmetal_core__DOT___064541_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hab155f14__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x4fff00ff00000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h101b2914__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h75b63843__0))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h61f75715__0 = (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h75b63843__0))));
    vlSelf->wasmetal_core__DOT___001316_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))))));
    vlSelf->wasmetal_core__DOT___001786_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8eb0ad88__0)))));
    if (vlSelf->wasmetal_core__DOT___000181_) {
        vlSelf->wasmetal_core__DOT___002601_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001710_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001709_)))));
        vlSelf->wasmetal_core__DOT___002068_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca6242ab__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___002601_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001711_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___001708_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001707_)))));
        vlSelf->wasmetal_core__DOT___002068_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001846_));
    }
    vlSelf->__VdfgTmp_h29c4951c__0 = (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001712_));
    vlSelf->__VdfgTmp_hd0a40acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001711_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001709_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001710_))))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___002234_))))));
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000721_));
        vlSelf->wasmetal_core__DOT___002288_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001289_));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000722_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002147_;
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002111_;
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002148_;
    } else {
        vlSelf->wasmetal_core__DOT___002853_ = (1U 
                                                & (0xc0005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002233_)))))));
        vlSelf->wasmetal_core__DOT___002271_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000574_))))));
        vlSelf->wasmetal_core__DOT___002288_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001662_))))));
        vlSelf->wasmetal_core__DOT___000167_ = vlSelf->wasmetal_core__DOT___000721_;
        vlSelf->wasmetal_core__DOT___002852_ = vlSelf->wasmetal_core__DOT___002387_;
        vlSelf->wasmetal_core__DOT___002729_ = vlSelf->wasmetal_core__DOT___002110_;
        vlSelf->wasmetal_core__DOT___002769_ = vlSelf->wasmetal_core__DOT___002147_;
    }
    vlSelf->__VdfgTmp_h47d0b828__0 = (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002233_));
    vlSelf->wasmetal_core__DOT___064925_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064507_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064493_)))));
    vlSelf->wasmetal_core__DOT___064509_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064507_)))));
    vlSelf->wasmetal_core__DOT___066324_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066131_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066323_)))));
    vlSelf->wasmetal_core__DOT___066530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066323_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066529_)))));
    vlSelf->wasmetal_core__DOT___066611_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066403_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066610_)))));
    vlSelf->wasmetal_core__DOT___066404_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066266_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066403_)))));
    vlSelf->wasmetal_core__DOT___064757_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063977_)))));
    vlSelf->wasmetal_core__DOT___063981_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063976_)))));
    vlSelf->wasmetal_core__DOT___002382_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001726_))))));
    vlSelf->wasmetal_core__DOT___002143_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001730_))))));
    vlSelf->wasmetal_core__DOT___063880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063877_))));
    vlSelf->wasmetal_core__DOT___048742_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001655_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_)))))))));
    vlSelf->wasmetal_core__DOT___002105_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001495_))))));
    vlSelf->__VdfgTmp_h8fa00ac2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001497_))));
    vlSelf->__VdfgTmp_h2b3c1bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0));
    vlSelf->__VdfgTmp_h4408f503__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hec35f81b__0));
    vlSelf->wasmetal_core__DOT___048829_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0643d6d2__0))));
    vlSelf->wasmetal_core__DOT___069246_ = (1U & (IData)(
                                                         (0xcc00f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000169_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048922_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048923_)))))))));
    vlSelf->__VdfgTmp_h7357dd51__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002231_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001705_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))))))));
    vlSelf->__VdfgTmp_h95b0aa6a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002387_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002231_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000922_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000921_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000822_))))))))));
    vlSelf->__VdfgTmp_hd61aa5bc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001705_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___000722_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___000820_))))))))));
    vlSelf->__VdfgTmp_hb54a817c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001290_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001289_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))))))));
    vlSelf->__VdfgTmp_h471ef662__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001286_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002181_))));
    vlSelf->__VdfgTmp_h162766a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000719_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002385_))));
    vlSelf->wasmetal_core__DOT___069133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___069084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___069033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068935_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068891_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068789_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068696_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068648_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068340_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068233_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068148_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068072_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___068024_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067901_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067814_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067729_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067663_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___067591_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063836_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063837_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___063861_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O))))));
    vlSelf->wasmetal_core__DOT___063832_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063830_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063828_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                       >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063826_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O))))))));
    vlSelf->wasmetal_core__DOT___010424_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010423_))));
    vlSelf->wasmetal_core__DOT___055217_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x10U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055244_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055247_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055250_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x16U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055253_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x17U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055256_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x18U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055259_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x19U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055262_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1aU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055265_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1bU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055268_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1cU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054752_))));
    vlSelf->wasmetal_core__DOT___055867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054752_))));
    vlSelf->wasmetal_core__DOT___055113_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 7U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055157_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xbU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055179_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xcU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055198_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___055203_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xfU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___007883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007873_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007895_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007908_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007932_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007971_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007984_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008000_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008008_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008041_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008049_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008057_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008078_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008086_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008108_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008116_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008153_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008161_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008191_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008199_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008228_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008236_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008258_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008266_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008295_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008303_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008311_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008319_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008342_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008350_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008379_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008387_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008409_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008417_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
}
